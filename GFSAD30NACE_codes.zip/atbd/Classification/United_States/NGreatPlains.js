/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var Cropclass = /* color: #d63000 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-112.84812927246094, 48.802389708056715]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.47390747070312, 48.883279745637154]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.92366027832031, 48.940591783794225]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.40798950195312, 48.706871077633664]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.445068359375, 48.633411232166274]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.76641845703125, 48.743560844228675]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.13333129882812, 48.6574561789211]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8353271484375, 49.096849399335085]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.47003173828125, 49.098198191140014]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.07221984863281, 49.06176794679168]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.2200927734375, 49.051418685119835]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.72055799886584, 48.83313427304379]),
            {
              "class": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.88054656982422, 48.748064215715885]),
            {
              "class": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.77411643229425, 48.703221546234424]),
            {
              "class": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.80501548014581, 48.604563117583055]),
            {
              "class": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.09855643473566, 48.52799844618419]),
            {
              "class": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.76896667480469, 48.47317339219709]),
            {
              "class": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.0721206665039, 48.349657166273865]),
            {
              "class": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.18644714355469, 48.31268079239889]),
            {
              "class": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.25991821289062, 48.30925569777241]),
            {
              "class": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.35948181152344, 48.251451126194965]),
            {
              "class": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.40308375936002, 48.210971910512576]),
            {
              "class": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.68975821696222, 47.890663561718554]),
            {
              "class": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.25305167399347, 47.77081378676538]),
            {
              "class": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.99600217631087, 48.00809524354601]),
            {
              "class": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.23838804056868, 48.138166037366865]),
            {
              "class": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.45262145996094, 48.20731116378069]),
            {
              "class": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.35855102604546, 48.3051453086345]),
            {
              "class": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.21710205078125, 48.42125109382807]),
            {
              "class": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.5054931640625, 48.32888980156284]),
            {
              "class": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.48729705810547, 48.247564679234515]),
            {
              "class": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.54154205322266, 48.30971239033872]),
            {
              "class": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.32421873952262, 48.2304150636995]),
            {
              "class": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.05848692799918, 48.227899303319134]),
            {
              "class": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.58607482910156, 48.630234572010984]),
            {
              "class": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.34986877441406, 48.655188222083616]),
            {
              "class": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.236572265625, 48.691462403273576]),
            {
              "class": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.04612731933594, 47.55083595114118]),
            {
              "class": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8851089477539, 47.64251706903726]),
            {
              "class": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.73542022705078, 47.62169455682993]),
            {
              "class": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8404769897461, 47.68621734070485]),
            {
              "class": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.22637176513672, 47.517457531165014]),
            {
              "class": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88579559326172, 47.57516098895805]),
            {
              "class": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.35889434814453, 47.64297969729851]),
            {
              "class": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.24800109863281, 47.62030609435432]),
            {
              "class": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.12371826171875, 47.70377962378233]),
            {
              "class": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.5168228149414, 47.51142860760034]),
            {
              "class": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.15805053710938, 47.60154575128312]),
            {
              "class": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.17229843139648, 47.57028441540011]),
            {
              "class": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.2164153214544, 47.94813562073794]),
            {
              "class": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.47253409586847, 47.961011699193854]),
            {
              "class": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.46807098388672, 48.05630794838534]),
            {
              "class": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.27031707763672, 48.09782651688743]),
            {
              "class": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.1539306640625, 48.06846878826242]),
            {
              "class": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.10002899169922, 47.992933362527985]),
            {
              "class": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.89300537109375, 47.9511002390484]),
            {
              "class": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.08457946777344, 47.836460523624304]),
            {
              "class": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.11307525634766, 47.77489253295927]),
            {
              "class": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88545218668878, 47.75989302467463]),
            {
              "class": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.77902213297784, 47.77420034317595]),
            {
              "class": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.04524222575128, 48.47362861597093]),
            {
              "class": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.16609191894531, 48.5052566627974]),
            {
              "class": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.38616172038019, 48.49638454186656]),
            {
              "class": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.5392837524414, 48.476587470947635]),
            {
              "class": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.6106948852539, 48.57299702712423]),
            {
              "class": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.51868438720703, 48.744441995637025]),
            {
              "class": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.42907706461847, 48.84418241182897]),
            {
              "class": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.37277221679688, 48.9107914862123]),
            {
              "class": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.35114288330078, 48.99308336289853]),
            {
              "class": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.62992095947266, 48.96829736018096]),
            {
              "class": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.26408386230469, 48.4109969877199]),
            {
              "class": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.45771789550781, 48.42535213772693]),
            {
              "class": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.02238464355469, 48.35467658135566]),
            {
              "class": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.59882354736328, 48.434236655643794]),
            {
              "class": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.76602172851562, 48.514582003819704]),
            {
              "class": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.03793334960938, 48.56459127408449]),
            {
              "class": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.89339447021484, 48.61545903427912]),
            {
              "class": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.7093734741211, 48.64813271297672]),
            {
              "class": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.41548919677734, 48.73130950796342]),
            {
              "class": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.32759857177734, 48.793997759719886]),
            {
              "class": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.49411006551236, 48.88280390116157]),
            {
              "class": 1,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.7368392944336, 48.967621205615316]),
            {
              "class": 1,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.98815155029297, 48.90785803229914]),
            {
              "class": 1,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1598129272461, 48.89454253816268]),
            {
              "class": 1,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.46708679199219, 48.82700773131775]),
            {
              "class": 1,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.58690643310547, 48.79919940087454]),
            {
              "class": 1,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93949891184457, 48.715103348072574]),
            {
              "class": 1,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.80508805369027, 48.7042289446125]),
            {
              "class": 1,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.03322602366097, 48.68258642325862]),
            {
              "class": 1,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.88491059397347, 48.67635255835124]),
            {
              "class": 1,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.86808778950945, 48.97888924447353]),
            {
              "class": 1,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.10978700825945, 48.99038002744043]),
            {
              "class": 1,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.68235017964616, 48.97979057811003]),
            {
              "class": 1,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.69024658726994, 48.90515007529769]),
            {
              "class": 1,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.87220764684025, 48.819548466587385]),
            {
              "class": 1,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.69470977783203, 48.78042569271142]),
            {
              "class": 1,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.55291748046875, 48.744894808151756]),
            {
              "class": 1,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.32539366628043, 48.09555817974867]),
            {
              "class": 1,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.28625487233512, 47.954114142913475]),
            {
              "class": 1,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.63438414479606, 48.10060257455954]),
            {
              "class": 1,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.02601619344205, 48.202301912822136]),
            {
              "class": 1,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.3638457832858, 48.26679005725536]),
            {
              "class": 1,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.82276916503906, 47.943536131391646]),
            {
              "class": 1,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.17913818359375, 47.77999303635534]),
            {
              "class": 1,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.13931274414062, 47.55943386432964]),
            {
              "class": 1,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.775146484375, 47.670523483587715]),
            {
              "class": 1,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.93582153320312, 47.80582577304197]),
            {
              "class": 1,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.94406127929688, 47.951814827705405]),
            {
              "class": 1,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.89942932128906, 48.09647543523636]),
            {
              "class": 1,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.17958068847656, 47.96055189449862]),
            {
              "class": 1,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.57371520996094, 48.05656207551024]),
            {
              "class": 1,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.20841979980469, 48.17437754085814]),
            {
              "class": 1,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.06903076171875, 48.18582377275853]),
            {
              "class": 1,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06269836425781, 45.968862240860986]),
            {
              "class": 1,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.89378356933594, 46.086618154266844]),
            {
              "class": 1,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.23779296875, 45.827415258168614]),
            {
              "class": 1,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.04621887207031, 46.29718759638023]),
            {
              "class": 1,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.07437133789062, 46.36024852878409]),
            {
              "class": 1,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.36894226074219, 46.25684741582015]),
            {
              "class": 1,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.83311462402344, 46.25542310216669]),
            {
              "class": 1,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.92375183105469, 46.339868360645134]),
            {
              "class": 1,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02468872070312, 46.24070308613423]),
            {
              "class": 1,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09541320800781, 46.31995487152027]),
            {
              "class": 1,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.63742065429688, 46.29054537418622]),
            {
              "class": 1,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.14784242818132, 46.320903242177515]),
            {
              "class": 1,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.78941345214844, 46.463927326859285]),
            {
              "class": 1,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.54084777832031, 46.64383033403504]),
            {
              "class": 1,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.216064453125, 46.78083493881298]),
            {
              "class": 1,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.062255859375, 46.79164865038574]),
            {
              "class": 1,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.39115905761719, 46.66551059011803]),
            {
              "class": 1,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.06088256835938, 46.517346626426836]),
            {
              "class": 1,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.97299194335938, 46.64995826465109]),
            {
              "class": 1,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.95651245117188, 46.82689566254178]),
            {
              "class": 1,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.81300354003906, 46.970932690326315]),
            {
              "class": 1,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.94621276855469, 47.03742481466569]),
            {
              "class": 1,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.04852294921875, 47.10383419198636]),
            {
              "class": 1,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.24147033691406, 47.14541478480986]),
            {
              "class": 1,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.69328308105469, 47.20236009279427]),
            {
              "class": 1,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18997192382812, 47.220551041126946]),
            {
              "class": 1,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.83634948730469, 47.15662196522938]),
            {
              "class": 1,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.21719360351562, 46.7907084138757]),
            {
              "class": 1,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.30165101145394, 46.996228178063326]),
            {
              "class": 1,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.36344910715707, 46.75590811546296]),
            {
              "class": 1,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.4046478481032, 47.12205890177826]),
            {
              "class": 1,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.77362060546875, 47.27415469402649]),
            {
              "class": 1,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.37193298339844, 47.186496226375354]),
            {
              "class": 1,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.86518859863281, 47.39189180893538]),
            {
              "class": 1,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.04440307617188, 47.36631911220705]),
            {
              "class": 1,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.02655029296875, 47.570090189025365]),
            {
              "class": 1,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.79927062988281, 47.56870035656916]),
            {
              "class": 1,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.86106872558594, 47.56175064106445]),
            {
              "class": 1,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46075439453125, 47.48988291916795]),
            {
              "class": 1,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.43328857421875, 47.57333298799665]),
            {
              "class": 1,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.34402465820312, 47.56406731534881]),
            {
              "class": 1,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.41107173543423, 47.58491283029642]),
            {
              "class": 1,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.67131038289517, 47.5469215561631]),
            {
              "class": 1,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84709163289517, 47.550165789444314]),
            {
              "class": 1,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.63285823445767, 47.464357855949245]),
            {
              "class": 1,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.76194758992642, 47.360738023175784]),
            {
              "class": 1,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.51200862508267, 47.67930811949181]),
            {
              "class": 1,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.44265742879361, 47.797985083917204]),
            {
              "class": 1,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.0739287910983, 47.723670466234296]),
            {
              "class": 1,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.87205501180142, 47.79660131005065]),
            {
              "class": 1,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.38909907918423, 47.883707095465745]),
            {
              "class": 1,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.77156066894531, 47.833950269332824]),
            {
              "class": 1,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.89309692382812, 47.98813304491988]),
            {
              "class": 1,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.15838614664972, 47.954114199049215]),
            {
              "class": 1,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.66400138102472, 47.873575318543026]),
            {
              "class": 1,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.40925589762628, 47.876799280665594]),
            {
              "class": 1,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.45457458496094, 47.70796311910238]),
            {
              "class": 1,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.13803100585938, 47.88462806784694]),
            {
              "class": 1,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.98765563964844, 47.842246389881765]),
            {
              "class": 1,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.81118774414062, 48.02901767389226]),
            {
              "class": 1,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.21905500814319, 48.042791743785216]),
            {
              "class": 1,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.47105390951037, 48.10656354993432]),
            {
              "class": 1,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.42161560058594, 48.21374202082817]),
            {
              "class": 1,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.4635009765625, 48.34397739310956]),
            {
              "class": 1,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.92791731283069, 48.30654007098095]),
            {
              "class": 1,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.86680586263537, 48.45111465321012]),
            {
              "class": 1,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.15725691244006, 48.46796253393762]),
            {
              "class": 1,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46624739095569, 48.419680694566324]),
            {
              "class": 1,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.47198452800512, 48.47392974380831]),
            {
              "class": 1,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91168212890625, 47.98542497358732]),
            {
              "class": 1,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.50357055664062, 47.789270229836035]),
            {
              "class": 1,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.41705322265625, 47.81233157003937]),
            {
              "class": 1,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.71780395507812, 47.95968177924799]),
            {
              "class": 1,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.14764404296875, 47.961521004451406]),
            {
              "class": 1,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.47949151694775, 48.61676496247369]),
            {
              "class": 1,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.31469659507275, 48.98762106014392]),
            {
              "class": 1,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.69946222007275, 48.8161018520362]),
            {
              "class": 1,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.77661065757275, 48.86671606306692]),
            {
              "class": 1,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.208068177104, 48.61494918544581]),
            {
              "class": 1,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.1144402474165, 48.50224344268642]),
            {
              "class": 1,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.922179505229, 48.314451198568456]),
            {
              "class": 1,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09771711751819, 48.180329956288205]),
            {
              "class": 1,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09497053548694, 48.04554611590052]),
            {
              "class": 1,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.52618391439319, 48.216487127990206]),
            {
              "class": 1,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.64016706869006, 48.28232822815502]),
            {
              "class": 1,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.61363220214844, 48.276387720768156]),
            {
              "class": 1,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29159545898438, 48.32663174691869]),
            {
              "class": 1,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.06568875163794, 48.39643450985242]),
            {
              "class": 1,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.56968688964844, 48.430616451264484]),
            {
              "class": 1,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.82443237304688, 48.42697146047654]),
            {
              "class": 1,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.26663208007812, 48.36359811849643]),
            {
              "class": 1,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96862776204944, 48.57892747635792]),
            {
              "class": 1,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.14646911621094, 48.68919608739101]),
            {
              "class": 1,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.91644287109375, 48.83223029027272]),
            {
              "class": 1,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.63011169433594, 48.621157511823945]),
            {
              "class": 1,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.51176452636719, 48.70505854373432]),
            {
              "class": 1,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.29203796386719, 48.93247292646333]),
            {
              "class": 1,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.47811889648438, 48.945552835060106]),
            {
              "class": 1,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.08467085286975, 49.019907782822685]),
            {
              "class": 1,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.8402250520885, 49.06041827513986]),
            {
              "class": 1,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0819242708385, 49.09055466273274]),
            {
              "class": 1,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.49116499349475, 49.083359575175116]),
            {
              "class": 1,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.44197048991919, 48.92480380023175]),
            {
              "class": 1,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.26412930339575, 48.7820336712214]),
            {
              "class": 1,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.14121975749731, 48.82635400468193]),
            {
              "class": 1,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.71137966960669, 48.93427725556983]),
            {
              "class": 1,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.79377746582031, 49.12022315947843]),
            {
              "class": 1,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.21356201171875, 49.005045667772826]),
            {
              "class": 1,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.7892147526145, 49.04826859200232]),
            {
              "class": 1,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.90594448894262, 49.126963795126606]),
            {
              "class": 1,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.43490567058325, 48.980265395974214]),
            {
              "class": 1,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.17054715007544, 48.98747540960758]),
            {
              "class": 1,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.95082058757544, 48.97575860773051]),
            {
              "class": 1,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.33122219890356, 49.10673957836604]),
            {
              "class": 1,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.16780056804419, 49.03431507396018]),
            {
              "class": 1,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.24127197265625, 48.86792531839314]),
            {
              "class": 1,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.271484375, 48.75804830158298]),
            {
              "class": 1,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.97622680664062, 48.82906633248339]),
            {
              "class": 1,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65325927734375, 48.789272429859714]),
            {
              "class": 1,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.875732421875, 48.819120817510665]),
            {
              "class": 1,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.58689880371094, 49.01810655063122]),
            {
              "class": 1,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50999450683594, 48.86611859237254]),
            {
              "class": 1,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.22297668457031, 48.85618043320864]),
            {
              "class": 1,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.11860656738281, 49.095950294204634]),
            {
              "class": 1,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.86248779296875, 49.077063018289735]),
            {
              "class": 1,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.71073913574219, 49.06806655224619]),
            {
              "class": 1,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.59126281738281, 49.0167555837101]),
            {
              "class": 1,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.42303466796875, 48.97350528087845]),
            {
              "class": 1,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.76223754882812, 48.88102213122725]),
            {
              "class": 1,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60980224609375, 48.814599255641696]),
            {
              "class": 1,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.44775390625, 48.779771269067346]),
            {
              "class": 1,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.10855102539062, 48.78067641890851]),
            {
              "class": 1,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94650268554688, 48.783843541613045]),
            {
              "class": 1,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87165832519531, 48.873796727453275]),
            {
              "class": 1,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7061767578125, 49.005045667772826]),
            {
              "class": 1,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57159423828125, 49.105840762142314]),
            {
              "class": 1,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.90118408203125, 49.06041827513986]),
            {
              "class": 1,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.16897583007812, 48.98161757303024]),
            {
              "class": 1,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.60523986816406, 48.88734328295096]),
            {
              "class": 1,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.40542602539062, 48.79696212866862]),
            {
              "class": 1,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.74531488120556, 48.75080503979194]),
            {
              "class": 1,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.51048211753368, 48.65065216844145]),
            {
              "class": 1,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.18614196777344, 48.59346222533205]),
            {
              "class": 1,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.48345947265625, 48.53484358695269]),
            {
              "class": 1,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64344787597656, 48.68556968127019]),
            {
              "class": 1,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.85012817382812, 48.671514890878385]),
            {
              "class": 1,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28408813476562, 48.51074011155204]),
            {
              "class": 1,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.45437622070312, 48.449292925765825]),
            {
              "class": 1,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.56080627441406, 48.52574921425483]),
            {
              "class": 1,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.14994812011719, 48.456579443419834]),
            {
              "class": 1,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.919921875, 48.64566197716135]),
            {
              "class": 1,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.52853393554688, 48.678769465911834]),
            {
              "class": 1,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.94532775878906, 48.736315714906176]),
            {
              "class": 1,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.458251953125, 48.59573290225537]),
            {
              "class": 1,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.30238308757544, 48.45248090590464]),
            {
              "class": 1,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65119900554419, 48.551663554421815]),
            {
              "class": 1,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65531887859106, 48.362229364471645]),
            {
              "class": 1,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.59901394695044, 48.346259149590836]),
            {
              "class": 1,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.30169644206762, 48.26724712972801]),
            {
              "class": 1,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.88764920085669, 48.346259149590836]),
            {
              "class": 1,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.14239468425512, 48.348084570357706]),
            {
              "class": 1,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.53608703613281, 48.29512082094983]),
            {
              "class": 1,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.36305236816406, 48.264961726487336]),
            {
              "class": 1,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.15019226074219, 48.24758932208723]),
            {
              "class": 1,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.00736999511719, 48.38138701504879]),
            {
              "class": 1,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64276123046875, 48.37545814761913]),
            {
              "class": 1,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1923211067915, 48.41968080582256]),
            {
              "class": 1,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.97396850585938, 48.577564629320186]),
            {
              "class": 1,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.74806213378906, 48.68058294644568]),
            {
              "class": 1,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.27015686035156, 48.74265524635517]),
            {
              "class": 1,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90898132324219, 48.766648076910975]),
            {
              "class": 1,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.97627258300781, 48.64702298739334]),
            {
              "class": 1,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.61647033691406, 48.694635206927046]),
            {
              "class": 1,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.38919067382812, 48.842625217720816]),
            {
              "class": 1,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.85542297363281, 49.02080837447428]),
            {
              "class": 1,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.54231262207031, 49.02125866418907]),
            {
              "class": 1,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18388366699219, 48.995134906150234]),
            {
              "class": 1,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0142822265625, 49.04916845062124]),
            {
              "class": 1,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75541687011719, 49.05186880769088]),
            {
              "class": 1,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33724975585938, 48.920743197701675]),
            {
              "class": 1,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52264404296875, 48.89411551550751]),
            {
              "class": 1,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13262939453125, 48.920743197701675]),
            {
              "class": 1,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92182855308056, 49.00369412645194]),
            {
              "class": 1,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.45971612632275, 48.91216973036302]),
            {
              "class": 1,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14042596518993, 49.03611593932345]),
            {
              "class": 1,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60665826499462, 49.02486083524459]),
            {
              "class": 1,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.93443298339844, 48.97440671187122]),
            {
              "class": 1,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85821533203125, 48.87199021343521]),
            {
              "class": 1,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.27593994140625, 48.695995005654204]),
            {
              "class": 1,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9326171875, 48.67604923338758]),
            {
              "class": 1,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.78361511230469, 48.78474839710662]),
            {
              "class": 1,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.10221862792969, 48.78474839710662]),
            {
              "class": 1,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.68611145019531, 48.92435263847657]),
            {
              "class": 1,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.00608825683594, 49.070765663123744]),
            {
              "class": 1,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95252990722656, 49.002793445107336]),
            {
              "class": 1,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.18118286132812, 48.562570886901554]),
            {
              "class": 1,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.34117126464844, 48.53711678617122]),
            {
              "class": 1,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90240478515625, 48.446560212059104]),
            {
              "class": 1,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.58448791503906, 48.34489015252812]),
            {
              "class": 1,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17637634277344, 48.338043947021575]),
            {
              "class": 1,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.59317016601562, 48.18536602843584]),
            {
              "class": 1,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88362121582031, 48.103812554208744]),
            {
              "class": 1,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.71161651611328, 48.11275300381311]),
            {
              "class": 1,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.38031005859375, 48.01432127392049]),
            {
              "class": 1,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4053726196289, 48.08704872852861]),
            {
              "class": 1,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1444466561079, 48.24390666072034]),
            {
              "class": 1,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.00934982299805, 48.072815285616706]),
            {
              "class": 1,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.66722869873047, 48.11708342089568]),
            {
              "class": 1,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.88558197021484, 47.95960746347441]),
            {
              "class": 1,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.06925964355469, 47.94512131204253]),
            {
              "class": 1,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.23680114746094, 48.014985534583616]),
            {
              "class": 1,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.23302459716797, 47.86710202310911]),
            {
              "class": 1,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.39060974121094, 47.85604553495615]),
            {
              "class": 1,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91716766357422, 47.85696699903625]),
            {
              "class": 1,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.8498764038086, 47.8242449673761]),
            {
              "class": 1,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13277435302734, 47.764047153652626]),
            {
              "class": 1,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5317153930664, 47.73426847872454]),
            {
              "class": 1,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64913177490234, 47.62100033020152]),
            {
              "class": 1,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52725219726562, 47.50215198093836]),
            {
              "class": 1,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.44416809082031, 47.419053229006096]),
            {
              "class": 1,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2021255493164, 47.434150753899395]),
            {
              "class": 1,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.0260009765625, 47.45226206364848]),
            {
              "class": 1,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90549401938915, 47.5587138595604]),
            {
              "class": 1,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.46398095786572, 47.64251706903726]),
            {
              "class": 1,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.0455697029829, 47.286008285335704]),
            {
              "class": 1,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02291107177734, 47.191370720169225]),
            {
              "class": 1,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.11526489257812, 47.129742300418165]),
            {
              "class": 1,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1252212524414, 47.03154974057701]),
            {
              "class": 1,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.10599517822266, 46.97325009592403]),
            {
              "class": 1,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.92952728271484, 46.98472773911258]),
            {
              "class": 1,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.33979797363281, 46.90972720516483]),
            {
              "class": 1,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.492919921875, 47.03716564782498]),
            {
              "class": 1,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.67625427246094, 47.052606266963494]),
            {
              "class": 1,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81186642497778, 47.16803503238347]),
            {
              "class": 1,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94816555827856, 47.24080846021604]),
            {
              "class": 1,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14900936931372, 47.146090133816855]),
            {
              "class": 1,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01133694499731, 47.08908448183059]),
            {
              "class": 1,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20909118652344, 47.04535441154594]),
            {
              "class": 1,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31037139892578, 46.994329645299324]),
            {
              "class": 1,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.27329220622778, 46.896825962159035]),
            {
              "class": 1,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01854672282934, 46.823816557448964]),
            {
              "class": 1,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20909085124731, 46.444979835628615]),
            {
              "class": 1,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00378384441137, 46.43315021018212]),
            {
              "class": 1,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.90868377685547, 46.43740917121037]),
            {
              "class": 1,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.80328369140625, 46.46839491716848]),
            {
              "class": 1,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.63162231445312, 46.458698983627485]),
            {
              "class": 1,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.76448822021484, 46.57658818122167]),
            {
              "class": 1,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9437026977539, 46.61056076758578]),
            {
              "class": 1,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78234100341797, 46.39385743548155]),
            {
              "class": 1,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64741516113281, 46.31921801038337]),
            {
              "class": 1,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.50218963623047, 46.2900454142889]),
            {
              "class": 1,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.56089782714844, 46.19910753608674]),
            {
              "class": 1,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.69445037841797, 46.13324394332423]),
            {
              "class": 1,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01580014079809, 46.20623610243483]),
            {
              "class": 1,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22213711589575, 46.2266660335074]),
            {
              "class": 1,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.7452621459961, 46.24851289404068]),
            {
              "class": 1,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96155548095703, 46.35690589133678]),
            {
              "class": 1,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09579467773438, 46.35809062355858]),
            {
              "class": 1,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42195095866919, 45.9619159534915]),
            {
              "class": 1,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.18883480876684, 45.93637386273091]),
            {
              "class": 1,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.57747616618872, 45.95976800670213]),
            {
              "class": 1,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73128509521484, 45.967166139528345]),
            {
              "class": 1,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95753479003906, 46.07111264263497]),
            {
              "class": 1,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88681030273438, 46.14109470442274]),
            {
              "class": 1,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1247329711914, 46.10540067161436]),
            {
              "class": 1,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.05503845214844, 46.24162732241575]),
            {
              "class": 1,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30223083496094, 46.251124436507304]),
            {
              "class": 1,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22669982910156, 46.35311454668691]),
            {
              "class": 1,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45809936523438, 46.36282926666033]),
            {
              "class": 1,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57242584228516, 46.22381577274736]),
            {
              "class": 1,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45809902995825, 46.15607930212338]),
            {
              "class": 1,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.07769775390625, 46.06968351221457]),
            {
              "class": 1,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38600158691406, 45.954755748755076]),
            {
              "class": 1,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85635375976562, 46.34887454613087]),
            {
              "class": 1,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74031066894531, 46.26918997577604]),
            {
              "class": 1,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85772705078125, 46.6108220352239]),
            {
              "class": 1,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.88038635253906, 46.72720448796254]),
            {
              "class": 1,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72657775878906, 46.76907839752879]),
            {
              "class": 1,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96141052246094, 46.955468450485036]),
            {
              "class": 1,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.02887344360352, 46.989399219012455]),
            {
              "class": 1,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07453536987305, 47.013983723343046]),
            {
              "class": 1,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56085205078125, 47.69964554778434]),
            {
              "class": 1,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.34867858886719, 47.790143211381206]),
            {
              "class": 1,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47261793538928, 47.91301786265838]),
            {
              "class": 1,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.35880644246936, 47.92279681876338]),
            {
              "class": 1,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.58402633666992, 47.94660372715352]),
            {
              "class": 1,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.62865829467773, 47.99797544881695]),
            {
              "class": 1,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.48772430419922, 48.03173570098085]),
            {
              "class": 1,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56153869628906, 48.06122910985434]),
            {
              "class": 1,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.01104736328125, 47.33515014881751]),
            {
              "class": 1,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1181640625, 47.23360735069865]),
            {
              "class": 1,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02066040039062, 47.473176959240575]),
            {
              "class": 1,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70343017578125, 47.281608284344244]),
            {
              "class": 1,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43907165527344, 47.24106666233981]),
            {
              "class": 1,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.11404418945312, 47.09962759271168]),
            {
              "class": 1,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.38070678710938, 47.087940876913834]),
            {
              "class": 1,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92178344726562, 46.97327537524879]),
            {
              "class": 1,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.21772766113281, 46.91514668053888]),
            {
              "class": 1,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.32690362632275, 46.99622815841167]),
            {
              "class": 1,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5191650390625, 46.95828046424618]),
            {
              "class": 1,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.71279907226562, 46.938124433491886]),
            {
              "class": 1,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.04444885253906, 47.000442938278205]),
            {
              "class": 1,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0063398592174, 46.90173965165501]),
            {
              "class": 1,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92085266113281, 46.89399809067236]),
            {
              "class": 1,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8381118774414, 46.86971049009682]),
            {
              "class": 1,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75444030761719, 46.43317562814604]),
            {
              "class": 1,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.96043395996094, 46.43317562814604]),
            {
              "class": 1,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35755920410156, 46.44216637351961]),
            {
              "class": 1,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26417541503906, 46.5806253203753]),
            {
              "class": 1,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.66448974609375, 46.578737470591534]),
            {
              "class": 1,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.00643920898438, 46.59997199089071]),
            {
              "class": 1,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.07991027832031, 46.37825258490919]),
            {
              "class": 1,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.62672424316406, 46.315212424300114]),
            {
              "class": 1,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38777160644531, 46.308098069653035]),
            {
              "class": 1,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0849609375, 46.30477772100206]),
            {
              "class": 1,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.74369812011719, 46.37304149474974]),
            {
              "class": 1,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55143737792969, 46.37541023374067]),
            {
              "class": 1,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.62834167480469, 46.692834111965965]),
            {
              "class": 1,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.96067810058594, 46.66126946166248]),
            {
              "class": 1,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.86273193359375, 46.88230422061239]),
            {
              "class": 1,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.00001525878906, 46.77472186569618]),
            {
              "class": 1,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.06661987304688, 46.89732038404178]),
            {
              "class": 1,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.94920349121094, 46.96484122641075]),
            {
              "class": 1,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.86543273925781, 46.767197148335704]),
            {
              "class": 1,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.89839172363281, 46.66551056135737]),
            {
              "class": 1,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.447021484375, 46.51923655492233]),
            {
              "class": 1,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.61961364746094, 46.632515489430695]),
            {
              "class": 1,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.22135925292969, 46.60940694280149]),
            {
              "class": 1,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.12797546386719, 46.999506348467634]),
            {
              "class": 1,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29757690429688, 47.116451956363285]),
            {
              "class": 1,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.77160577476025, 46.99622817984986]),
            {
              "class": 1,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.47360162436962, 47.04210423939221]),
            {
              "class": 1,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.23945617675781, 47.00512559104809]),
            {
              "class": 1,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.51205444335938, 46.694247023243996]),
            {
              "class": 1,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.18177795410156, 46.76343439541996]),
            {
              "class": 1,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0572509765625, 46.79211874813452]),
            {
              "class": 1,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.05317620933056, 45.903440069766745]),
            {
              "class": 1,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.51896600425243, 45.97792929440555]),
            {
              "class": 1,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.17814569175243, 46.066612582586096]),
            {
              "class": 1,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.36216668784618, 45.980792266067006]),
            {
              "class": 1,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8190300911665, 46.108044647102005]),
            {
              "class": 1,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.34593133628368, 46.02228872013455]),
            {
              "class": 1,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.78263787925243, 45.897705984206134]),
            {
              "class": 1,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.52171258628368, 45.906784679534844]),
            {
              "class": 1,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.80049066245556, 46.04945917702983]),
            {
              "class": 1,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.05454950034618, 46.221228504926714]),
            {
              "class": 1,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.176085755229, 46.37825261382234]),
            {
              "class": 1,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.64942865073681, 46.315212453246616]),
            {
              "class": 1,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.79843072593212, 46.18273407830907]),
            {
              "class": 1,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.49400262534618, 46.279156862239766]),
            {
              "class": 1,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.16304016113281, 46.52207145417901]),
            {
              "class": 1,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.34225463867188, 46.512621358966555]),
            {
              "class": 1,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.86503601074219, 46.51829161331091]),
            {
              "class": 1,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.45922784507275, 46.562216027928564]),
            {
              "class": 1,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.66384820640087, 46.78788760579132]),
            {
              "class": 1,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84580926597118, 46.84145768115117]),
            {
              "class": 1,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.77268185466528, 46.71423397270867]),
            {
              "class": 1,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89696502685547, 46.81770838030787]),
            {
              "class": 1,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.09231567382812, 46.919342575530095]),
            {
              "class": 1,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.27942657470703, 46.9261426089492]),
            {
              "class": 1,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.24663925170898, 47.030730737457006]),
            {
              "class": 1,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30453491210938, 48.0235070148927]),
            {
              "class": 1,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.48649597167969, 48.13864892633645]),
            {
              "class": 1,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01339721679688, 47.98169867484599]),
            {
              "class": 1,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9488525390625, 48.31658689798329]),
            {
              "class": 1,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5201016015625, 48.34899725622276]),
            {
              "class": 1,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00584411621094, 48.47752235722803]),
            {
              "class": 1,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.49748229980469, 48.61934189279006]),
            {
              "class": 1,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.65335083007812, 48.85618032291095]),
            {
              "class": 1,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.13973999023438, 48.86928020983113]),
            {
              "class": 1,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00790405273438, 48.704605400059265]),
            {
              "class": 1,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.07632379233837, 48.74401363704633]),
            {
              "class": 1,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30085754394531, 48.63931011041397]),
            {
              "class": 1,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74237060546875, 48.83900965314944]),
            {
              "class": 1,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97720336914062, 48.467507259329885]),
            {
              "class": 1,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.38438415527344, 48.42651581824538]),
            {
              "class": 1,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40155029296875, 48.474335949593026]),
            {
              "class": 1,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.63432244956493, 48.52074667411845]),
            {
              "class": 1,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.45373468101025, 48.69916735770812]),
            {
              "class": 1,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.31777954101562, 48.796962239096736]),
            {
              "class": 1,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85909967124462, 49.06761657634657]),
            {
              "class": 1,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.30841793864965, 45.53235278175722]),
            {
              "class": 1,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.53363766521215, 45.6519941518088]),
            {
              "class": 1,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.1882553100586, 45.708602599885154]),
            {
              "class": 1,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98500790446997, 45.94282023178539]),
            {
              "class": 1,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69284057617188, 45.87999636765373]),
            {
              "class": 1,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.44770812988281, 45.99317114357898]),
            {
              "class": 1,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30591583251953, 46.07611436584392]),
            {
              "class": 1,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.87985229492188, 46.09968753836681]),
            {
              "class": 1,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.27604641765356, 46.18128233466367]),
            {
              "class": 1,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30660247802734, 46.405458792272555]),
            {
              "class": 1,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.66527557373047, 46.43811902345062]),
            {
              "class": 1,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.43353271484375, 46.33012415082471]),
            {
              "class": 1,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.03356170654297, 46.25539765937862]),
            {
              "class": 1,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91339874267578, 46.15655499489235]),
            {
              "class": 1,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.14582824707031, 46.01153413194137]),
            {
              "class": 1,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.8371810913086, 45.97313171431228]),
            {
              "class": 1,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.27378845214844, 45.97480194380041]),
            {
              "class": 1,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38880090415478, 46.21360131401936]),
            {
              "class": 1,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88274316489697, 46.24946250227109]),
            {
              "class": 1,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19795922935009, 47.40813392588423]),
            {
              "class": 1,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94218377768993, 47.47013512153749]),
            {
              "class": 1,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66168908774853, 47.50841394268466]),
            {
              "class": 1,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14371490478516, 47.5371626964791]),
            {
              "class": 1,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.30576257407665, 47.584656214261656]),
            {
              "class": 1,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.48978424072266, 47.635114516147596]),
            {
              "class": 1,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84021759033203, 47.712789607967196]),
            {
              "class": 1,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5964584350586, 47.77904542183762]),
            {
              "class": 1,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1631851196289, 47.79081041123198]),
            {
              "class": 1,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.71377563476562, 47.81364039941535]),
            {
              "class": 1,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42538452148438, 47.78804233186612]),
            {
              "class": 1,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04120635986328, 47.84060849277437]),
            {
              "class": 1,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96224145591259, 47.72387649895719]),
            {
              "class": 1,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.65943078696728, 47.68413714851781]),
            {
              "class": 1,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.07382202148438, 47.6381219526968]),
            {
              "class": 1,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26676940917969, 47.58187739870991]),
            {
              "class": 1,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.91177368164062, 47.4912499216532]),
            {
              "class": 1,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01683044433594, 47.39953612222709]),
            {
              "class": 1,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2451400756836, 47.300212693241974]),
            {
              "class": 1,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.62818908691406, 47.32744640068387]),
            {
              "class": 1,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40983581542969, 47.34489652379174]),
            {
              "class": 1,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.05586938560009, 47.363503632390675]),
            {
              "class": 1,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.89710864424706, 46.90107391836034]),
            {
              "class": 1,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5647722184658, 46.943750250278995]),
            {
              "class": 1,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22378158569336, 46.99782950922649]),
            {
              "class": 1,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30291748046875, 47.06194948129151]),
            {
              "class": 1,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51783618330956, 47.28673215033179]),
            {
              "class": 1,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2459245622158, 47.35236525412156]),
            {
              "class": 1,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.58743286132812, 47.54738508693116]),
            {
              "class": 1,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88217544555664, 47.597262947021896]),
            {
              "class": 1,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80750274658203, 47.69660430753462]),
            {
              "class": 1,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9115292057395, 47.72571181196363]),
            {
              "class": 1,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80166625976562, 47.812359939991985]),
            {
              "class": 1,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.09447479248047, 48.24985083236864]),
            {
              "class": 1,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.25926971435547, 48.15923994391785]),
            {
              "class": 1,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.66394805908203, 48.12670933509252]),
            {
              "class": 1,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.11713409423828, 48.02486018110898]),
            {
              "class": 1,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.90564727783203, 47.91222501801776]),
            {
              "class": 1,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.64334869384766, 47.91061416445888]),
            {
              "class": 1,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3989028930664, 47.9602971815913]),
            {
              "class": 1,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91756439208984, 48.03266634498774]),
            {
              "class": 1,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87052917480469, 47.648299797236675]),
            {
              "class": 1,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.6023941040039, 47.63442058071062]),
            {
              "class": 1,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.82967376708984, 47.52232671049855]),
            {
              "class": 1,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.12836456298828, 47.520703531116446]),
            {
              "class": 1,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.33538818359375, 47.47988146837776]),
            {
              "class": 1,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50224304199219, 47.32186114333998]),
            {
              "class": 1,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.04719543457031, 47.68670435269322]),
            {
              "class": 1,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.05955505371094, 47.871272253191]),
            {
              "class": 1,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.77940368652344, 47.78045444582603]),
            {
              "class": 1,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6400146484375, 47.687166589503065]),
            {
              "class": 1,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55830383300781, 47.90810721881943]),
            {
              "class": 1,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.76704406738281, 48.02993594767116]),
            {
              "class": 1,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3104248046875, 47.71027320725262]),
            {
              "class": 1,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.27471923828125, 47.519105661324076]),
            {
              "class": 1,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.74369812011719, 47.459715649510834]),
            {
              "class": 1,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.41317749023438, 47.33840759195888]),
            {
              "class": 1,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.64663696289062, 47.12626383179999]),
            {
              "class": 1,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91580200195312, 47.352830445966944]),
            {
              "class": 1,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.41539001464844, 48.152851873586854]),
            {
              "class": 1,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.36045837402344, 48.50892063525602]),
            {
              "class": 1,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.973876953125, 48.441094454703894]),
            {
              "class": 1,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.36801013350487, 48.677409423356465]),
            {
              "class": 1,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.27256640791893, 48.513924343257955]),
            {
              "class": 1,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.83904895186424, 48.71819804610524]),
            {
              "class": 1,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.52731323242188, 49.004595231388386]),
            {
              "class": 1,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.90771484375, 48.99468438012662]),
            {
              "class": 1,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.85802686214447, 48.188261076480224]),
            {
              "class": 1,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.75390088558197, 48.14796092054795]),
            {
              "class": 1,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.32681274414062, 47.38212926566967]),
            {
              "class": 1,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.07344055175781, 47.432317952880446]),
            {
              "class": 1,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.98348864912987, 47.244796047185126]),
            {
              "class": 1,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58248901367188, 47.09775778767918]),
            {
              "class": 1,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.53665542602539, 47.49587688397851]),
            {
              "class": 1,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.61613464355469, 47.56298738232529]),
            {
              "class": 1,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.72273602336645, 47.56518822992853]),
            {
              "class": 1,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.55914172530174, 48.06298716446088]),
            {
              "class": 1,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7818603515625, 48.054115545626495]),
            {
              "class": 1,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.5291748046875, 48.00750861789548]),
            {
              "class": 1,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.57518005371094, 48.075580456755944]),
            {
              "class": 1,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.33279418945312, 48.116854270433265]),
            {
              "class": 1,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.14122009277344, 48.1608431551482]),
            {
              "class": 1,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98294830322266, 48.22927174701178]),
            {
              "class": 1,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68803405761719, 48.197700615708186]),
            {
              "class": 1,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5970458984375, 48.248503694696694]),
            {
              "class": 1,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87376403808594, 48.24118736289726]),
            {
              "class": 1,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4261703491211, 48.36539830428084]),
            {
              "class": 1,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75370025634766, 48.32911813014801]),
            {
              "class": 1,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01805877685547, 48.39595410611743]),
            {
              "class": 1,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.71593475341797, 48.1981583057325]),
            {
              "class": 1,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72760772705078, 48.03197759359979]),
            {
              "class": 1,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52779388427734, 47.8926611486313]),
            {
              "class": 1,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20207977294922, 47.806492771533584]),
            {
              "class": 1,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12036895751953, 47.86733236965201]),
            {
              "class": 1,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03694152832031, 47.62285152422975]),
            {
              "class": 1,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64315032958984, 47.394888194604746]),
            {
              "class": 1,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75335693359375, 47.266441984776066]),
            {
              "class": 1,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2672119140625, 47.23055161598554]),
            {
              "class": 1,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63044738769531, 47.04582236005479]),
            {
              "class": 1,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85326385498047, 47.06126041662543]),
            {
              "class": 1,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9813232421875, 47.20233497890604]),
            {
              "class": 1,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.46712493896484, 47.10544483806417]),
            {
              "class": 1,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9814224243164, 47.10708059436738]),
            {
              "class": 1,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.86263275146484, 46.93294172202208]),
            {
              "class": 1,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56840515136719, 46.92637707746578]),
            {
              "class": 1,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18628692626953, 46.64239075527649]),
            {
              "class": 1,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.00226458907127, 46.65558880172426]),
            {
              "class": 1,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6239242553711, 46.66760564927692]),
            {
              "class": 1,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31596374511719, 46.652053926485856]),
            {
              "class": 1,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0972671508789, 46.673495285289846]),
            {
              "class": 1,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91358947753906, 46.54731697292799]),
            {
              "class": 1,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.81024932861328, 46.47265112300053]),
            {
              "class": 1,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3725114762783, 46.50645248513039]),
            {
              "class": 1,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.49507769942284, 46.61692827107518]),
            {
              "class": 1,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23312377929688, 46.7697585992675]),
            {
              "class": 1,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.48340472579002, 46.827105288480425]),
            {
              "class": 1,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.65335083007812, 46.89330688688735]),
            {
              "class": 1,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02197894454002, 46.937630359355026]),
            {
              "class": 1,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64535522460938, 46.90034480649963]),
            {
              "class": 1,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60278186202049, 46.771404642742645]),
            {
              "class": 1,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.69856891036034, 46.726473129909195]),
            {
              "class": 1,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52313098311424, 46.576352214831076]),
            {
              "class": 1,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.03169250488281, 47.46389359141875]),
            {
              "class": 1,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.56820410490036, 47.299306375109694]),
            {
              "class": 1,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.58880347013474, 47.11691921309325]),
            {
              "class": 1,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8174564242363, 47.13046818353112]),
            {
              "class": 1,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.12738037109375, 46.677289619407695]),
            {
              "class": 1,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88224792480469, 46.58864800624931]),
            {
              "class": 1,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47850036621094, 46.02753306552826]),
            {
              "class": 1,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.87606811523438, 46.11042473838272]),
            {
              "class": 1,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.82594299316406, 45.906784562887616]),
            {
              "class": 1,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09888458251953, 48.7643363613842]),
            {
              "class": 1,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9382095336914, 48.684160903461425]),
            {
              "class": 1,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88396453857422, 48.67622700769798]),
            {
              "class": 1,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.97185516357422, 48.54752375797609]),
            {
              "class": 1,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.99211120605469, 48.6403955804156]),
            {
              "class": 1,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.87126159667969, 48.67917402914728]),
            {
              "class": 1,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.89289093017578, 48.56706599314279]),
            {
              "class": 1,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.06695556640625, 48.78650923977862]),
            {
              "class": 1,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.0645523071289, 48.7643363613842]),
            {
              "class": 1,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9491958618164, 48.51046369041123]),
            {
              "class": 1,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.93683624267578, 48.60862493071417]),
            {
              "class": 1,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96945190429688, 48.59114254808809]),
            {
              "class": 1,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05425262451172, 48.574789910928864]),
            {
              "class": 1,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00447082519531, 48.595229880723096]),
            {
              "class": 1,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88087463378906, 48.59068837960678]),
            {
              "class": 1,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8503189086914, 48.60499272583296]),
            {
              "class": 1,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.80740356445312, 48.5402503014931]),
            {
              "class": 1,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11467742919922, 48.64742780553354]),
            {
              "class": 1,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15827941894531, 48.547296478282604]),
            {
              "class": 1,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23381042480469, 48.82268881260476]),
            {
              "class": 1,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.16033935546875, 48.705009755756315]),
            {
              "class": 1,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15072631835938, 48.64697414317915]),
            {
              "class": 1,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02266693115234, 48.814324606354575]),
            {
              "class": 1,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94473266601562, 48.772935170565056]),
            {
              "class": 1,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.98009490966797, 48.52433597124222]),
            {
              "class": 1,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.71810150146484, 48.23656499525637]),
            {
              "class": 1,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.68703079223633, 48.19927781885944]),
            {
              "class": 1,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.79328918457031, 48.24696853068224]),
            {
              "class": 1,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.73372268676758, 48.207744161767124]),
            {
              "class": 1,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.68874740600586, 48.16974908365419]),
            {
              "class": 1,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5780258178711, 48.11018210246057]),
            {
              "class": 1,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6058349609375, 48.138943255367394]),
            {
              "class": 1,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.4523696899414, 48.09195455361717]),
            {
              "class": 1,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.42267227172852, 48.14421247749484]),
            {
              "class": 1,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.40052795410156, 48.185087836811206]),
            {
              "class": 1,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.4688491821289, 48.25222665558031]),
            {
              "class": 1,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.55416488647461, 48.30100997135589]),
            {
              "class": 1,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.68909072875977, 48.354309828540046]),
            {
              "class": 1,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89285278320312, 48.414390741518666]),
            {
              "class": 1,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.90847396850586, 48.34552546443802]),
            {
              "class": 1,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.97954177856445, 48.40367941865278]),
            {
              "class": 1,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.26158142089844, 48.46836878749391]),
            {
              "class": 1,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.44422912597656, 48.64697414317915]),
            {
              "class": 1,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.57469177246094, 48.427378042075105]),
            {
              "class": 1,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.72026062011719, 48.458807239544754]),
            {
              "class": 1,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77381896972656, 48.40094425125627]),
            {
              "class": 1,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.68592834472656, 48.1688331920297]),
            {
              "class": 1,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46757507324219, 48.062937645083274]),
            {
              "class": 1,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.38134002685547, 48.177762437638485]),
            {
              "class": 1,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3006591796875, 48.202252639342944]),
            {
              "class": 1,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.14753723144531, 48.14111973876635]),
            {
              "class": 1,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98480224609375, 48.124621985098386]),
            {
              "class": 1,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95252990722656, 48.161047452791834]),
            {
              "class": 1,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.8938217163086, 48.17478619520565]),
            {
              "class": 1,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95596313476562, 48.00324675972156]),
            {
              "class": 1,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.96145629882812, 47.961651894081285]),
            {
              "class": 1,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.85468292236328, 47.91611193960254]),
            {
              "class": 1,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.15646362304688, 47.91127959148981]),
            {
              "class": 1,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.14616394042969, 47.95176531374989]),
            {
              "class": 1,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.32469177246094, 47.96533013872905]),
            {
              "class": 1,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46820068359375, 47.96533013872905]),
            {
              "class": 1,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52862548828125, 47.89240610116927]),
            {
              "class": 1,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.53034210205078, 47.81361563260797]),
            {
              "class": 1,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46442413330078, 47.74163217193159]),
            {
              "class": 1,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.16504669189453, 47.80531493467812]),
            {
              "class": 1,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02943420410156, 47.502822820057]),
            {
              "class": 1,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.34323120117188, 47.4963282938289]),
            {
              "class": 1,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.94600677490234, 47.43760918357941]),
            {
              "class": 1,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.877685546875, 47.34952381511167]),
            {
              "class": 1,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.18701934814453, 47.3136897998641]),
            {
              "class": 1,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.29379272460938, 47.23052651544568]),
            {
              "class": 1,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1684799194336, 47.1976445098103]),
            {
              "class": 1,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13861083984375, 47.175711845199594]),
            {
              "class": 1,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.01295471191406, 47.17547847026292]),
            {
              "class": 1,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9054946899414, 46.92234225552786]),
            {
              "class": 1,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.49017333984375, 46.92515600959837]),
            {
              "class": 1,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41532897949219, 46.80050596062535]),
            {
              "class": 1,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48674011230469, 46.641870479966094]),
            {
              "class": 1,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47953033447266, 46.72924837688553]),
            {
              "class": 1,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3775634765625, 46.692759975646915]),
            {
              "class": 1,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.0373306274414, 46.626075576788274]),
            {
              "class": 1,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46408081054688, 46.5453790196972]),
            {
              "class": 1,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5972900390625, 46.65483299992016]),
            {
              "class": 1,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.43970489501953, 46.84396679546876]),
            {
              "class": 1,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.04488372802734, 46.722658634437906]),
            {
              "class": 1,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.93134307861328, 46.883168838029256]),
            {
              "class": 1,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.10987091064453, 46.8141353004049]),
            {
              "class": 1,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09888458251953, 46.84349713645834]),
            {
              "class": 1,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88945770263672, 46.71277279873541]),
            {
              "class": 1,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81461334228516, 46.68475276917368]),
            {
              "class": 1,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03605651855469, 46.73536659595935]),
            {
              "class": 1,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.74148559570312, 46.71959900580625]),
            {
              "class": 1,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.65874481201172, 46.627018685477715]),
            {
              "class": 1,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.89838409423828, 46.641163344081356]),
            {
              "class": 1,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81289672851562, 46.41606197702145]),
            {
              "class": 1,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.72019958496094, 46.372493188739845]),
            {
              "class": 1,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.56536102294922, 46.4013850752625]),
            {
              "class": 1,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3062515258789, 46.62654713318691]),
            {
              "class": 1,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22625732421875, 46.63314849144766]),
            {
              "class": 1,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22728729248047, 46.74124884437594]),
            {
              "class": 1,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05974578857422, 46.74289564406229]),
            {
              "class": 1,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.95091247558594, 46.93898815089391]),
            {
              "class": 1,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.89460754394531, 47.04624158542928]),
            {
              "class": 1,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.86302185058594, 47.08950345269175]),
            {
              "class": 1,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8503189086914, 47.13249664546723]),
            {
              "class": 1,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96807861328125, 47.162384470764025]),
            {
              "class": 1,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5753173828125, 47.2505488695384]),
            {
              "class": 1,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11742401123047, 47.20415254450597]),
            {
              "class": 1,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22213745117188, 47.334611419185734]),
            {
              "class": 1,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2897720336914, 47.386007600386485]),
            {
              "class": 1,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14111328125, 47.3264671597711]),
            {
              "class": 1,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.33062744140625, 47.42225711468637]),
            {
              "class": 1,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.41405487060547, 47.44385553462423]),
            {
              "class": 1,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11742401123047, 47.49978438692642]),
            {
              "class": 1,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.92413330078125, 47.54453096678544]),
            {
              "class": 1,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8942642211914, 47.56631081719529]),
            {
              "class": 1,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.68209075927734, 47.48029727048722]),
            {
              "class": 1,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48021697998047, 47.63853650087559]),
            {
              "class": 1,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.19731903076172, 47.75407487506912]),
            {
              "class": 1,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3174819946289, 47.75245910473863]),
            {
              "class": 1,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9926986694336, 47.808058900765786]),
            {
              "class": 1,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60690307617188, 47.937483890977425]),
            {
              "class": 1,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48605346679688, 47.96668640289594]),
            {
              "class": 1,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.31404876708984, 47.98829023346093]),
            {
              "class": 1,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.31336212158203, 47.91493838836484]),
            {
              "class": 1,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.09054565429688, 47.95427160344332]),
            {
              "class": 1,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5365219116211, 48.11176378893746]),
            {
              "class": 1,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1691665649414, 48.176365892269025]),
            {
              "class": 1,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.21036529541016, 48.2337979902009]),
            {
              "class": 1,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6353988647461, 48.272431117826315]),
            {
              "class": 1,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.25396728515625, 48.31651490863183]),
            {
              "class": 1,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30958557128906, 48.344589903057404]),
            {
              "class": 1,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13140106201172, 48.3345485912747]),
            {
              "class": 1,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.66595458984375, 48.45149827617327]),
            {
              "class": 1,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9158935546875, 48.53909099640961]),
            {
              "class": 1,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36039733886719, 48.59089275454252]),
            {
              "class": 1,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45000457763672, 48.71382259597383]),
            {
              "class": 1,
              "system:index": "780"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.75041198730469, 48.69161762466665]),
            {
              "class": 1,
              "system:index": "781"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.89254760742188, 48.87891878932831]),
            {
              "class": 1,
              "system:index": "782"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.38683319091797, 48.86762816253942]),
            {
              "class": 1,
              "system:index": "783"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.119384765625, 48.83871254629035]),
            {
              "class": 1,
              "system:index": "784"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.12110137939453, 48.79236758424221]),
            {
              "class": 1,
              "system:index": "785"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.94669342041016, 48.850687444558226]),
            {
              "class": 1,
              "system:index": "786"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.87013244628906, 48.86807983653428]),
            {
              "class": 1,
              "system:index": "787"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95905303955078, 48.88704646288713]),
            {
              "class": 1,
              "system:index": "788"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.89244842529297, 48.73964055022153]),
            {
              "class": 1,
              "system:index": "789"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91339111328125, 48.69660327381606]),
            {
              "class": 1,
              "system:index": "790"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.00299835205078, 48.70611994712437]),
            {
              "class": 1,
              "system:index": "791"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.10118865966797, 48.8644663304184]),
            {
              "class": 1,
              "system:index": "792"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.09054565429688, 48.94525614046956]),
            {
              "class": 1,
              "system:index": "793"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9377670288086, 48.93826553969257]),
            {
              "class": 1,
              "system:index": "794"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98033905029297, 48.908488148742826]),
            {
              "class": 1,
              "system:index": "795"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.84918975830078, 48.968025177156015]),
            {
              "class": 1,
              "system:index": "796"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.7619857788086, 48.93059730326622]),
            {
              "class": 1,
              "system:index": "797"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.7180404663086, 48.83690476574827]),
            {
              "class": 1,
              "system:index": "798"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.54363250732422, 48.824474508377314]),
            {
              "class": 1,
              "system:index": "799"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02394104003906, 48.93037174906936]),
            {
              "class": 1,
              "system:index": "800"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.45814514160156, 48.91187283734306]),
            {
              "class": 1,
              "system:index": "801"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.40424346923828, 48.83080302474781]),
            {
              "class": 1,
              "system:index": "802"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.51342010498047, 48.83215903141579]),
            {
              "class": 1,
              "system:index": "803"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.07396697998047, 48.91051898941723]),
            {
              "class": 1,
              "system:index": "804"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.06332397460938, 48.94119720116444]),
            {
              "class": 1,
              "system:index": "805"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.07671356201172, 48.826056712399456]),
            {
              "class": 1,
              "system:index": "806"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.14022827148438, 48.8674023240131]),
            {
              "class": 1,
              "system:index": "807"
            }),
        ee.Feature(
            ee.Geometry.Point([-94.98710632324219, 48.789879570180965]),
            {
              "class": 1,
              "system:index": "808"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.28133392333984, 48.774043862726934]),
            {
              "class": 1,
              "system:index": "809"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.45814514160156, 48.94773644086716]),
            {
              "class": 1,
              "system:index": "810"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.3778076171875, 48.917287862194556]),
            {
              "class": 1,
              "system:index": "811"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.54431915283203, 48.90442621976255]),
            {
              "class": 1,
              "system:index": "812"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.46672821044922, 48.79553396225856]),
            {
              "class": 1,
              "system:index": "813"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.5975341796875, 48.71631437921428]),
            {
              "class": 1,
              "system:index": "814"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.3012466430664, 48.811815077838396]),
            {
              "class": 1,
              "system:index": "815"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.25798797607422, 48.862207756591175]),
            {
              "class": 1,
              "system:index": "816"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.0973129272461, 48.89720419742181]),
            {
              "class": 1,
              "system:index": "817"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.39016723632812, 48.8522688208314]),
            {
              "class": 1,
              "system:index": "818"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2015380859375, 48.25750709214511]),
            {
              "class": 1,
              "system:index": "819"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2344970703125, 47.909806780532875]),
            {
              "class": 1,
              "system:index": "820"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22419738769531, 47.79788929468741]),
            {
              "class": 1,
              "system:index": "821"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.52838134765625, 47.7835884945075]),
            {
              "class": 1,
              "system:index": "822"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2564697265625, 47.61954064740436]),
            {
              "class": 1,
              "system:index": "823"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09716796875, 47.56072771701498]),
            {
              "class": 1,
              "system:index": "824"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.53961181640625, 47.68244814805962]),
            {
              "class": 1,
              "system:index": "825"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2015380859375, 47.89374127869283]),
            {
              "class": 1,
              "system:index": "826"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.12532043457031, 47.986658790010935]),
            {
              "class": 1,
              "system:index": "827"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24960327148438, 48.07161002191397]),
            {
              "class": 1,
              "system:index": "828"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26676940917969, 48.16008560019513]),
            {
              "class": 1,
              "system:index": "829"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85272216796875, 48.15596318249269]),
            {
              "class": 1,
              "system:index": "830"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02987670898438, 48.261209936829474]),
            {
              "class": 1,
              "system:index": "831"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78680419921875, 48.095462996410404]),
            {
              "class": 1,
              "system:index": "832"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.54098510742188, 47.87854581424045]),
            {
              "class": 1,
              "system:index": "833"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.32606506347656, 47.85136705520528]),
            {
              "class": 1,
              "system:index": "834"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.27593994140625, 48.126638658746586]),
            {
              "class": 1,
              "system:index": "835"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.888671875, 48.116554484686276]),
            {
              "class": 1,
              "system:index": "836"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.09947204589844, 47.798811791824974]),
            {
              "class": 1,
              "system:index": "837"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.96145629882812, 47.785895341354895]),
            {
              "class": 1,
              "system:index": "838"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.361083984375, 47.829245008860234]),
            {
              "class": 1,
              "system:index": "839"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6632080078125, 46.23158052647235]),
            {
              "class": 1,
              "system:index": "840"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.73736572265625, 46.12698461506306]),
            {
              "class": 1,
              "system:index": "841"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.49978637695312, 46.128888134888456]),
            {
              "class": 1,
              "system:index": "842"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.59248352050781, 45.96733136502381]),
            {
              "class": 1,
              "system:index": "843"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.536865234375, 45.91432955029767]),
            {
              "class": 1,
              "system:index": "844"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.77650451660156, 46.07032481115491]),
            {
              "class": 1,
              "system:index": "845"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64947509765625, 46.27146466068824]),
            {
              "class": 1,
              "system:index": "846"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11845397949219, 46.43023792624756]),
            {
              "class": 1,
              "system:index": "847"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31620788574219, 46.27573624054673]),
            {
              "class": 1,
              "system:index": "848"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42057800292969, 46.34545825026133]),
            {
              "class": 1,
              "system:index": "849"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.33680725097656, 46.59657147884356]),
            {
              "class": 1,
              "system:index": "850"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39997863769531, 46.67012469753826]),
            {
              "class": 1,
              "system:index": "851"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.70921325683594, 46.68001845830864]),
            {
              "class": 1,
              "system:index": "852"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.08343505859375, 47.17545513128845]),
            {
              "class": 1,
              "system:index": "853"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.86473846435547, 47.11754645198541]),
            {
              "class": 1,
              "system:index": "854"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60003662109375, 47.11848096350946]),
            {
              "class": 1,
              "system:index": "855"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8942642211914, 47.02518259664473]),
            {
              "class": 1,
              "system:index": "856"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1634292602539, 47.220244333257895]),
            {
              "class": 1,
              "system:index": "857"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14214324951172, 47.2771094019997]),
            {
              "class": 1,
              "system:index": "858"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22625732421875, 47.27687647305705]),
            {
              "class": 1,
              "system:index": "859"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.18299865722656, 47.374848913544355]),
            {
              "class": 1,
              "system:index": "860"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31895446777344, 47.40552969756802]),
            {
              "class": 1,
              "system:index": "861"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35328674316406, 47.32041635390075]),
            {
              "class": 1,
              "system:index": "862"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04326629638672, 47.44292678110185]),
            {
              "class": 1,
              "system:index": "863"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.832763671875, 47.07105716795056]),
            {
              "class": 1,
              "system:index": "864"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.61029052734375, 46.925413952558074]),
            {
              "class": 1,
              "system:index": "865"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87258911132812, 46.91837932415156]),
            {
              "class": 1,
              "system:index": "866"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.06828308105469, 47.06217073607982]),
            {
              "class": 1,
              "system:index": "867"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89181518554688, 47.13649046753257]),
            {
              "class": 1,
              "system:index": "868"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53887939453125, 47.10658808137484]),
            {
              "class": 1,
              "system:index": "869"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40704345703125, 46.866763824701295]),
            {
              "class": 1,
              "system:index": "870"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.32670593261719, 46.85455653885574]),
            {
              "class": 1,
              "system:index": "871"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20310974121094, 47.1607737815166]),
            {
              "class": 1,
              "system:index": "872"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.46609497070312, 46.6560347296143]),
            {
              "class": 1,
              "system:index": "873"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.43794250488281, 46.590956573124544]),
            {
              "class": 1,
              "system:index": "874"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56806182861328, 46.81016437224756]),
            {
              "class": 1,
              "system:index": "875"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.6628189086914, 46.74527184082299]),
            {
              "class": 1,
              "system:index": "876"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7174072265625, 46.87216231583148]),
            {
              "class": 1,
              "system:index": "877"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.73628997802734, 46.85173907873365]),
            {
              "class": 1,
              "system:index": "878"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.60994720458984, 46.912281899046924]),
            {
              "class": 1,
              "system:index": "879"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53956604003906, 47.025206001585396]),
            {
              "class": 1,
              "system:index": "880"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.52926635742188, 47.10027840027947]),
            {
              "class": 1,
              "system:index": "881"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.52033996582031, 47.25826213085228]),
            {
              "class": 1,
              "system:index": "882"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73825073242188, 47.32393057095941]),
            {
              "class": 1,
              "system:index": "883"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.95763397216797, 47.28947645039601]),
            {
              "class": 1,
              "system:index": "884"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0468978881836, 47.21607027274681]),
            {
              "class": 1,
              "system:index": "885"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8553237915039, 47.14232881553146]),
            {
              "class": 1,
              "system:index": "886"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52264404296875, 47.24730946320093]),
            {
              "class": 1,
              "system:index": "887"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.53500366210938, 47.17734544103808]),
            {
              "class": 1,
              "system:index": "888"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41381072998047, 47.19157893475296]),
            {
              "class": 1,
              "system:index": "889"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94610595703125, 48.82585328344825]),
            {
              "class": 1,
              "system:index": "890"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00653076171875, 48.98562459864604]),
            {
              "class": 1,
              "system:index": "891"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3443603515625, 48.967596939155555]),
            {
              "class": 1,
              "system:index": "892"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.437744140625, 48.98382212608503]),
            {
              "class": 1,
              "system:index": "893"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.59567260742188, 48.928815391832714]),
            {
              "class": 1,
              "system:index": "894"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04910278320312, 48.55116009425219]),
            {
              "class": 1,
              "system:index": "895"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05734252929688, 48.46836878749391]),
            {
              "class": 1,
              "system:index": "896"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05734252929688, 48.43740105746244]),
            {
              "class": 1,
              "system:index": "897"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.10403442382812, 48.3617240221937]),
            {
              "class": 1,
              "system:index": "898"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20565795898438, 48.242967421301366]),
            {
              "class": 1,
              "system:index": "899"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.72088623046875, 48.47110032750183]),
            {
              "class": 1,
              "system:index": "900"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7069091796875, 48.41735304952527]),
            {
              "class": 1,
              "system:index": "901"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.19442749023438, 48.76795709209035]),
            {
              "class": 1,
              "system:index": "902"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36883544921875, 48.68914728403741]),
            {
              "class": 1,
              "system:index": "903"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4814453125, 48.32977826971931]),
            {
              "class": 1,
              "system:index": "904"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.46383666992188, 48.48111471624846]),
            {
              "class": 1,
              "system:index": "905"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42950439453125, 48.84212454876025]),
            {
              "class": 1,
              "system:index": "906"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.06832885742188, 48.96669538503326]),
            {
              "class": 1,
              "system:index": "907"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09304809570312, 48.580241377838234]),
            {
              "class": 1,
              "system:index": "908"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95822143554688, 48.972104465264906]),
            {
              "class": 1,
              "system:index": "909"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83462524414062, 48.680080770292875]),
            {
              "class": 1,
              "system:index": "910"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15484619140625, 48.25942712329832]),
            {
              "class": 1,
              "system:index": "911"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82501220703125, 48.0165684107673]),
            {
              "class": 1,
              "system:index": "912"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11776733398438, 47.82145396250001]),
            {
              "class": 1,
              "system:index": "913"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14248657226562, 47.923704717745686]),
            {
              "class": 1,
              "system:index": "914"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30453491210938, 48.053299953804434]),
            {
              "class": 1,
              "system:index": "915"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2835922241211, 48.103075273531246]),
            {
              "class": 1,
              "system:index": "916"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.55172729492188, 48.06110203345823]),
            {
              "class": 1,
              "system:index": "917"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.61833190917969, 48.03126417018395]),
            {
              "class": 1,
              "system:index": "918"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.66021728515625, 48.02414643492424]),
            {
              "class": 1,
              "system:index": "919"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.43499755859375, 47.93566683402829]),
            {
              "class": 1,
              "system:index": "920"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1575927734375, 48.00761112785838]),
            {
              "class": 1,
              "system:index": "921"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.37079620361328, 47.84196634093296]),
            {
              "class": 1,
              "system:index": "922"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42469787597656, 47.82675569114168]),
            {
              "class": 1,
              "system:index": "923"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5857162475586, 47.83367017560078]),
            {
              "class": 1,
              "system:index": "924"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.67601013183594, 47.84081417507446]),
            {
              "class": 1,
              "system:index": "925"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44564056396484, 47.905986501953414]),
            {
              "class": 1,
              "system:index": "926"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.12532043457031, 47.93681689170652]),
            {
              "class": 1,
              "system:index": "927"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09373474121094, 48.02253906833847]),
            {
              "class": 1,
              "system:index": "928"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23346710205078, 47.98693453667708]),
            {
              "class": 1,
              "system:index": "929"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.32891082763672, 47.956823800497475]),
            {
              "class": 1,
              "system:index": "930"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20050811767578, 47.76171450353841]),
            {
              "class": 1,
              "system:index": "931"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51087188720703, 47.74163217193159]),
            {
              "class": 1,
              "system:index": "932"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6519775390625, 47.73539814842237]),
            {
              "class": 1,
              "system:index": "933"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1462631225586, 47.86316162572424]),
            {
              "class": 1,
              "system:index": "934"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.10334777832031, 47.68919695228655]),
            {
              "class": 1,
              "system:index": "935"
            })]),
    NonCropClass = /* color: #98ff00 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-106.39155864715576, 47.59214329958163]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.87495708465576, 48.90883596581475]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.99996411800385, 48.10202754658489]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3542732000351, 48.200062770804315]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.22680127620697, 47.94680525706371]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.03454053401947, 48.121282876779276]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.43829345703125, 48.401121338766735]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.48009300231934, 48.3921740659321]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.39374732971191, 48.41371324118753]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.34173393249512, 48.42294152421548]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.3091179355979, 48.438375215667136]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.26311268657446, 48.458414929212914]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.33358001708984, 48.472642879447136]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.37100219726562, 48.49858438718115]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.39374732971191, 48.51177760574678]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.33443832397461, 48.503759722788494]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.44927978515625, 48.51302851027592]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.49588584899902, 48.52667271655989]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.56146015971899, 48.54162027247774]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59338917583227, 48.537244448716194]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.55631065368652, 48.570252687580385]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58248901367188, 48.58541448442715]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.56661000102758, 48.59500892718137]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.49313893169165, 48.604942067319854]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.55742645263672, 48.62253315935443]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59536328166723, 48.65225383474165]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6219711303711, 48.670395232018016]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58145904541016, 48.676743183365254]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5300464630127, 48.68620694687946]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.64154052734375, 48.70439278012252]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.70934677124023, 48.69838821587115]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.74342155456543, 48.70626197938161]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.79191589355469, 48.69912466323299]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89285278320312, 48.78162993474522]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0562744140625, 48.85125914939359]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.26913452148438, 48.88287682422157]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.34878540039062, 48.97130005139146]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.98074340820312, 48.95326721096991]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.91575622558594, 48.87334499480425]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.46051025390625, 48.84849948466756]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.02586364746094, 48.96178508460206]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.62417602539062, 48.803746483535086]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.88029479980469, 48.680129582433054]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.54727172851562, 48.66108460905916]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46693420410156, 48.71593276792655]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.36668395996094, 48.766195488051345]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.17623901367188, 48.640671292057675]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.99290466308594, 48.51028522083825]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.35545349121094, 48.49936661860671]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2215576171875, 48.56666053029694]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.48046875, 48.66514192282099]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.55840301513672, 48.723156615245976]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72594451904297, 48.70775298274991]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75135040283203, 48.73606485011293]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.58655548095703, 48.67103709014797]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.39669799804688, 48.64949371190501]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.64972686767578, 48.62884878866235]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.85537719726562, 48.73742341891725]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.96627044677734, 48.745574060727044]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72457122802734, 48.673984415194546]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4581527709961, 48.638378209302736]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5299072265625, 48.609784381294936]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.46055603027344, 48.56890795161741]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26245880126953, 48.56913513423543]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.30640411376953, 48.65493706343894]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.08942413330078, 48.64518387594166]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0798110961914, 48.68237195672491]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14435577392578, 48.685545277841996]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.36682891845703, 48.507076381710306]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28992462158203, 48.481594370882306]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.19860076904297, 48.47522186701595]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9805908203125, 48.42740257035477]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.12169647216797, 48.38090641357214]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.16941833496094, 48.2907562419934]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.11002215743065, 48.1796185332121]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28202685713768, 48.13266705872107]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.16907501220703, 48.23819029635602]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38330706954002, 48.20159076678378]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.51514300704002, 48.195640876189884]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38021716475487, 48.30171968035632]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38365039229393, 48.31290915173912]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.51136645674706, 48.3806783865421]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0523452758789, 48.23727562771042]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88652038574219, 48.27316409727077]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73133715987206, 48.31313748218503]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4865480363369, 48.28595898519907]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4374528825283, 48.28230362993473]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.29119873046875, 48.234760204615434]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.29634857177734, 48.211429481963854]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31282806396484, 48.20570954495009]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.29566192626953, 48.26196594148157]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22974395751953, 48.22561216902837]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3210678100586, 48.24344932372342]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.26991271972656, 48.22058005238642]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31763458251953, 48.2162337353525]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.29669189453125, 48.20113313535833]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.19918823242188, 48.18373904986413]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.37874603271484, 48.22492600043456]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41582489013672, 48.21348850289789]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.43299102783203, 48.24459251900001]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4645767211914, 48.28070432974626]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50577545166016, 48.27956194181247]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23214721679688, 48.189003672476055]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.16657257080078, 48.156720742404985]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14803314208984, 48.20731119171074]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.08451843261719, 48.31861710636597]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31317138671875, 48.351938807729724]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3492202758789, 48.417377638273685]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.33548736572266, 48.51299007246082]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55384063720703, 48.47818068464095]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.59984454512596, 48.49615714367999]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.68876647949219, 48.646998565292165]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.77631244063377, 48.78019954373228]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.86901092529297, 48.83875952189563]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9417953491211, 48.96243710436418]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0736312866211, 48.91778598921904]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.10590362548828, 48.82926795509034]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.24597930908203, 48.80213928357021]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49873733520508, 48.76570637590025]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.51641845703125, 48.764348571623394]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.37308120727539, 48.761067059727296]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23764038085938, 48.749523487019964]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.85861206054688, 48.76796924620325]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.81501007080078, 48.70751417184864]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.54584503173828, 48.68099969793604]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.30466012656689, 48.706268077729725]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.27290277183056, 48.699810550365356]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.02676248550415, 48.68243407937619]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84907150268555, 48.66512966080082]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84426498413086, 48.66116137043448]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.86846923828125, 48.80303160832187]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.39159326255322, 48.7234840726281]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.26868371665478, 48.52025514811515]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.49287347495556, 48.56298861391925]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20328073203564, 48.56151172917539]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12397384643555, 48.5952421043055]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75953674316406, 48.60659406844894]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49740982055664, 48.601145444055746]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.59491314738989, 48.564402539216466]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38497161865234, 48.6451655586989]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63911628723145, 48.68932336598273]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62607002258301, 48.65378475468319]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60821723937988, 48.59688219951952]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63276481628418, 48.7988984758647]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66100311279297, 48.703033332702795]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9258041381836, 48.97098975434948]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.82109069824219, 48.96907406271385]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.98193673789501, 48.96366465371901]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11239938437939, 48.95588760020393]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.19102096557617, 48.92837640909554]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.32491683959961, 48.94596727968563]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.1901626586914, 48.90231703009798]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.06038665771484, 48.85603089688608]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14724731445312, 48.913047866734864]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.31621417403221, 47.2347478777759]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.36977252364159, 47.28693987679029]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.17888507246971, 47.253160750521]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.0357194840908, 47.27506140056353]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.94989013671875, 47.30975766971374]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.82766723632812, 47.35396825205114]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.74183654785156, 47.29765148056903]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.68209838867188, 47.35978262198455]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.55438232421875, 47.32767899329869]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4970474243164, 47.39790937433821]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58528137207031, 47.37117703980742]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.3428955078125, 47.427048319635475]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.38452339172363, 47.43953122218646]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.35619926452637, 47.40695333848042]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29259872436523, 47.427164453303355]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29139709472656, 47.44138890358899]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.25311660766602, 47.447193690919015]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.27860832214355, 47.45357821715906]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.3315658569336, 47.46564865752698]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.25732231140137, 47.46042619677548]),
            {
              "class": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.21972846984863, 47.468897903842034]),
            {
              "class": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.20951461791992, 47.454622869858305]),
            {
              "class": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.2150936126709, 47.43598986233587]),
            {
              "class": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.2271957397461, 47.40735996034952]),
            {
              "class": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.26539039611816, 47.392661490663144]),
            {
              "class": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29912185668945, 47.38382881761982]),
            {
              "class": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.22685241699219, 47.37813328308906]),
            {
              "class": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.22582244873047, 47.35278650788665]),
            {
              "class": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.1769847869873, 47.35511240754143]),
            {
              "class": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.28710556030273, 47.33289588047609]),
            {
              "class": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.2374095916748, 47.32568222280391]),
            {
              "class": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.32289695739746, 47.33464097222067]),
            {
              "class": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.3431526646018, 47.355519429441294]),
            {
              "class": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.36890187114477, 47.35092571435225]),
            {
              "class": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.39593853801489, 47.35644975342326]),
            {
              "class": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.41113090515137, 47.34714577549797]),
            {
              "class": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.45430374145508, 47.34958822847383]),
            {
              "class": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.47318649291992, 47.34726208534545]),
            {
              "class": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4853744506836, 47.371100192617575]),
            {
              "class": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0601692199707, 47.438782776576126]),
            {
              "class": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.12093734741211, 47.43855056025711]),
            {
              "class": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.07167053222656, 47.48230522545953]),
            {
              "class": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.95339584350586, 47.452829957224864]),
            {
              "class": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.89485931396484, 47.459794110109534]),
            {
              "class": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.90275573730469, 47.48764149841761]),
            {
              "class": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.61985778808594, 47.65476288424665]),
            {
              "class": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76937484741211, 47.47847669570015]),
            {
              "class": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.83992767333984, 47.40789258671091]),
            {
              "class": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.8389835357666, 47.37482029121396]),
            {
              "class": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.83014297485352, 47.34551741072283]),
            {
              "class": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.711181640625, 47.29369307951942]),
            {
              "class": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.535400390625, 47.288104254199624]),
            {
              "class": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.87185668945312, 47.28833713371258]),
            {
              "class": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72560119628906, 47.232183519539255]),
            {
              "class": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91751861572266, 47.21119801495262]),
            {
              "class": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75718688964844, 47.109884623954294]),
            {
              "class": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.89142608642578, 47.11572589267385]),
            {
              "class": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.06171417236328, 47.1346471995709]),
            {
              "class": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.56114959716797, 47.142587471160084]),
            {
              "class": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.47222900390625, 47.19533678846782]),
            {
              "class": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2775650024414, 47.243605469466424]),
            {
              "class": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.19139099121094, 47.28298064905759]),
            {
              "class": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.01526641845703, 47.37791957221906]),
            {
              "class": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8374252319336, 47.35978267876295]),
            {
              "class": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.81991577148438, 47.336753793841716]),
            {
              "class": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.75640106201172, 47.419982439374046]),
            {
              "class": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6671371459961, 47.390472229694126]),
            {
              "class": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82952880859375, 47.36908442884172]),
            {
              "class": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.48517608642578, 47.30999045387342]),
            {
              "class": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4364242553711, 47.43089933533605]),
            {
              "class": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4803695678711, 47.47338403385438]),
            {
              "class": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.39522552490234, 47.404880839925625]),
            {
              "class": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31488800048828, 47.383033964488156]),
            {
              "class": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.34613037109375, 47.30510176765975]),
            {
              "class": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.2335205078125, 47.257122143732964]),
            {
              "class": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.15936279296875, 47.24593617518241]),
            {
              "class": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.38835906982422, 47.18530444224557]),
            {
              "class": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.54319763183594, 47.128340837938936]),
            {
              "class": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49856567382812, 47.0706146598591]),
            {
              "class": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8051528930664, 46.93552054911172]),
            {
              "class": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.90025329589844, 46.88321759122024]),
            {
              "class": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82849884033203, 46.81418411629544]),
            {
              "class": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.93939208984375, 46.8541122507108]),
            {
              "class": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.06195831298828, 46.8480074877964]),
            {
              "class": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2332763671875, 46.81089456614384]),
            {
              "class": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.27893829345703, 46.92825276003137]),
            {
              "class": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.42617797851562, 46.54385129860464]),
            {
              "class": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.62118530273438, 46.41902771653125]),
            {
              "class": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.45089721679688, 46.35570837747234]),
            {
              "class": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.37708282470703, 46.39005593629281]),
            {
              "class": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.46789169311523, 46.39384468843029]),
            {
              "class": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28524398803711, 46.367199448028515]),
            {
              "class": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3424072265625, 46.39751479125016]),
            {
              "class": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2076530456543, 46.398106720201554]),
            {
              "class": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.17778396606445, 46.442246506236664]),
            {
              "class": 2,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.15804290771484, 46.49072355305621]),
            {
              "class": 2,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.39321899414062, 46.5136464340308]),
            {
              "class": 2,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.25400161743164, 46.56512855106321]),
            {
              "class": 2,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.51956176757812, 46.57692949487892]),
            {
              "class": 2,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.59320449829102, 46.59863652281073]),
            {
              "class": 2,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.60590744018555, 46.563948315459164]),
            {
              "class": 2,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.49999237060547, 46.66311641265934]),
            {
              "class": 2,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.44179916381836, 46.7234009328233]),
            {
              "class": 2,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.40077209472656, 46.761867748207294]),
            {
              "class": 2,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.44197082519531, 46.756928592525]),
            {
              "class": 2,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.44059753417969, 46.80265725963846]),
            {
              "class": 2,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.51406860351562, 46.83918874649489]),
            {
              "class": 2,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.64350128173828, 46.783383071031565]),
            {
              "class": 2,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.71388244628906, 46.78655673529581]),
            {
              "class": 2,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.8089828491211, 46.74928376853985]),
            {
              "class": 2,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.68538665771484, 46.745519764528204]),
            {
              "class": 2,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.6668472290039, 46.70033121453392]),
            {
              "class": 2,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.82099914550781, 46.70115530284899]),
            {
              "class": 2,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.62564849853516, 46.73104942732227]),
            {
              "class": 2,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.51578521728516, 46.759398226961615]),
            {
              "class": 2,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.49381256103516, 46.7341085214634]),
            {
              "class": 2,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.38909912109375, 46.79595908649485]),
            {
              "class": 2,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.39030075073242, 46.83543102528308]),
            {
              "class": 2,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.45536041259766, 46.879802325905445]),
            {
              "class": 2,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3750228881836, 46.91522606476626]),
            {
              "class": 2,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29296875, 46.94804836025318]),
            {
              "class": 2,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.25915145874023, 46.98342700349298]),
            {
              "class": 2,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.36334991455078, 47.0070778052965]),
            {
              "class": 2,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.14877319335938, 47.046628480692064]),
            {
              "class": 2,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.06156921386719, 47.06417123736658]),
            {
              "class": 2,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.9608039855957, 47.102978500389945]),
            {
              "class": 2,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.95994567871094, 47.15028048075761]),
            {
              "class": 2,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.85420227050781, 47.139539088812]),
            {
              "class": 2,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.8092269897461, 47.17747471585078]),
            {
              "class": 2,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.72013473510742, 47.16428786157259]),
            {
              "class": 2,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.7601318359375, 47.20931971238399]),
            {
              "class": 2,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.7052001953125, 47.22028023370454]),
            {
              "class": 2,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.64786529541016, 47.21538325947024]),
            {
              "class": 2,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.62434768676758, 47.23298693791099]),
            {
              "class": 2,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.57542419433594, 47.1487627989955]),
            {
              "class": 2,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.47877883911133, 47.16277052284554]),
            {
              "class": 2,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.43964004516602, 47.17794144715179]),
            {
              "class": 2,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.37149047851562, 47.15483332302367]),
            {
              "class": 2,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.41303253173828, 47.16293935563544]),
            {
              "class": 2,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.3891716003418, 47.13900733595646]),
            {
              "class": 2,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.43191528320312, 47.07438120609355]),
            {
              "class": 2,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.666748046875, 47.08747348348841]),
            {
              "class": 2,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.50881958007812, 47.026192642272974]),
            {
              "class": 2,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.71824645996094, 47.024320363477536]),
            {
              "class": 2,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.65644836425781, 47.010744378337094]),
            {
              "class": 2,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46144104003906, 46.992949931603384]),
            {
              "class": 2,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.43534851074219, 46.96156107460807]),
            {
              "class": 2,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.59671020507812, 47.05426894436826]),
            {
              "class": 2,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46144104003906, 46.915615827306546]),
            {
              "class": 2,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.65850830078125, 46.86493662237223]),
            {
              "class": 2,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60357666015625, 46.80857022789268]),
            {
              "class": 2,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.90638732910156, 46.86211970687456]),
            {
              "class": 2,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68528747558594, 46.79775991643325]),
            {
              "class": 2,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.71000671386719, 46.84239715972359]),
            {
              "class": 2,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.75807189941406, 46.76108257009091]),
            {
              "class": 2,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.76631164550781, 46.67493406492913]),
            {
              "class": 2,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69764709472656, 46.63911611977475]),
            {
              "class": 2,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.04096984863281, 46.75167412726417]),
            {
              "class": 2,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.94346618652344, 46.73191105027657]),
            {
              "class": 2,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.56855773925781, 46.61884019393485]),
            {
              "class": 2,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.53765869140625, 46.73991126366979]),
            {
              "class": 2,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.38316345214844, 46.71731937027576]),
            {
              "class": 2,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.33235168457031, 46.66456815227231]),
            {
              "class": 2,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.37904357910156, 46.84380603862315]),
            {
              "class": 2,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.40582275390625, 46.91561571279724]),
            {
              "class": 2,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.56031799316406, 46.87010046895854]),
            {
              "class": 2,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.02061462402344, 46.63392997799669]),
            {
              "class": 2,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.1558837890625, 46.652314965131595]),
            {
              "class": 2,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.17648315429688, 46.77095966713162]),
            {
              "class": 2,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.88534009456635, 46.83441216485561]),
            {
              "class": 2,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65874707698822, 46.80575035606379]),
            {
              "class": 2,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4870857000351, 46.91514679504924]),
            {
              "class": 2,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.51317822933197, 47.00325270208876]),
            {
              "class": 2,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5626220703125, 47.16082416260084]),
            {
              "class": 2,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.16093444824219, 47.17436172052969]),
            {
              "class": 2,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.96249389648438, 47.28719769298874]),
            {
              "class": 2,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5616455078125, 46.721441032665666]),
            {
              "class": 2,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1771240234375, 47.843055474192965]),
            {
              "class": 2,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.03955078125, 47.769266815855026]),
            {
              "class": 2,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.852783203125, 48.502440267958214]),
            {
              "class": 2,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.9132080078125, 48.9373243356788]),
            {
              "class": 2,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.8515625, 48.51335820808373]),
            {
              "class": 2,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.52197265625, 47.69907048434718]),
            {
              "class": 2,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.1207275390625, 48.144493463619746]),
            {
              "class": 2,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6380615234375, 48.19578254163064]),
            {
              "class": 2,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.5718994140625, 47.473063543945685]),
            {
              "class": 2,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.52294921875, 47.97561095175772]),
            {
              "class": 2,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3251953125, 47.75449650442711]),
            {
              "class": 2,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2919921875, 47.92656475269582]),
            {
              "class": 2,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.13681030273438, 47.890663786537125]),
            {
              "class": 2,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.83468627929688, 47.71263338688739]),
            {
              "class": 2,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.99673461914062, 48.08826965768432]),
            {
              "class": 2,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.86190795898438, 48.05615281593264]),
            {
              "class": 2,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.77838134765625, 48.20921570751386]),
            {
              "class": 2,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.88250732421875, 47.66456229562911]),
            {
              "class": 2,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.05142211914062, 47.85381641165476]),
            {
              "class": 2,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.16677856445312, 48.029526532546704]),
            {
              "class": 2,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.72021484375, 47.7680449805238]),
            {
              "class": 2,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.51422119140625, 47.571066827382126]),
            {
              "class": 2,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.53618311882019, 47.42075458892431]),
            {
              "class": 2,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.32332301139832, 47.37055487947137]),
            {
              "class": 2,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.13655543327332, 47.43190358561922]),
            {
              "class": 2,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.83992457389832, 47.55438671471517]),
            {
              "class": 2,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.03469848632812, 47.9376061938334]),
            {
              "class": 2,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.07177734375, 48.152443212212]),
            {
              "class": 2,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.73944091796875, 48.19548619194339]),
            {
              "class": 2,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.80673217773438, 48.146029464086595]),
            {
              "class": 2,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.928955078125, 48.06991963118268]),
            {
              "class": 2,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.03744506835938, 48.26775363177779]),
            {
              "class": 2,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.43844604492188, 47.98726350651133]),
            {
              "class": 2,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.82296752929688, 48.26775363177779]),
            {
              "class": 2,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.313720703125, 48.28968808601295]),
            {
              "class": 2,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.05691528320312, 48.330789805857556]),
            {
              "class": 2,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.57464599609375, 47.90907764929585]),
            {
              "class": 2,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.82183837890625, 48.4329437114213]),
            {
              "class": 2,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.74081420898438, 48.63482165058262]),
            {
              "class": 2,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.99899291992188, 48.76624443767796]),
            {
              "class": 2,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.21871948242188, 48.856680961643626]),
            {
              "class": 2,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.39862060546875, 48.88739222461014]),
            {
              "class": 2,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.99237060546875, 48.90183806086945]),
            {
              "class": 2,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.6492919921875, 48.55943897540767]),
            {
              "class": 2,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.48699951171875, 48.3189193760411]),
            {
              "class": 2,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.34967041015625, 48.35999755604845]),
            {
              "class": 2,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.59686279296875, 48.40560115972117]),
            {
              "class": 2,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.44717407226562, 48.09835938246044]),
            {
              "class": 2,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.05715942382812, 47.963360388677806]),
            {
              "class": 2,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.51058959960938, 48.09285614164879]),
            {
              "class": 2,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.5009765625, 48.38645262266463]),
            {
              "class": 2,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.61701965332031, 48.4702143936859]),
            {
              "class": 2,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.75297546386719, 48.5123077651567]),
            {
              "class": 2,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.87382507324219, 48.53004476903026]),
            {
              "class": 2,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.94489288330078, 48.56550014533784]),
            {
              "class": 2,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.57925415039062, 48.4677104439124]),
            {
              "class": 2,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.5287857055664, 48.48614572481918]),
            {
              "class": 2,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.80413055419922, 48.56141040810912]),
            {
              "class": 2,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.63727569580078, 48.541184069526324]),
            {
              "class": 2,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.44123840332031, 48.44494159695404]),
            {
              "class": 2,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.38424682617188, 48.42626352240119]),
            {
              "class": 2,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.35746765136719, 48.38523878873279]),
            {
              "class": 2,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.52191925048828, 48.42033977224713]),
            {
              "class": 2,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.26202392578125, 48.3676792130102]),
            {
              "class": 2,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.20674896240234, 48.39367435269076]),
            {
              "class": 2,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.04710388183594, 48.34440915085325]),
            {
              "class": 2,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.90462493896484, 48.36676686177667]),
            {
              "class": 2,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.00006866455078, 48.43378113416534]),
            {
              "class": 2,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.9080581665039, 48.47317344776665]),
            {
              "class": 2,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.6986312866211, 48.3790822244033]),
            {
              "class": 2,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.73605346679688, 48.328661611274484]),
            {
              "class": 2,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.56782531738281, 48.35467666490449]),
            {
              "class": 2,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.56610870361328, 48.394814186517515]),
            {
              "class": 2,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.64610290527344, 48.429908563964794]),
            {
              "class": 2,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.51564025878906, 48.44220864910131]),
            {
              "class": 2,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46139526367188, 48.473856281895074]),
            {
              "class": 2,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.74051666259766, 48.48751103469318]),
            {
              "class": 2,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.43289947509766, 48.402336338067435]),
            {
              "class": 2,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3199462890625, 48.410769067695085]),
            {
              "class": 2,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20458984375, 48.434692284261686]),
            {
              "class": 2,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.34200477600098, 48.457390378528935]),
            {
              "class": 2,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.36612319946289, 48.46888710340058]),
            {
              "class": 2,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.38500595092773, 48.47884503213417]),
            {
              "class": 2,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.37479209899902, 48.465529418326874]),
            {
              "class": 2,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.8365478515625, 48.53680942905274]),
            {
              "class": 2,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.1549072265625, 48.6947820435003]),
            {
              "class": 2,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.193359375, 48.92991234994968]),
            {
              "class": 2,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0343017578125, 48.259624443268805]),
            {
              "class": 2,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.138916015625, 47.842856551560565]),
            {
              "class": 2,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.78048706054688, 47.94215646305957]),
            {
              "class": 2,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.59715270996094, 47.9559537347249]),
            {
              "class": 2,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.41793823242188, 48.066658187813566]),
            {
              "class": 2,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.5799812078476, 47.821964754680344]),
            {
              "class": 2,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84433972835541, 47.7989076919623]),
            {
              "class": 2,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99540174007416, 47.79660142266394]),
            {
              "class": 2,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18721997737885, 47.76937971361346]),
            {
              "class": 2,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.14190137386322, 47.83763771031696]),
            {
              "class": 2,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.16318738460541, 47.670523709360296]),
            {
              "class": 2,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.12405395507812, 47.448572545535356]),
            {
              "class": 2,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.20645141601562, 47.375619823278214]),
            {
              "class": 2,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2874755859375, 47.354225996899615]),
            {
              "class": 2,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.49827575683594, 47.536260575220425]),
            {
              "class": 2,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.32730102539062, 47.556190317916155]),
            {
              "class": 2,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69352185726166, 47.49359474419457]),
            {
              "class": 2,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.56305921077728, 47.50704750026128]),
            {
              "class": 2,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.79033887386322, 47.631669148399794]),
            {
              "class": 2,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30213391780853, 47.45925140065436]),
            {
              "class": 2,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.25887525081635, 47.554800116642106]),
            {
              "class": 2,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.21973645687103, 47.59602707168144]),
            {
              "class": 2,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.08790588378906, 47.70565292855988]),
            {
              "class": 2,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.271240234375, 47.82334785292167]),
            {
              "class": 2,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.14695739746094, 47.86252032369468]),
            {
              "class": 2,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.67454528808594, 47.944916212066786]),
            {
              "class": 2,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.67557525634766, 48.11504531688755]),
            {
              "class": 2,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.62030029296875, 48.079504707755135]),
            {
              "class": 2,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.64158630371094, 48.08490872914642]),
            {
              "class": 2,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5970401763916, 48.12989885888654]),
            {
              "class": 2,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.63566398620605, 48.12405523378342]),
            {
              "class": 2,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.56219224631786, 48.13562725766383]),
            {
              "class": 2,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.61317567527294, 48.14490590752526]),
            {
              "class": 2,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.61961297690868, 48.13608550195944]),
            {
              "class": 2,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.64527635276318, 48.1372883737768]),
            {
              "class": 2,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58596734702587, 48.14983090112834]),
            {
              "class": 2,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.62871170043945, 48.18766909867078]),
            {
              "class": 2,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.64484786987305, 48.17994345061677]),
            {
              "class": 2,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65952491760254, 48.19979887744804]),
            {
              "class": 2,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.52828979492188, 48.272731792136696]),
            {
              "class": 2,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.11012268066406, 48.13360837769627]),
            {
              "class": 2,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.79495239257812, 48.13085871792627]),
            {
              "class": 2,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.06480407714844, 48.22060479200722]),
            {
              "class": 2,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.77641296386719, 48.26907526715596]),
            {
              "class": 2,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6287841796875, 48.39050706123037]),
            {
              "class": 2,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.05999755859375, 48.37591402472049]),
            {
              "class": 2,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.94034957885742, 48.399702826709145]),
            {
              "class": 2,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.87408828735352, 48.373938824750724]),
            {
              "class": 2,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.83580780029297, 48.337664788720794]),
            {
              "class": 2,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.77778625488281, 48.343255875974165]),
            {
              "class": 2,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70671844482422, 48.34896043492318]),
            {
              "class": 2,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.30434283614159, 48.31917560434469]),
            {
              "class": 2,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.25336074829102, 48.325681766722646]),
            {
              "class": 2,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31721878051758, 48.333442485245975]),
            {
              "class": 2,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.25730895996094, 48.35375171530966]),
            {
              "class": 2,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.27550506591797, 48.314380962116104]),
            {
              "class": 2,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.17714309692383, 48.35055754130601]),
            {
              "class": 2,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.28173828125, 47.45058021066994]),
            {
              "class": 2,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.69647216796875, 47.307372880163065]),
            {
              "class": 2,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89697265625, 47.016045851045405]),
            {
              "class": 2,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.80908203125, 46.73253323718993]),
            {
              "class": 2,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3089599609375, 46.78709871779294]),
            {
              "class": 2,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.75390625, 46.80214153980606]),
            {
              "class": 2,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8143310546875, 47.146966196317635]),
            {
              "class": 2,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.85003662109375, 47.36135286156281]),
            {
              "class": 2,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.02032470703125, 47.42828686235781]),
            {
              "class": 2,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.3201904296875, 47.08528625775099]),
            {
              "class": 2,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.89447021484375, 46.60814371586807]),
            {
              "class": 2,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58111572265625, 46.521278678919316]),
            {
              "class": 2,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.77337646484375, 46.674143508655085]),
            {
              "class": 2,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.11395263671875, 46.596821381470996]),
            {
              "class": 2,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.2705078125, 46.57039339905105]),
            {
              "class": 2,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5616455078125, 46.49292304912831]),
            {
              "class": 2,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.995849609375, 46.12676078683081]),
            {
              "class": 2,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6387939453125, 46.109626078650955]),
            {
              "class": 2,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.19659423828125, 46.18003469415884]),
            {
              "class": 2,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.59234619140625, 46.29591716458173]),
            {
              "class": 2,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.2432861328125, 46.40019157115768]),
            {
              "class": 2,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9356689453125, 46.511828445823475]),
            {
              "class": 2,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.996337890625, 46.398297448284396]),
            {
              "class": 2,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.80682373046875, 46.19524633869947]),
            {
              "class": 2,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.75164258480072, 47.045847605054774]),
            {
              "class": 2,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.52573621273041, 47.09635569662677]),
            {
              "class": 2,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.58135449886322, 47.13747504951527]),
            {
              "class": 2,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.38154065608978, 47.279744879466975]),
            {
              "class": 2,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.33347547054291, 47.234073485215454]),
            {
              "class": 2,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.65483093261719, 47.18696299229992]),
            {
              "class": 2,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.66856384277344, 47.2564482973005]),
            {
              "class": 2,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.19014224410057, 46.76210296351277]),
            {
              "class": 2,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.11855944991112, 46.773625849062405]),
            {
              "class": 2,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.99427661299706, 46.76551305378459]),
            {
              "class": 2,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.92458209395409, 46.796429189628526]),
            {
              "class": 2,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.91805896162987, 46.8286195144652]),
            {
              "class": 2,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.06345614790916, 46.82591814768718]),
            {
              "class": 2,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.15821322798729, 46.787967221384996]),
            {
              "class": 2,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.25846347212791, 46.760456635779974]),
            {
              "class": 2,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28833255171776, 46.7235186389132]),
            {
              "class": 2,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.16610965132713, 46.67795832765287]),
            {
              "class": 2,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.02345904707909, 46.65451570614636]),
            {
              "class": 2,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.98832082748413, 46.41913010805496]),
            {
              "class": 2,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.38956594467163, 46.728768982894145]),
            {
              "class": 2,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.09543752670288, 46.254152629073005]),
            {
              "class": 2,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.03226613998413, 46.128665243831676]),
            {
              "class": 2,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.25201016015625, 45.949445175437724]),
            {
              "class": 2,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.8974609375, 45.84048659904199]),
            {
              "class": 2,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.44976806640625, 45.873005388459305]),
            {
              "class": 2,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.172119140625, 45.88638995091943]),
            {
              "class": 2,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.941162109375, 45.98762559126485]),
            {
              "class": 2,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.77430725097656, 46.00082880633377]),
            {
              "class": 2,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.66650390625, 46.06756527701043]),
            {
              "class": 2,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96656799316406, 46.13326950081397]),
            {
              "class": 2,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.072998046875, 46.21410185525681]),
            {
              "class": 2,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.14372253417969, 46.01895095990418]),
            {
              "class": 2,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.28929138183594, 45.99271960477776]),
            {
              "class": 2,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.48179626464844, 45.966475810891396]),
            {
              "class": 2,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.47630310058594, 46.06851807129926]),
            {
              "class": 2,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.35614013671875, 46.15848292228206]),
            {
              "class": 2,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.42137145996094, 46.23737853580226]),
            {
              "class": 2,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.52711486816406, 46.2782076233974]),
            {
              "class": 2,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.25108337402344, 46.04326346576072]),
            {
              "class": 2,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.88990783691406, 45.95263339868413]),
            {
              "class": 2,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.5085700750351, 45.69999704828298]),
            {
              "class": 2,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.6404060125351, 45.814973889799866]),
            {
              "class": 2,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.65345227718353, 45.675533948065976]),
            {
              "class": 2,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95626294612885, 45.665937654991524]),
            {
              "class": 2,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18790662288666, 45.5742101683852]),
            {
              "class": 2,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96175611019135, 45.61504983247493]),
            {
              "class": 2,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.53672254085541, 45.597756661732866]),
            {
              "class": 2,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.03273010253906, 45.513616572006846]),
            {
              "class": 2,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.75875854492188, 45.50062375811265]),
            {
              "class": 2,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.67086791992188, 45.64145954320643]),
            {
              "class": 2,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.52255249023438, 45.64625999324296]),
            {
              "class": 2,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60769653320312, 45.47559211115832]),
            {
              "class": 2,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.25932312011719, 45.37197779794108]),
            {
              "class": 2,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29914855957031, 45.46355370589808]),
            {
              "class": 2,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.53398132324219, 45.39416243291975]),
            {
              "class": 2,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.00938415527344, 45.14432550629148]),
            {
              "class": 2,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.70451354980469, 45.23191769996776]),
            {
              "class": 2,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.59602355957031, 45.254640589577804]),
            {
              "class": 2,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.6392822265625, 45.43368736557809]),
            {
              "class": 2,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.14602661132812, 45.259957400215754]),
            {
              "class": 2,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.46943664550781, 45.19225174890171]),
            {
              "class": 2,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.59715270996094, 45.19757439777125]),
            {
              "class": 2,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.44564819335938, 45.23143425354609]),
            {
              "class": 2,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.21356201171875, 45.16127385373452]),
            {
              "class": 2,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.20394897460938, 45.27687133093921]),
            {
              "class": 2,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.1229248046875, 45.37824836892159]),
            {
              "class": 2,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.19982373714447, 45.05902372844602]),
            {
              "class": 2,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.07416760921478, 44.98573710094515]),
            {
              "class": 2,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.64751660823822, 45.06678370200075]),
            {
              "class": 2,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.55001294612885, 45.014383439912294]),
            {
              "class": 2,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.7230476140976, 45.01001458514469]),
            {
              "class": 2,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98877942562103, 44.988650942157406]),
            {
              "class": 2,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.51842725276947, 44.9356930636444]),
            {
              "class": 2,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.20439147949219, 44.961935305432426]),
            {
              "class": 2,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.06431579589844, 45.00176151315641]),
            {
              "class": 2,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.52024841308594, 44.94249784776207]),
            {
              "class": 2,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.75370788574219, 44.99739169561493]),
            {
              "class": 2,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.81207275390625, 45.08036123959492]),
            {
              "class": 2,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30513505637646, 48.146165841748925]),
            {
              "class": 2,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3459904640913, 48.147082138121995]),
            {
              "class": 2,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.27037362754345, 48.130930017828]),
            {
              "class": 2,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.32487611472607, 48.1256594183839]),
            {
              "class": 2,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30873994529247, 48.11769522523979]),
            {
              "class": 2,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31483191251755, 48.187401453275335]),
            {
              "class": 2,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.17200964689255, 48.07259823130012]),
            {
              "class": 2,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.34641760587692, 48.27407812411353]),
            {
              "class": 2,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31654852628708, 48.29212680402273]),
            {
              "class": 2,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15999335050583, 48.26333727606104]),
            {
              "class": 2,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.13252753019333, 48.19449661517568]),
            {
              "class": 2,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15347021818161, 48.16611007314807]),
            {
              "class": 2,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.36942291259766, 48.390254642338896]),
            {
              "class": 2,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.41096496582031, 48.41942830916411]),
            {
              "class": 2,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14248657226562, 48.41578257156608]),
            {
              "class": 2,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2894287109375, 48.461563861556776]),
            {
              "class": 2,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51670837402344, 48.4729458343484]),
            {
              "class": 2,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.18127936124802, 48.571406904280465]),
            {
              "class": 2,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.17235565185547, 48.593664794260164]),
            {
              "class": 2,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44873046875, 48.62113302179174]),
            {
              "class": 2,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1469497680664, 48.75440232065866]),
            {
              "class": 2,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.71607971191406, 48.87302019573711]),
            {
              "class": 2,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.70560836791992, 48.89277499115225]),
            {
              "class": 2,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64355278015137, 48.886397867300616]),
            {
              "class": 2,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.7389965057373, 48.8928314222459]),
            {
              "class": 2,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.80809020996094, 48.98612383153062]),
            {
              "class": 2,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.43043518066406, 48.78836743504344]),
            {
              "class": 2,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.43112182617188, 48.89185805961729]),
            {
              "class": 2,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8510993719101, 48.794248394819704]),
            {
              "class": 2,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0213874578476, 48.83720210400892]),
            {
              "class": 2,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.11889111995697, 48.85211425387205]),
            {
              "class": 2,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.11271131038666, 48.93111963683806]),
            {
              "class": 2,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94310986995697, 48.70052703401834]),
            {
              "class": 2,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85521924495697, 48.89411551550751]),
            {
              "class": 2,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87351453304291, 48.942846928290955]),
            {
              "class": 2,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.03443908691406, 48.96197412058102]),
            {
              "class": 2,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.59907913208008, 48.93660883366759]),
            {
              "class": 2,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.65229415893555, 48.9390895638402]),
            {
              "class": 2,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.51170349121094, 48.933000278784334]),
            {
              "class": 2,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.46895980834961, 48.869130850480154]),
            {
              "class": 2,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.59427261352539, 48.89802889922586]),
            {
              "class": 2,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.7290267944336, 48.869130850480154]),
            {
              "class": 2,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.44836044311523, 48.84518701325896]),
            {
              "class": 2,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.49882888793945, 48.854223769019896]),
            {
              "class": 2,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.37883758544922, 48.831402820553656]),
            {
              "class": 2,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.2986703813076, 48.81716270521263]),
            {
              "class": 2,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.25043353438377, 48.86404933456109]),
            {
              "class": 2,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.31617984175682, 48.89904448731573]),
            {
              "class": 2,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.32510623335838, 48.91720972903152]),
            {
              "class": 2,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.01302719116211, 48.87455045144273]),
            {
              "class": 2,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-94.98865127563477, 48.910892133091025]),
            {
              "class": 2,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-94.9991226196289, 48.82202288192415]),
            {
              "class": 2,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.03087997436523, 48.83027280049017]),
            {
              "class": 2,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.05851745605469, 48.765366928272655]),
            {
              "class": 2,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.0259017944336, 48.71963368702889]),
            {
              "class": 2,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.06229400634766, 48.74590142739869]),
            {
              "class": 2,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.0643539428711, 48.69391877773009]),
            {
              "class": 2,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.17009735107422, 48.715216641849665]),
            {
              "class": 2,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.20322799682617, 48.752013501566545]),
            {
              "class": 2,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.24700030684471, 48.76559322694598]),
            {
              "class": 2,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.35051211714745, 48.74103387366141]),
            {
              "class": 2,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.43205127120018, 48.73571298497826]),
            {
              "class": 2,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.47445297241211, 48.76717728910655]),
            {
              "class": 2,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.54500579833984, 48.77724623008387]),
            {
              "class": 2,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.53109988570213, 48.702529637897925]),
            {
              "class": 2,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.54689273238182, 48.672385182860026]),
            {
              "class": 2,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.67958697676659, 48.673858827505484]),
            {
              "class": 2,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.70876941084862, 48.66841746380792]),
            {
              "class": 2,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.72662353515625, 48.70966644356008]),
            {
              "class": 2,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.811767578125, 48.69697804013548]),
            {
              "class": 2,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.85090637207031, 48.69709134360484]),
            {
              "class": 2,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.88249206542969, 48.71238497098384]),
            {
              "class": 2,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98154067993164, 48.72891948738206]),
            {
              "class": 2,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02582931518555, 48.767856102347544]),
            {
              "class": 2,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.05810165405273, 48.744203441806555]),
            {
              "class": 2,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.18100985884666, 48.70026376487159]),
            {
              "class": 2,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.09415054321289, 48.74442989110246]),
            {
              "class": 2,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.21637210249901, 48.77079781498604]),
            {
              "class": 2,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.37584552168846, 48.69312559810625]),
            {
              "class": 2,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.44451007246971, 48.69187914773605]),
            {
              "class": 2,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57548770308495, 48.72914600553646]),
            {
              "class": 2,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52244433760643, 48.7781512045192]),
            {
              "class": 2,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.62578582763672, 48.720086667725205]),
            {
              "class": 2,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.65119171142578, 48.68337977236313]),
            {
              "class": 2,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94473132491112, 48.748957557413625]),
            {
              "class": 2,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03554153442383, 48.77950863558173]),
            {
              "class": 2,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09562301635742, 48.79364635978346]),
            {
              "class": 2,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.16411590576172, 48.80789315501187]),
            {
              "class": 2,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.36358508467674, 48.868792102481514]),
            {
              "class": 2,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5644302368164, 48.877485908497086]),
            {
              "class": 2,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.77831897139549, 48.86811459960431]),
            {
              "class": 2,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88028717041016, 48.861226077827055]),
            {
              "class": 2,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.97332763671875, 48.89204741560964]),
            {
              "class": 2,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92011260986328, 48.92081942516044]),
            {
              "class": 2,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13108310103416, 48.952280466667354]),
            {
              "class": 2,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.86669921875, 48.48222147649899]),
            {
              "class": 2,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60449981689453, 48.162127410068045]),
            {
              "class": 2,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.77169799804688, 48.1958945104102]),
            {
              "class": 2,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17912292480469, 48.11710821049372]),
            {
              "class": 2,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.99235534667969, 48.25170448401726]),
            {
              "class": 2,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.99098205566406, 48.327088395421754]),
            {
              "class": 2,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.009521484375, 48.39050728387052]),
            {
              "class": 2,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.80215454101562, 48.32343598464593]),
            {
              "class": 2,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95046997070312, 47.94951546632721]),
            {
              "class": 2,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.4107666015625, 48.02580330652647]),
            {
              "class": 2,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.43960571289062, 48.12444227253951]),
            {
              "class": 2,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.30845642089844, 47.90764716818545]),
            {
              "class": 2,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.24253845214844, 48.06390494484469]),
            {
              "class": 2,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.61813354492188, 47.79706268471334]),
            {
              "class": 2,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.32356262207031, 47.80997635960589]),
            {
              "class": 2,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.43754577636719, 47.882325718619164]),
            {
              "class": 2,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.3009033203125, 47.96377055367347]),
            {
              "class": 2,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95939636230469, 47.91317020255259]),
            {
              "class": 2,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.14152908325195, 47.67892403070675]),
            {
              "class": 2,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.00334167480469, 47.69567999710733]),
            {
              "class": 2,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13534927368164, 47.7283675166199]),
            {
              "class": 2,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02256774902344, 47.63915046666514]),
            {
              "class": 2,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02874755859375, 47.67037069177346]),
            {
              "class": 2,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.10393524169922, 47.61635948671391]),
            {
              "class": 2,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17568969726562, 47.6470150967414]),
            {
              "class": 2,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.87081909179688, 47.60987896195349]),
            {
              "class": 2,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.86103439331055, 47.57989640610176]),
            {
              "class": 2,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.75065612792969, 47.57619079825278]),
            {
              "class": 2,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.89330673217773, 47.55093936550389]),
            {
              "class": 2,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98360061645508, 47.53471643038303]),
            {
              "class": 2,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.80026626586914, 47.46965841449653]),
            {
              "class": 2,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.65109252929688, 47.50492266088686]),
            {
              "class": 2,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.64680099487305, 47.46548084576467]),
            {
              "class": 2,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.56131362915039, 47.45863351035011]),
            {
              "class": 2,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.77159881591797, 47.45724072281708]),
            {
              "class": 2,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.85262298583984, 47.42902880873865]),
            {
              "class": 2,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.97484588623047, 47.44145319058115]),
            {
              "class": 2,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.82206726074219, 47.38337015610732]),
            {
              "class": 2,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9271240234375, 47.39789692049072]),
            {
              "class": 2,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.07389450073242, 47.32208126038236]),
            {
              "class": 2,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.96780776977539, 47.31521526779432]),
            {
              "class": 2,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.01432800292969, 47.29484478744069]),
            {
              "class": 2,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17294311523438, 47.26996146830827]),
            {
              "class": 2,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.26358032226562, 47.27694980370269]),
            {
              "class": 2,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.35421752929688, 47.49309321741805]),
            {
              "class": 2,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30786895751953, 47.507937582949396]),
            {
              "class": 2,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.28040313720703, 47.540974414684875]),
            {
              "class": 2,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.32366180419922, 47.53819316796519]),
            {
              "class": 2,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.31010055541992, 47.57074768297168]),
            {
              "class": 2,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.14238739013672, 47.48010095451986]),
            {
              "class": 2,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30203247070312, 47.46397215911473]),
            {
              "class": 2,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.16830691695213, 47.5111842284301]),
            {
              "class": 2,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.20572909712791, 47.53054397873189]),
            {
              "class": 2,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.11080035567284, 47.56020733186106]),
            {
              "class": 2,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.10668048262596, 47.54804275271702]),
            {
              "class": 2,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.25482559204102, 47.64805591493897]),
            {
              "class": 2,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.31765365600586, 47.676381332266345]),
            {
              "class": 2,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41756057739258, 47.717166032950395]),
            {
              "class": 2,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.26924514770508, 47.720977136492465]),
            {
              "class": 2,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.20641708374023, 47.723402239051914]),
            {
              "class": 2,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61788940429688, 47.7680449805238]),
            {
              "class": 2,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.5975341796875, 47.20007792643334]),
            {
              "class": 2,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.56697845458984, 47.30230809209667]),
            {
              "class": 2,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.6960678100586, 47.30603304055759]),
            {
              "class": 2,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.39875030517578, 47.264811131961395]),
            {
              "class": 2,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.48389434814453, 47.23358226227743]),
            {
              "class": 2,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.40999412536621, 47.22417952505301]),
            {
              "class": 2,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.3954029083252, 47.235603199173944]),
            {
              "class": 2,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.34905433654785, 47.235778032197]),
            {
              "class": 2,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.63873291015625, 47.16927747752561]),
            {
              "class": 2,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.4883548617363, 47.05096889451649]),
            {
              "class": 2,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.67134588956833, 47.063131456544184]),
            {
              "class": 2,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.6919452548027, 47.12039851019931]),
            {
              "class": 2,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.35480231046677, 47.10310801320312]),
            {
              "class": 2,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.22811889648438, 47.02640136117949]),
            {
              "class": 2,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.11688232421875, 47.0844092077392]),
            {
              "class": 2,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.08975982666016, 47.13254517161803]),
            {
              "class": 2,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.26451110839844, 47.15239441199544]),
            {
              "class": 2,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.34107208251953, 46.93247289867062]),
            {
              "class": 2,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.18383026123047, 46.97488996727415]),
            {
              "class": 2,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.50140380859375, 46.96294159846763]),
            {
              "class": 2,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.39360046386719, 46.98941184056507]),
            {
              "class": 2,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.4330825805664, 47.01305999403548]),
            {
              "class": 2,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.60920715332031, 47.051670599086854]),
            {
              "class": 2,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.06778717041016, 46.95544321995638]),
            {
              "class": 2,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.1485538482666, 46.87909198929459]),
            {
              "class": 2,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.11387825012207, 46.887129002437156]),
            {
              "class": 2,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.1924991607666, 46.848105960918566]),
            {
              "class": 2,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.28528146445751, 46.85438678579445]),
            {
              "class": 2,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.32296113669872, 46.85614762887697]),
            {
              "class": 2,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.35394601523876, 46.85333025223053]),
            {
              "class": 2,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.13404309749603, 46.78788773492106]),
            {
              "class": 2,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.43085098266602, 46.73152006848421]),
            {
              "class": 2,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.43325424194336, 46.763396442731086]),
            {
              "class": 2,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.48852920532227, 46.75081282009223]),
            {
              "class": 2,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.52938461303711, 46.78056187905694]),
            {
              "class": 2,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.44252395629883, 46.79736929750397]),
            {
              "class": 2,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.50037384033203, 46.83789705946848]),
            {
              "class": 2,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.67306518554688, 46.85515613000145]),
            {
              "class": 2,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.75031280517578, 46.81287917945038]),
            {
              "class": 2,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.84352493286133, 46.81593362905638]),
            {
              "class": 2,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.82756042480469, 46.81499381688629]),
            {
              "class": 2,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91562271118164, 46.802069733954774]),
            {
              "class": 2,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.86721420288086, 46.81969271348924]),
            {
              "class": 2,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.87133407592773, 46.8482296862432]),
            {
              "class": 2,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.81399917602539, 46.838014486844926]),
            {
              "class": 2,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.82086563110352, 46.855508298191694]),
            {
              "class": 2,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.83700180053711, 46.859968895365945]),
            {
              "class": 2,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91888427734375, 46.80159970878819]),
            {
              "class": 2,
              "system:index": "780"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91270446777344, 46.78914254561918]),
            {
              "class": 2,
              "system:index": "781"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.96162796020508, 46.84552930516045]),
            {
              "class": 2,
              "system:index": "782"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02960586547852, 46.85891247162846]),
            {
              "class": 2,
              "system:index": "783"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1794662475586, 46.79607660549051]),
            {
              "class": 2,
              "system:index": "784"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.20006561279297, 46.841067508557096]),
            {
              "class": 2,
              "system:index": "785"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1054801940918, 46.82098483806877]),
            {
              "class": 2,
              "system:index": "786"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65859985351562, 47.10637956210674]),
            {
              "class": 2,
              "system:index": "787"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01599884033203, 47.10240687157063]),
            {
              "class": 2,
              "system:index": "788"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.70460510253906, 47.18997089660989]),
            {
              "class": 2,
              "system:index": "789"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14989471435547, 47.234747849319476]),
            {
              "class": 2,
              "system:index": "790"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.23332214355469, 47.24267316131241]),
            {
              "class": 2,
              "system:index": "791"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03487890958786, 47.329308021903046]),
            {
              "class": 2,
              "system:index": "792"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81343573331833, 47.373734745582276]),
            {
              "class": 2,
              "system:index": "793"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.79970282316208, 47.494265515674314]),
            {
              "class": 2,
              "system:index": "794"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65962713956833, 47.52603590234076]),
            {
              "class": 2,
              "system:index": "795"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.50170135498047, 47.5929921150476]),
            {
              "class": 2,
              "system:index": "796"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.59027862548828, 47.63765916846027]),
            {
              "class": 2,
              "system:index": "797"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85807037353516, 47.65269388793359]),
            {
              "class": 2,
              "system:index": "798"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72623443603516, 47.55755536735986]),
            {
              "class": 2,
              "system:index": "799"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19795989990234, 47.60549358996346]),
            {
              "class": 2,
              "system:index": "800"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98956298828125, 47.67604694310578]),
            {
              "class": 2,
              "system:index": "801"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8831302523613, 47.76866254953467]),
            {
              "class": 2,
              "system:index": "802"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.09667700529099, 47.78458227877158]),
            {
              "class": 2,
              "system:index": "803"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33116644620895, 47.7707393123811]),
            {
              "class": 2,
              "system:index": "804"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.69406127929688, 47.814793168652265]),
            {
              "class": 2,
              "system:index": "805"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.78778839111328, 47.65107508514425]),
            {
              "class": 2,
              "system:index": "806"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.62848663330078, 47.647605811046894]),
            {
              "class": 2,
              "system:index": "807"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00150680541992, 47.61259235458026]),
            {
              "class": 2,
              "system:index": "808"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.02957344055176, 47.61936175948206]),
            {
              "class": 2,
              "system:index": "809"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07798194885254, 47.626766600330285]),
            {
              "class": 2,
              "system:index": "810"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.12063980102539, 47.62578320530697]),
            {
              "class": 2,
              "system:index": "811"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.13978004455566, 47.63521143818887]),
            {
              "class": 2,
              "system:index": "812"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.86204528808594, 47.507022474341134]),
            {
              "class": 2,
              "system:index": "813"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.66017150878906, 47.53924868634739]),
            {
              "class": 2,
              "system:index": "814"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.56232452392578, 47.52649967437693]),
            {
              "class": 2,
              "system:index": "815"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.67768096923828, 47.507022474341134]),
            {
              "class": 2,
              "system:index": "816"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3769302368164, 47.50679055936418]),
            {
              "class": 2,
              "system:index": "817"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.66463470458984, 47.5619574265075]),
            {
              "class": 2,
              "system:index": "818"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7992172241211, 47.54712834355556]),
            {
              "class": 2,
              "system:index": "819"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.30242919921875, 47.59183454349804]),
            {
              "class": 2,
              "system:index": "820"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.03978729248047, 47.59507599585039]),
            {
              "class": 2,
              "system:index": "821"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0473403930664, 47.413710055715576]),
            {
              "class": 2,
              "system:index": "822"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.86812591552734, 47.404416178002904]),
            {
              "class": 2,
              "system:index": "823"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8159408569336, 47.301376813969775]),
            {
              "class": 2,
              "system:index": "824"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56497192382812, 47.247334612690636]),
            {
              "class": 2,
              "system:index": "825"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8818588256836, 47.194403634737924]),
            {
              "class": 2,
              "system:index": "826"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99137878417969, 47.202801491642]),
            {
              "class": 2,
              "system:index": "827"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.69371795654297, 47.165000668124]),
            {
              "class": 2,
              "system:index": "828"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.59724426269531, 47.17620371826354]),
            {
              "class": 2,
              "system:index": "829"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47879791259766, 47.1808709583771]),
            {
              "class": 2,
              "system:index": "830"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.44720953702927, 47.231484140995775]),
            {
              "class": 2,
              "system:index": "831"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8546371459961, 47.239876127736295]),
            {
              "class": 2,
              "system:index": "832"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.67233008146286, 47.29159740319221]),
            {
              "class": 2,
              "system:index": "833"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66203039884567, 47.33233301644235]),
            {
              "class": 2,
              "system:index": "834"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.646240234375, 47.4318283437044]),
            {
              "class": 2,
              "system:index": "835"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.69670867919922, 47.433686339593365]),
            {
              "class": 2,
              "system:index": "836"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00304907560349, 46.42131807419779]),
            {
              "class": 2,
              "system:index": "837"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.33195227384567, 46.376806041416174]),
            {
              "class": 2,
              "system:index": "838"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3992435336113, 46.488018041878554]),
            {
              "class": 2,
              "system:index": "839"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84615057706833, 46.43054740568826]),
            {
              "class": 2,
              "system:index": "840"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.4146957397461, 46.30214325534737]),
            {
              "class": 2,
              "system:index": "841"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.59494018554688, 46.320640666193775]),
            {
              "class": 2,
              "system:index": "842"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23204803466797, 46.266553740117395]),
            {
              "class": 2,
              "system:index": "843"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.964599609375, 46.33083534155604]),
            {
              "class": 2,
              "system:index": "844"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.64599609375, 46.347190118218016]),
            {
              "class": 2,
              "system:index": "845"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56840515136719, 46.362118520978235]),
            {
              "class": 2,
              "system:index": "846"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.37202453613281, 46.332020581016316]),
            {
              "class": 2,
              "system:index": "847"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14062231779099, 46.25587237697149]),
            {
              "class": 2,
              "system:index": "848"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.37511444091797, 46.16416453305713]),
            {
              "class": 2,
              "system:index": "849"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35711669921875, 46.025780621392215]),
            {
              "class": 2,
              "system:index": "850"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.810546875, 46.172428221984994]),
            {
              "class": 2,
              "system:index": "851"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7169189453125, 46.55150930317848]),
            {
              "class": 2,
              "system:index": "852"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.37310791015625, 46.55528683261572]),
            {
              "class": 2,
              "system:index": "853"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.93757629394531, 46.45494031729237]),
            {
              "class": 2,
              "system:index": "854"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.843505859375, 46.60563329742772]),
            {
              "class": 2,
              "system:index": "855"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.77690124511719, 46.590535626147414]),
            {
              "class": 2,
              "system:index": "856"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.74050903320312, 46.624499471027995]),
            {
              "class": 2,
              "system:index": "857"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.09275817871094, 46.600915727038064]),
            {
              "class": 2,
              "system:index": "858"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.38595581054688, 46.57779369389422]),
            {
              "class": 2,
              "system:index": "859"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.21635437011719, 46.37777904346903]),
            {
              "class": 2,
              "system:index": "860"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.67665100097656, 46.378726469197325]),
            {
              "class": 2,
              "system:index": "861"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94856262207031, 46.22645409204479]),
            {
              "class": 2,
              "system:index": "862"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.151123046875, 46.2255040275644]),
            {
              "class": 2,
              "system:index": "863"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3294792175293, 46.26547292044062]),
            {
              "class": 2,
              "system:index": "864"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41359329223633, 46.266659633513974]),
            {
              "class": 2,
              "system:index": "865"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.26270294189453, 46.25170517133254]),
            {
              "class": 2,
              "system:index": "866"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22081756591797, 46.2680836552909]),
            {
              "class": 2,
              "system:index": "867"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23351916670799, 46.216676786519734]),
            {
              "class": 2,
              "system:index": "868"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.2529169023037, 46.17425660271754]),
            {
              "class": 2,
              "system:index": "869"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35797366499901, 46.169977119581034]),
            {
              "class": 2,
              "system:index": "870"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.40054568648338, 46.237815232945515]),
            {
              "class": 2,
              "system:index": "871"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26171875, 46.5041149402089]),
            {
              "class": 2,
              "system:index": "872"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47526550292969, 46.53577124512216]),
            {
              "class": 2,
              "system:index": "873"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93144226074219, 46.52301644540045]),
            {
              "class": 2,
              "system:index": "874"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80097961425781, 46.54993973200908]),
            {
              "class": 2,
              "system:index": "875"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13949584960938, 46.639116177324155]),
            {
              "class": 2,
              "system:index": "876"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.48075866699219, 46.630629504725576]),
            {
              "class": 2,
              "system:index": "877"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74237060546875, 46.41708333896576]),
            {
              "class": 2,
              "system:index": "878"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87702560424805, 46.49994114962096]),
            {
              "class": 2,
              "system:index": "879"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.68184661865234, 46.434083951523796]),
            {
              "class": 2,
              "system:index": "880"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.67601013183594, 46.52982842859307]),
            {
              "class": 2,
              "system:index": "881"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87359237670898, 46.57669353177407]),
            {
              "class": 2,
              "system:index": "882"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94534549117088, 46.62257495373906]),
            {
              "class": 2,
              "system:index": "883"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.14876556396484, 46.71575135381589]),
            {
              "class": 2,
              "system:index": "884"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.15288543701172, 46.75833982606322]),
            {
              "class": 2,
              "system:index": "885"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20180892944336, 46.79572404773359]),
            {
              "class": 2,
              "system:index": "886"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24180468916893, 46.79102308561676]),
            {
              "class": 2,
              "system:index": "887"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58341082930565, 46.838601648546145]),
            {
              "class": 2,
              "system:index": "888"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40728625655174, 46.88191435907569]),
            {
              "class": 2,
              "system:index": "889"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.28472137451172, 46.98366124974494]),
            {
              "class": 2,
              "system:index": "890"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30429077148438, 47.01082353510817]),
            {
              "class": 2,
              "system:index": "891"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20266723632812, 47.04475697589583]),
            {
              "class": 2,
              "system:index": "892"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3525276184082, 47.035632171250434]),
            {
              "class": 2,
              "system:index": "893"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.28369140625, 47.093396245776766]),
            {
              "class": 2,
              "system:index": "894"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18704605102539, 47.11431144749684]),
            {
              "class": 2,
              "system:index": "895"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24953079223633, 47.12505799246432]),
            {
              "class": 2,
              "system:index": "896"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30841064453125, 47.13136473620352]),
            {
              "class": 2,
              "system:index": "897"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39767456054688, 47.161836789467024]),
            {
              "class": 2,
              "system:index": "898"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4378433227539, 47.14537704505201]),
            {
              "class": 2,
              "system:index": "899"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26910018920898, 47.16872268734972]),
            {
              "class": 2,
              "system:index": "900"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.93031311035156, 46.87852430623076]),
            {
              "class": 2,
              "system:index": "901"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81838989257812, 46.881809688934595]),
            {
              "class": 2,
              "system:index": "902"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78096771240234, 46.909961860044746]),
            {
              "class": 2,
              "system:index": "903"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.75762176513672, 46.88204435142974]),
            {
              "class": 2,
              "system:index": "904"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.75762176513672, 46.856225323601564]),
            {
              "class": 2,
              "system:index": "905"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.80465698242188, 46.860216348388164]),
            {
              "class": 2,
              "system:index": "906"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85443878173828, 46.861624874546735]),
            {
              "class": 2,
              "system:index": "907"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85134887695312, 46.830393875659034]),
            {
              "class": 2,
              "system:index": "908"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85752868652344, 46.81441913177815]),
            {
              "class": 2,
              "system:index": "909"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8115234375, 46.822876940410055]),
            {
              "class": 2,
              "system:index": "910"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.90971374511719, 46.822876940410055]),
            {
              "class": 2,
              "system:index": "911"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.80980682373047, 46.794679071105875]),
            {
              "class": 2,
              "system:index": "912"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.70818328857422, 46.87828962833961]),
            {
              "class": 2,
              "system:index": "913"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.844482421875, 46.88673738579027]),
            {
              "class": 2,
              "system:index": "914"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81529998779297, 46.92919067685434]),
            {
              "class": 2,
              "system:index": "915"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.83624267578125, 46.96012988687806]),
            {
              "class": 2,
              "system:index": "916"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.75556182861328, 47.071316120183305]),
            {
              "class": 2,
              "system:index": "917"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.95537567138672, 47.10918357870688]),
            {
              "class": 2,
              "system:index": "918"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.08205908536911, 47.17573691471185]),
            {
              "class": 2,
              "system:index": "919"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03125, 47.30929226881667]),
            {
              "class": 2,
              "system:index": "920"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23552703857422, 47.333961901503514]),
            {
              "class": 2,
              "system:index": "921"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05528259277344, 47.42788017524657]),
            {
              "class": 2,
              "system:index": "922"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4655532836914, 47.387450737057165]),
            {
              "class": 2,
              "system:index": "923"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63978958129883, 47.595809681214135]),
            {
              "class": 2,
              "system:index": "924"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73789405822754, 47.62109739141243]),
            {
              "class": 2,
              "system:index": "925"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.79488563537598, 47.63943341599855]),
            {
              "class": 2,
              "system:index": "926"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88552284240723, 47.65105633903499]),
            {
              "class": 2,
              "system:index": "927"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98860549926758, 47.67886009087985]),
            {
              "class": 2,
              "system:index": "928"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.90071487426758, 47.67747314733626]),
            {
              "class": 2,
              "system:index": "929"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95109748840332, 47.65943952617512]),
            {
              "class": 2,
              "system:index": "930"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13211441040039, 47.61525390630595]),
            {
              "class": 2,
              "system:index": "931"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.45297622680664, 48.31323943898042]),
            {
              "class": 2,
              "system:index": "932"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5739974975586, 48.3334425966908]),
            {
              "class": 2,
              "system:index": "933"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.40388107299805, 48.34542362788125]),
            {
              "class": 2,
              "system:index": "934"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.41332244873047, 48.39126837351423]),
            {
              "class": 2,
              "system:index": "935"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.34791946411133, 48.43445215241746]),
            {
              "class": 2,
              "system:index": "936"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.30878067016602, 48.44800364495805]),
            {
              "class": 2,
              "system:index": "937"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.28011322021484, 48.483288877213425]),
            {
              "class": 2,
              "system:index": "938"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44559478759766, 48.466104618841975]),
            {
              "class": 2,
              "system:index": "939"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50104141235352, 48.45039470953119]),
            {
              "class": 2,
              "system:index": "940"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25367736816406, 48.431035239155314]),
            {
              "class": 2,
              "system:index": "941"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.17024993896484, 48.449597811706866]),
            {
              "class": 2,
              "system:index": "942"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11737823486328, 48.44196866399113]),
            {
              "class": 2,
              "system:index": "943"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07532119750977, 48.45107796134672]),
            {
              "class": 2,
              "system:index": "944"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99910354614258, 48.386024449751744]),
            {
              "class": 2,
              "system:index": "945"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99755859375, 48.36800897852025]),
            {
              "class": 2,
              "system:index": "946"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99773025512695, 48.35500651460048]),
            {
              "class": 2,
              "system:index": "947"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0198745727539, 48.33036116485347]),
            {
              "class": 2,
              "system:index": "948"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89387512207031, 48.33207303250341]),
            {
              "class": 2,
              "system:index": "949"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07823944091797, 48.339832778404954]),
            {
              "class": 2,
              "system:index": "950"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07566452026367, 48.324083936586426]),
            {
              "class": 2,
              "system:index": "951"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01472473144531, 48.283776434468905]),
            {
              "class": 2,
              "system:index": "952"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99069213867188, 48.26995265616277]),
            {
              "class": 2,
              "system:index": "953"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07463455200195, 48.239321383447255]),
            {
              "class": 2,
              "system:index": "954"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11343002319336, 48.25303914750075]),
            {
              "class": 2,
              "system:index": "955"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.10364532470703, 48.22308394294554]),
            {
              "class": 2,
              "system:index": "956"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0609016418457, 48.201235204029025]),
            {
              "class": 2,
              "system:index": "957"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89439010620117, 48.183268880155026]),
            {
              "class": 2,
              "system:index": "958"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84580993652344, 48.19688724485517]),
            {
              "class": 2,
              "system:index": "959"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90623474121094, 48.10515096140574]),
            {
              "class": 2,
              "system:index": "960"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.76238250732422, 48.03391675722756]),
            {
              "class": 2,
              "system:index": "961"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.75259780883789, 48.00314429716694]),
            {
              "class": 2,
              "system:index": "962"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.79499816894531, 47.960859647532565]),
            {
              "class": 2,
              "system:index": "963"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.80958938598633, 47.986142677940954]),
            {
              "class": 2,
              "system:index": "964"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.72152709960938, 47.920150965795585]),
            {
              "class": 2,
              "system:index": "965"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67723846435547, 47.9551117777747]),
            {
              "class": 2,
              "system:index": "966"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.62625503540039, 47.90105054311098]),
            {
              "class": 2,
              "system:index": "967"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.55587387084961, 47.94269419670841]),
            {
              "class": 2,
              "system:index": "968"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.99402618408203, 48.029681689154046]),
            {
              "class": 2,
              "system:index": "969"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82064819335938, 48.062732844979564]),
            {
              "class": 2,
              "system:index": "970"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16568756103516, 48.09415766111924]),
            {
              "class": 2,
              "system:index": "971"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.3497085571289, 48.09966076263194]),
            {
              "class": 2,
              "system:index": "972"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01565551757812, 48.11662495107189]),
            {
              "class": 2,
              "system:index": "973"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9820072054863, 48.25305142575195]),
            {
              "class": 2,
              "system:index": "974"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1831111907959, 48.22662294986314]),
            {
              "class": 2,
              "system:index": "975"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12320137023926, 48.22565089417079]),
            {
              "class": 2,
              "system:index": "976"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.41348075866699, 48.26069038204292]),
            {
              "class": 2,
              "system:index": "977"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.44103240966797, 48.28824339362608]),
            {
              "class": 2,
              "system:index": "978"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.5584487915039, 48.29920739939945]),
            {
              "class": 2,
              "system:index": "979"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.48772430419922, 48.35969547415076]),
            {
              "class": 2,
              "system:index": "980"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.63912963867188, 48.35558912130858]),
            {
              "class": 2,
              "system:index": "981"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10491943359375, 48.337334659615735]),
            {
              "class": 2,
              "system:index": "982"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16328430175781, 48.317018887699085]),
            {
              "class": 2,
              "system:index": "983"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5641860961914, 48.33185704612032]),
            {
              "class": 2,
              "system:index": "984"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40694427490234, 48.31656226052406]),
            {
              "class": 2,
              "system:index": "985"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.16627502441406, 48.59366501601007]),
            {
              "class": 2,
              "system:index": "986"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09304809570312, 47.92743553790226]),
            {
              "class": 2,
              "system:index": "987"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02987670898438, 47.91132948131752]),
            {
              "class": 2,
              "system:index": "988"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.37577438354492, 47.94913337102125]),
            {
              "class": 2,
              "system:index": "989"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39362716674805, 47.9563764201205]),
            {
              "class": 2,
              "system:index": "990"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28548049926758, 47.97315799651115]),
            {
              "class": 2,
              "system:index": "991"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.45302200317383, 47.96764125526193]),
            {
              "class": 2,
              "system:index": "992"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.49576568603516, 47.94142921951415]),
            {
              "class": 2,
              "system:index": "993"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24891528487206, 47.99039355183623]),
            {
              "class": 2,
              "system:index": "994"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28359088301659, 47.965572367450065]),
            {
              "class": 2,
              "system:index": "995"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.17458590865135, 47.94878832631502]),
            {
              "class": 2,
              "system:index": "996"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05648422241211, 47.94027937673302]),
            {
              "class": 2,
              "system:index": "997"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02369689941406, 47.94533898774854]),
            {
              "class": 2,
              "system:index": "998"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9931411743164, 47.90691955166546]),
            {
              "class": 2,
              "system:index": "999"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05545425415039, 47.909220919970316]),
            {
              "class": 2,
              "system:index": "1000"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.07708358764648, 47.88769913156925]),
            {
              "class": 2,
              "system:index": "1001"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.10317611694336, 47.915549155164406]),
            {
              "class": 2,
              "system:index": "1002"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03365325927734, 47.87526535997529]),
            {
              "class": 2,
              "system:index": "1003"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04772815108299, 47.9699399223029]),
            {
              "class": 2,
              "system:index": "1004"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.16360092163086, 47.971434001016185]),
            {
              "class": 2,
              "system:index": "1005"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.84019088745117, 47.82112056039781]),
            {
              "class": 2,
              "system:index": "1006"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78045272827148, 47.78526188386021]),
            {
              "class": 2,
              "system:index": "1007"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6353988647461, 47.765188642547095]),
            {
              "class": 2,
              "system:index": "1008"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.74938201904297, 47.75676480272586]),
            {
              "class": 2,
              "system:index": "1009"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6302490234375, 47.74857038819113]),
            {
              "class": 2,
              "system:index": "1010"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48210525512695, 47.79160520581653]),
            {
              "class": 2,
              "system:index": "1011"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45618438720703, 47.82653768533521]),
            {
              "class": 2,
              "system:index": "1012"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.405029296875, 47.87296248218387]),
            {
              "class": 2,
              "system:index": "1013"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30317497253418, 48.000611158452394]),
            {
              "class": 2,
              "system:index": "1014"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27090263366699, 48.00767471982271]),
            {
              "class": 2,
              "system:index": "1015"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18592958152294, 47.98912368376118]),
            {
              "class": 2,
              "system:index": "1016"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13142776489258, 47.99486776883647]),
            {
              "class": 2,
              "system:index": "1017"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.09057235717773, 47.98481520035729]),
            {
              "class": 2,
              "system:index": "1018"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.12207221984863, 48.02248782821937]),
            {
              "class": 2,
              "system:index": "1019"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.08173179626465, 48.038616643590466]),
            {
              "class": 2,
              "system:index": "1020"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02611351013184, 48.04647838414992]),
            {
              "class": 2,
              "system:index": "1021"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87548065185547, 48.036722773843465]),
            {
              "class": 2,
              "system:index": "1022"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95985154807568, 48.018124775131554]),
            {
              "class": 2,
              "system:index": "1023"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98457078635693, 48.00899549710106]),
            {
              "class": 2,
              "system:index": "1024"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.97367095947266, 47.99084697641884]),
            {
              "class": 2,
              "system:index": "1025"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94157028198242, 47.99659086968051]),
            {
              "class": 2,
              "system:index": "1026"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84732818603516, 47.98090847508953]),
            {
              "class": 2,
              "system:index": "1027"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92865259572864, 47.93643030839997]),
            {
              "class": 2,
              "system:index": "1028"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93603420257568, 47.937494089912384]),
            {
              "class": 2,
              "system:index": "1029"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.01735877990723, 47.91087996549219]),
            {
              "class": 2,
              "system:index": "1030"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0821180343628, 47.89842300090045]),
            {
              "class": 2,
              "system:index": "1031"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00263848155737, 47.84214227181966]),
            {
              "class": 2,
              "system:index": "1032"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.05724859237671, 47.791969184622836]),
            {
              "class": 2,
              "system:index": "1033"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.17580223083496, 47.764663178491354]),
            {
              "class": 2,
              "system:index": "1034"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.06259088218212, 47.71282864906465]),
            {
              "class": 2,
              "system:index": "1035"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.11511993408203, 47.66706985322914]),
            {
              "class": 2,
              "system:index": "1036"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13417367637157, 47.690127612254614]),
            {
              "class": 2,
              "system:index": "1037"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.12071681022644, 48.46300331080852]),
            {
              "class": 2,
              "system:index": "1038"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.25529932975769, 48.40468926546645]),
            {
              "class": 2,
              "system:index": "1039"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.43794703483582, 48.62574513851536]),
            {
              "class": 2,
              "system:index": "1040"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.00398707389832, 48.185415318156444]),
            {
              "class": 2,
              "system:index": "1041"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.60710597038269, 48.36273470173617]),
            {
              "class": 2,
              "system:index": "1042"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.02483057975769, 48.448431073805]),
            {
              "class": 2,
              "system:index": "1043"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.5384521484375, 48.12678318638512]),
            {
              "class": 2,
              "system:index": "1044"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.8131103515625, 48.03687286466413]),
            {
              "class": 2,
              "system:index": "1045"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.88177490234375, 47.90631576265461]),
            {
              "class": 2,
              "system:index": "1046"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.71835327148438, 47.576625458550936]),
            {
              "class": 2,
              "system:index": "1047"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.91336059570312, 47.77081378676538]),
            {
              "class": 2,
              "system:index": "1048"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.1759033203125, 47.669186215489624]),
            {
              "class": 2,
              "system:index": "1049"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.60049438476562, 47.57014006758082]),
            {
              "class": 2,
              "system:index": "1050"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.30935668945312, 47.90079222154591]),
            {
              "class": 2,
              "system:index": "1051"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.137451171875, 48.21196094562526]),
            {
              "class": 2,
              "system:index": "1052"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.88177490234375, 48.42747615512281]),
            {
              "class": 2,
              "system:index": "1053"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.115234375, 48.32439815631672]),
            {
              "class": 2,
              "system:index": "1054"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.24981689453125, 48.54307585983849]),
            {
              "class": 2,
              "system:index": "1055"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.08363795280457, 48.79339252334683]),
            {
              "class": 2,
              "system:index": "1056"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.88426661491394, 48.93432593102544]),
            {
              "class": 2,
              "system:index": "1057"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.77165675163269, 48.8828770446993]),
            {
              "class": 2,
              "system:index": "1058"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.61372828483582, 48.74360981591422]),
            {
              "class": 2,
              "system:index": "1059"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.6590576171875, 48.584881626662266]),
            {
              "class": 2,
              "system:index": "1060"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.2415771484375, 48.281463546189585]),
            {
              "class": 2,
              "system:index": "1061"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.50961303710938, 47.77358267092912]),
            {
              "class": 2,
              "system:index": "1062"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.28302001953125, 47.8206311465462]),
            {
              "class": 2,
              "system:index": "1063"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.87103271484375, 47.80495305495713]),
            {
              "class": 2,
              "system:index": "1064"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.10037231445312, 47.95324397537571]),
            {
              "class": 2,
              "system:index": "1065"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.70211791992188, 48.349046388384416]),
            {
              "class": 2,
              "system:index": "1066"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.39862060546875, 48.587606889455785]),
            {
              "class": 2,
              "system:index": "1067"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.99050903320312, 48.91176693157597]),
            {
              "class": 2,
              "system:index": "1068"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.05917358398438, 48.7173406567828]),
            {
              "class": 2,
              "system:index": "1069"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.14019775390625, 48.67655133903904]),
            {
              "class": 2,
              "system:index": "1070"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.29949951171875, 48.588515277728966]),
            {
              "class": 2,
              "system:index": "1071"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.63870239257812, 48.549439836142405]),
            {
              "class": 2,
              "system:index": "1072"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.72109985351562, 48.42018546161165]),
            {
              "class": 2,
              "system:index": "1073"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.63839721679688, 46.495556167319506]),
            {
              "class": 2,
              "system:index": "1074"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14126586914062, 46.38293856752681]),
            {
              "class": 2,
              "system:index": "1075"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02178955078125, 46.59944946486856]),
            {
              "class": 2,
              "system:index": "1076"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.41455078125, 46.763383782259346]),
            {
              "class": 2,
              "system:index": "1077"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.30194091796875, 46.167467800812595]),
            {
              "class": 2,
              "system:index": "1078"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.51754760742188, 46.070372437247975]),
            {
              "class": 2,
              "system:index": "1079"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.67547607421875, 46.86394700508323]),
            {
              "class": 2,
              "system:index": "1080"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.97509765625, 47.11499982620772]),
            {
              "class": 2,
              "system:index": "1081"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89544677734375, 46.12750807795425]),
            {
              "class": 2,
              "system:index": "1082"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.283935546875, 47.81499895328108]),
            {
              "class": 2,
              "system:index": "1083"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3333740234375, 46.45299704748289]),
            {
              "class": 2,
              "system:index": "1084"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3443603515625, 46.54374960273857]),
            {
              "class": 2,
              "system:index": "1085"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.437744140625, 46.426499019253]),
            {
              "class": 2,
              "system:index": "1086"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14111328125, 46.5116253954379]),
            {
              "class": 2,
              "system:index": "1087"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.4437255859375, 48.03218251603596]),
            {
              "class": 2,
              "system:index": "1088"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.4217529296875, 47.886880851069]),
            {
              "class": 2,
              "system:index": "1089"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.79803466796875, 47.89240610116927]),
            {
              "class": 2,
              "system:index": "1090"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36434555053711, 47.68099195934532]),
            {
              "class": 2,
              "system:index": "1091"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.536865234375, 48.026672195436014]),
            {
              "class": 2,
              "system:index": "1092"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5093994140625, 48.1000946979738]),
            {
              "class": 2,
              "system:index": "1093"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46820068359375, 48.15509285476017]),
            {
              "class": 2,
              "system:index": "1094"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.25921630859375, 47.79839667295524]),
            {
              "class": 2,
              "system:index": "1095"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.37457275390625, 46.41135150289922]),
            {
              "class": 2,
              "system:index": "1096"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31689453125, 46.32606831171259]),
            {
              "class": 2,
              "system:index": "1097"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.45147705078125, 46.40945776747576]),
            {
              "class": 2,
              "system:index": "1098"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.17132568359375, 46.356406479672486]),
            {
              "class": 2,
              "system:index": "1099"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2015380859375, 46.47569938660751]),
            {
              "class": 2,
              "system:index": "1100"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28118896484375, 46.46056554578541]),
            {
              "class": 2,
              "system:index": "1101"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3333740234375, 46.43974964419869]),
            {
              "class": 2,
              "system:index": "1102"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.93511962890625, 46.524855311033406]),
            {
              "class": 2,
              "system:index": "1103"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96807861328125, 46.538082005463075]),
            {
              "class": 2,
              "system:index": "1104"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22625732421875, 47.85924575819688]),
            {
              "class": 2,
              "system:index": "1105"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3775634765625, 47.20650833393468]),
            {
              "class": 2,
              "system:index": "1106"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.31988525390625, 47.17477833929904]),
            {
              "class": 2,
              "system:index": "1107"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.39318466186523, 47.09005279231576]),
            {
              "class": 2,
              "system:index": "1108"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48940086364746, 46.83671012836047]),
            {
              "class": 2,
              "system:index": "1109"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45721435546875, 46.89210855010362]),
            {
              "class": 2,
              "system:index": "1110"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4599609375, 46.9933677428342]),
            {
              "class": 2,
              "system:index": "1111"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3665771484375, 47.19344533938292]),
            {
              "class": 2,
              "system:index": "1112"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.35009765625, 47.327653995607115]),
            {
              "class": 2,
              "system:index": "1113"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.55092000961304, 48.01141529224274]),
            {
              "class": 2,
              "system:index": "1114"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41326904296875, 48.011975126709956]),
            {
              "class": 2,
              "system:index": "1115"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.448974609375, 46.722917550837565]),
            {
              "class": 2,
              "system:index": "1116"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9710693359375, 46.9465122958623]),
            {
              "class": 2,
              "system:index": "1117"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.42923355102539, 46.55384354491238]),
            {
              "class": 2,
              "system:index": "1118"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46270751953125, 46.632464724627475]),
            {
              "class": 2,
              "system:index": "1119"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.39708995819092, 46.675501698595085]),
            {
              "class": 2,
              "system:index": "1120"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41876220703125, 47.03456658359043]),
            {
              "class": 2,
              "system:index": "1121"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30340576171875, 47.24940695788845]),
            {
              "class": 2,
              "system:index": "1122"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30340576171875, 47.34626718205302]),
            {
              "class": 2,
              "system:index": "1123"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2786865234375, 47.42065432071318]),
            {
              "class": 2,
              "system:index": "1124"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3555908203125, 47.44294999517948]),
            {
              "class": 2,
              "system:index": "1125"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.0699462890625, 47.743017409121826]),
            {
              "class": 2,
              "system:index": "1126"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.4052734375, 48.011975126709956]),
            {
              "class": 2,
              "system:index": "1127"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9765625, 48.026672195436014]),
            {
              "class": 2,
              "system:index": "1128"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.0040283203125, 48.07440873478364]),
            {
              "class": 2,
              "system:index": "1129"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.383056640625, 48.090922612296744]),
            {
              "class": 2,
              "system:index": "1130"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9381103515625, 47.886880851069]),
            {
              "class": 2,
              "system:index": "1131"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1798095703125, 48.33616902211533]),
            {
              "class": 2,
              "system:index": "1132"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.52337646484375, 48.03401915864286]),
            {
              "class": 2,
              "system:index": "1133"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.64697265625, 48.16242149265211]),
            {
              "class": 2,
              "system:index": "1134"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.789794921875, 48.211862417203214]),
            {
              "class": 2,
              "system:index": "1135"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.097412109375, 48.27405352192057]),
            {
              "class": 2,
              "system:index": "1136"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.328125, 48.3069476151602]),
            {
              "class": 2,
              "system:index": "1137"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.492919921875, 48.070738264258296]),
            {
              "class": 2,
              "system:index": "1138"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3116455078125, 48.389090159616025]),
            {
              "class": 2,
              "system:index": "1139"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.44708633422852, 48.44969932875656]),
            {
              "class": 2,
              "system:index": "1140"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.207275390625, 48.425555463221066]),
            {
              "class": 2,
              "system:index": "1141"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.50115966796875, 48.334343174592010]),
            {
              "class": 2,
              "system:index": "1142"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61376953125, 48.43284538647476]),
            {
              "class": 2,
              "system:index": "1143"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.78155517578125, 47.94394667836214]),
            {
              "class": 2,
              "system:index": "1144"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.350341796875, 48.028509034432986]),
            {
              "class": 2,
              "system:index": "1145"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9051513671875, 48.22284281261854]),
            {
              "class": 2,
              "system:index": "1146"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.273193359375, 48.30146673770983]),
            {
              "class": 2,
              "system:index": "1147"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.28143310546875, 48.53297579974164]),
            {
              "class": 2,
              "system:index": "1148"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6221809387207, 48.54775103664887]),
            {
              "class": 2,
              "system:index": "1149"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.77557373046875, 48.53115701097671]),
            {
              "class": 2,
              "system:index": "1150"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84698486328125, 48.612937834706464]),
            {
              "class": 2,
              "system:index": "1151"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.19329833984375, 47.635783590864854]),
            {
              "class": 2,
              "system:index": "1152"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.59454345703125, 48.330691283387175]),
            {
              "class": 2,
              "system:index": "1153"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61582946777344, 47.89442036863712]),
            {
              "class": 2,
              "system:index": "1154"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64398193359375, 47.210240027362104]),
            {
              "class": 2,
              "system:index": "1155"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47077560424805, 46.793889809224936]),
            {
              "class": 2,
              "system:index": "1156"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17431640625, 47.95498440806741]),
            {
              "class": 2,
              "system:index": "1157"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.383056640625, 48.24479653871236]),
            {
              "class": 2,
              "system:index": "1158"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.35009765625, 48.46381589406607]),
            {
              "class": 2,
              "system:index": "1159"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.558837890625, 48.598408688619145]),
            {
              "class": 2,
              "system:index": "1160"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.0369873046875, 48.56206753526866]),
            {
              "class": 2,
              "system:index": "1161"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.92437744140625, 48.31425453625819]),
            {
              "class": 2,
              "system:index": "1162"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.49591064453125, 48.228332127214934]),
            {
              "class": 2,
              "system:index": "1163"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.50390625, 48.03401915864286]),
            {
              "class": 2,
              "system:index": "1164"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.85296630859375, 48.109265147494874]),
            {
              "class": 2,
              "system:index": "1165"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.87493896484375, 47.98440682947526]),
            {
              "class": 2,
              "system:index": "1166"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52866840362549, 47.88149892104062]),
            {
              "class": 2,
              "system:index": "1167"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1083984375, 48.15875730456923]),
            {
              "class": 2,
              "system:index": "1168"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2786865234375, 48.38544219115484]),
            {
              "class": 2,
              "system:index": "1169"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61651611328125, 48.525700252688765]),
            {
              "class": 2,
              "system:index": "1170"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5093994140625, 47.52091047852613]),
            {
              "class": 2,
              "system:index": "1171"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73162841796875, 48.210032122340415]),
            {
              "class": 2,
              "system:index": "1172"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.26220703125, 47.20837421346631]),
            {
              "class": 2,
              "system:index": "1173"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64455056190491, 48.53245716741657]),
            {
              "class": 2,
              "system:index": "1174"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.63185834884644, 48.51666120333876]),
            {
              "class": 2,
              "system:index": "1175"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.62482023239136, 48.51312189086307]),
            {
              "class": 2,
              "system:index": "1176"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61793231964111, 48.51305081779917]),
            {
              "class": 2,
              "system:index": "1177"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60259008407593, 48.13496950325605]),
            {
              "class": 2,
              "system:index": "1178"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60297632217407, 48.10496670299884]),
            {
              "class": 2,
              "system:index": "1179"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.62067890167236, 48.087769329953254]),
            {
              "class": 2,
              "system:index": "1180"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52203798294067, 47.888737055525176]),
            {
              "class": 2,
              "system:index": "1181"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.44502639770508, 47.042404807857594]),
            {
              "class": 2,
              "system:index": "1182"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45386695861816, 47.015726739723355]),
            {
              "class": 2,
              "system:index": "1183"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46390914916992, 46.98844984958496]),
            {
              "class": 2,
              "system:index": "1184"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45506858825684, 46.959460216541046]),
            {
              "class": 2,
              "system:index": "1185"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41283988952637, 46.96602086264215]),
            {
              "class": 2,
              "system:index": "1186"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45172119140625, 46.888237214077876]),
            {
              "class": 2,
              "system:index": "1187"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47807121276855, 46.859604118587974]),
            {
              "class": 2,
              "system:index": "1188"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46262168884277, 46.84052647103586]),
            {
              "class": 2,
              "system:index": "1189"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48880004882812, 46.84316839564082]),
            {
              "class": 2,
              "system:index": "1190"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47824287414551, 46.772202328820114]),
            {
              "class": 2,
              "system:index": "1191"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.42545700073242, 46.76426570188367]),
            {
              "class": 2,
              "system:index": "1192"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41043663024902, 46.77978512417255]),
            {
              "class": 2,
              "system:index": "1193"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41447067260742, 46.790187687140744]),
            {
              "class": 2,
              "system:index": "1194"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36958122253418, 46.53908568558788]),
            {
              "class": 2,
              "system:index": "1195"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.35601997375488, 46.52308363415361]),
            {
              "class": 2,
              "system:index": "1196"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.35807991027832, 46.54841311924781]),
            {
              "class": 2,
              "system:index": "1197"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.93450546264648, 46.886888046473345]),
            {
              "class": 2,
              "system:index": "1198"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.93098640441895, 46.898325565613284]),
            {
              "class": 2,
              "system:index": "1199"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.87004661560059, 46.896683405150576]),
            {
              "class": 2,
              "system:index": "1200"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95089912414551, 46.852502155445094]),
            {
              "class": 2,
              "system:index": "1201"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95613479614258, 46.93244765730184]),
            {
              "class": 2,
              "system:index": "1202"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90558052062988, 46.939539041026705]),
            {
              "class": 2,
              "system:index": "1203"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.84455490112305, 46.919551826363204]),
            {
              "class": 2,
              "system:index": "1204"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.8842945098877, 46.95694118331636]),
            {
              "class": 2,
              "system:index": "1205"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90729713439941, 46.98177484207681]),
            {
              "class": 2,
              "system:index": "1206"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.84386825561523, 46.9913186756412]),
            {
              "class": 2,
              "system:index": "1207"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.85485458374023, 47.02286559957434]),
            {
              "class": 2,
              "system:index": "1208"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90154647827148, 47.04070857337129]),
            {
              "class": 2,
              "system:index": "1209"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.92351913452148, 47.03304560072368]),
            {
              "class": 2,
              "system:index": "1210"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91416358947754, 47.05819474745514]),
            {
              "class": 2,
              "system:index": "1211"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.87459564208984, 47.06263847995432]),
            {
              "class": 2,
              "system:index": "1212"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90532302856445, 47.090637165667175]),
            {
              "class": 2,
              "system:index": "1213"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.93493461608887, 47.110034720926414]),
            {
              "class": 2,
              "system:index": "1214"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.93974113464355, 47.135322721001465]),
            {
              "class": 2,
              "system:index": "1215"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.97021102905273, 47.15785570055076]),
            {
              "class": 2,
              "system:index": "1216"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91742515563965, 47.16614263175676]),
            {
              "class": 2,
              "system:index": "1217"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.87811470031738, 47.16894355562019]),
            {
              "class": 2,
              "system:index": "1218"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.877685546875, 47.12510384497075]),
            {
              "class": 2,
              "system:index": "1219"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.83039283752441, 47.1554627545689]),
            {
              "class": 2,
              "system:index": "1220"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.94111442565918, 47.18364598278901]),
            {
              "class": 2,
              "system:index": "1221"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95725059509277, 47.19251214527277]),
            {
              "class": 2,
              "system:index": "1222"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.89888572692871, 47.22679624955804]),
            {
              "class": 2,
              "system:index": "1223"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.88240623474121, 47.19799442567996]),
            {
              "class": 2,
              "system:index": "1224"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.85227966308594, 47.216186871116655]),
            {
              "class": 2,
              "system:index": "1225"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.99475860595703, 47.25756309208491]),
            {
              "class": 2,
              "system:index": "1226"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.84386825561523, 47.26729055213527]),
            {
              "class": 2,
              "system:index": "1227"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.88686943054199, 47.33120264043347]),
            {
              "class": 2,
              "system:index": "1228"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.88910102844238, 47.35940879179006]),
            {
              "class": 2,
              "system:index": "1229"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9410285949707, 47.35603647843866]),
            {
              "class": 2,
              "system:index": "1230"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.95767974853516, 47.37835950831887]),
            {
              "class": 2,
              "system:index": "1231"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9337329864502, 47.39561849771388]),
            {
              "class": 2,
              "system:index": "1232"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9600830078125, 47.47451936570433]),
            {
              "class": 2,
              "system:index": "1233"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.0538101196289, 47.54965238525127]),
            {
              "class": 2,
              "system:index": "1234"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.94566345214844, 47.57953652084203]),
            {
              "class": 2,
              "system:index": "1235"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98274230957031, 47.7206182220987]),
            {
              "class": 2,
              "system:index": "1236"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.74275970458984, 47.66978023497619]),
            {
              "class": 2,
              "system:index": "1237"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.21997833251953, 47.77602132106089]),
            {
              "class": 2,
              "system:index": "1238"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.35009765625, 47.72108015828196]),
            {
              "class": 2,
              "system:index": "1239"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3827133178711, 47.75525207011625]),
            {
              "class": 2,
              "system:index": "1240"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.21757507324219, 47.80001101643181]),
            {
              "class": 2,
              "system:index": "1241"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.59557342529297, 47.89424772020999]),
            {
              "class": 2,
              "system:index": "1242"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61720275878906, 47.97245599240245]),
            {
              "class": 2,
              "system:index": "1243"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.33258819580078, 48.20751536008785]),
            {
              "class": 2,
              "system:index": "1244"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.24332427978516, 48.24593970387843]),
            {
              "class": 2,
              "system:index": "1245"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.22306823730469, 48.32384328242262]),
            {
              "class": 2,
              "system:index": "1246"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.15543365478516, 48.31699436192931]),
            {
              "class": 2,
              "system:index": "1247"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.63436889648438, 48.40481902832667]),
            {
              "class": 2,
              "system:index": "1248"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36760711669922, 48.45106561953216]),
            {
              "class": 2,
              "system:index": "1249"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.26495361328125, 48.46905168628047]),
            {
              "class": 2,
              "system:index": "1250"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2010389038086, 48.472466042367756]),
            {
              "class": 2,
              "system:index": "1251"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.31816864013672, 48.49431248122277]),
            {
              "class": 2,
              "system:index": "1252"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48296356201172, 48.45334268913211]),
            {
              "class": 2,
              "system:index": "1253"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.59282684326172, 48.49021699068627]),
            {
              "class": 2,
              "system:index": "1254"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.66595458984375, 48.50841663887411]),
            {
              "class": 2,
              "system:index": "1255"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.26220703125, 48.53456718631883]),
            {
              "class": 2,
              "system:index": "1256"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3113021850586, 48.566611608294686]),
            {
              "class": 2,
              "system:index": "1257"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5203857421875, 48.575471376441655]),
            {
              "class": 2,
              "system:index": "1258"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.59797668457031, 48.59727342304645]),
            {
              "class": 2,
              "system:index": "1259"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.67831420898438, 48.605446765729745]),
            {
              "class": 2,
              "system:index": "1260"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2841796875, 48.627689720487204]),
            {
              "class": 2,
              "system:index": "1261"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17740631103516, 48.63790003903611]),
            {
              "class": 2,
              "system:index": "1262"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.37584686279297, 48.62020084032983]),
            {
              "class": 2,
              "system:index": "1263"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.67591094970703, 48.68506755483561]),
            {
              "class": 2,
              "system:index": "1264"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57257080078125, 48.74962445836071]),
            {
              "class": 2,
              "system:index": "1265"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.37550354003906, 48.75618876280552]),
            {
              "class": 2,
              "system:index": "1266"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17637634277344, 48.734228932815334]),
            {
              "class": 2,
              "system:index": "1267"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.08367919921875, 48.82472313822776]),
            {
              "class": 2,
              "system:index": "1268"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1691665649414, 48.83037360946773]),
            {
              "class": 2,
              "system:index": "1269"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41807556152344, 48.825175199374314]),
            {
              "class": 2,
              "system:index": "1270"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57772064208984, 48.86968324077576]),
            {
              "class": 2,
              "system:index": "1271"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.68827056884766, 48.9344541168398]),
            {
              "class": 2,
              "system:index": "1272"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.76483154296875, 48.93061985312317]),
            {
              "class": 2,
              "system:index": "1273"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.25019073486328, 48.8751028370328]),
            {
              "class": 2,
              "system:index": "1274"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4596176147461, 48.90693110948285]),
            {
              "class": 2,
              "system:index": "1275"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.56364440917969, 48.95069008682183]),
            {
              "class": 2,
              "system:index": "1276"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85787200927734, 48.957453515451924]),
            {
              "class": 2,
              "system:index": "1277"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.86988830566406, 48.98765230234855]),
            {
              "class": 2,
              "system:index": "1278"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24685668945312, 48.96985075314792]),
            {
              "class": 2,
              "system:index": "1279"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8829345703125, 48.90963896308377]),
            {
              "class": 2,
              "system:index": "1280"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5413818359375, 48.26491251331118]),
            {
              "class": 2,
              "system:index": "1281"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.2115478515625, 47.129950756663064]),
            {
              "class": 2,
              "system:index": "1282"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7618408203125, 48.73445537176822]),
            {
              "class": 2,
              "system:index": "1283"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8826904296875, 48.77429274267509]),
            {
              "class": 2,
              "system:index": "1284"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1298828125, 48.45835188280866]),
            {
              "class": 2,
              "system:index": "1285"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7947998046875, 48.741700879765396]),
            {
              "class": 2,
              "system:index": "1286"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37329864501953, 48.762978520066326]),
            {
              "class": 2,
              "system:index": "1287"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36780548095703, 48.81409852735575]),
            {
              "class": 2,
              "system:index": "1288"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2888412475586, 48.815228912154815]),
            {
              "class": 2,
              "system:index": "1289"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6407470703125, 48.61225687435643]),
            {
              "class": 2,
              "system:index": "1290"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73859405517578, 48.56752037390829]),
            {
              "class": 2,
              "system:index": "1291"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91128540039062, 48.539568361357915]),
            {
              "class": 2,
              "system:index": "1292"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40728759765625, 48.52092510684308]),
            {
              "class": 2,
              "system:index": "1293"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5580062866211, 48.64856194356451]),
            {
              "class": 2,
              "system:index": "1294"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.48350524902344, 48.65581982296044]),
            {
              "class": 2,
              "system:index": "1295"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5580062866211, 48.73536111738082]),
            {
              "class": 2,
              "system:index": "1296"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65413665771484, 48.78605682994538]),
            {
              "class": 2,
              "system:index": "1297"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.68400573730469, 48.88142495734278]),
            {
              "class": 2,
              "system:index": "1298"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.68743896484375, 48.78605682994538]),
            {
              "class": 2,
              "system:index": "1299"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.04312133789062, 48.62564740882852]),
            {
              "class": 2,
              "system:index": "1300"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16259765625, 48.63744629097557]),
            {
              "class": 2,
              "system:index": "1301"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18251037597656, 48.67010571995449]),
            {
              "class": 2,
              "system:index": "1302"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.08775329589844, 48.69005384564219]),
            {
              "class": 2,
              "system:index": "1303"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.13032531738281, 48.525700252688765]),
            {
              "class": 2,
              "system:index": "1304"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27452087402344, 48.50432228771794]),
            {
              "class": 2,
              "system:index": "1305"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33013916015625, 48.60067914322632]),
            {
              "class": 2,
              "system:index": "1306"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.55467224121094, 48.51160090553359]),
            {
              "class": 2,
              "system:index": "1307"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56428527832031, 48.53433984844163]),
            {
              "class": 2,
              "system:index": "1308"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.51896667480469, 48.401400122702725]),
            {
              "class": 2,
              "system:index": "1309"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.22164916992188, 48.608397925562606]),
            {
              "class": 2,
              "system:index": "1310"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.28619384765625, 48.5929591811917]),
            {
              "class": 2,
              "system:index": "1311"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27314758300781, 48.748945343432936]),
            {
              "class": 2,
              "system:index": "1312"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.13993835449219, 48.75166174807409]),
            {
              "class": 2,
              "system:index": "1313"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73825073242188, 48.46199462233164]),
            {
              "class": 2,
              "system:index": "1314"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92158508300781, 48.48475582205773]),
            {
              "class": 2,
              "system:index": "1315"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14955139160156, 48.55070556650788]),
            {
              "class": 2,
              "system:index": "1316"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14886474609375, 48.61747733567233]),
            {
              "class": 2,
              "system:index": "1317"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31802368164062, 48.40504694719738]),
            {
              "class": 2,
              "system:index": "1318"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63388061523438, 48.4633605822591]),
            {
              "class": 2,
              "system:index": "1319"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25416564941406, 48.347122734178186]),
            {
              "class": 2,
              "system:index": "1320"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25485229492188, 48.24342470678627]),
            {
              "class": 2,
              "system:index": "1321"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.08937072753906, 48.23885166797079]),
            {
              "class": 2,
              "system:index": "1322"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02413940429688, 48.445144760667]),
            {
              "class": 2,
              "system:index": "1323"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.899169921875, 48.31790760445764]),
            {
              "class": 2,
              "system:index": "1324"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91152954101562, 48.235650297553086]),
            {
              "class": 2,
              "system:index": "1325"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32351684570312, 48.14226521928136]),
            {
              "class": 2,
              "system:index": "1326"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1573486328125, 47.91450120703987]),
            {
              "class": 2,
              "system:index": "1327"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.44779968261719, 47.854638476529935]),
            {
              "class": 2,
              "system:index": "1328"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60298156738281, 47.85648143832491]),
            {
              "class": 2,
              "system:index": "1329"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98612976074219, 47.89516850516946]),
            {
              "class": 2,
              "system:index": "1330"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7615966796875, 47.75455961892611]),
            {
              "class": 2,
              "system:index": "1331"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64830017089844, 47.712995683722205]),
            {
              "class": 2,
              "system:index": "1332"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.28413391113281, 47.809004297545634]),
            {
              "class": 2,
              "system:index": "1333"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.28825378417969, 47.96188179204513]),
            {
              "class": 2,
              "system:index": "1334"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.3988037109375, 48.026672195436014]),
            {
              "class": 2,
              "system:index": "1335"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66477966308594, 48.103304541415994]),
            {
              "class": 2,
              "system:index": "1336"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.34480285644531, 48.039528693690556]),
            {
              "class": 2,
              "system:index": "1337"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3660888671875, 47.73793802588284]),
            {
              "class": 2,
              "system:index": "1338"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.360595703125, 47.61819841513311]),
            {
              "class": 2,
              "system:index": "1339"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.71009826660156, 47.607551881912855]),
            {
              "class": 2,
              "system:index": "1340"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11590576171875, 47.54455416428098]),
            {
              "class": 2,
              "system:index": "1341"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.04130554199219, 47.474983479729254]),
            {
              "class": 2,
              "system:index": "1342"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22532653808594, 47.31787944612917]),
            {
              "class": 2,
              "system:index": "1343"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02207946777344, 47.292270864380086]),
            {
              "class": 2,
              "system:index": "1344"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18687438964844, 47.38114922279503]),
            {
              "class": 2,
              "system:index": "1345"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39218139648438, 47.24427960201268]),
            {
              "class": 2,
              "system:index": "1346"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.05548095703125, 47.1607737815166]),
            {
              "class": 2,
              "system:index": "1347"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92707824707031, 47.189245836660895]),
            {
              "class": 2,
              "system:index": "1348"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84605407714844, 47.35650163792198]),
            {
              "class": 2,
              "system:index": "1349"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.79249572753906, 47.18644598356959]),
            {
              "class": 2,
              "system:index": "1350"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.822021484375, 47.464772024276016]),
            {
              "class": 2,
              "system:index": "1351"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.46633911132812, 47.491224888201955]),
            {
              "class": 2,
              "system:index": "1352"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31939697265625, 47.508852732220944]),
            {
              "class": 2,
              "system:index": "1353"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.17245483398438, 47.568187190520135]),
            {
              "class": 2,
              "system:index": "1354"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.998046875, 47.33091177687734]),
            {
              "class": 2,
              "system:index": "1355"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.65541076660156, 47.345336678558915]),
            {
              "class": 2,
              "system:index": "1356"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.72476196289062, 47.51580946245539]),
            {
              "class": 2,
              "system:index": "1357"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.74330139160156, 47.124811848234195]),
            {
              "class": 2,
              "system:index": "1358"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73162841796875, 47.010225655683485]),
            {
              "class": 2,
              "system:index": "1359"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30085754394531, 46.85549565938302]),
            {
              "class": 2,
              "system:index": "1360"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57070922851562, 46.88835453139628]),
            {
              "class": 2,
              "system:index": "1361"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6959228515625, 46.8216769734396]),
            {
              "class": 2,
              "system:index": "1362"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55491638183594, 46.842769191277306]),
            {
              "class": 2,
              "system:index": "1363"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.69911193847656, 46.90848239480924]),
            {
              "class": 2,
              "system:index": "1364"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89755249023438, 47.02749950743632]),
            {
              "class": 2,
              "system:index": "1365"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.95591735839844, 46.89863054418798]),
            {
              "class": 2,
              "system:index": "1366"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18319702148438, 46.75345826283328]),
            {
              "class": 2,
              "system:index": "1367"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.4317626953125, 46.628173890644035]),
            {
              "class": 2,
              "system:index": "1368"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53201293945312, 46.91035873251691]),
            {
              "class": 2,
              "system:index": "1369"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.48806762695312, 46.77321344137514]),
            {
              "class": 2,
              "system:index": "1370"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.613037109375, 46.74593057501516]),
            {
              "class": 2,
              "system:index": "1371"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.80392456054688, 46.74687159348754]),
            {
              "class": 2,
              "system:index": "1372"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.580078125, 46.96614973585947]),
            {
              "class": 2,
              "system:index": "1373"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.95361328125, 46.65033174178208]),
            {
              "class": 2,
              "system:index": "1374"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89250183105469, 46.97364661391091]),
            {
              "class": 2,
              "system:index": "1375"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00373840332031, 47.1084107503186]),
            {
              "class": 2,
              "system:index": "1376"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.82658386230469, 47.198997516440805]),
            {
              "class": 2,
              "system:index": "1377"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.66178894042969, 47.190599057438234]),
            {
              "class": 2,
              "system:index": "1378"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.48326110839844, 47.21252557132299]),
            {
              "class": 2,
              "system:index": "1379"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.24131774902344, 47.0742839905687]),
            {
              "class": 2,
              "system:index": "1380"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.2447509765625, 47.200863660159506]),
            {
              "class": 2,
              "system:index": "1381"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.29830932617188, 47.335984219015955]),
            {
              "class": 2,
              "system:index": "1382"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44387817382812, 47.062123972886255]),
            {
              "class": 2,
              "system:index": "1383"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.49674987792969, 47.37505815266676]),
            {
              "class": 2,
              "system:index": "1384"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.29556274414062, 47.50787871356566]),
            {
              "class": 2,
              "system:index": "1385"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.67253112792969, 47.42804080625704]),
            {
              "class": 2,
              "system:index": "1386"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.68214416503906, 47.26846705726702]),
            {
              "class": 2,
              "system:index": "1387"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7171630859375, 47.14111450335573]),
            {
              "class": 2,
              "system:index": "1388"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.76179504394531, 47.00502837786176]),
            {
              "class": 2,
              "system:index": "1389"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.84075927734375, 47.034987782606855]),
            {
              "class": 2,
              "system:index": "1390"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.98358154296875, 47.04153916152341]),
            {
              "class": 2,
              "system:index": "1391"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.05567932128906, 46.832435514229765]),
            {
              "class": 2,
              "system:index": "1392"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.42396545410156, 46.9464654313151]),
            {
              "class": 2,
              "system:index": "1393"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.30654907226562, 46.87094184636541]),
            {
              "class": 2,
              "system:index": "1394"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.15205383300781, 46.76945110872837]),
            {
              "class": 2,
              "system:index": "1395"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.92340087890625, 46.83055645034461]),
            {
              "class": 2,
              "system:index": "1396"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37933349609375, 47.19433186997943]),
            {
              "class": 2,
              "system:index": "1397"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.79200744628906, 47.41967868063382]),
            {
              "class": 2,
              "system:index": "1398"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.49125671386719, 47.42432447784522]),
            {
              "class": 2,
              "system:index": "1399"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.810546875, 47.595930797660394]),
            {
              "class": 2,
              "system:index": "1400"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.97465515136719, 47.616300710789794]),
            {
              "class": 2,
              "system:index": "1401"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14288330078125, 47.452654948900864]),
            {
              "class": 2,
              "system:index": "1402"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87371826171875, 47.70925329943249]),
            {
              "class": 2,
              "system:index": "1403"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87440490722656, 47.2530890225903]),
            {
              "class": 2,
              "system:index": "1404"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44456481933594, 47.6399013662164]),
            {
              "class": 2,
              "system:index": "1405"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.54824829101562, 47.63620000732477]),
            {
              "class": 2,
              "system:index": "1406"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.72883605957031, 47.68291042258681]),
            {
              "class": 2,
              "system:index": "1407"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.56080627441406, 47.72680782384896]),
            {
              "class": 2,
              "system:index": "1408"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.68234252929688, 47.63712537162984]),
            {
              "class": 2,
              "system:index": "1409"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31430053710938, 47.694003782324664]),
            {
              "class": 2,
              "system:index": "1410"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35000610351562, 47.76189912988142]),
            {
              "class": 2,
              "system:index": "1411"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26966857910156, 47.84168982064775]),
            {
              "class": 2,
              "system:index": "1412"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.19139099121094, 47.64822846502931]),
            {
              "class": 2,
              "system:index": "1413"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.12890625, 47.64360246290002]),
            {
              "class": 2,
              "system:index": "1414"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.986083984375, 47.661641554434894]),
            {
              "class": 2,
              "system:index": "1415"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73477172851562, 47.814030629864924]),
            {
              "class": 2,
              "system:index": "1416"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.59538269042969, 47.844454929044815]),
            {
              "class": 2,
              "system:index": "1417"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55624389648438, 47.684759479731206]),
            {
              "class": 2,
              "system:index": "1418"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.80618286132812, 47.580184976882485]),
            {
              "class": 2,
              "system:index": "1419"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.98951721191406, 47.85090627545349]),
            {
              "class": 2,
              "system:index": "1420"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14332580566406, 47.940680895327475]),
            {
              "class": 2,
              "system:index": "1421"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5299072265625, 47.89420167772215]),
            {
              "class": 2,
              "system:index": "1422"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.97853088378906, 47.502776430601386]),
            {
              "class": 2,
              "system:index": "1423"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5850830078125, 47.598245960020104]),
            {
              "class": 2,
              "system:index": "1424"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.22503662109375, 47.754051812712525]),
            {
              "class": 2,
              "system:index": "1425"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95243835449219, 47.81356951846977]),
            {
              "class": 2,
              "system:index": "1426"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.86454772949219, 47.80711352899855]),
            {
              "class": 2,
              "system:index": "1427"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5631103515625, 47.72680782384896]),
            {
              "class": 2,
              "system:index": "1428"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4312744140625, 47.72542215537813]),
            {
              "class": 2,
              "system:index": "1429"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.43882751464844, 47.86242454103532]),
            {
              "class": 2,
              "system:index": "1430"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60499572753906, 47.943440723110214]),
            {
              "class": 2,
              "system:index": "1431"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.68876647949219, 47.99033526772428]),
            {
              "class": 2,
              "system:index": "1432"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.72859191894531, 48.108760826483355]),
            {
              "class": 2,
              "system:index": "1433"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.58164978027344, 48.06380954887861]),
            {
              "class": 2,
              "system:index": "1434"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.480712890625, 48.07390407181212]),
            {
              "class": 2,
              "system:index": "1435"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.78215026855469, 48.162833708615004]),
            {
              "class": 2,
              "system:index": "1436"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.86180114746094, 48.23514721801178]),
            {
              "class": 2,
              "system:index": "1437"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1563720703125, 48.067480513580016]),
            {
              "class": 2,
              "system:index": "1438"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46148681640625, 47.93700090979204]),
            {
              "class": 2,
              "system:index": "1439"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35643005371094, 47.93976093402872]),
            {
              "class": 2,
              "system:index": "1440"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.56379699707031, 47.89696399998474]),
            {
              "class": 2,
              "system:index": "1441"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.86317443847656, 48.07298646972608]),
            {
              "class": 2,
              "system:index": "1442"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.00325012207031, 48.1577954230116]),
            {
              "class": 2,
              "system:index": "1443"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.579833984375, 48.24095536125953]),
            {
              "class": 2,
              "system:index": "1444"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.4534912109375, 48.1145833033218]),
            {
              "class": 2,
              "system:index": "1445"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.1898193359375, 48.02097762336855]),
            {
              "class": 2,
              "system:index": "1446"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6951904296875, 47.89774666090477]),
            {
              "class": 2,
              "system:index": "1447"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.30242919921875, 47.816658934472834]),
            {
              "class": 2,
              "system:index": "1448"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7501220703125, 48.22265987000074]),
            {
              "class": 2,
              "system:index": "1449"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6951904296875, 48.42719583162685]),
            {
              "class": 2,
              "system:index": "1450"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.75286865234375, 48.48002237798574]),
            {
              "class": 2,
              "system:index": "1451"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.821533203125, 48.45634830911615]),
            {
              "class": 2,
              "system:index": "1452"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.11541748046875, 48.65087555035517]),
            {
              "class": 2,
              "system:index": "1453"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.01104736328125, 48.65631880808167]),
            {
              "class": 2,
              "system:index": "1454"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5853271484375, 48.530975172911944]),
            {
              "class": 2,
              "system:index": "1455"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5523681640625, 48.56733866646507]),
            {
              "class": 2,
              "system:index": "1456"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25299072265625, 48.57642545709303]),
            {
              "class": 2,
              "system:index": "1457"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01678466796875, 48.76506057260905]),
            {
              "class": 2,
              "system:index": "1458"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9151611328125, 48.58914422058952]),
            {
              "class": 2,
              "system:index": "1459"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01678466796875, 48.10908179931216]),
            {
              "class": 2,
              "system:index": "1460"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.294189453125, 48.22082996109895]),
            {
              "class": 2,
              "system:index": "1461"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3765869140625, 48.25558704468864]),
            {
              "class": 2,
              "system:index": "1462"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37109375, 48.121917725806576]),
            {
              "class": 2,
              "system:index": "1463"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.63751220703125, 47.848003316686345]),
            {
              "class": 2,
              "system:index": "1464"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.799560546875, 47.787141043954094]),
            {
              "class": 2,
              "system:index": "1465"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.80780029296875, 48.32868267632223]),
            {
              "class": 2,
              "system:index": "1466"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.93963623046875, 48.37613873254698]),
            {
              "class": 2,
              "system:index": "1467"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.91766357421875, 48.25192951628099]),
            {
              "class": 2,
              "system:index": "1468"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.90667724609375, 48.325030379720175]),
            {
              "class": 2,
              "system:index": "1469"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.85380554199219, 48.505186689391145]),
            {
              "class": 2,
              "system:index": "1470"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02684020996094, 48.60971455232072]),
            {
              "class": 2,
              "system:index": "1471"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.51666259765625, 48.61425434309112]),
            {
              "class": 2,
              "system:index": "1472"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.2117919921875, 48.5565686721256]),
            {
              "class": 2,
              "system:index": "1473"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.17196655273438, 48.386308618474125]),
            {
              "class": 2,
              "system:index": "1474"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.41847229003906, 48.2744648400209]),
            {
              "class": 2,
              "system:index": "1475"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.65948486328125, 48.44692110192914]),
            {
              "class": 2,
              "system:index": "1476"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94581604003906, 48.45102008821735]),
            {
              "class": 2,
              "system:index": "1477"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02546691894531, 48.50791624702708]),
            {
              "class": 2,
              "system:index": "1478"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.689208984375, 48.59609271701509]),
            {
              "class": 2,
              "system:index": "1479"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.82310485839844, 48.59609271701509]),
            {
              "class": 2,
              "system:index": "1480"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.084716796875, 48.59427619657812]),
            {
              "class": 2,
              "system:index": "1481"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02841186523438, 48.639669614705866]),
            {
              "class": 2,
              "system:index": "1482"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.96249389648438, 48.68592885575615]),
            {
              "class": 2,
              "system:index": "1483"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.81761169433594, 48.81540976859771]),
            {
              "class": 2,
              "system:index": "1484"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.24357604980469, 48.55520520853211]),
            {
              "class": 2,
              "system:index": "1485"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50724792480469, 48.55475071712515]),
            {
              "class": 2,
              "system:index": "1486"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.24906921386719, 48.72761646293367]),
            {
              "class": 2,
              "system:index": "1487"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.06298828125, 48.86195929897614]),
            {
              "class": 2,
              "system:index": "1488"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.96205139160156, 48.83078041604922]),
            {
              "class": 2,
              "system:index": "1489"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82884216308594, 48.79912982710076]),
            {
              "class": 2,
              "system:index": "1490"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76268005371094, 48.63694716062554]),
            {
              "class": 2,
              "system:index": "1491"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02017211914062, 48.554296221635376]),
            {
              "class": 2,
              "system:index": "1492"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.03047180175781, 48.46877852508993]),
            {
              "class": 2,
              "system:index": "1493"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.34976196289062, 48.42095315795417]),
            {
              "class": 2,
              "system:index": "1494"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.41018676757812, 48.55520520853211]),
            {
              "class": 2,
              "system:index": "1495"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.54888916015625, 48.55293271066906]),
            {
              "class": 2,
              "system:index": "1496"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.16024780273438, 48.5979091721387]),
            {
              "class": 2,
              "system:index": "1497"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.56973266601562, 48.50973585656221]),
            {
              "class": 2,
              "system:index": "1498"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.74688720703125, 48.53020211794664]),
            {
              "class": 2,
              "system:index": "1499"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.85194396972656, 48.53656771284665]),
            {
              "class": 2,
              "system:index": "1500"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.15200805664062, 48.67006037153976]),
            {
              "class": 2,
              "system:index": "1501"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.35525512695312, 48.679128688894366]),
            {
              "class": 2,
              "system:index": "1502"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.75326538085938, 48.18755991997093]),
            {
              "class": 2,
              "system:index": "1503"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60289001464844, 48.28725938825818]),
            {
              "class": 2,
              "system:index": "1504"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.578857421875, 48.3990751328293]),
            {
              "class": 2,
              "system:index": "1505"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.78828430175781, 48.3990751328293]),
            {
              "class": 2,
              "system:index": "1506"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18035888671875, 48.3977074437249]),
            {
              "class": 2,
              "system:index": "1507"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98878479003906, 48.41502878889199]),
            {
              "class": 2,
              "system:index": "1508"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.89608764648438, 48.4519309152297]),
            {
              "class": 2,
              "system:index": "1509"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.87205505371094, 48.40773630995691]),
            {
              "class": 2,
              "system:index": "1510"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.01075744628906, 48.24154980752695]),
            {
              "class": 2,
              "system:index": "1511"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.39346313476562, 48.268523404293646]),
            {
              "class": 2,
              "system:index": "1512"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.33509826660156, 48.393148214481364]),
            {
              "class": 2,
              "system:index": "1513"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.02816772460938, 48.34753344980634]),
            {
              "class": 2,
              "system:index": "1514"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.01580810546875, 48.42550989513118]),
            {
              "class": 2,
              "system:index": "1515"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.98422241210938, 48.2049527086518]),
            {
              "class": 2,
              "system:index": "1516"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.89083862304688, 48.11747130958421]),
            {
              "class": 2,
              "system:index": "1517"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.26300048828125, 48.0665627829468]),
            {
              "class": 2,
              "system:index": "1518"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.63172912597656, 48.05830259690578]),
            {
              "class": 2,
              "system:index": "1519"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.86587524414062, 48.19808783950184]),
            {
              "class": 2,
              "system:index": "1520"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.99496459960938, 48.36715280605105]),
            {
              "class": 2,
              "system:index": "1521"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.37742614746094, 48.5406594583897]),
            {
              "class": 2,
              "system:index": "1522"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.51750183105469, 48.51746852716918]),
            {
              "class": 2,
              "system:index": "1523"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.70289611816406, 48.6256020204161]),
            {
              "class": 2,
              "system:index": "1524"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.45845031738281, 48.6437530203395]),
            {
              "class": 2,
              "system:index": "1525"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3094482421875, 48.62106325006815]),
            {
              "class": 2,
              "system:index": "1526"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.11512756347656, 48.65690841199208]),
            {
              "class": 2,
              "system:index": "1527"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.96269226074219, 48.60699046807504]),
            {
              "class": 2,
              "system:index": "1528"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.86106872558594, 48.668699983152656]),
            {
              "class": 2,
              "system:index": "1529"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.74777221679688, 48.56383976953848]),
            {
              "class": 2,
              "system:index": "1530"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68116760253906, 48.63513210961188]),
            {
              "class": 2,
              "system:index": "1531"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.62417602539062, 48.665072101232816]),
            {
              "class": 2,
              "system:index": "1532"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.49371337890625, 48.597455064480904]),
            {
              "class": 2,
              "system:index": "1533"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.33784484863281, 48.51337490738512]),
            {
              "class": 2,
              "system:index": "1534"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29571533203125, 48.24840885064789]),
            {
              "class": 2,
              "system:index": "1535"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.6500244140625, 48.282690269638394]),
            {
              "class": 2,
              "system:index": "1536"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.74134826660156, 48.250237773467106]),
            {
              "class": 2,
              "system:index": "1537"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.75302124023438, 48.496542106438255]),
            {
              "class": 2,
              "system:index": "1538"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.75262451171875, 48.15875730456923]),
            {
              "class": 2,
              "system:index": "1539"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.63040161132812, 47.76517619125415]),
            {
              "class": 2,
              "system:index": "1540"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69631958007812, 47.758714187846294]),
            {
              "class": 2,
              "system:index": "1541"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.62490844726562, 47.89977218436005]),
            {
              "class": 2,
              "system:index": "1542"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82815551757812, 48.07349114169717]),
            {
              "class": 2,
              "system:index": "1543"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88308715820312, 48.18806348121142]),
            {
              "class": 2,
              "system:index": "1544"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.85012817382812, 48.19081007655071]),
            {
              "class": 2,
              "system:index": "1545"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.854248046875, 48.159673376126634]),
            {
              "class": 2,
              "system:index": "1546"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.81991577148438, 48.16150547016802]),
            {
              "class": 2,
              "system:index": "1547"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.76773071289062, 48.115683488677305]),
            {
              "class": 2,
              "system:index": "1548"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60842895507812, 48.19081007655071]),
            {
              "class": 2,
              "system:index": "1549"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.678466796875, 47.777174925180354]),
            {
              "class": 2,
              "system:index": "1550"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41754150390625, 47.84450101574877]),
            {
              "class": 2,
              "system:index": "1551"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.414794921875, 48.02483529097477]),
            {
              "class": 2,
              "system:index": "1552"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.30767822265625, 47.98532601005293]),
            {
              "class": 2,
              "system:index": "1553"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.25411987304688, 48.213692646648035]),
            {
              "class": 2,
              "system:index": "1554"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.67709350585938, 48.19904897935913]),
            {
              "class": 2,
              "system:index": "1555"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.81716918945312, 48.057889555610984]),
            {
              "class": 2,
              "system:index": "1556"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69631958007812, 48.066149807925314]),
            {
              "class": 2,
              "system:index": "1557"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.57958984375, 47.96785877999251]),
            {
              "class": 2,
              "system:index": "1558"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6015625, 47.83804887261066]),
            {
              "class": 2,
              "system:index": "1559"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.47247314453125, 47.8703015638657]),
            {
              "class": 2,
              "system:index": "1560"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.32965087890625, 47.931066347509784]),
            {
              "class": 2,
              "system:index": "1561"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.47933959960938, 47.99635490025391]),
            {
              "class": 2,
              "system:index": "1562"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.370849609375, 48.1706649589215]),
            {
              "class": 2,
              "system:index": "1563"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.80068969726562, 48.20454084523924]),
            {
              "class": 2,
              "system:index": "1564"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95037841796875, 48.11201596330927]),
            {
              "class": 2,
              "system:index": "1565"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92840576171875, 48.25851283439989]),
            {
              "class": 2,
              "system:index": "1566"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.83364868164062, 48.24388198818308]),
            {
              "class": 2,
              "system:index": "1567"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.77734375, 48.235650297553086]),
            {
              "class": 2,
              "system:index": "1568"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02615356445312, 47.913580765920166]),
            {
              "class": 2,
              "system:index": "1569"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.91354370117188, 47.78455738546876]),
            {
              "class": 2,
              "system:index": "1570"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02615356445312, 47.84173590980837]),
            {
              "class": 2,
              "system:index": "1571"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.99319458007812, 47.84450101574877]),
            {
              "class": 2,
              "system:index": "1572"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.67709350585938, 48.42282147238751]),
            {
              "class": 2,
              "system:index": "1573"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.28707885742188, 48.1935565246874]),
            {
              "class": 2,
              "system:index": "1574"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.03689575195312, 48.22009793454488]),
            {
              "class": 2,
              "system:index": "1575"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.97235107421875, 48.191725575618726]),
            {
              "class": 2,
              "system:index": "1576"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.99569702148438, 47.7420939217573]),
            {
              "class": 2,
              "system:index": "1577"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.67572021484375, 47.75686775372488]),
            {
              "class": 2,
              "system:index": "1578"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.90780639648438, 48.254855515290764]),
            {
              "class": 2,
              "system:index": "1579"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.05062866210938, 48.425555463221066]),
            {
              "class": 2,
              "system:index": "1580"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.91741943359375, 48.41917592250883]),
            {
              "class": 2,
              "system:index": "1581"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4971923828125, 48.37723330604312]),
            {
              "class": 2,
              "system:index": "1582"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50955200195312, 48.32977826971931]),
            {
              "class": 2,
              "system:index": "1583"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9259033203125, 48.36628606659289]),
            {
              "class": 2,
              "system:index": "1584"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92178344726562, 48.32156041109598]),
            {
              "class": 2,
              "system:index": "1585"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.56448364257812, 48.353511312557394]),
            {
              "class": 2,
              "system:index": "1586"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.96435546875, 48.26216989188535]),
            {
              "class": 2,
              "system:index": "1587"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.10443115234375, 48.33799480425318]),
            {
              "class": 2,
              "system:index": "1588"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.12091064453125, 48.31425453625819]),
            {
              "class": 2,
              "system:index": "1589"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.90118408203125, 48.37540892957362]),
            {
              "class": 2,
              "system:index": "1590"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9259033203125, 48.43193420325805]),
            {
              "class": 2,
              "system:index": "1591"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.041259765625, 47.913580765920166]),
            {
              "class": 2,
              "system:index": "1592"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.96847534179688, 47.82883013320963]),
            {
              "class": 2,
              "system:index": "1593"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.93276977539062, 47.78917089079264]),
            {
              "class": 2,
              "system:index": "1594"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.36260986328125, 47.933826688535746]),
            {
              "class": 2,
              "system:index": "1595"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60568237304688, 47.82698618879922]),
            {
              "class": 2,
              "system:index": "1596"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5301513671875, 47.78363463526376]),
            {
              "class": 2,
              "system:index": "1597"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.00143432617188, 47.79378398661931]),
            {
              "class": 2,
              "system:index": "1598"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.99868774414062, 47.87767079094932]),
            {
              "class": 2,
              "system:index": "1599"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6787109375, 48.18897902934712]),
            {
              "class": 2,
              "system:index": "1600"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.69107055664062, 48.166085419012525]),
            {
              "class": 2,
              "system:index": "1601"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.56747436523438, 48.14226521928136]),
            {
              "class": 2,
              "system:index": "1602"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57296752929688, 48.1642534885474]),
            {
              "class": 2,
              "system:index": "1603"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5743408203125, 48.213692646648035]),
            {
              "class": 2,
              "system:index": "1604"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.93939208984375, 48.41006090395106]),
            {
              "class": 2,
              "system:index": "1605"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.15911865234375, 48.44924389032873]),
            {
              "class": 2,
              "system:index": "1606"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.51617431640625, 48.1688331920297]),
            {
              "class": 2,
              "system:index": "1607"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46011352539062, 48.34621001474202]),
            {
              "class": 2,
              "system:index": "1608"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94375610351562, 48.36993540791379]),
            {
              "class": 2,
              "system:index": "1609"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94512939453125, 48.31973404047174]),
            {
              "class": 2,
              "system:index": "1610"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.93551635742188, 48.26216989188535]),
            {
              "class": 2,
              "system:index": "1611"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.63064575195312, 48.208201762059105]),
            {
              "class": 2,
              "system:index": "1612"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6622314453125, 48.189894561126884]),
            {
              "class": 2,
              "system:index": "1613"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.975341796875, 47.886880851069]),
            {
              "class": 2,
              "system:index": "1614"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73089599609375, 47.989921667414194]),
            {
              "class": 2,
              "system:index": "1615"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7281494140625, 48.191725575618726]),
            {
              "class": 2,
              "system:index": "1616"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.01791381835938, 48.322473571887066]),
            {
              "class": 2,
              "system:index": "1617"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.98770141601562, 48.38088186285944]),
            {
              "class": 2,
              "system:index": "1618"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50405883789062, 48.322473571887066]),
            {
              "class": 2,
              "system:index": "1619"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.07147216796875, 47.91910316704857]),
            {
              "class": 2,
              "system:index": "1620"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57022094726562, 47.888722666599186]),
            {
              "class": 2,
              "system:index": "1621"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73638916015625, 47.758714187846294]),
            {
              "class": 2,
              "system:index": "1622"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5908203125, 47.706065135695724]),
            {
              "class": 2,
              "system:index": "1623"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57846069335938, 47.68388118858138]),
            {
              "class": 2,
              "system:index": "1624"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.84213256835938, 47.81038774105833]),
            {
              "class": 2,
              "system:index": "1625"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.91217041015625, 47.76148371616669]),
            {
              "class": 2,
              "system:index": "1626"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.29006958007812, 47.90345483298757]),
            {
              "class": 2,
              "system:index": "1627"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.49606323242188, 47.81592114659012]),
            {
              "class": 2,
              "system:index": "1628"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.0906982421875, 48.42373281900577]),
            {
              "class": 2,
              "system:index": "1629"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02615356445312, 48.43193420325805]),
            {
              "class": 2,
              "system:index": "1630"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02728271484375, 48.441045300141234]),
            {
              "class": 2,
              "system:index": "1631"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.62789916992188, 48.254855515290764]),
            {
              "class": 2,
              "system:index": "1632"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.63201904296875, 48.322473571887066]),
            {
              "class": 2,
              "system:index": "1633"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.79818725585938, 48.31699436192931]),
            {
              "class": 2,
              "system:index": "1634"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.74874877929688, 48.40094425125627]),
            {
              "class": 2,
              "system:index": "1635"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73776245117188, 48.441045300141234]),
            {
              "class": 2,
              "system:index": "1636"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.69931030273438, 48.308774443523276]),
            {
              "class": 2,
              "system:index": "1637"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7666015625, 48.29872607827854]),
            {
              "class": 2,
              "system:index": "1638"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7281494140625, 48.253026757626124]),
            {
              "class": 2,
              "system:index": "1639"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.65673828125, 48.26674084583965]),
            {
              "class": 2,
              "system:index": "1640"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.58670043945312, 48.303293762253944]),
            {
              "class": 2,
              "system:index": "1641"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.61141967773438, 48.25851283439989]),
            {
              "class": 2,
              "system:index": "1642"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.72540283203125, 48.2347355834968]),
            {
              "class": 2,
              "system:index": "1643"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44387817382812, 48.35716156917839]),
            {
              "class": 2,
              "system:index": "1644"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.42739868164062, 48.23930899024907]),
            {
              "class": 2,
              "system:index": "1645"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.40130615234375, 48.2182679340594]),
            {
              "class": 2,
              "system:index": "1646"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.26397705078125, 48.206371336358906]),
            {
              "class": 2,
              "system:index": "1647"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.426025390625, 48.145930585161196]),
            {
              "class": 2,
              "system:index": "1648"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3765869140625, 48.15875730456923]),
            {
              "class": 2,
              "system:index": "1649"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.34774780273438, 48.15417670141274]),
            {
              "class": 2,
              "system:index": "1650"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.36972045898438, 48.20271028869972]),
            {
              "class": 2,
              "system:index": "1651"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.52764892578125, 48.24479653871236]),
            {
              "class": 2,
              "system:index": "1652"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.35736083984375, 48.109265147494874]),
            {
              "class": 2,
              "system:index": "1653"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.39306640625, 48.12943437745315]),
            {
              "class": 2,
              "system:index": "1654"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.458984375, 48.21460773683882]),
            {
              "class": 2,
              "system:index": "1655"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.49057006835938, 48.24113823848043]),
            {
              "class": 2,
              "system:index": "1656"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43014526367188, 48.27131139102036]),
            {
              "class": 2,
              "system:index": "1657"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.51666259765625, 48.29050321714062]),
            {
              "class": 2,
              "system:index": "1658"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.45486450195312, 48.3434717583591]),
            {
              "class": 2,
              "system:index": "1659"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.41915893554688, 48.38361810886624]),
            {
              "class": 2,
              "system:index": "1660"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.39306640625, 48.2182679340594]),
            {
              "class": 2,
              "system:index": "1661"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.64300537109375, 48.176159867027536]),
            {
              "class": 2,
              "system:index": "1662"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.45486450195312, 48.444689281392094]),
            {
              "class": 2,
              "system:index": "1663"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28202819824219, 48.56479402807606]),
            {
              "class": 2,
              "system:index": "1664"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3431396484375, 48.633816159562485]),
            {
              "class": 2,
              "system:index": "1665"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.32322692871094, 48.66557095325139]),
            {
              "class": 2,
              "system:index": "1666"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.21748352050781, 48.50295743049265]),
            {
              "class": 2,
              "system:index": "1667"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14744567871094, 48.44332281905888]),
            {
              "class": 2,
              "system:index": "1668"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35481262207031, 48.52433597124222]),
            {
              "class": 2,
              "system:index": "1669"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38433837890625, 48.63926125872981]),
            {
              "class": 2,
              "system:index": "1670"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35549926757812, 48.62337807671534]),
            {
              "class": 2,
              "system:index": "1671"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.36717224121094, 48.58841747596737]),
            {
              "class": 2,
              "system:index": "1672"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.18658447265625, 48.532521108675226]),
            {
              "class": 2,
              "system:index": "1673"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.13714599609375, 48.512965529990865]),
            {
              "class": 2,
              "system:index": "1674"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3211669921875, 48.64969605608839]),
            {
              "class": 2,
              "system:index": "1675"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.33901977539062, 48.61429972785455]),
            {
              "class": 2,
              "system:index": "1676"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.29713439941406, 48.5588864412307]),
            {
              "class": 2,
              "system:index": "1677"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.21473693847656, 48.489761915762536]),
            {
              "class": 2,
              "system:index": "1678"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.39463806152344, 48.66602444828526]),
            {
              "class": 2,
              "system:index": "1679"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50038146972656, 48.63744629097557]),
            {
              "class": 2,
              "system:index": "1680"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00991821289062, 48.87013489622034]),
            {
              "class": 2,
              "system:index": "1681"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.88357543945312, 48.92701086532901]),
            {
              "class": 2,
              "system:index": "1682"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.76066589355469, 48.87148983809234]),
            {
              "class": 2,
              "system:index": "1683"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25985717773438, 48.834441554238715]),
            {
              "class": 2,
              "system:index": "1684"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11016845703125, 48.74939808773793]),
            {
              "class": 2,
              "system:index": "1685"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.97489929199219, 48.7222262088273]),
            {
              "class": 2,
              "system:index": "1686"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93438720703125, 48.7222262088273]),
            {
              "class": 2,
              "system:index": "1687"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.32371520996094, 48.81409852735575]),
            {
              "class": 2,
              "system:index": "1688"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50155639648438, 48.78243740444988]),
            {
              "class": 2,
              "system:index": "1689"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37109375, 48.72675587520717]),
            {
              "class": 2,
              "system:index": "1690"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.10673522949219, 48.70455661164196]),
            {
              "class": 2,
              "system:index": "1691"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83001708984375, 48.78469957597415]),
            {
              "class": 2,
              "system:index": "1692"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.79362487792969, 48.726302926927936]),
            {
              "class": 2,
              "system:index": "1693"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.78126525878906, 48.64697414317913]),
            {
              "class": 2,
              "system:index": "1694"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.88151550292969, 48.58251264888238]),
            {
              "class": 2,
              "system:index": "1695"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.95635986328125, 48.585692256886624]),
            {
              "class": 2,
              "system:index": "1696"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.04081726074219, 48.56933785614441]),
            {
              "class": 2,
              "system:index": "1697"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.17471313476562, 48.5534326717307]),
            {
              "class": 2,
              "system:index": "1698"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93576049804688, 48.525700252688765]),
            {
              "class": 2,
              "system:index": "1699"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.06072998046875, 48.46609239183472]),
            {
              "class": 2,
              "system:index": "1700"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83688354492188, 48.47610776896956]),
            {
              "class": 2,
              "system:index": "1701"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.78469848632812, 48.395473475227774]),
            {
              "class": 2,
              "system:index": "1702"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.33195495605469, 48.38133791407511]),
            {
              "class": 2,
              "system:index": "1703"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3326416015625, 48.458807239544754]),
            {
              "class": 2,
              "system:index": "1704"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37315368652344, 48.495677571224654]),
            {
              "class": 2,
              "system:index": "1705"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43495178222656, 48.518423660301615]),
            {
              "class": 2,
              "system:index": "1706"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.27565002441406, 48.27588152743497]),
            {
              "class": 2,
              "system:index": "1707"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25161743164062, 48.295985271707636]),
            {
              "class": 2,
              "system:index": "1708"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.20109230957031, 48.35898659941894]),
            {
              "class": 2,
              "system:index": "1709"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37933349609375, 48.3548801894373]),
            {
              "class": 2,
              "system:index": "1710"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.48851013183594, 48.32156041109598]),
            {
              "class": 2,
              "system:index": "1711"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.59425354003906, 48.46199462233164]),
            {
              "class": 2,
              "system:index": "1712"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.74806213378906, 48.50932644976633]),
            {
              "class": 2,
              "system:index": "1713"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.91972351074219, 48.50386733939324]),
            {
              "class": 2,
              "system:index": "1714"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.95748901367188, 48.5034123869848]),
            {
              "class": 2,
              "system:index": "1715"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.90187072753906, 48.4045911084346]),
            {
              "class": 2,
              "system:index": "1716"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.8819580078125, 48.30283701224864]),
            {
              "class": 2,
              "system:index": "1717"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.82771301269531, 48.27496753285298]),
            {
              "class": 2,
              "system:index": "1718"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70068359375, 48.33343022631068]),
            {
              "class": 2,
              "system:index": "1719"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.69587707519531, 48.15051192444075]),
            {
              "class": 2,
              "system:index": "1720"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.53520202636719, 48.15646705410985]),
            {
              "class": 2,
              "system:index": "1721"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.76179504394531, 48.19996433122712]),
            {
              "class": 2,
              "system:index": "1722"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87646484375, 48.22009793454488]),
            {
              "class": 2,
              "system:index": "1723"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.52490234375, 48.30375050817212]),
            {
              "class": 2,
              "system:index": "1724"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.53314208984375, 48.39456162202509]),
            {
              "class": 2,
              "system:index": "1725"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.52078247070312, 48.422365792950686]),
            {
              "class": 2,
              "system:index": "1726"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.52627563476562, 48.44286732344491]),
            {
              "class": 2,
              "system:index": "1727"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.47889709472656, 48.49840764096434]),
            {
              "class": 2,
              "system:index": "1728"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.47065734863281, 48.34894812401375]),
            {
              "class": 2,
              "system:index": "1729"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50567626953125, 48.23427822033628]),
            {
              "class": 2,
              "system:index": "1730"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.48164367675781, 48.26674084583965]),
            {
              "class": 2,
              "system:index": "1731"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5853271484375, 48.228332127214934]),
            {
              "class": 2,
              "system:index": "1732"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44044494628906, 48.08129016136076]),
            {
              "class": 2,
              "system:index": "1733"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.33744812011719, 48.140432438188114]),
            {
              "class": 2,
              "system:index": "1734"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.53314208984375, 48.153718618604735]),
            {
              "class": 2,
              "system:index": "1735"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.491943359375, 48.017946316196635]),
            {
              "class": 2,
              "system:index": "1736"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.72265625, 48.015190468512934]),
            {
              "class": 2,
              "system:index": "1737"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.83869934082031, 48.09183989449307]),
            {
              "class": 2,
              "system:index": "1738"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.22758483886719, 48.192641058330935]),
            {
              "class": 2,
              "system:index": "1739"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.98451232910156, 48.12668449417932]),
            {
              "class": 2,
              "system:index": "1740"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0360107421875, 47.95222519664452]),
            {
              "class": 2,
              "system:index": "1741"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.16647338867188, 48.0165684107673]),
            {
              "class": 2,
              "system:index": "1742"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25230407714844, 48.04916896238881]),
            {
              "class": 2,
              "system:index": "1743"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.18089294433594, 48.11201596330927]),
            {
              "class": 2,
              "system:index": "1744"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.2392578125, 48.14180703014265]),
            {
              "class": 2,
              "system:index": "1745"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.09025573730469, 48.02529452322739]),
            {
              "class": 2,
              "system:index": "1746"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9371337890625, 48.00140902055228]),
            {
              "class": 2,
              "system:index": "1747"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.02159118652344, 47.916342040161155]),
            {
              "class": 2,
              "system:index": "1748"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00030517578125, 47.867998465477655]),
            {
              "class": 2,
              "system:index": "1749"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.08270263671875, 47.853716971068195]),
            {
              "class": 2,
              "system:index": "1750"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.08338928222656, 47.77163739198216]),
            {
              "class": 2,
              "system:index": "1751"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.26535034179688, 47.75317468890147]),
            {
              "class": 2,
              "system:index": "1752"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.34500122070312, 47.69820940045468]),
            {
              "class": 2,
              "system:index": "1753"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.38002010160156, 47.56726060598141]),
            {
              "class": 2,
              "system:index": "1754"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.27153015136719, 47.53899190311993]),
            {
              "class": 2,
              "system:index": "1755"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0799560546875, 47.65012501030461]),
            {
              "class": 2,
              "system:index": "1756"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14518737792969, 47.668161849014616]),
            {
              "class": 2,
              "system:index": "1757"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14862060546875, 47.3304463918556]),
            {
              "class": 2,
              "system:index": "1758"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.34088134765625, 47.319275921066065]),
            {
              "class": 2,
              "system:index": "1759"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43014526367188, 47.429945332976125]),
            {
              "class": 2,
              "system:index": "1760"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43220520019531, 47.29692789291742]),
            {
              "class": 2,
              "system:index": "1761"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.06210327148438, 47.28807918803615]),
            {
              "class": 2,
              "system:index": "1762"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01609802246094, 47.40996762926796]),
            {
              "class": 2,
              "system:index": "1763"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91859436035156, 47.3746396594011]),
            {
              "class": 2,
              "system:index": "1764"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83207702636719, 47.33463470942129]),
            {
              "class": 2,
              "system:index": "1765"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01266479492188, 47.09864243495673]),
            {
              "class": 2,
              "system:index": "1766"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23239135742188, 47.13088505030974]),
            {
              "class": 2,
              "system:index": "1767"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.31204223632812, 47.1210741484473]),
            {
              "class": 2,
              "system:index": "1768"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23445129394531, 47.02988649779455]),
            {
              "class": 2,
              "system:index": "1769"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50498962402344, 46.97556750833867]),
            {
              "class": 2,
              "system:index": "1770"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.49949645996094, 47.08742303288898]),
            {
              "class": 2,
              "system:index": "1771"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.56678771972656, 47.1210741484473]),
            {
              "class": 2,
              "system:index": "1772"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.67459106445312, 47.184112659842015]),
            {
              "class": 2,
              "system:index": "1773"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.08338928222656, 46.98962081759436]),
            {
              "class": 2,
              "system:index": "1774"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.04905700683594, 47.15843932956511]),
            {
              "class": 2,
              "system:index": "1775"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83207702636719, 46.98118927533911]),
            {
              "class": 2,
              "system:index": "1776"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.85198974609375, 47.178045538155594]),
            {
              "class": 2,
              "system:index": "1777"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67826843261719, 47.11967244332479]),
            {
              "class": 2,
              "system:index": "1778"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.68376159667969, 47.286681888764214]),
            {
              "class": 2,
              "system:index": "1779"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.39811706542969, 47.01443930276005]),
            {
              "class": 2,
              "system:index": "1780"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53132629394531, 47.04954010021555]),
            {
              "class": 2,
              "system:index": "1781"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74075317382812, 47.05515408550349]),
            {
              "class": 2,
              "system:index": "1782"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.52033996582031, 46.855026101172285]),
            {
              "class": 2,
              "system:index": "1783"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.71122741699219, 46.771379325560325]),
            {
              "class": 2,
              "system:index": "1784"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.41390991210938, 46.72903648802457]),
            {
              "class": 2,
              "system:index": "1785"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.29306030273438, 46.94557476823196]),
            {
              "class": 2,
              "system:index": "1786"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.17289733886719, 47.05702528260841]),
            {
              "class": 2,
              "system:index": "1787"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.217529296875, 47.131819327544115]),
            {
              "class": 2,
              "system:index": "1788"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19898986816406, 46.81321897604194]),
            {
              "class": 2,
              "system:index": "1789"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.30679321289062, 46.80616962858922]),
            {
              "class": 2,
              "system:index": "1790"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.86390686035156, 47.00226563747878]),
            {
              "class": 2,
              "system:index": "1791"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91334533691406, 46.94323087731894]),
            {
              "class": 2,
              "system:index": "1792"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96072387695312, 46.82073726164968]),
            {
              "class": 2,
              "system:index": "1793"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96965026855469, 46.60369541161162]),
            {
              "class": 2,
              "system:index": "1794"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87901306152344, 46.43075850004631]),
            {
              "class": 2,
              "system:index": "1795"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.052734375, 46.46718711888634]),
            {
              "class": 2,
              "system:index": "1796"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.29786682128906, 46.4477930946896]),
            {
              "class": 2,
              "system:index": "1797"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27589416503906, 46.556499533500876]),
            {
              "class": 2,
              "system:index": "1798"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.24087524414062, 46.40140865838162]),
            {
              "class": 2,
              "system:index": "1799"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6572265625, 46.66640227857272]),
            {
              "class": 2,
              "system:index": "1800"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87763977050781, 46.684776229520075]),
            {
              "class": 2,
              "system:index": "1801"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65997314453125, 46.71067759419637]),
            {
              "class": 2,
              "system:index": "1802"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.68194580078125, 46.243026429883216]),
            {
              "class": 2,
              "system:index": "1803"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84262084960938, 46.2340028786225]),
            {
              "class": 2,
              "system:index": "1804"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85086059570312, 45.9874205909687]),
            {
              "class": 2,
              "system:index": "1805"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03762817382812, 46.03749263453821]),
            {
              "class": 2,
              "system:index": "1806"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.13169860839844, 46.11037360219251]),
            {
              "class": 2,
              "system:index": "1807"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19143676757812, 46.14987006896229]),
            {
              "class": 2,
              "system:index": "1808"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18251037597656, 46.197418556693144]),
            {
              "class": 2,
              "system:index": "1809"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16740417480469, 46.2890709079757]),
            {
              "class": 2,
              "system:index": "1810"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.36721801757812, 46.087519345973455]),
            {
              "class": 2,
              "system:index": "1811"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.50454711914062, 45.995053544340294]),
            {
              "class": 2,
              "system:index": "1812"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.70573425292969, 46.08180430179255]),
            {
              "class": 2,
              "system:index": "1813"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74006652832031, 46.1408312087306]),
            {
              "class": 2,
              "system:index": "1814"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.50248718261719, 45.88857434601571]),
            {
              "class": 2,
              "system:index": "1815"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.46609497070312, 45.88331671631865]),
            {
              "class": 2,
              "system:index": "1816"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.25872802734375, 45.944943074191265]),
            {
              "class": 2,
              "system:index": "1817"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.32052612304688, 46.11656166641602]),
            {
              "class": 2,
              "system:index": "1818"
            })]),
    cdl = ee.Image("users/images/CDL_composite_08_12_wo_fallow"),
    prev = ee.Image("users/images/NGreatPlains_2010_v1"),
    input = ee.Image("users/images/input/NGreatPlains_2010_InputSR");
/***** End of imports. If edited, may not auto-convert in the playground. *****/


var zones=ee.FeatureCollection("ft:1emWmrrMBzdiKOitmcYSBmoCozs4Fpqq_f6A86pnR"); 
var zones2=ee.FeatureCollection("ft:13cK2cS_HzpvNGVZlIfH9zInVbJOMQgjXQKwgLHpL");
var countries = ee.FeatureCollection("ft:1tdSwUL7MVpOauSgRzqVTOwdfy17KDbw-1d9omPw"); 

//Map.addLayer(zones)


/*
function radians(img) {return img.toFloat().multiply(Math.PI).divide(180).divide(1.5708).toFloat();}
var terrain = ee.Algorithms.Terrain(ee.Image('USGS/SRTMGL1_003'));
var slope = radians(terrain.select('slope'));
var elevation = terrain.select('elevation').divide(4000.00).float();
*/

//input=input.select(ee.List.sequence(0,43)).addBands(slope).addBands(elevation);

//visual parameters for FCC display 
var vizParams = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  gamma: [1.5,1.6, 1.7]
};



//add all max val to map
//Map.addLayer(FCC,vizParams,'FCC');


//Map.addLayer(cdl,{palette:'ffff00'},'CDL')
//Map.addLayer(prev,{palette:'00ff00'},'prev')
//throw('stop')

//create bounds for training samples inside area of interest
function buffer(geometry) {
  return geometry.buffer(60).bounds();
} 

//buffer function of 1km********************************************************
function buffer1(geometry) {
  return geometry.buffer(10000);
}

function buffer2(geometry) {
  return geometry.buffer(10000);
}

var studyArea = zones.filterMetadata('name','equals','NGreatPlains');

var region= ee.FeatureCollection(countries.filterMetadata('Country','equals','United States'))
              .map(buffer2)

studyArea=buffer1(studyArea.geometry());



var CropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea);
/*
var CropSamplesArea2 = Cropclass2.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea2);

var CropSamplesArea2 = Cropclass3.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea3);
*/
var NonCropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea);
/*
var NonCropSamplesArea2 = NonCropClass2.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea2);

var NonCropSamplesArea2 = NonCropClass3.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea3);
*/
//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                   // .merge(CropSamplesArea2)
                   // .merge(CropSamplesArea3)
                    .merge(NonCropSamplesArea)
                   //.merge(NonCropSamplesArea2)
                  // .merge(NonCropSamplesArea3);
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);

//print(input)

var training = input.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});
 

//build classifier
var classifier = ee.Classifier.randomForest(400,5).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input.classify(classifier);

classified = classified.updateMask(classified.eq(1)).clip(studyArea).clipToCollection(region);

////Export the classified image
Export.image.toAsset({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  description: 'NGreatPlains_v1_asset',
  assetId: 'NGreatPlains_2010_v1',
  region: studyArea, 
});


Export.image.toDrive({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  folder: 'data',
  description: 'NGreatPlains',
  fileNamePrefix: 'NGreatPlains_2010_v1',
  region: studyArea, 
});
 

Export.table.toDrive({
  collection: training,
  description: 'RandomForestTrainingTable_NGreatPlains_v1',
  folder: 'data',
  fileNamePrefix: 'RFtable_NGreatPlains_2010_v1',
  fileFormat: 'CSV'
});


//print('Classified',classified);

//add layer to map
Map.addLayer(classified, {palette: '00FF00'}, 'cropland');

Map.addLayer(cdl,{palette:'ffff00'},'CDL')

