/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var Cropclass = /* color: #ff0000 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-101.964111328125, 36.98719701173416]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.45574951171875, 36.65850456897558]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.15499877929688, 36.74878811183201]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.25799560546875, 36.70806354647625]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.63839721679688, 36.57032090532844]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.10830688476562, 36.474306755095235]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49307250976562, 37.02996578145435]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.162109375, 36.7762924811868]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14425659179688, 37.01680872317756]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.997314453125, 36.81258314263445]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.45736694335938, 36.856548768788954]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.33102416992188, 36.958671131530316]),
            {
              "class": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.93276977539062, 36.48314061639213]),
            {
              "class": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.10443115234375, 36.19109202182454]),
            {
              "class": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.08932495117188, 36.04021586880111]),
            {
              "class": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.61279296875, 36.33835943134044]),
            {
              "class": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43289184570312, 36.45553145640271]),
            {
              "class": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.72402954101562, 36.457740551058286]),
            {
              "class": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.21566772460938, 36.363798554158635]),
            {
              "class": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4422607421875, 36.33614694088851]),
            {
              "class": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5960693359375, 36.24870331653197]),
            {
              "class": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6729736328125, 36.20439070158873]),
            {
              "class": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2332763671875, 36.115690180653395]),
            {
              "class": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.46810913085938, 36.0857311106239]),
            {
              "class": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70156860351562, 36.05687084084707]),
            {
              "class": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.27883911132812, 36.88181755936464]),
            {
              "class": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.72103881835938, 36.78399193687661]),
            {
              "class": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69631958007812, 36.319551259461186]),
            {
              "class": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0025634765625, 36.49528553125808]),
            {
              "class": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6842041015625, 36.96964388918141]),
            {
              "class": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.10055541992188, 36.82797398619907]),
            {
              "class": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57846069335938, 36.55377524336089]),
            {
              "class": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.12252807617188, 36.30737884678978]),
            {
              "class": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.10467529296875, 36.57914380937464]),
            {
              "class": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.75399780273438, 36.97622678464096]),
            {
              "class": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.700439453125, 36.56590907528833]),
            {
              "class": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.964111328125, 36.18887535558557]),
            {
              "class": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95724487304688, 35.98911865383744]),
            {
              "class": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.195068359375, 36.46988944681576]),
            {
              "class": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.0137939453125, 36.35273908735874]),
            {
              "class": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70205688476562, 36.27860013544234]),
            {
              "class": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.57684326171875, 35.951329861522666]),
            {
              "class": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.38870239257812, 36.05798104702502]),
            {
              "class": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.19369506835938, 36.09017021216552]),
            {
              "class": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.99432373046875, 35.68630240145625]),
            {
              "class": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.36099243164062, 35.808904044068626]),
            {
              "class": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4420166015625, 36.387018318771105]),
            {
              "class": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.15338134765625, 36.07685215551435]),
            {
              "class": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.84439086914062, 36.23319675732526]),
            {
              "class": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.92404174804688, 36.46326301239126]),
            {
              "class": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76336669921875, 36.64307970866717]),
            {
              "class": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.52304077148438, 36.737783602451906]),
            {
              "class": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.42141723632812, 36.83017242546416]),
            {
              "class": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.40081787109375, 35.94243575255426]),
            {
              "class": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.78121948242188, 35.88682489453265]),
            {
              "class": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.22891235351562, 35.71083783530009]),
            {
              "class": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9091796875, 36.47982803641967]),
            {
              "class": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.09457397460938, 36.00134056648952]),
            {
              "class": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.13302612304688, 35.85566574217861]),
            {
              "class": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5518798828125, 35.1659501617872]),
            {
              "class": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.79083251953125, 35.02437356760802]),
            {
              "class": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8597412109375, 34.847621012767874]),
            {
              "class": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55075073242188, 35.037867641214405]),
            {
              "class": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.42578125, 35.345375322554474]),
            {
              "class": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92864990234375, 35.6427892190328]),
            {
              "class": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.78857421875, 35.70080152485188]),
            {
              "class": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.29830932617188, 35.78105661888156]),
            {
              "class": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6512451171875, 36.09571873655538]),
            {
              "class": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3326416015625, 35.12440157992043]),
            {
              "class": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.16073608398438, 35.185032937998294]),
            {
              "class": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.19644165039062, 35.099686964274724]),
            {
              "class": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.32940673828125, 34.755153088189324]),
            {
              "class": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72354125976562, 34.85776361287335]),
            {
              "class": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.37472534179688, 34.98837848142154]),
            {
              "class": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.96273803710938, 35.081707990840705]),
            {
              "class": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69769287109375, 35.10979839484955]),
            {
              "class": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.62490844726562, 35.36889537510474]),
            {
              "class": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.96298217773438, 35.4550769336729]),
            {
              "class": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.47683715820312, 35.507635947037855]),
            {
              "class": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.66635131835938, 34.896068816229686]),
            {
              "class": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.89981079101562, 34.97487624147657]),
            {
              "class": 1,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.337890625, 35.343134960281894]),
            {
              "class": 1,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37109375, 34.928726792983845]),
            {
              "class": 1,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.63888549804688, 34.70210643670556]),
            {
              "class": 1,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87234497070312, 34.65128519895413]),
            {
              "class": 1,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60293579101562, 34.53936876533996]),
            {
              "class": 1,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26211547851562, 34.44315867450577]),
            {
              "class": 1,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70431518554688, 34.45448326886294]),
            {
              "class": 1,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70706176757812, 34.65128519895413]),
            {
              "class": 1,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.09619140625, 34.359308974793564]),
            {
              "class": 1,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87509155273438, 34.36044263880677]),
            {
              "class": 1,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.96710205078125, 34.25381122162007]),
            {
              "class": 1,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.91766357421875, 34.109530506665884]),
            {
              "class": 1,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.4644775390625, 34.19362958613085]),
            {
              "class": 1,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0799560546875, 34.35364042469895]),
            {
              "class": 1,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.03875732421875, 34.69533207371177]),
            {
              "class": 1,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.41116333007812, 34.732584206123626]),
            {
              "class": 1,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.3218994140625, 35.2108436808834]),
            {
              "class": 1,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97171020507812, 35.314004597852474]),
            {
              "class": 1,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16946411132812, 35.05360791102559]),
            {
              "class": 1,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47845458984375, 35.00862766620555]),
            {
              "class": 1,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.32327270507812, 34.53936876533996]),
            {
              "class": 1,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.05136108398438, 34.440893571391165]),
            {
              "class": 1,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82476806640625, 34.92084502261776]),
            {
              "class": 1,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82339477539062, 35.11878528004355]),
            {
              "class": 1,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73550415039062, 35.29719384502174]),
            {
              "class": 1,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58169555664062, 35.400244786795064]),
            {
              "class": 1,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.4317626953125, 34.60043278504442]),
            {
              "class": 1,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53887939453125, 34.31735262740534]),
            {
              "class": 1,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.55673217773438, 34.267431281324875]),
            {
              "class": 1,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.44412231445312, 34.076549928891744]),
            {
              "class": 1,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.09805297851562, 34.13340497084095]),
            {
              "class": 1,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11041259765625, 34.26970107685835]),
            {
              "class": 1,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7835693359375, 34.025347738147936]),
            {
              "class": 1,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66958618164062, 34.35477416538757]),
            {
              "class": 1,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72589111328125, 34.178861487501464]),
            {
              "class": 1,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.69818115234375, 33.97639231886985]),
            {
              "class": 1,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.283203125, 33.959308210392024]),
            {
              "class": 1,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.07284545898438, 34.0094118622566]),
            {
              "class": 1,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23626708984375, 33.96842016198477]),
            {
              "class": 1,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35574340820312, 34.23905366851639]),
            {
              "class": 1,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.39144897460938, 34.40011121603371]),
            {
              "class": 1,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.34201049804688, 34.538237527295756]),
            {
              "class": 1,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.64437866210938, 34.57216798051356]),
            {
              "class": 1,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.45623779296875, 34.6060845921693]),
            {
              "class": 1,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.920654296875, 34.719039917647876]),
            {
              "class": 1,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.15274047851562, 34.85100201839405]),
            {
              "class": 1,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67483520507812, 34.77545980961412]),
            {
              "class": 1,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74212646484375, 34.99512876641514]),
            {
              "class": 1,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97994995117188, 34.89268966339912]),
            {
              "class": 1,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.23538208007812, 35.34201075584807]),
            {
              "class": 1,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65585327148438, 34.45674800347809]),
            {
              "class": 1,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36471557617188, 34.118626335469514]),
            {
              "class": 1,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13125610351562, 34.11180455556898]),
            {
              "class": 1,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.19854736328125, 34.371778435431224]),
            {
              "class": 1,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87420654296875, 33.75631505992706]),
            {
              "class": 1,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63800048828125, 33.80653802509606]),
            {
              "class": 1,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24935913085938, 33.94905609818093]),
            {
              "class": 1,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.448486328125, 33.66263917576218]),
            {
              "class": 1,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37158203125, 33.5093393678006]),
            {
              "class": 1,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.00192260742188, 33.45321401062559]),
            {
              "class": 1,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.58419799804688, 33.43717151666947]),
            {
              "class": 1,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.51828002929688, 33.65578083204094]),
            {
              "class": 1,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67758178710938, 33.69349495645655]),
            {
              "class": 1,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.73251342773438, 33.83962341851979]),
            {
              "class": 1,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.382080078125, 33.86585445407186]),
            {
              "class": 1,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73638916015625, 33.455505553269184]),
            {
              "class": 1,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.96734619140625, 33.358061612778876]),
            {
              "class": 1,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.75723266601562, 33.384439582098224]),
            {
              "class": 1,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.52926635742188, 33.505904166596224]),
            {
              "class": 1,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.371337890625, 33.63177232463965]),
            {
              "class": 1,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.29306030273438, 33.54940663754663]),
            {
              "class": 1,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.08432006835938, 33.51162942617925]),
            {
              "class": 1,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84811401367188, 33.343148788082694]),
            {
              "class": 1,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40841674804688, 33.200775086578396]),
            {
              "class": 1,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.72152709960938, 33.052414410040605]),
            {
              "class": 1,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11154174804688, 32.9372338139709]),
            {
              "class": 1,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.48233032226562, 32.81382424144306]),
            {
              "class": 1,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.83663940429688, 32.73415132036002]),
            {
              "class": 1,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.26397705078125, 33.4761267117029]),
            {
              "class": 1,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.71603393554688, 32.94299641333288]),
            {
              "class": 1,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.83575439453125, 33.1892832251331]),
            {
              "class": 1,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47457885742188, 33.5459730276919]),
            {
              "class": 1,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.019775390625, 33.27199095538211]),
            {
              "class": 1,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74624633789062, 33.277731642555224]),
            {
              "class": 1,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.635009765625, 33.51735430695927]),
            {
              "class": 1,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91241455078125, 33.1329513125159]),
            {
              "class": 1,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99618530273438, 33.13065128220441]),
            {
              "class": 1,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.04974365234375, 33.19043247913695]),
            {
              "class": 1,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90692138671875, 33.574582273543555]),
            {
              "class": 1,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.96871948242188, 33.49674296343326]),
            {
              "class": 1,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.73251342773438, 33.758598560812004]),
            {
              "class": 1,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84375, 33.916013113401696]),
            {
              "class": 1,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.4537353515625, 33.93880275084578]),
            {
              "class": 1,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.35760498046875, 34.00030430441023]),
            {
              "class": 1,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.17221069335938, 34.414840472199934]),
            {
              "class": 1,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91265869140625, 34.38311269824024]),
            {
              "class": 1,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20654296875, 34.57556026465247]),
            {
              "class": 1,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11453247070312, 34.76417891445512]),
            {
              "class": 1,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.90579223632812, 34.86114420171435]),
            {
              "class": 1,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5748291015625, 34.99512876641514]),
            {
              "class": 1,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55697631835938, 35.1861553147444]),
            {
              "class": 1,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41964721679688, 35.22430689927387]),
            {
              "class": 1,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4375, 35.48191987272801]),
            {
              "class": 1,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6572265625, 35.65841206428204]),
            {
              "class": 1,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81378173828125, 35.77994251888403]),
            {
              "class": 1,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4100341796875, 35.86456960744962]),
            {
              "class": 1,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85223388671875, 36.15118243124803]),
            {
              "class": 1,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03488159179688, 36.023557373379276]),
            {
              "class": 1,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.15573120117188, 36.22211876039103]),
            {
              "class": 1,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83551025390625, 36.2675285739382]),
            {
              "class": 1,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.23675537109375, 36.35605709240176]),
            {
              "class": 1,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20379638671875, 36.48424477824479]),
            {
              "class": 1,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9154052734375, 36.49859745028132]),
            {
              "class": 1,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81790161132812, 36.76639204454786]),
            {
              "class": 1,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18319702148438, 36.70035646962128]),
            {
              "class": 1,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5858154296875, 36.86094394142341]),
            {
              "class": 1,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.76571655273438, 37.05517710666082]),
            {
              "class": 1,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31253051757812, 36.948794297566366]),
            {
              "class": 1,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45809936523438, 36.75759058319245]),
            {
              "class": 1,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47732543945312, 36.641977814705946]),
            {
              "class": 1,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00765991210938, 36.82797398619907]),
            {
              "class": 1,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1024169921875, 37.040928255945914]),
            {
              "class": 1,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3935546875, 37.0540811361903]),
            {
              "class": 1,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.24087524414062, 37.070519031125826]),
            {
              "class": 1,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.50454711914062, 36.8037869853087]),
            {
              "class": 1,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.69268798828125, 36.954281585675965]),
            {
              "class": 1,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.82589721679688, 37.089144339214535]),
            {
              "class": 1,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53338623046875, 36.34057185894721]),
            {
              "class": 1,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.28619384765625, 35.951329861522666]),
            {
              "class": 1,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97720336914062, 35.75765724051559]),
            {
              "class": 1,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01016235351562, 35.52216747798627]),
            {
              "class": 1,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33587646484375, 35.67737855391475]),
            {
              "class": 1,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00216674804688, 35.9635576265708]),
            {
              "class": 1,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0419921875, 36.10459556076901]),
            {
              "class": 1,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41552734375, 36.092389668927595]),
            {
              "class": 1,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52264404296875, 36.29409768373033]),
            {
              "class": 1,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30703735351562, 36.527294814546245]),
            {
              "class": 1,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02413940429688, 36.629855940857]),
            {
              "class": 1,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.855224609375, 36.61222072017988]),
            {
              "class": 1,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0419921875, 35.7186429809343]),
            {
              "class": 1,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.78656005859375, 35.87792352995116]),
            {
              "class": 1,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60940551757812, 36.13787471840729]),
            {
              "class": 1,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.41851806640625, 36.41354670392874]),
            {
              "class": 1,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.68630981445312, 36.62765175890194]),
            {
              "class": 1,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.61077880859375, 36.74218559555117]),
            {
              "class": 1,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5421142578125, 36.932330061503144]),
            {
              "class": 1,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.61489868164062, 37.08585785263673]),
            {
              "class": 1,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.46109008789062, 37.10995544464346]),
            {
              "class": 1,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22763061523438, 37.088048859522694]),
            {
              "class": 1,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.08206176757812, 37.00803608513944]),
            {
              "class": 1,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.998291015625, 37.083666782415534]),
            {
              "class": 1,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.18505859375, 36.90268547298942]),
            {
              "class": 1,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.152099609375, 36.71356812817935]),
            {
              "class": 1,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.90078735351562, 36.84775766525785]),
            {
              "class": 1,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.91177368164062, 36.54053616262899]),
            {
              "class": 1,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.18917846679688, 36.55818776636068]),
            {
              "class": 1,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44873046875, 36.71797150960849]),
            {
              "class": 1,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35397338867188, 36.6563012066723]),
            {
              "class": 1,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22488403320312, 36.500805317604794]),
            {
              "class": 1,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01751708984375, 36.52839834681223]),
            {
              "class": 1,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11639404296875, 36.328402729422656]),
            {
              "class": 1,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60116577148438, 36.245380741380465]),
            {
              "class": 1,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31414794921875, 35.991340960635405]),
            {
              "class": 1,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.10678100585938, 35.705262263265716]),
            {
              "class": 1,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.63162231445312, 36.04021586880111]),
            {
              "class": 1,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93624877929688, 36.26199220445664]),
            {
              "class": 1,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.15185546875, 36.36490441440569]),
            {
              "class": 1,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.75497436523438, 36.43896124085945]),
            {
              "class": 1,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.56134033203125, 36.55377524336089]),
            {
              "class": 1,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.899169921875, 37.002552672159545]),
            {
              "class": 1,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84561157226562, 36.094609063015085]),
            {
              "class": 1,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23587036132812, 35.545635932499415]),
            {
              "class": 1,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.99005126953125, 35.338654049359086]),
            {
              "class": 1,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.79229736328125, 35.39576704533903]),
            {
              "class": 1,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4544677734375, 35.46514408578589]),
            {
              "class": 1,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.29928588867188, 34.989503567579305]),
            {
              "class": 1,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.97357177734375, 34.81605826221895]),
            {
              "class": 1,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.18780517578125, 34.7461262752594]),
            {
              "class": 1,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38143920898438, 34.83184114982865]),
            {
              "class": 1,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4652099609375, 34.829586636768205]),
            {
              "class": 1,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.67807006835938, 34.87353850537196]),
            {
              "class": 1,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.86895751953125, 35.34425514918409]),
            {
              "class": 1,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.78793334960938, 35.34425514918409]),
            {
              "class": 1,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.07907104492188, 35.42598697382711]),
            {
              "class": 1,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9486083984375, 35.573565616089326]),
            {
              "class": 1,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.06121826171875, 35.12103184646136]),
            {
              "class": 1,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.009033203125, 35.06372505419625]),
            {
              "class": 1,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8497314453125, 35.02437356760802]),
            {
              "class": 1,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88406372070312, 34.05493499798558]),
            {
              "class": 1,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.56820678710938, 34.06972475691634]),
            {
              "class": 1,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31552124023438, 33.52422366383016]),
            {
              "class": 1,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.84173583984375, 33.60775712333095]),
            {
              "class": 1,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63687133789062, 33.96500329452546]),
            {
              "class": 1,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1962890625, 33.78827853625996]),
            {
              "class": 1,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.80902099609375, 33.830497692052425]),
            {
              "class": 1,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.57830810546875, 33.90917503325776]),
            {
              "class": 1,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.22262573242188, 33.925129700072]),
            {
              "class": 1,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.1251220703125, 33.895497227123876]),
            {
              "class": 1,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.39016723632812, 33.84646707394075]),
            {
              "class": 1,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.2679443359375, 33.50475906922609]),
            {
              "class": 1,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.49179077148438, 33.3442960191357]),
            {
              "class": 1,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.97930908203125, 33.54814769105164]),
            {
              "class": 1,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3446044921875, 33.05229919215274]),
            {
              "class": 1,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.16607666015625, 33.120185271122686]),
            {
              "class": 1,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.34323120117188, 32.86678441609813]),
            {
              "class": 1,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.50390625, 32.66816507239637]),
            {
              "class": 1,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4544677734375, 32.56058766527008]),
            {
              "class": 1,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4324951171875, 32.430860696282764]),
            {
              "class": 1,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40228271484375, 32.343885454380015]),
            {
              "class": 1,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52313232421875, 32.437815096755045]),
            {
              "class": 1,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57257080078125, 32.54206669858704]),
            {
              "class": 1,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.56021118164062, 32.60803019334514]),
            {
              "class": 1,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.3778076171875, 33.383178097197096]),
            {
              "class": 1,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.82412719726562, 33.41986510381329]),
            {
              "class": 1,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8499755859375, 33.28335703764299]),
            {
              "class": 1,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85821533203125, 33.418718869350016]),
            {
              "class": 1,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.32101440429688, 33.3453284021284]),
            {
              "class": 1,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29904174804688, 33.170778047916066]),
            {
              "class": 1,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.899169921875, 33.87828289809257]),
            {
              "class": 1,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0584716796875, 33.010851443704546]),
            {
              "class": 1,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44461059570312, 32.39955925752319]),
            {
              "class": 1,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22625732421875, 32.17782086182375]),
            {
              "class": 1,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.41729736328125, 34.58449250692858]),
            {
              "class": 1,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.128662109375, 34.5844925069286]),
            {
              "class": 1,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.23440551757812, 34.74939849875287]),
            {
              "class": 1,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76748657226562, 34.87905889279583]),
            {
              "class": 1,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.80319213867188, 34.703235443285095]),
            {
              "class": 1,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38983154296875, 35.092945313732635]),
            {
              "class": 1,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.06549072265625, 34.799144669738155]),
            {
              "class": 1,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.09432983398438, 34.407759422739296]),
            {
              "class": 1,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.97039031982422, 34.39529531980665]),
            {
              "class": 1,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.711181640625, 34.36044263880677]),
            {
              "class": 1,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.7939224243164, 34.426168904360736]),
            {
              "class": 1,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.78465270996094, 34.57895241036948]),
            {
              "class": 1,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.26873779296875, 34.267431281324875]),
            {
              "class": 1,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.24298858642578, 34.19732120677331]),
            {
              "class": 1,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.9916763305664, 34.23252546390448]),
            {
              "class": 1,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.84954071044922, 34.210950405913884]),
            {
              "class": 1,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.49807739257812, 34.54728700119802]),
            {
              "class": 1,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79058837890625, 34.76417891445512]),
            {
              "class": 1,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.60794067382812, 35.160336728130346]),
            {
              "class": 1,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.55438232421875, 35.131140628613615]),
            {
              "class": 1,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.90756225585938, 34.92084502261776]),
            {
              "class": 1,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4859619140625, 34.876918445772084]),
            {
              "class": 1,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0025634765625, 34.84536693184101]),
            {
              "class": 1,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69082641601562, 34.79237826089951]),
            {
              "class": 1,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02041625976562, 34.65354458279874]),
            {
              "class": 1,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.29144287109375, 34.42163771567672]),
            {
              "class": 1,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.30953979492188, 34.23678304606286]),
            {
              "class": 1,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.43038940429688, 34.21180215769026]),
            {
              "class": 1,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10903930664062, 34.37064492478658]),
            {
              "class": 1,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7835693359375, 34.101570854106576]),
            {
              "class": 1,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98956298828125, 34.14022500809142]),
            {
              "class": 1,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81515502929688, 34.19476548661919]),
            {
              "class": 1,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.80117797851562, 34.5959110624079]),
            {
              "class": 1,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01129150390625, 34.423903340716706]),
            {
              "class": 1,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.6295166015625, 34.47146728120385]),
            {
              "class": 1,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.3548583984375, 34.69081552362158]),
            {
              "class": 1,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.25186157226562, 33.86699475113557]),
            {
              "class": 1,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.62677001953125, 33.74489664315623]),
            {
              "class": 1,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82888793945312, 33.73233462866422]),
            {
              "class": 1,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.23150634765625, 34.087923993423324]),
            {
              "class": 1,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50091552734375, 34.813803317113155]),
            {
              "class": 1,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73550415039062, 34.97150033361733]),
            {
              "class": 1,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7506103515625, 35.40584161390886]),
            {
              "class": 1,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3990478515625, 34.90282670487579]),
            {
              "class": 1,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30978393554688, 34.94111090242764]),
            {
              "class": 1,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87307739257812, 35.420391545750746]),
            {
              "class": 1,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.16558837890625, 35.5936689609791]),
            {
              "class": 1,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0694580078125, 35.902399875143615]),
            {
              "class": 1,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18206787109375, 35.68518697509635]),
            {
              "class": 1,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.800048828125, 33.544828460753685]),
            {
              "class": 1,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78955078125, 32.42518098455072]),
            {
              "class": 1,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.72500610351562, 32.46342595776104]),
            {
              "class": 1,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.59042358398438, 32.10002639514208]),
            {
              "class": 1,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85272216796875, 32.07908379244607]),
            {
              "class": 1,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96945190429688, 31.8693940962347]),
            {
              "class": 1,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.16033935546875, 31.983617898488095]),
            {
              "class": 1,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1466064453125, 32.39039874854987]),
            {
              "class": 1,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02850341796875, 31.84956532831343]),
            {
              "class": 1,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.69754028320312, 31.848398797399188]),
            {
              "class": 1,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.07382202148438, 31.80055833029521]),
            {
              "class": 1,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01202392578125, 31.44623870291349]),
            {
              "class": 1,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81015014648438, 31.52587333323966]),
            {
              "class": 1,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51602172851562, 31.44741029142872]),
            {
              "class": 1,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01065063476562, 31.334871033950602]),
            {
              "class": 1,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.91864013671875, 31.286766314555713]),
            {
              "class": 1,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2015380859375, 31.15053220759678]),
            {
              "class": 1,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.06558227539062, 31.012925049646267]),
            {
              "class": 1,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61239624023438, 30.791396195188927]),
            {
              "class": 1,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.34024047851562, 30.75245796847024]),
            {
              "class": 1,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00927734375, 31.190483229019833]),
            {
              "class": 1,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.0916748046875, 31.027047769854388]),
            {
              "class": 1,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.47207641601562, 30.745376598245574]),
            {
              "class": 1,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42263793945312, 30.66980960132695]),
            {
              "class": 1,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42538452148438, 30.90575967622237]),
            {
              "class": 1,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.46932983398438, 30.493651170505892]),
            {
              "class": 1,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40066528320312, 30.620186607785225]),
            {
              "class": 1,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44186401367188, 30.4297295750316]),
            {
              "class": 1,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.50253295898438, 30.594183452544698]),
            {
              "class": 1,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40365600585938, 30.490101071309315]),
            {
              "class": 1,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.24847412109375, 30.385907241796573]),
            {
              "class": 1,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17294311523438, 30.409597432180085]),
            {
              "class": 1,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.53274536132812, 30.692249731071875]),
            {
              "class": 1,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.80877685546875, 31.143480278378625]),
            {
              "class": 1,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.41989135742188, 31.312581657447687]),
            {
              "class": 1,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.130126953125, 30.76543912810554]),
            {
              "class": 1,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.525634765625, 30.652090026760014]),
            {
              "class": 1,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.19903564453125, 30.159376896356193]),
            {
              "class": 1,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9710693359375, 29.841835102794132]),
            {
              "class": 1,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.24435424804688, 29.61763959537609]),
            {
              "class": 1,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.93374633789062, 29.96326311304828]),
            {
              "class": 1,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.29653930664062, 29.523280500828598]),
            {
              "class": 1,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17294311523438, 29.559123451577964]),
            {
              "class": 1,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02737426757812, 29.604506272365295]),
            {
              "class": 1,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90927124023438, 29.739339757443286]),
            {
              "class": 1,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41464233398438, 29.424048845483828]),
            {
              "class": 1,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3885498046875, 29.38456832654707]),
            {
              "class": 1,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.51626586914062, 29.467101009006807]),
            {
              "class": 1,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45309448242188, 29.39533726120821]),
            {
              "class": 1,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.51351928710938, 29.351057685705033]),
            {
              "class": 1,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.41876220703125, 29.330706559937948]),
            {
              "class": 1,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.51214599609375, 29.322325503752857]),
            {
              "class": 1,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.646728515625, 29.24686502317129]),
            {
              "class": 1,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.68243408203125, 29.15575922535626]),
            {
              "class": 1,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.84036254882812, 29.0537687665771]),
            {
              "class": 1,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.745361328125, 29.90494852052797]),
            {
              "class": 1,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8167724609375, 29.92161331969558]),
            {
              "class": 1,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85247802734375, 29.935895213372444]),
            {
              "class": 1,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.01177978515625, 29.671349002200945]),
            {
              "class": 1,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9815673828125, 29.696403582804574]),
            {
              "class": 1,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.97744750976562, 29.643901107457324]),
            {
              "class": 1,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.17794799804688, 29.544787796199465]),
            {
              "class": 1,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.61190795898438, 29.25525227286301]),
            {
              "class": 1,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.184814453125, 29.018948912608682]),
            {
              "class": 1,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84835815429688, 28.928843133114825]),
            {
              "class": 1,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93350219726562, 29.177344230436756]),
            {
              "class": 1,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.55859375, 29.065772888415406]),
            {
              "class": 1,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.525634765625, 28.66408122441068]),
            {
              "class": 1,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73849487304688, 28.15555732831094]),
            {
              "class": 1,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60665893554688, 28.11438258566676]),
            {
              "class": 1,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85110473632812, 28.22818001256762]),
            {
              "class": 1,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.591552734375, 28.41555985166584]),
            {
              "class": 1,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40066528320312, 28.264472841903483]),
            {
              "class": 1,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.36358642578125, 28.245118203195265]),
            {
              "class": 1,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40615844726562, 28.229389972499913]),
            {
              "class": 1,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6519775390625, 28.233019769990715]),
            {
              "class": 1,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73300170898438, 28.352733760237818]),
            {
              "class": 1,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50091552734375, 28.115593833316765]),
            {
              "class": 1,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.72476196289062, 28.133760906108467]),
            {
              "class": 1,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.76596069335938, 28.125283321961753]),
            {
              "class": 1,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83462524414062, 28.17492820114568]),
            {
              "class": 1,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2562255859375, 29.445577209984613]),
            {
              "class": 1,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.79043579101562, 29.35943637984135]),
            {
              "class": 1,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82614135742188, 29.347466605839525]),
            {
              "class": 1,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84536743164062, 29.3067588581613]),
            {
              "class": 1,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.36309814453125, 29.299573451627978]),
            {
              "class": 1,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.61166381835938, 29.351057685705033]),
            {
              "class": 1,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.51004028320312, 29.373798251985612]),
            {
              "class": 1,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.63912963867188, 29.2540541364353]),
            {
              "class": 1,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.832763671875, 29.222897664495267]),
            {
              "class": 1,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87396240234375, 29.2324852813013]),
            {
              "class": 1,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.42352294921875, 29.045365049852848]),
            {
              "class": 1,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.13925170898438, 29.310351371763026]),
            {
              "class": 1,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.195556640625, 29.431225474131686]),
            {
              "class": 1,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97720336914062, 29.44198946622571]),
            {
              "class": 1,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.86322021484375, 29.476665675902137]),
            {
              "class": 1,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.19345092773438, 34.36837785748377]),
            {
              "class": 1,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.40219116210938, 34.371778435431224]),
            {
              "class": 1,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.08633422851562, 34.3366324743773]),
            {
              "class": 1,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.337646484375, 34.116352469972746]),
            {
              "class": 1,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35275268554688, 34.371778435431224]),
            {
              "class": 1,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.47634887695312, 34.56199029762806]),
            {
              "class": 1,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.47360229492188, 34.685169489428475]),
            {
              "class": 1,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.39532470703125, 34.876918445772084]),
            {
              "class": 1,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.93115234375, 34.78335551870688]),
            {
              "class": 1,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.60543823242188, 34.29353023058858]),
            {
              "class": 1,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.86361694335938, 34.31168124115256]),
            {
              "class": 1,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35824584960938, 34.186813861893455]),
            {
              "class": 1,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1673583984375, 34.24018895677778]),
            {
              "class": 1,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9970703125, 34.28331856338139]),
            {
              "class": 1,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.85562133789062, 34.279914398549934]),
            {
              "class": 1,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.84326171875, 34.371778435431224]),
            {
              "class": 1,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.98196411132812, 34.41937202924269]),
            {
              "class": 1,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6510009765625, 34.16295449004889]),
            {
              "class": 1,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.54937744140625, 34.2435947296974]),
            {
              "class": 1,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46560668945312, 34.219751425785425]),
            {
              "class": 1,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.03439331054688, 34.33436448702631]),
            {
              "class": 1,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.41915893554688, 34.32756015705253]),
            {
              "class": 1,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.16098022460938, 34.829586636768205]),
            {
              "class": 1,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.78057861328125, 33.916013113401696]),
            {
              "class": 1,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.71878051757812, 33.461234144932305]),
            {
              "class": 1,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67620849609375, 33.39934533042092]),
            {
              "class": 1,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.78033447265625, 33.408516828002675]),
            {
              "class": 1,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.97808837890625, 33.68206818063879]),
            {
              "class": 1,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.0357666015625, 33.73347670599252]),
            {
              "class": 1,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1126708984375, 33.773439833797745]),
            {
              "class": 1,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1346435546875, 33.8533101812195]),
            {
              "class": 1,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41891479492188, 33.84190469789482]),
            {
              "class": 1,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46011352539062, 34.01282694464166]),
            {
              "class": 1,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5411376953125, 34.0037197530556]),
            {
              "class": 1,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.90231323242188, 33.92285064485909]),
            {
              "class": 1,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82952880859375, 33.96044725772099]),
            {
              "class": 1,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02728271484375, 34.043556504127444]),
            {
              "class": 1,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.91329956054688, 34.17431693701009]),
            {
              "class": 1,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.39508056640625, 34.00713506435885]),
            {
              "class": 1,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48983764648438, 33.97866994069442]),
            {
              "class": 1,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4527587890625, 34.24132422972854]),
            {
              "class": 1,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0682373046875, 34.131131502784406]),
            {
              "class": 1,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.9254150390625, 34.13795172349637]),
            {
              "class": 1,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.68234252929688, 34.024209560512354]),
            {
              "class": 1,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.43240356445312, 34.082237152120896]),
            {
              "class": 1,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.65350341796875, 33.74147082163694]),
            {
              "class": 1,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.01193237304688, 33.73461876811943]),
            {
              "class": 1,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.2220458984375, 33.672925666287185]),
            {
              "class": 1,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.99819946289062, 33.65235145518946]),
            {
              "class": 1,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.85537719726562, 33.643205782197015]),
            {
              "class": 1,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.55599975585938, 33.672925666287185]),
            {
              "class": 1,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.63015747070312, 33.53223722395908]),
            {
              "class": 1,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4200439453125, 33.51162942617925]),
            {
              "class": 1,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.18521118164062, 33.50704924881552]),
            {
              "class": 1,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02316284179688, 33.65578083204094]),
            {
              "class": 1,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9256591796875, 33.70720508199262]),
            {
              "class": 1,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1014404296875, 33.871555787081476]),
            {
              "class": 1,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.00119018554688, 33.92171109438836]),
            {
              "class": 1,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.23602294921875, 33.97980872872457]),
            {
              "class": 1,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1124267578125, 34.20498790244057]),
            {
              "class": 1,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.24151611328125, 34.17204456998344]),
            {
              "class": 1,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.46536254882812, 34.67613503380097]),
            {
              "class": 1,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.66448974609375, 34.57782171051108]),
            {
              "class": 1,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88858032226562, 34.56312121279482]),
            {
              "class": 1,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46835327148438, 34.313949841632144]),
            {
              "class": 1,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89407348632812, 34.488447837809304]),
            {
              "class": 1,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.75262451171875, 33.552840110956154]),
            {
              "class": 1,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.53564453125, 33.489871424805116]),
            {
              "class": 1,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.44363403320312, 33.47498122050127]),
            {
              "class": 1,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.32965087890625, 33.55627344791359]),
            {
              "class": 1,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.42578125, 33.68206818063879]),
            {
              "class": 1,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49581909179688, 33.7437547178534]),
            {
              "class": 1,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.788330078125, 33.65120829920497]),
            {
              "class": 1,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.01766967773438, 33.540250041407845]),
            {
              "class": 1,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.78558349609375, 33.44519313450846]),
            {
              "class": 1,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.66336059570312, 33.41883360541482]),
            {
              "class": 1,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55624389648438, 33.39705230475205]),
            {
              "class": 1,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60568237304688, 33.276583535317876]),
            {
              "class": 1,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88583374023438, 33.34544323507434]),
            {
              "class": 1,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.06024169921875, 33.392466071900756]),
            {
              "class": 1,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.13851928710938, 33.379852683775226]),
            {
              "class": 1,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70706176757812, 33.520789053588494]),
            {
              "class": 1,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.919921875, 33.33167564632156]),
            {
              "class": 1,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.19869995117188, 33.14790004052224]),
            {
              "class": 1,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02566528320312, 33.019027516378955]),
            {
              "class": 1,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69058227539062, 33.08578864901153]),
            {
              "class": 1,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.34176635742188, 33.09614359735857]),
            {
              "class": 1,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.249755859375, 33.13065128220441]),
            {
              "class": 1,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.90505981445312, 33.06737684108429]),
            {
              "class": 1,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.71279907226562, 32.92109653816924]),
            {
              "class": 1,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64138793945312, 33.10534697199519]),
            {
              "class": 1,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.68533325195312, 33.2076694795496]),
            {
              "class": 1,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8817138671875, 33.260508448729944]),
            {
              "class": 1,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.07122802734375, 33.28576797042537]),
            {
              "class": 1,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.139892578125, 33.25936011503665]),
            {
              "class": 1,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28408813476562, 33.31216783738619]),
            {
              "class": 1,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.20718383789062, 33.46925353734003]),
            {
              "class": 1,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3541259765625, 33.348884792201694]),
            {
              "class": 1,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35137939453125, 33.710632271492095]),
            {
              "class": 1,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.30331420898438, 33.86585445407186]),
            {
              "class": 1,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3046875, 33.4348794896361]),
            {
              "class": 1,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38296508789062, 33.17893926058104]),
            {
              "class": 1,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.51480102539062, 33.04090311724091]),
            {
              "class": 1,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.8759765625, 32.80574473290688]),
            {
              "class": 1,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0078125, 32.797664489898004]),
            {
              "class": 1,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.952880859375, 32.923402043498875]),
            {
              "class": 1,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.86361694335938, 33.116849834921005]),
            {
              "class": 1,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.53402709960938, 32.748012603583476]),
            {
              "class": 1,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69882202148438, 32.856518010109546]),
            {
              "class": 1,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.403564453125, 32.730685662660896]),
            {
              "class": 1,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26760864257812, 32.92455477363828]),
            {
              "class": 1,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.16323852539062, 32.87036022808352]),
            {
              "class": 1,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92703247070312, 32.906109289516756]),
            {
              "class": 1,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88720703125, 32.82651912783954]),
            {
              "class": 1,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02316284179688, 32.604675440554985]),
            {
              "class": 1,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.09869384765625, 32.72144325007593]),
            {
              "class": 1,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.25250244140625, 32.62434010409917]),
            {
              "class": 1,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26348876953125, 32.644000448276756]),
            {
              "class": 1,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.20169067382812, 32.71913249723243]),
            {
              "class": 1,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.37472534179688, 32.54449790638623]),
            {
              "class": 1,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.63153076171875, 32.509761735919426]),
            {
              "class": 1,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.425537109375, 32.49586350791503]),
            {
              "class": 1,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.61642456054688, 32.561860954350664]),
            {
              "class": 1,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.88284301757812, 32.60351856115668]),
            {
              "class": 1,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02041625976562, 32.82074894982263]),
            {
              "class": 1,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.84600830078125, 32.7537875018279]),
            {
              "class": 1,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88995361328125, 32.73530650964904]),
            {
              "class": 1,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.94076538085938, 32.6925545366082]),
            {
              "class": 1,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.76223754882812, 32.7491676131845]),
            {
              "class": 1,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.74713134765625, 32.58037783597417]),
            {
              "class": 1,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6839599609375, 32.55723113666635]),
            {
              "class": 1,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9476318359375, 32.5664905331415]),
            {
              "class": 1,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95449829101562, 32.532920675187846]),
            {
              "class": 1,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.72515869140625, 32.46921923476024]),
            {
              "class": 1,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.62216186523438, 32.48196313217176]),
            {
              "class": 1,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.86111450195312, 32.34632201382947]),
            {
              "class": 1,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89956665039062, 32.282488692700504]),
            {
              "class": 1,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.58233642578125, 32.33820027152775]),
            {
              "class": 1,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.52191162109375, 32.46458464297592]),
            {
              "class": 1,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35711669921875, 32.535236240827224]),
            {
              "class": 1,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.72927856445312, 32.0639555946604]),
            {
              "class": 1,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.63589477539062, 32.080247396291796]),
            {
              "class": 1,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89407348632812, 32.00225320314841]),
            {
              "class": 1,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89407348632812, 32.125616389766726]),
            {
              "class": 1,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9915771484375, 32.158175096845596]),
            {
              "class": 1,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88308715820312, 33.02133046690858]),
            {
              "class": 1,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6729736328125, 33.04435666306044]),
            {
              "class": 1,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.53265380859375, 32.91072102090145]),
            {
              "class": 1,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.74713134765625, 33.389026238446085]),
            {
              "class": 1,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7720947265625, 32.5826921773649]),
            {
              "class": 1,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.66497802734375, 32.55144352864431]),
            {
              "class": 1,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.63064575195312, 32.42865847084369]),
            {
              "class": 1,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.546875, 32.4900719456707]),
            {
              "class": 1,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.54000854492188, 32.38807945627931]),
            {
              "class": 1,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.81329345703125, 32.375322284319346]),
            {
              "class": 1,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.94400024414062, 32.92916554402031]),
            {
              "class": 1,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89181518554688, 32.82767311846154]),
            {
              "class": 1,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11566162109375, 32.8322889310024]),
            {
              "class": 1,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.4150390625, 32.71797709835757]),
            {
              "class": 1,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.41778564453125, 32.85305711806933]),
            {
              "class": 1,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.04287719726562, 32.59541998703928]),
            {
              "class": 1,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.02639770507812, 32.43561304116276]),
            {
              "class": 1,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.63912963867188, 32.49470522529474]),
            {
              "class": 1,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.678955078125, 32.52597362010653]),
            {
              "class": 1,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.86297607421875, 32.57690621187388]),
            {
              "class": 1,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60018920898438, 31.700129553985928]),
            {
              "class": 1,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49169921875, 31.722326680224338]),
            {
              "class": 1,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.81442260742188, 31.61947427549924]),
            {
              "class": 1,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.93527221679688, 31.649874339453326]),
            {
              "class": 1,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7828369140625, 31.555133721172034]),
            {
              "class": 1,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.47796630859375, 32.35328292697968]),
            {
              "class": 1,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.47384643554688, 31.648705289976853]),
            {
              "class": 1,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3271484375, 31.429834925591393]),
            {
              "class": 1,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.22964477539062, 31.490748764752368]),
            {
              "class": 1,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0140380859375, 31.608948861695676]),
            {
              "class": 1,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.1239013671875, 31.41342827771443]),
            {
              "class": 1,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.272216796875, 31.361845848762645]),
            {
              "class": 1,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07034301757812, 32.0115694354482]),
            {
              "class": 1,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11978149414062, 31.898546300090374]),
            {
              "class": 1,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.931640625, 32.565333160841035]),
            {
              "class": 1,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.766845703125, 32.20234331330286]),
            {
              "class": 1,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.920654296875, 31.902043944448852]),
            {
              "class": 1,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93026733398438, 31.85423130442635]),
            {
              "class": 1,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.71578979492188, 32.33355894864107]),
            {
              "class": 1,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.68695068359375, 32.507445513754526]),
            {
              "class": 1,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02752685546875, 32.31615186824962]),
            {
              "class": 1,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.09756469726562, 32.53060504985312]),
            {
              "class": 1,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.25411987304688, 32.47269502206151]),
            {
              "class": 1,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.481201171875, 31.292634058899516]),
            {
              "class": 1,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.45098876953125, 31.384123555094018]),
            {
              "class": 1,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33837890625, 31.528214501765127]),
            {
              "class": 1,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.393310546875, 31.839066018972925]),
            {
              "class": 1,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.613037109375, 31.436865467417928]),
            {
              "class": 1,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.57595825195312, 31.354809686417862]),
            {
              "class": 1,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.55123901367188, 31.16110911780645]),
            {
              "class": 1,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.69705200195312, 31.35011861899766]),
            {
              "class": 1,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.08363342285156, 31.28588612140468]),
            {
              "class": 1,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92570495605469, 31.273269116693573]),
            {
              "class": 1,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89068603515625, 31.189602138268175]),
            {
              "class": 1,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.79009246826172, 31.235701533345093]),
            {
              "class": 1,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40292358398438, 31.29028700498854]),
            {
              "class": 1,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.4046401977539, 31.38705443900803]),
            {
              "class": 1,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7282943725586, 31.22689446881399]),
            {
              "class": 1,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.53809356689453, 31.229536674364116]),
            {
              "class": 1,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.118408203125, 31.35598241670874]),
            {
              "class": 1,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52058410644531, 32.22500026203563]),
            {
              "class": 1,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32145690917969, 32.27378066442218]),
            {
              "class": 1,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.08319091796875, 32.15933769278929]),
            {
              "class": 1,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4869384765625, 31.910204597744382]),
            {
              "class": 1,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.50410461425781, 32.00050630418923]),
            {
              "class": 1,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.90167236328125, 32.05115285720172]),
            {
              "class": 1,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.99299621582031, 32.13840869677249]),
            {
              "class": 1,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.95866394042969, 31.787718866070374]),
            {
              "class": 1,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35304260253906, 31.783049527817788]),
            {
              "class": 1,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.16902160644531, 31.66039512307388]),
            {
              "class": 1,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.81402587890625, 31.637013986617973]),
            {
              "class": 1,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.547607421875, 31.507727287629667]),
            {
              "class": 1,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.66914367675781, 31.629998499002554]),
            {
              "class": 1,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.11134338378906, 31.621228395415503]),
            {
              "class": 1,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51783752441406, 31.632921683148886]),
            {
              "class": 1,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.34298706054688, 31.573855555238104]),
            {
              "class": 1,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40684509277344, 31.22689446881399]),
            {
              "class": 1,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.37319946289062, 31.00115451727899]),
            {
              "class": 1,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26882934570312, 31.13348914746469]),
            {
              "class": 1,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.27706909179688, 31.39819096367598]),
            {
              "class": 1,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2674560546875, 31.527043924837933]),
            {
              "class": 1,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05390930175781, 31.438037173124464]),
            {
              "class": 1,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.95777893066406, 31.678511458063923]),
            {
              "class": 1,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.08686828613281, 31.099981793749432]),
            {
              "class": 1,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78543090820312, 31.01351353811319]),
            {
              "class": 1,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.7840576171875, 30.98938253174058]),
            {
              "class": 1,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7833251953125, 33.22030778968541]),
            {
              "class": 1,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.39895629882812, 33.20422235093439]),
            {
              "class": 1,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.47174072265625, 33.364943593285545]),
            {
              "class": 1,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.52255249023438, 33.6477787401531]),
            {
              "class": 1,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.425048828125, 32.9464537926927]),
            {
              "class": 1,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.37149047851562, 32.7491676131845]),
            {
              "class": 1,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.161376953125, 32.35560311232581]),
            {
              "class": 1,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.11056518554688, 32.23603621746476]),
            {
              "class": 1,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.41268920898438, 32.74570253945518]),
            {
              "class": 1,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.3646240234375, 33.14675022877648]),
            {
              "class": 1,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0572509765625, 32.93838636388491]),
            {
              "class": 1,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.96112060546875, 33.710632271492095]),
            {
              "class": 1,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.42416381835938, 33.19043247913695]),
            {
              "class": 1,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.35089111328125, 32.82767311846154]),
            {
              "class": 1,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.51568603515625, 32.95221579117345]),
            {
              "class": 1,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18722534179688, 31.981288219195633]),
            {
              "class": 1,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.22293090820312, 31.955657843600374]),
            {
              "class": 1,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.17486572265625, 31.93235129404254]),
            {
              "class": 1,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.67587280273438, 32.12503487864545]),
            {
              "class": 1,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6714096069336, 32.16892854336097]),
            {
              "class": 1,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.65733337402344, 32.03049011704932]),
            {
              "class": 1,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.74385070800781, 32.177356033083505]),
            {
              "class": 1,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.79706573486328, 32.24532861404601]),
            {
              "class": 1,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6446304321289, 32.06453749470133]),
            {
              "class": 1,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.63227081298828, 31.944005307724854]),
            {
              "class": 1,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.02184295654297, 34.858327053995225]),
            {
              "class": 1,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.04072570800781, 34.917185371895016]),
            {
              "class": 1,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.1004638671875, 34.84452163557631]),
            {
              "class": 1,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09840393066406, 34.726941022280975]),
            {
              "class": 1,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09806060791016, 34.66286389017133]),
            {
              "class": 1,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.05857849121094, 34.591389093621565]),
            {
              "class": 1,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.04724884033203, 34.79181436843148]),
            {
              "class": 1,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.03145599365234, 34.83716719862983]),
            {
              "class": 1,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.00296020507812, 34.907866608344264]),
            {
              "class": 1,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95935821533203, 34.84815635479386]),
            {
              "class": 1,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.07471466064453, 34.66227088145567]),
            {
              "class": 1,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.12621307373047, 34.69812657253841]),
            {
              "class": 1,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95146179199219, 34.7723295226707]),
            {
              "class": 1,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95558166503906, 34.87660863056391]),
            {
              "class": 1,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0455322265625, 35.02968713186243]),
            {
              "class": 1,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06201171875, 35.0729980007656]),
            {
              "class": 1,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06990814208984, 35.123278350923385]),
            {
              "class": 1,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.98236083984375, 35.05922870088872]),
            {
              "class": 1,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.97789764404297, 35.08030321662189]),
            {
              "class": 1,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06269836425781, 35.04517600081111]),
            {
              "class": 1,
              "system:index": "723"
            })]),
    NonCropClass = /* color: #00ff00 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-106.336669921875, 32.99945000822837]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0235595703125, 32.54218257955074]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.765380859375, 33.03629817885956]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.347900390625, 33.56886118255557]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.765380859375, 33.44977658311846]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.3201904296875, 34.872411827691025]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.4630126953125, 34.615126683462194]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.4852294921875, 35.634976650677295]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.5511474609375, 35.96022296929667]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.281982421875, 36.213255233061844]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.908447265625, 35.991340960635405]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.5733642578125, 35.576916524038616]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.3536376953125, 35.808904044068626]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.9361572265625, 35.679609609368576]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.787841796875, 35.55010533588551]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.721435546875, 33.710632271492095]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7379150390625, 34.18454183141725]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.501708984375, 34.73709847578162]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.919189453125, 34.62868797377059]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7928466796875, 34.97600151317588]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.23779296875, 34.68291096793206]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5673828125, 32.63474905974431]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.98486328125, 32.31034876452581]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0068359375, 32.077920173788286]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.171630859375, 31.90554145590038]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.995849609375, 31.910204597744382]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.512451171875, 32.41706632846282]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5179443359375, 32.342841356393016]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.962890625, 32.67174887226337]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.78367614746094, 32.29641979896909]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.754150390625, 32.29816103674399]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.76445007324219, 32.327756960342946]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.78092956542969, 32.365463235972015]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.885986328125, 32.41648668224032]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.820068359375, 32.442567075075075]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.77131652832031, 32.31092909162696]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.83723449707031, 32.20757234095538]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6552734375, 32.13201276750207]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.66694641113281, 32.230227986930124]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.60377502441406, 32.15933769278929]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58317565917969, 32.126197897182095]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.55227661132812, 32.385180257193184]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.52000427246094, 32.314410976167025]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.52069091796875, 32.26100737759521]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.57630920410156, 32.32079408355392]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.54609680175781, 32.31034876452581]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.47811889648438, 32.375322284319346]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.60720825195312, 31.991771310172094]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.68617248535156, 31.990024211531352]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58592224121094, 31.898546300090374]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.57493591308594, 31.85889704445453]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.61270141601562, 31.86589521179635]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.65802001953125, 31.873475960193534]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.61613464355469, 31.822147951852507]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58111572265625, 31.821564514920738]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99952697753906, 34.728916180452224]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.92159271240234, 34.696743445069416]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.93017578125, 34.73427708614381]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95146179199219, 34.73032697882122]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.98236083984375, 34.69617889941474]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.03282928466797, 34.755153088189324]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.05857849121094, 34.75910200859339]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.92777252197266, 34.67500565754207]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.90648651123047, 34.71762892664953]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.89962005615234, 34.72948050268947]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01154327392578, 34.75035771666415]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.12518310546875, 34.787021126769986]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.07059478759766, 34.80647431931937]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.05789184570312, 34.8177494305477]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.12312316894531, 34.88283300707508]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06132507324219, 34.897476755550905]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09016418457031, 34.89803992452223]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.08673095703125, 34.92140803132199]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.08295440673828, 34.95855806459077]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01531982421875, 34.96643621094802]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0019302368164, 35.01621981859141]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.02699279785156, 34.99850370014629]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.03797912597656, 34.993159990797906]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0287094116211, 34.78786701318875]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9957504272461, 34.86170761967989]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.00227355957031, 34.83606819543943]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06510162353516, 34.87579181441272]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.07505798339844, 34.92084502261776]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.15608215332031, 34.6899686430415]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.97068786621094, 34.68065238482746]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09737396240234, 35.04995419014033]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09806060791016, 35.12243591901068]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.17668151855469, 35.077493595617426]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.21479034423828, 35.11176436068283]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.20655059814453, 35.123278350923385]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.1880111694336, 35.11513447747909]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.1667251586914, 35.07409379739952]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09565734863281, 35.005225001032194]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06956481933594, 34.99397560469042]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.04209899902344, 35.00550621612543]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.98751068115234, 35.00494378497231]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9854507446289, 35.0249077229128]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.94802856445312, 35.06229184102332]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.03145599365234, 35.0726888920805]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99918365478516, 35.102748585722075]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.07437133789062, 35.029968228526506]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.02664947509766, 35.038963909379085]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09737396240234, 34.977661233240255]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.98957061767578, 34.96612669915952]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.0185546875, 36.469668359097916]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68048095703125, 36.89917106202791]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.1007080078125, 36.65057195438067]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72216796875, 36.8817076058771]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.42416381835938, 36.94319674926757]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.1890869140625, 36.87731362767047]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0078125, 37.0386261605288]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75238037109375, 36.46757015134362]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.46810913085938, 36.579033421600414]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5955810546875, 36.5194591749921]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.66448974609375, 36.298414201695046]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.93389892578125, 36.62423504465701]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.80343627929688, 36.77068228329776]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.01492309570312, 37.06273876446209]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.20468139648438, 36.64076560553376]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5576171875, 36.34377965932238]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1893310546875, 36.33382365024197]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.55462646484375, 35.851102010903205]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.52304077148438, 36.06231059304925]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.073974609375, 36.327185603872984]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.30081176757812, 36.7376734419161]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7059326171875, 37.06273876446209]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.06024169921875, 36.10226551857859]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55624389648438, 36.08118079848187]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.28021240234375, 35.910075015421974]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64138793945312, 35.654953010602384]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.67022705078125, 35.62481919730749]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.13851928710938, 35.57121992439205]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.326904296875, 35.69176779241012]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.24588012695312, 35.85889353607558]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.99456787109375, 35.943436416935356]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.645751953125, 35.971226831043005]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44387817382812, 35.94788354024775]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3216552734375, 35.91674842170916]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.1788330078125, 35.87669954125495]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.10330200195312, 35.72187634453095]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67758178710938, 35.99345212123401]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.16510009765625, 36.014560348184574]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.491943359375, 36.24859259334145]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.33676147460938, 36.47198772659898]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6182861328125, 36.39575160568821]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.97695922851562, 36.66169922472401]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.20767211914062, 36.960755970015285]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.964599609375, 37.007926313661855]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.415283203125, 36.953074309038584]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.239501953125, 36.79048076998159]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.557861328125, 36.834459092991985]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6842041015625, 36.82456617314496]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7830810546875, 37.00902295037756]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02340698242188, 36.64296941237415]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.12640380859375, 36.483030091512155]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.44638061523438, 36.43001174505142]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87646484375, 36.26852497063735]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.8050537109375, 36.388013188674655]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1895751953125, 36.19319768840408]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7064208984375, 36.906968073879646]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.69131469726562, 37.04849133354014]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27932739257812, 36.95417173661799]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.25460815429688, 37.10875064012892]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.28094482421875, 36.84215270176004]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.19992065429688, 36.83335994284849]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0859375, 36.869623557488396]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1463623046875, 36.895986288933976]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24386596679688, 37.032048666326304]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22463989257812, 37.10327450059275]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.01589965820312, 36.720062919871545]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32763671875, 36.55807734863189]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8717041015625, 36.39464604904382]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.90878295898438, 36.38911870470339]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.06121826171875, 36.298414201695046]),
            {
              "class": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37020874023438, 36.31722747394866]),
            {
              "class": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.602294921875, 36.41675149594656]),
            {
              "class": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65036010742188, 36.59998380812813]),
            {
              "class": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82339477539062, 36.72886868574625]),
            {
              "class": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81790161132812, 36.90147737896412]),
            {
              "class": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85086059570312, 37.04629918366208]),
            {
              "class": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85772705078125, 36.42559191363084]),
            {
              "class": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94561767578125, 36.300627763427364]),
            {
              "class": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6956787109375, 36.13776370300767]),
            {
              "class": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73001098632812, 36.149962543270235]),
            {
              "class": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64486694335938, 36.13332729078243]),
            {
              "class": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6187744140625, 36.14552682084525]),
            {
              "class": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57208251953125, 36.12667220217373]),
            {
              "class": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.04861450195312, 36.25412977733629]),
            {
              "class": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0911865234375, 36.32939834883555]),
            {
              "class": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12002563476562, 36.49296699584963]),
            {
              "class": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.04586791992188, 36.6572926199262]),
            {
              "class": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03076171875, 36.70575139705177]),
            {
              "class": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.26834106445312, 36.688133555860055]),
            {
              "class": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.24911499023438, 36.869623557488396]),
            {
              "class": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07882690429688, 36.95856128880386]),
            {
              "class": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91290283203125, 36.339354923511834]),
            {
              "class": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8607177734375, 36.777282347115175]),
            {
              "class": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.86346435546875, 36.93770866265942]),
            {
              "class": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.855224609375, 37.01340933902164]),
            {
              "class": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27682495117188, 36.61211037971582]),
            {
              "class": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57208251953125, 36.353734395712486]),
            {
              "class": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.50067138671875, 36.18433088540656]),
            {
              "class": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74923706054688, 36.38137976239378]),
            {
              "class": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4100341796875, 35.980117562617814]),
            {
              "class": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41690063476562, 35.84776261538195]),
            {
              "class": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93624877929688, 35.85555432883774]),
            {
              "class": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.14498901367188, 35.94899514625903]),
            {
              "class": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.68768310546875, 36.026778182080605]),
            {
              "class": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.50180053710938, 36.11336033213504]),
            {
              "class": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47845458984375, 36.354840398966495]),
            {
              "class": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.73114013671875, 36.498486947454886]),
            {
              "class": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.525146484375, 36.64186751683511]),
            {
              "class": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.71328735351562, 36.72996933548762]),
            {
              "class": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8931884765625, 36.920104129477585]),
            {
              "class": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07171630859375, 36.33714246133696]),
            {
              "class": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.074462890625, 36.19652248071005]),
            {
              "class": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.810791015625, 35.986785055808845]),
            {
              "class": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.08132934570312, 35.53211436160702]),
            {
              "class": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.18295288085938, 35.55893156656635]),
            {
              "class": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.13351440429688, 35.69511361250054]),
            {
              "class": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.6240234375, 35.740827610011664]),
            {
              "class": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53201293945312, 35.47509803243269]),
            {
              "class": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.35897827148438, 35.606956625181205]),
            {
              "class": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.195556640625, 35.473979660633766]),
            {
              "class": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.722900390625, 35.38557914785515]),
            {
              "class": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.97146606445312, 35.37326252119478]),
            {
              "class": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.03738403320312, 35.276904247426025]),
            {
              "class": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93301391601562, 35.10631573780949]),
            {
              "class": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.10604858398438, 35.15461065409882]),
            {
              "class": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.75860595703125, 35.11642634605195]),
            {
              "class": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.51553344726562, 35.2914774207649]),
            {
              "class": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97308349609375, 35.50864208813962]),
            {
              "class": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.08294677734375, 35.37214287132747]),
            {
              "class": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84674072265625, 35.50193442464285]),
            {
              "class": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.69705200195312, 35.53323206060978]),
            {
              "class": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.48007202148438, 35.55781449846486]),
            {
              "class": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31802368164062, 35.575687901336266]),
            {
              "class": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24661254882812, 35.34974387763472]),
            {
              "class": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63275146484375, 35.469506154405586]),
            {
              "class": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.525634765625, 35.56675169825656]),
            {
              "class": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51327514648438, 35.69622903619562]),
            {
              "class": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50228881835938, 35.910075015421974]),
            {
              "class": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.55996704101562, 36.037883918645505]),
            {
              "class": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51602172851562, 36.164377043925995]),
            {
              "class": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.78106689453125, 35.93120553737864]),
            {
              "class": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.12713623046875, 36.07785111511623]),
            {
              "class": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.07907104492188, 35.67949808531158]),
            {
              "class": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.23699951171875, 35.779831135225514]),
            {
              "class": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20816040039062, 35.55334552483526]),
            {
              "class": 2,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.14224243164062, 35.437064802019435]),
            {
              "class": 2,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.71926879882812, 35.357584232259576]),
            {
              "class": 2,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.59979248046875, 35.45496509666105]),
            {
              "class": 2,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50503540039062, 35.470624588426595]),
            {
              "class": 2,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94699096679688, 35.08384322876143]),
            {
              "class": 2,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85360717773438, 35.02651030516293]),
            {
              "class": 2,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96484375, 34.8170729949075]),
            {
              "class": 2,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.756103515625, 34.871172491916084]),
            {
              "class": 2,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62838745117188, 34.86215837878392]),
            {
              "class": 2,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55422973632812, 34.83961877355455]),
            {
              "class": 2,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.42239379882812, 34.65230195688557]),
            {
              "class": 2,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41827392578125, 34.593537087085906]),
            {
              "class": 2,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58444213867188, 34.65230195688557]),
            {
              "class": 2,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.67095947265625, 34.59805893895141]),
            {
              "class": 2,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07196044921875, 34.685056592386374]),
            {
              "class": 2,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27108764648438, 34.664727653463174]),
            {
              "class": 2,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.32464599609375, 34.636484739736]),
            {
              "class": 2,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33563232421875, 34.63874452691222]),
            {
              "class": 2,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40292358398438, 34.62518488033385]),
            {
              "class": 2,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.5416259765625, 34.75391198746149]),
            {
              "class": 2,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.55810546875, 34.890324201215144]),
            {
              "class": 2,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.81903076171875, 35.055743884196815]),
            {
              "class": 2,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66134643554688, 35.4269941369237]),
            {
              "class": 2,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12277221679688, 35.685075458834945]),
            {
              "class": 2,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14886474609375, 35.88671366081317]),
            {
              "class": 2,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92776489257812, 35.943436416935356]),
            {
              "class": 2,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19143676757812, 35.6616478702956]),
            {
              "class": 2,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.06234741210938, 35.284751666691]),
            {
              "class": 2,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72726440429688, 35.205121164288414]),
            {
              "class": 2,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49105834960938, 35.05349551872815]),
            {
              "class": 2,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22463989257812, 35.00064111365079]),
            {
              "class": 2,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18618774414062, 35.16246990596837]),
            {
              "class": 2,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18206787109375, 35.28699364679988]),
            {
              "class": 2,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24077606201172, 35.069036059359284]),
            {
              "class": 2,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2943344116211, 35.09066988772264]),
            {
              "class": 2,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33415985107422, 35.01815992910967]),
            {
              "class": 2,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4539794921875, 35.047115424101726]),
            {
              "class": 2,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.09761047363281, 35.1532913275517]),
            {
              "class": 2,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.01143646240234, 35.11622974228198]),
            {
              "class": 2,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00594329833984, 35.18107644319254]),
            {
              "class": 2,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.90740966796875, 35.153010621389924]),
            {
              "class": 2,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88097381591797, 34.943897076238585]),
            {
              "class": 2,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.965087890625, 35.00381894539507]),
            {
              "class": 2,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.14155578613281, 34.97569207186789]),
            {
              "class": 2,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21502685546875, 34.978223886229465]),
            {
              "class": 2,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24455261230469, 34.986943981011365]),
            {
              "class": 2,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26412200927734, 35.013098692562956]),
            {
              "class": 2,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0643081665039, 34.917438744460185]),
            {
              "class": 2,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.03752899169922, 34.95233942826029]),
            {
              "class": 2,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3327865600586, 35.28035157973238]),
            {
              "class": 2,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33724975585938, 35.331624126514605]),
            {
              "class": 2,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26515197753906, 35.415047521798236]),
            {
              "class": 2,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35407257080078, 35.47070841574049]),
            {
              "class": 2,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2895278930664, 35.5344333684541]),
            {
              "class": 2,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31768035888672, 35.625181932190245]),
            {
              "class": 2,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41758728027344, 35.63160024148037]),
            {
              "class": 2,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47904205322266, 35.61987946196389]),
            {
              "class": 2,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.03375244140625, 35.54476992950401]),
            {
              "class": 2,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98259735107422, 35.61597215365163]),
            {
              "class": 2,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.97676086425781, 35.72725560208419]),
            {
              "class": 2,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.77729034423828, 35.73979662846325]),
            {
              "class": 2,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63069152832031, 35.73589518744782]),
            {
              "class": 2,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.57301330566406, 35.855916149884266]),
            {
              "class": 2,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70210266113281, 35.87817386733605]),
            {
              "class": 2,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.03993225097656, 35.887075203784214]),
            {
              "class": 2,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51293182373047, 35.92100237008372]),
            {
              "class": 2,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4871826171875, 35.717500105161456]),
            {
              "class": 2,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50469207763672, 35.72056624719815]),
            {
              "class": 2,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.45628356933594, 35.66312618833877]),
            {
              "class": 2,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5417709350586, 35.6477832549148]),
            {
              "class": 2,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.52254486083984, 35.641366245151815]),
            {
              "class": 2,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5809097290039, 35.602295071368864]),
            {
              "class": 2,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.59567260742188, 35.60173677344789]),
            {
              "class": 2,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60185241699219, 35.55370858368754]),
            {
              "class": 2,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.55241394042969, 35.540300228736704]),
            {
              "class": 2,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5640869140625, 35.508446401301285]),
            {
              "class": 2,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60734558105469, 35.487483041766076]),
            {
              "class": 2,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.46864318847656, 35.51096163680243]),
            {
              "class": 2,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30968475341797, 35.4735044298216]),
            {
              "class": 2,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3996353149414, 35.594199370299634]),
            {
              "class": 2,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39448547363281, 35.65894204426748]),
            {
              "class": 2,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.43980407714844, 35.35150796909579]),
            {
              "class": 2,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.41474151611328, 35.3069724972039]),
            {
              "class": 2,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.64579772949219, 35.24110471404952]),
            {
              "class": 2,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.69248962402344, 35.219791332943]),
            {
              "class": 2,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70553588867188, 35.26381412663067]),
            {
              "class": 2,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.74089813232422, 35.335265168102616]),
            {
              "class": 2,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.72201538085938, 35.3929403156837]),
            {
              "class": 2,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.745361328125, 35.39657862709866]),
            {
              "class": 2,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.65094757080078, 35.42428038213702]),
            {
              "class": 2,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.61489868164062, 35.46483646971286]),
            {
              "class": 2,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.76046752929688, 35.13700876943112]),
            {
              "class": 2,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.767333984375, 35.176025310133475]),
            {
              "class": 2,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.76802062988281, 35.22175467585241]),
            {
              "class": 2,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.78141021728516, 35.25736645589764]),
            {
              "class": 2,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80784606933594, 35.28903937895127]),
            {
              "class": 2,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95032501220703, 35.26689766448071]),
            {
              "class": 2,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92423248291016, 35.17714781127161]),
            {
              "class": 2,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95856475830078, 35.134481873639885]),
            {
              "class": 2,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9046630859375, 35.069036059359284]),
            {
              "class": 2,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93556213378906, 35.04852076955226]),
            {
              "class": 2,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87342071533203, 35.045428977644875]),
            {
              "class": 2,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93384552001953, 35.01619170767348]),
            {
              "class": 2,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7951431274414, 35.01647288506471]),
            {
              "class": 2,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6849365234375, 35.020409267028455]),
            {
              "class": 2,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70931243896484, 35.090950808796045]),
            {
              "class": 2,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70999908447266, 35.142623812614744]),
            {
              "class": 2,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60459899902344, 35.134481873639885]),
            {
              "class": 2,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.57404327392578, 35.173218989477945]),
            {
              "class": 2,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51121520996094, 35.1266199185393]),
            {
              "class": 2,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44049072265625, 35.192861199626385]),
            {
              "class": 2,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.45834350585938, 35.23297267139358]),
            {
              "class": 2,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.33955383300781, 35.229326992963756]),
            {
              "class": 2,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31243133544922, 35.27726858819759]),
            {
              "class": 2,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.46417999267578, 35.3106147173926]),
            {
              "class": 2,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50640869140625, 35.315097182719654]),
            {
              "class": 2,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39551544189453, 35.06397797357383]),
            {
              "class": 2,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70862579345703, 34.94727412136869]),
            {
              "class": 2,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.71583557128906, 35.00775593639867]),
            {
              "class": 2,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.76596069335938, 34.96668943138517]),
            {
              "class": 2,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82878875732422, 34.93320218242599]),
            {
              "class": 2,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88818359375, 34.993413128611195]),
            {
              "class": 2,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87479400634766, 34.91040051769901]),
            {
              "class": 2,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.57747650146484, 34.811520129199856]),
            {
              "class": 2,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40066528320312, 34.89040866353663]),
            {
              "class": 2,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31311798095703, 34.887874137331806]),
            {
              "class": 2,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.36152648925781, 34.96387590333297]),
            {
              "class": 2,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31311798095703, 34.95965543010509]),
            {
              "class": 2,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3172378540039, 34.96894018426276]),
            {
              "class": 2,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29904174804688, 35.01815992910967]),
            {
              "class": 2,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31346130371094, 35.068755062816386]),
            {
              "class": 2,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2945785522461, 35.090950808796045]),
            {
              "class": 2,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51773834228516, 35.11594890831468]),
            {
              "class": 2,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5747299194336, 35.070441027562424]),
            {
              "class": 2,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.62348175048828, 35.040931616879064]),
            {
              "class": 2,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6461410522461, 34.96021817242816]),
            {
              "class": 2,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60322570800781, 34.957967179949925]),
            {
              "class": 2,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60504150390625, 34.83511011164098]),
            {
              "class": 2,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74374389648438, 34.75391198746149]),
            {
              "class": 2,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.975830078125, 34.80692538091858]),
            {
              "class": 2,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7176513671875, 34.653431642649174]),
            {
              "class": 2,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45809936523438, 34.63196498067385]),
            {
              "class": 2,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27545166015625, 34.61727406301391]),
            {
              "class": 2,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3056640625, 34.71785468338242]),
            {
              "class": 2,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63755798339844, 34.67438449058859]),
            {
              "class": 2,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.54898071289062, 34.68680687554181]),
            {
              "class": 2,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02207946777344, 34.61902577795237]),
            {
              "class": 2,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91976928710938, 34.71785468338242]),
            {
              "class": 2,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.11065673828125, 34.793449642523775]),
            {
              "class": 2,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.10035705566406, 34.52799912048479]),
            {
              "class": 2,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21434020996094, 34.596984990372896]),
            {
              "class": 2,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25828552246094, 34.43120955972538]),
            {
              "class": 2,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02070617675781, 34.48103341639039]),
            {
              "class": 2,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.96371459960938, 34.50310493470426]),
            {
              "class": 2,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87101745605469, 34.51894754990762]),
            {
              "class": 2,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70828247070312, 34.47254281550973]),
            {
              "class": 2,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.55653381347656, 34.43800547240013]),
            {
              "class": 2,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.33062744140625, 34.43007685388478]),
            {
              "class": 2,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23655700683594, 34.41081850619604]),
            {
              "class": 2,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22900390625, 34.51442139576511]),
            {
              "class": 2,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29286193847656, 34.60828868923784]),
            {
              "class": 2,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29286193847656, 34.64896926315459]),
            {
              "class": 2,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29217529296875, 34.71277493030426]),
            {
              "class": 2,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44049072265625, 34.81092816915859]),
            {
              "class": 2,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.49885559082031, 34.78217120707432]),
            {
              "class": 2,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.66708374023438, 34.74945502391104]),
            {
              "class": 2,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63412475585938, 34.72970622706126]),
            {
              "class": 2,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60185241699219, 34.92529268267243]),
            {
              "class": 2,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82569885253906, 34.81656561292197]),
            {
              "class": 2,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93075561523438, 34.88643786079858]),
            {
              "class": 2,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00079345703125, 34.96187822946248]),
            {
              "class": 2,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35191345214844, 34.86897536196479]),
            {
              "class": 2,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22419738769531, 34.826712039653856]),
            {
              "class": 2,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.21389770507812, 34.60828868923784]),
            {
              "class": 2,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23037719726562, 34.49008910495783]),
            {
              "class": 2,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23655700683594, 34.450463210197306]),
            {
              "class": 2,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26608276367188, 34.40911902727715]),
            {
              "class": 2,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.21870422363281, 34.437439167452055]),
            {
              "class": 2,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26333618164062, 34.43177590688923]),
            {
              "class": 2,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.55584716796875, 34.42611226256099]),
            {
              "class": 2,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.52357482910156, 34.53535279725113]),
            {
              "class": 2,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60528564453125, 34.570415242691794]),
            {
              "class": 2,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.59017944335938, 34.63258643111276]),
            {
              "class": 2,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88818359375, 34.47537311180219]),
            {
              "class": 2,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.96165466308594, 34.48839123824084]),
            {
              "class": 2,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95822143554688, 34.54383700187194]),
            {
              "class": 2,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13812255859375, 34.549492657863325]),
            {
              "class": 2,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.42857360839844, 34.627501445893564]),
            {
              "class": 2,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.53569030761719, 34.69866286804246]),
            {
              "class": 2,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.53775024414062, 34.756224953243844]),
            {
              "class": 2,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.46702575683594, 34.70543695835769]),
            {
              "class": 2,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57002258300781, 34.778787375699146]),
            {
              "class": 2,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49861145019531, 34.766942872936305]),
            {
              "class": 2,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49174499511719, 34.733092070326634]),
            {
              "class": 2,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38737487792969, 34.411951472959196]),
            {
              "class": 2,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25965881347656, 34.425545877022195]),
            {
              "class": 2,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.59130859375, 34.35471747525744]),
            {
              "class": 2,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37226867675781, 34.298011622536684]),
            {
              "class": 2,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.338623046875, 34.20436323134432]),
            {
              "class": 2,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.294677734375, 34.124253886182366]),
            {
              "class": 2,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1243896484375, 34.154943042255084]),
            {
              "class": 2,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39286804199219, 34.13334813141581]),
            {
              "class": 2,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25553894042969, 34.24864636892467]),
            {
              "class": 2,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25141906738281, 34.36718761913122]),
            {
              "class": 2,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.13743591308594, 34.29460805291978]),
            {
              "class": 2,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.10104370117188, 34.32239983544505]),
            {
              "class": 2,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.07769775390625, 34.30368393210688]),
            {
              "class": 2,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9815673828125, 34.27758813649028]),
            {
              "class": 2,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9815673828125, 34.37795579539223]),
            {
              "class": 2,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88681030273438, 34.425545877022195]),
            {
              "class": 2,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.81814575195312, 34.28780049999771]),
            {
              "class": 2,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84698486328125, 34.22083019376304]),
            {
              "class": 2,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8277587890625, 34.14414627680845]),
            {
              "class": 2,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.55241394042969, 34.14244139821954]),
            {
              "class": 2,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.46383666992188, 34.42894413269396]),
            {
              "class": 2,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3663330078125, 34.62185109678595]),
            {
              "class": 2,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.22831726074219, 33.964946359475036]),
            {
              "class": 2,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.17201232910156, 33.972349403760425]),
            {
              "class": 2,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.10060119628906, 33.8794800213629]),
            {
              "class": 2,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2015380859375, 34.113453216675545]),
            {
              "class": 2,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.27981567382812, 34.090710420112956]),
            {
              "class": 2,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.14179992675781, 34.2202624383684]),
            {
              "class": 2,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.13768005371094, 34.1759643787127]),
            {
              "class": 2,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73162841796875, 34.00252437554947]),
            {
              "class": 2,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.86827087402344, 33.98544551871911]),
            {
              "class": 2,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83050537109375, 33.959251271529716]),
            {
              "class": 2,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0035400390625, 33.820173053470754]),
            {
              "class": 2,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30841064453125, 33.89942983504477]),
            {
              "class": 2,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20953369140625, 33.913107010292094]),
            {
              "class": 2,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.28369140625, 34.009924147266986]),
            {
              "class": 2,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2562255859375, 34.03667178790073]),
            {
              "class": 2,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.04336547851562, 34.14016819059674]),
            {
              "class": 2,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94654846191406, 34.19414075711007]),
            {
              "class": 2,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88887023925781, 34.248646386245944]),
            {
              "class": 2,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84629821777344, 34.3745554855235]),
            {
              "class": 2,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.75566101074219, 34.36492047556795]),
            {
              "class": 2,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73368835449219, 34.2838291900656]),
            {
              "class": 2,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.61833190917969, 34.35415062374609]),
            {
              "class": 2,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.56889343261719, 34.319564378032695]),
            {
              "class": 2,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29835510253906, 34.40855254391948]),
            {
              "class": 2,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9366455078125, 35.35321610123824]),
            {
              "class": 2,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9588623046875, 35.75542836925963]),
            {
              "class": 2,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.4754638671875, 35.85343961959182]),
            {
              "class": 2,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0802001953125, 33.8247936182649]),
            {
              "class": 2,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6632080078125, 34.46127728843705]),
            {
              "class": 2,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.009521484375, 34.53371242139564]),
            {
              "class": 2,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4033203125, 34.70097741472011]),
            {
              "class": 2,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.26736450195312, 34.98387798216256]),
            {
              "class": 2,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.22891235351562, 34.99850370014629]),
            {
              "class": 2,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4527587890625, 34.99512876641514]),
            {
              "class": 2,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.44451904296875, 35.107551518679074]),
            {
              "class": 2,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.50357055664062, 35.10193405724606]),
            {
              "class": 2,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.68484497070312, 34.944488062306256]),
            {
              "class": 2,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.81942749023438, 34.977126769414646]),
            {
              "class": 2,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.15863037109375, 34.44429120303373]),
            {
              "class": 2,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.93753051757812, 34.557466483188996]),
            {
              "class": 2,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.8812255859375, 34.482788036293435]),
            {
              "class": 2,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.7384033203125, 34.119763245290784]),
            {
              "class": 2,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.04901123046875, 34.969249651079004]),
            {
              "class": 2,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.89932250976562, 35.14349410278418]),
            {
              "class": 2,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.89108276367188, 35.058104573869024]),
            {
              "class": 2,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72628784179688, 35.179420821752075]),
            {
              "class": 2,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.61529541015625, 34.903952965590065]),
            {
              "class": 2,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.54525756835938, 34.86903170200862]),
            {
              "class": 2,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69219970703125, 35.000753578642396]),
            {
              "class": 2,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73614501953125, 35.05922870088872]),
            {
              "class": 2,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.88308715820312, 35.12664799144554]),
            {
              "class": 2,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.99020385742188, 34.96249723244915]),
            {
              "class": 2,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.920166015625, 34.99850370014629]),
            {
              "class": 2,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.16873168945312, 34.82620475144151]),
            {
              "class": 2,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.39944458007812, 34.827332061981586]),
            {
              "class": 2,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.66586303710938, 34.76643521684169]),
            {
              "class": 2,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.919921875, 34.76079434523752]),
            {
              "class": 2,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.88009643554688, 34.697590256330386]),
            {
              "class": 2,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.733154296875, 34.16295449004889]),
            {
              "class": 2,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5518798828125, 34.15386343128204]),
            {
              "class": 2,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.97348022460938, 34.17658924285006]),
            {
              "class": 2,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0792236328125, 34.08906131584994]),
            {
              "class": 2,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.13278198242188, 34.03103839734782]),
            {
              "class": 2,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.8045654296875, 33.96158628979907]),
            {
              "class": 2,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.44476318359375, 33.830497692052425]),
            {
              "class": 2,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.48870849609375, 33.871555787081476]),
            {
              "class": 2,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.71417236328125, 34.19249367034176]),
            {
              "class": 2,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7279052734375, 34.20953080048952]),
            {
              "class": 2,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4530029296875, 34.38764597384264]),
            {
              "class": 2,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.58346557617188, 34.41937202924269]),
            {
              "class": 2,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7828369140625, 34.032176483390465]),
            {
              "class": 2,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69631958007812, 33.92740869431181]),
            {
              "class": 2,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.47360229492188, 33.804255802010865]),
            {
              "class": 2,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.18084716796875, 33.895497227123876]),
            {
              "class": 2,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.623046875, 34.0731374116421]),
            {
              "class": 2,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.51181030273438, 34.337766445056666]),
            {
              "class": 2,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.44451904296875, 34.61286625296406]),
            {
              "class": 2,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29071044921875, 34.70888024508579]),
            {
              "class": 2,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.172607421875, 34.96812428662085]),
            {
              "class": 2,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.21792602539062, 34.97487624147657]),
            {
              "class": 2,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.05999755859375, 35.04461384251413]),
            {
              "class": 2,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.18222045898438, 35.1637048348159]),
            {
              "class": 2,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.12567138671875, 34.97600151317588]),
            {
              "class": 2,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.10919189453125, 34.50316152428561]),
            {
              "class": 2,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.44039916992188, 33.84646707394075]),
            {
              "class": 2,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.36761474609375, 33.7094898901883]),
            {
              "class": 2,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.35800170898438, 33.610044573695646]),
            {
              "class": 2,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.798828125, 33.61690656060317]),
            {
              "class": 2,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.99383544921875, 33.52994771113065]),
            {
              "class": 2,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.28933715820312, 33.44633901936737]),
            {
              "class": 2,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.1561279296875, 33.72433966174761]),
            {
              "class": 2,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.19595336914062, 33.715201644740844]),
            {
              "class": 2,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.282470703125, 33.684353657331016]),
            {
              "class": 2,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0242919921875, 33.49788816685208]),
            {
              "class": 2,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.7166748046875, 33.592887216626245]),
            {
              "class": 2,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.7166748046875, 33.613475635436295]),
            {
              "class": 2,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8377685546875, 33.59059931110344]),
            {
              "class": 2,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.865234375, 33.55856226340838]),
            {
              "class": 2,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89407348632812, 33.540250041407845]),
            {
              "class": 2,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92291259765625, 33.58373523046865]),
            {
              "class": 2,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.90093994140625, 33.51735430695927]),
            {
              "class": 2,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5301513671875, 33.444047234512354]),
            {
              "class": 2,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60980224609375, 33.48185394054361]),
            {
              "class": 2,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6510009765625, 33.5093393678006]),
            {
              "class": 2,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.49420166015625, 33.76773195605407]),
            {
              "class": 2,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95449829101562, 33.804255802010865]),
            {
              "class": 2,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.20443725585938, 33.65349459599047]),
            {
              "class": 2,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.45849609375, 33.43946348316134]),
            {
              "class": 2,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.53128051757812, 33.31102018323779]),
            {
              "class": 2,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.54913330078125, 33.28576797042537]),
            {
              "class": 2,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.98471069335938, 33.19962596829635]),
            {
              "class": 2,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89956665039062, 33.2272006440319]),
            {
              "class": 2,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.10556030273438, 33.253618220151104]),
            {
              "class": 2,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.08358764648438, 33.2272006440319]),
            {
              "class": 2,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.48483276367188, 33.51162942617925]),
            {
              "class": 2,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.25823974609375, 33.77800586221063]),
            {
              "class": 2,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64825439453125, 34.09474769880026]),
            {
              "class": 2,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35711669921875, 34.0628990350628]),
            {
              "class": 2,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23764038085938, 33.473835714155776]),
            {
              "class": 2,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.53314208984375, 33.55627344791359]),
            {
              "class": 2,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50704956054688, 33.63291573870479]),
            {
              "class": 2,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.28182983398438, 33.155948300786484]),
            {
              "class": 2,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.12252807617188, 33.49788816685208]),
            {
              "class": 2,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.06622314453125, 33.552840110956154]),
            {
              "class": 2,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.97833251953125, 33.73347670599252]),
            {
              "class": 2,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99343872070312, 33.89321737944089]),
            {
              "class": 2,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23651123046875, 34.28331856338139]),
            {
              "class": 2,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.69381713867188, 34.098159345215535]),
            {
              "class": 2,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.82839965820312, 33.9672812214173]),
            {
              "class": 2,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9423828125, 34.11748941036342]),
            {
              "class": 2,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5853271484375, 34.43069984745346]),
            {
              "class": 2,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.2392578125, 34.6015631772409]),
            {
              "class": 2,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.38619995117188, 34.53710627387901]),
            {
              "class": 2,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.54962158203125, 34.59251960889388]),
            {
              "class": 2,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.83114624023438, 34.59478059328729]),
            {
              "class": 2,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.151123046875, 34.52126711205505]),
            {
              "class": 2,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.27334594726562, 34.616256875628956]),
            {
              "class": 2,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.10305786132812, 34.45335087852229]),
            {
              "class": 2,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.18133544921875, 34.75628137043312]),
            {
              "class": 2,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.36398315429688, 34.79576153473033]),
            {
              "class": 2,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23489379882812, 34.972625651697065]),
            {
              "class": 2,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41891479492188, 34.93773360346578]),
            {
              "class": 2,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.28021240234375, 35.1670728020265]),
            {
              "class": 2,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.39993286132812, 35.146862906756304]),
            {
              "class": 2,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.942626953125, 34.619647359797185]),
            {
              "class": 2,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90692138671875, 34.5710371883746]),
            {
              "class": 2,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.22140502929688, 34.56651386602819]),
            {
              "class": 2,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87396240234375, 34.11294155709559]),
            {
              "class": 2,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.73800659179688, 33.80197351806589]),
            {
              "class": 2,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.59381103515625, 33.84532650276791]),
            {
              "class": 2,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.45510864257812, 33.758598560812004]),
            {
              "class": 2,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.393310546875, 33.78143022380356]),
            {
              "class": 2,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.3548583984375, 33.920571528675076]),
            {
              "class": 2,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14199829101562, 33.9285481685662]),
            {
              "class": 2,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19830322265625, 33.773439833797745]),
            {
              "class": 2,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33563232421875, 33.73918686460779]),
            {
              "class": 2,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2889404296875, 33.306429415579075]),
            {
              "class": 2,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11978149414062, 33.280027811732154]),
            {
              "class": 2,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.19943237304688, 33.51391942394942]),
            {
              "class": 2,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57846069335938, 33.48758079074844]),
            {
              "class": 2,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.78720092773438, 33.046658951713965]),
            {
              "class": 2,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23764038085938, 33.152499136809354]),
            {
              "class": 2,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41616821289062, 33.366090537121586]),
            {
              "class": 2,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.08795166015625, 33.55055114384406]),
            {
              "class": 2,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92864990234375, 34.0094118622566]),
            {
              "class": 2,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.458984375, 34.08451193447477]),
            {
              "class": 2,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14999389648438, 33.82593446346627]),
            {
              "class": 2,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.33401489257812, 33.668354044590075]),
            {
              "class": 2,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55487060546875, 32.7295304134847]),
            {
              "class": 2,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.53564453125, 32.690243035492266]),
            {
              "class": 2,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.24014282226562, 32.861132322810946]),
            {
              "class": 2,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.27996826171875, 32.8092074693633]),
            {
              "class": 2,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31704711914062, 32.713355353177555]),
            {
              "class": 2,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14813232421875, 32.8149783969858]),
            {
              "class": 2,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.91192626953125, 32.87497382061986]),
            {
              "class": 2,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82952880859375, 33.12145055836597]),
            {
              "class": 2,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73065185546875, 33.25706340236547]),
            {
              "class": 2,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.54525756835938, 33.08808985403573]),
            {
              "class": 2,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84649658203125, 32.41590703229392]),
            {
              "class": 2,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.46334838867188, 32.71797709835757]),
            {
              "class": 2,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25299072265625, 32.578063434842164]),
            {
              "class": 2,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.3271484375, 32.652094628339384]),
            {
              "class": 2,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.53863525390625, 32.58037783597417]),
            {
              "class": 2,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.34500122070312, 32.92916554402031]),
            {
              "class": 2,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.13214111328125, 33.02133046690858]),
            {
              "class": 2,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.95361328125, 32.987931797174426]),
            {
              "class": 2,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14724731445312, 33.18813395605041]),
            {
              "class": 2,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.579833984375, 33.075432481213326]),
            {
              "class": 2,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.557861328125, 33.18583537264943]),
            {
              "class": 2,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73638916015625, 33.173192085918075]),
            {
              "class": 2,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.810546875, 33.17549100101063]),
            {
              "class": 2,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1016845703125, 32.94875863715422]),
            {
              "class": 2,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.89431762695312, 33.123750829710225]),
            {
              "class": 2,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.29119873046875, 33.0063602132054]),
            {
              "class": 2,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.38046264648438, 33.00405687168934]),
            {
              "class": 2,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3653564453125, 32.989083685928954]),
            {
              "class": 2,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.25686645507812, 32.795355714148336]),
            {
              "class": 2,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.44500732421875, 32.694865977875054]),
            {
              "class": 2,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22390747070312, 32.36488325846306]),
            {
              "class": 2,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.97671508789062, 32.54797078468894]),
            {
              "class": 2,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.06048583984375, 32.42402179265739]),
            {
              "class": 2,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.91354370117188, 32.44952057251956]),
            {
              "class": 2,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.2008056640625, 32.33355894864107]),
            {
              "class": 2,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7393798828125, 32.44024912337551]),
            {
              "class": 2,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56771850585938, 32.58037783597417]),
            {
              "class": 2,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.75173950195312, 32.54681317351514]),
            {
              "class": 2,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8602294921875, 32.65325087996883]),
            {
              "class": 2,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.788818359375, 32.654407116645416]),
            {
              "class": 2,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11428833007812, 32.72375394304274]),
            {
              "class": 2,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.20904541015625, 32.7295304134847]),
            {
              "class": 2,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.49493408203125, 33.048961180184065]),
            {
              "class": 2,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.13876342773438, 31.73050322928437]),
            {
              "class": 2,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82266235351562, 31.832065815584627]),
            {
              "class": 2,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1124267578125, 31.79472243129337]),
            {
              "class": 2,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.139892578125, 31.886886525780806]),
            {
              "class": 2,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95037841796875, 32.061627957476404]),
            {
              "class": 2,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.42852783203125, 32.209315283375815]),
            {
              "class": 2,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.78445434570312, 32.061627957476404]),
            {
              "class": 2,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.96710205078125, 31.99992399713997]),
            {
              "class": 2,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.46173095703125, 31.784216884487385]),
            {
              "class": 2,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.54000854492188, 31.358327833411312]),
            {
              "class": 2,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.48370361328125, 31.38177878211098]),
            {
              "class": 2,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.36398315429688, 31.483722267336216]),
            {
              "class": 2,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.49468994140625, 31.805226784149458]),
            {
              "class": 2,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47296142578125, 32.41358839527032]),
            {
              "class": 2,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7174072265625, 31.55162295891314]),
            {
              "class": 2,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40841674804688, 31.953327454663953]),
            {
              "class": 2,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.547119140625, 32.0383483283312]),
            {
              "class": 2,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.6954345703125, 31.928854801809585]),
            {
              "class": 2,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.327392578125, 32.30106302536928]),
            {
              "class": 2,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.70916748046875, 32.28481069238481]),
            {
              "class": 2,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.404296875, 32.480804670595184]),
            {
              "class": 2,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00030517578125, 32.217448573031014]),
            {
              "class": 2,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.76547241210938, 31.464982360950497]),
            {
              "class": 2,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.48507690429688, 31.583215062757294]),
            {
              "class": 2,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.78009033203125, 31.927689274849715]),
            {
              "class": 2,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3321533203125, 31.819230730326613]),
            {
              "class": 2,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.33489990234375, 32.03369169193891]),
            {
              "class": 2,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.10281372070312, 31.257422115608605]),
            {
              "class": 2,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.43951416015625, 31.18343427334403]),
            {
              "class": 2,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.42578125, 31.47083898476439]),
            {
              "class": 2,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.56585693359375, 31.553963481763727]),
            {
              "class": 2,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64138793945312, 31.644028945047822]),
            {
              "class": 2,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.51779174804688, 31.821564514920738]),
            {
              "class": 2,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49444580078125, 31.826231907142883]),
            {
              "class": 2,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.72515869140625, 31.906707263514612]),
            {
              "class": 2,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.33514404296875, 32.17793721052666]),
            {
              "class": 2,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.81192016601562, 31.99992399713997]),
            {
              "class": 2,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.65399169921875, 31.765537409484374]),
            {
              "class": 2,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92864990234375, 31.611287945395063]),
            {
              "class": 2,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.71578979492188, 31.856564203952235]),
            {
              "class": 2,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44387817382812, 32.00341778396365]),
            {
              "class": 2,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.36972045898438, 31.805226784149458]),
            {
              "class": 2,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.08544921875, 31.759699300023925]),
            {
              "class": 2,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23239135742188, 30.97643166961479]),
            {
              "class": 2,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.31204223632812, 31.13877870083069]),
            {
              "class": 2,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.58944702148438, 31.20457956539897]),
            {
              "class": 2,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9423828125, 31.145830979734345]),
            {
              "class": 2,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.19393920898438, 30.62373195163005]),
            {
              "class": 2,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57159423828125, 30.490101071309315]),
            {
              "class": 2,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22940063476562, 30.653271432798796]),
            {
              "class": 2,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.72265625, 30.602457940999596]),
            {
              "class": 2,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.79818725585938, 30.643819780284907]),
            {
              "class": 2,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57846069335938, 30.513765952287702]),
            {
              "class": 2,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.65261840820312, 30.642638258763267]),
            {
              "class": 2,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7281494140625, 30.53151083364524]),
            {
              "class": 2,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89044189453125, 30.287531589298723]),
            {
              "class": 2,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.62539672851562, 30.263811840754933]),
            {
              "class": 2,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74761962890625, 30.301760686320712]),
            {
              "class": 2,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99618530273438, 30.383537906740475]),
            {
              "class": 2,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.68032836914062, 30.391830328088133]),
            {
              "class": 2,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.42352294921875, 30.35273132428959]),
            {
              "class": 2,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.43862915039062, 30.274486436999464]),
            {
              "class": 2,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47021484375, 30.21635515266855]),
            {
              "class": 2,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.31777954101562, 30.334953881988564]),
            {
              "class": 2,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.26834106445312, 30.375244781665323]),
            {
              "class": 2,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2010498046875, 30.479449996609706]),
            {
              "class": 2,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.70529174804688, 30.70287744595804]),
            {
              "class": 2,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58993530273438, 30.365766062875743]),
            {
              "class": 2,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5089111328125, 30.09167243190633]),
            {
              "class": 2,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.59405517578125, 31.036461753598545]),
            {
              "class": 2,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26446533203125, 31.233940186109823]),
            {
              "class": 2,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.79342651367188, 31.090574094954192]),
            {
              "class": 2,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.65884399414062, 31.186958816798732]),
            {
              "class": 2,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.745361328125, 31.30788848477748]),
            {
              "class": 2,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.76321411132812, 31.354809686417862]),
            {
              "class": 2,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.78793334960938, 31.39115752282472]),
            {
              "class": 2,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70553588867188, 31.334871033950602]),
            {
              "class": 2,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7069091796875, 31.30671515507517]),
            {
              "class": 2,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.66571044921875, 31.299674869993048]),
            {
              "class": 2,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.66021728515625, 31.371226579385738]),
            {
              "class": 2,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26034545898438, 31.3430815791313]),
            {
              "class": 2,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.44436645507812, 31.389985231456645]),
            {
              "class": 2,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31527709960938, 31.58087527398547]),
            {
              "class": 2,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20816040039062, 31.724662910710993]),
            {
              "class": 2,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2232666015625, 30.98585065275817]),
            {
              "class": 2,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2122802734375, 31.12349696406732]),
            {
              "class": 2,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98568725585938, 30.85154244560597]),
            {
              "class": 2,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9815673828125, 30.746556862773613]),
            {
              "class": 2,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85797119140625, 30.539790669306914]),
            {
              "class": 2,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73162841796875, 30.416703368626855]),
            {
              "class": 2,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.72201538085938, 30.383537906740475]),
            {
              "class": 2,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.79754638671875, 30.331398006092726]),
            {
              "class": 2,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94174194335938, 30.22466172703242]),
            {
              "class": 2,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.10791015625, 30.105929860846892]),
            {
              "class": 2,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33587646484375, 30.017976305655733]),
            {
              "class": 2,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25347900390625, 30.243645548209447]),
            {
              "class": 2,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20266723632812, 30.43328187492765]),
            {
              "class": 2,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24376678466797, 30.304132001763683]),
            {
              "class": 2,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11433410644531, 30.355693917395335]),
            {
              "class": 2,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03983306884766, 30.41137396479027]),
            {
              "class": 2,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01305389404297, 30.468205931143327]),
            {
              "class": 2,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20600128173828, 30.515244816150467]),
            {
              "class": 2,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2403335571289, 30.407820867239447]),
            {
              "class": 2,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.34058380126953, 30.192914965504624]),
            {
              "class": 2,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4099349975586, 30.243645548209447]),
            {
              "class": 2,
              "system:index": "780"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50434875488281, 30.307392466842646]),
            {
              "class": 2,
              "system:index": "781"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50709533691406, 30.261736090037477]),
            {
              "class": 2,
              "system:index": "782"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.47379302978516, 30.258474107402265]),
            {
              "class": 2,
              "system:index": "783"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.13321685791016, 30.27982329983024]),
            {
              "class": 2,
              "system:index": "784"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.19398498535156, 30.308578063619894]),
            {
              "class": 2,
              "system:index": "785"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00790405273438, 30.268852766953753]),
            {
              "class": 2,
              "system:index": "786"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.99966430664062, 30.345887362335322]),
            {
              "class": 2,
              "system:index": "787"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11570739746094, 30.32781233821565]),
            {
              "class": 2,
              "system:index": "788"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.349853515625, 30.693312439902584]),
            {
              "class": 2,
              "system:index": "789"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2344970703125, 30.777120559815824]),
            {
              "class": 2,
              "system:index": "790"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.84585571289062, 30.705179905593372]),
            {
              "class": 2,
              "system:index": "791"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96052551269531, 30.642579124616418]),
            {
              "class": 2,
              "system:index": "792"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.34803771972656, 30.78779796241718]),
            {
              "class": 2,
              "system:index": "793"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30409240722656, 30.876238605034978]),
            {
              "class": 2,
              "system:index": "794"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.34323120117188, 30.627808878813426]),
            {
              "class": 2,
              "system:index": "795"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.54991149902344, 30.492408592739764]),
            {
              "class": 2,
              "system:index": "796"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.62681579589844, 30.462228236336934]),
            {
              "class": 2,
              "system:index": "797"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78199768066406, 30.54150563212306]),
            {
              "class": 2,
              "system:index": "798"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78955078125, 30.693961995453098]),
            {
              "class": 2,
              "system:index": "799"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.92413330078125, 30.402431697990522]),
            {
              "class": 2,
              "system:index": "800"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.58218383789062, 30.384663290210103]),
            {
              "class": 2,
              "system:index": "801"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40090942382812, 30.24892471392221]),
            {
              "class": 2,
              "system:index": "802"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.49017333984375, 30.135566789314673]),
            {
              "class": 2,
              "system:index": "803"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.39541625976562, 30.15991116256531]),
            {
              "class": 2,
              "system:index": "804"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.32881164550781, 30.10171219431091]),
            {
              "class": 2,
              "system:index": "805"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.44966125488281, 30.033968210447714]),
            {
              "class": 2,
              "system:index": "806"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40708923339844, 30.00364668507385]),
            {
              "class": 2,
              "system:index": "807"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4874267578125, 29.923339099254544]),
            {
              "class": 2,
              "system:index": "808"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.55540466308594, 29.955469920192577]),
            {
              "class": 2,
              "system:index": "809"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57394409179688, 29.879886498982728]),
            {
              "class": 2,
              "system:index": "810"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36245727539062, 29.750011258132396]),
            {
              "class": 2,
              "system:index": "811"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.20796203613281, 29.97688470066534]),
            {
              "class": 2,
              "system:index": "812"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.08642578125, 30.130815967321382]),
            {
              "class": 2,
              "system:index": "813"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.97999572753906, 30.315335633518327]),
            {
              "class": 2,
              "system:index": "814"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02188110351562, 30.005430560839788]),
            {
              "class": 2,
              "system:index": "815"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1578369140625, 29.671885893281008]),
            {
              "class": 2,
              "system:index": "816"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.50253295898438, 29.58892309863392]),
            {
              "class": 2,
              "system:index": "817"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.53823852539062, 29.56682796762943]),
            {
              "class": 2,
              "system:index": "818"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13105773925781, 29.64026065745658]),
            {
              "class": 2,
              "system:index": "819"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.01982116699219, 29.868573810721028]),
            {
              "class": 2,
              "system:index": "820"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6192626953125, 29.27016783774995]),
            {
              "class": 2,
              "system:index": "821"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81358337402344, 29.258786635056385]),
            {
              "class": 2,
              "system:index": "822"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.97975158691406, 29.304303842667558]),
            {
              "class": 2,
              "system:index": "823"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00721740722656, 29.30190870574928]),
            {
              "class": 2,
              "system:index": "824"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09648132324219, 29.43594975277581]),
            {
              "class": 2,
              "system:index": "825"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24136352539062, 29.349202251795106]),
            {
              "class": 2,
              "system:index": "826"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.21664428710938, 29.50828237240547]),
            {
              "class": 2,
              "system:index": "827"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40684509277344, 29.400661421477714]),
            {
              "class": 2,
              "system:index": "828"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.52426147460938, 29.370148076387515]),
            {
              "class": 2,
              "system:index": "829"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.48100280761719, 29.526208093251537]),
            {
              "class": 2,
              "system:index": "830"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.69248962402344, 29.448507048255017]),
            {
              "class": 2,
              "system:index": "831"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.78861999511719, 29.428773457970518]),
            {
              "class": 2,
              "system:index": "832"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.43568420410156, 29.644438145011417]),
            {
              "class": 2,
              "system:index": "833"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.47688293457031, 29.63071146366981]),
            {
              "class": 2,
              "system:index": "834"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44117736816406, 29.75358806281183]),
            {
              "class": 2,
              "system:index": "835"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38555908203125, 29.848326851045393]),
            {
              "class": 2,
              "system:index": "836"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44804382324219, 29.851304602696505]),
            {
              "class": 2,
              "system:index": "837"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31483459472656, 29.94178583928953]),
            {
              "class": 2,
              "system:index": "838"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35466003417969, 30.016133141872018]),
            {
              "class": 2,
              "system:index": "839"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.43087768554688, 30.02683456804441]),
            {
              "class": 2,
              "system:index": "840"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51945495605469, 30.020889473872057]),
            {
              "class": 2,
              "system:index": "841"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.33749389648438, 30.067845998734974]),
            {
              "class": 2,
              "system:index": "842"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8170166015625, 32.82836505486626]),
            {
              "class": 2,
              "system:index": "843"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.0367431640625, 32.91141230954107]),
            {
              "class": 2,
              "system:index": "844"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91015625, 33.21559724799054]),
            {
              "class": 2,
              "system:index": "845"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.009033203125, 33.36482878606327]),
            {
              "class": 2,
              "system:index": "846"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.10379028320312, 33.137436085989414]),
            {
              "class": 2,
              "system:index": "847"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3770751953125, 33.23282929332664]),
            {
              "class": 2,
              "system:index": "848"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.34686279296875, 33.002789895748236]),
            {
              "class": 2,
              "system:index": "849"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30703735351562, 33.53212263796623]),
            {
              "class": 2,
              "system:index": "850"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55697631835938, 33.72308313054425]),
            {
              "class": 2,
              "system:index": "851"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.21149444580078, 33.674325648924395]),
            {
              "class": 2,
              "system:index": "852"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23072052001953, 33.58713871077581]),
            {
              "class": 2,
              "system:index": "853"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35877990722656, 33.59857809047438]),
            {
              "class": 2,
              "system:index": "854"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.46417999267578, 33.615162496123126]),
            {
              "class": 2,
              "system:index": "855"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3773193359375, 33.64917913202928]),
            {
              "class": 2,
              "system:index": "856"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.27432250976562, 33.61258926298147]),
            {
              "class": 2,
              "system:index": "857"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24376678466797, 33.51618070931566]),
            {
              "class": 2,
              "system:index": "858"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38349914550781, 33.51045575087657]),
            {
              "class": 2,
              "system:index": "859"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.34642028808594, 33.48182527737716]),
            {
              "class": 2,
              "system:index": "860"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.064208984375, 33.520760403311975]),
            {
              "class": 2,
              "system:index": "861"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.99897766113281, 33.62116640801947]),
            {
              "class": 2,
              "system:index": "862"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94507598876953, 33.68518209972835]),
            {
              "class": 2,
              "system:index": "863"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.98867797851562, 33.72202666525305]),
            {
              "class": 2,
              "system:index": "864"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.99108123779297, 33.752575668002194]),
            {
              "class": 2,
              "system:index": "865"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9375228881836, 33.78796463938296]),
            {
              "class": 2,
              "system:index": "866"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03227996826172, 33.58284855229936]),
            {
              "class": 2,
              "system:index": "867"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.11570739746094, 33.679468349134936]),
            {
              "class": 2,
              "system:index": "868"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09579467773438, 33.812214797942914]),
            {
              "class": 2,
              "system:index": "869"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04395294189453, 33.91228073628531]),
            {
              "class": 2,
              "system:index": "870"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.79985046386719, 33.97664856132208]),
            {
              "class": 2,
              "system:index": "871"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8173599243164, 34.0312944749848]),
            {
              "class": 2,
              "system:index": "872"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.73084259033203, 34.105238079714795]),
            {
              "class": 2,
              "system:index": "873"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.68930053710938, 34.11973482967065]),
            {
              "class": 2,
              "system:index": "874"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.66149139404297, 34.13905996431378]),
            {
              "class": 2,
              "system:index": "875"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52793884277344, 34.13081890308264]),
            {
              "class": 2,
              "system:index": "876"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47472381591797, 34.141333219094484]),
            {
              "class": 2,
              "system:index": "877"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4654541015625, 34.17996919151697]),
            {
              "class": 2,
              "system:index": "878"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.34838104248047, 34.16292608895038]),
            {
              "class": 2,
              "system:index": "879"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.3387680053711, 34.12513494439542]),
            {
              "class": 2,
              "system:index": "880"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.27079010009766, 34.14161737164191]),
            {
              "class": 2,
              "system:index": "881"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2127685546875, 34.11689252550345]),
            {
              "class": 2,
              "system:index": "882"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.16539001464844, 34.11632405320654]),
            {
              "class": 2,
              "system:index": "883"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.15955352783203, 34.14048075571865]),
            {
              "class": 2,
              "system:index": "884"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.11011505126953, 33.99856807231409]),
            {
              "class": 2,
              "system:index": "885"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.03939056396484, 34.049217502637056]),
            {
              "class": 2,
              "system:index": "886"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.00299835205078, 33.94760362268466]),
            {
              "class": 2,
              "system:index": "887"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.8780288696289, 33.962412085470966]),
            {
              "class": 2,
              "system:index": "888"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.84129333496094, 34.034139652879304]),
            {
              "class": 2,
              "system:index": "889"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.89038848876953, 34.14673195408268]),
            {
              "class": 2,
              "system:index": "890"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.8443832397461, 34.124850736429224]),
            {
              "class": 2,
              "system:index": "891"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.965576171875, 34.21631629664517]),
            {
              "class": 2,
              "system:index": "892"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.04145050048828, 34.19104535378688]),
            {
              "class": 2,
              "system:index": "893"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.97724914550781, 34.2483909577987]),
            {
              "class": 2,
              "system:index": "894"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.93364715576172, 34.28300651894707]),
            {
              "class": 2,
              "system:index": "895"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.08196258544922, 34.30541391201676]),
            {
              "class": 2,
              "system:index": "896"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2563705444336, 34.33093403791268]),
            {
              "class": 2,
              "system:index": "897"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.21105194091797, 34.421609393246655]),
            {
              "class": 2,
              "system:index": "898"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.26392364501953, 34.43237056900935]),
            {
              "class": 2,
              "system:index": "899"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.23954772949219, 34.481344723728945]),
            {
              "class": 2,
              "system:index": "900"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.23886108398438, 33.44685467660297]),
            {
              "class": 2,
              "system:index": "901"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.32537841796875, 33.605412437679846]),
            {
              "class": 2,
              "system:index": "902"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.09329223632812, 33.65115115496183]),
            {
              "class": 2,
              "system:index": "903"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.96420288085938, 33.59397396445625]),
            {
              "class": 2,
              "system:index": "904"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.85296630859375, 33.45201094048311]),
            {
              "class": 2,
              "system:index": "905"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.75065612792969, 33.23805580221389]),
            {
              "class": 2,
              "system:index": "906"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91133117675781, 33.23173815734582]),
            {
              "class": 2,
              "system:index": "907"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.26495361328125, 33.26734073609995]),
            {
              "class": 2,
              "system:index": "908"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45240783691406, 33.36660667091574]),
            {
              "class": 2,
              "system:index": "909"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17843627929688, 33.5876821575234]),
            {
              "class": 2,
              "system:index": "910"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.14410400390625, 33.65515213713568]),
            {
              "class": 2,
              "system:index": "911"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.22238159179688, 33.66029598375789]),
            {
              "class": 2,
              "system:index": "912"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46133422851562, 33.61913660268053]),
            {
              "class": 2,
              "system:index": "913"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60621643066406, 33.63571705296988]),
            {
              "class": 2,
              "system:index": "914"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57051086425781, 33.03681626049718]),
            {
              "class": 2,
              "system:index": "915"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60140991210938, 32.986146353959235]),
            {
              "class": 2,
              "system:index": "916"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.71058654785156, 32.96828979510461]),
            {
              "class": 2,
              "system:index": "917"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.70440673828125, 33.033938068703776]),
            {
              "class": 2,
              "system:index": "918"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.33293151855469, 32.975778469076864]),
            {
              "class": 2,
              "system:index": "919"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.21757507324219, 33.051781342089114]),
            {
              "class": 2,
              "system:index": "920"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.11320495605469, 33.11736744238037]),
            {
              "class": 2,
              "system:index": "921"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.12556457519531, 33.22886634969869]),
            {
              "class": 2,
              "system:index": "922"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.07475280761719, 33.29604192577791]),
            {
              "class": 2,
              "system:index": "923"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.00814819335938, 33.19956852601376]),
            {
              "class": 2,
              "system:index": "924"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.75271606445312, 33.22369685830106]),
            {
              "class": 2,
              "system:index": "925"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.81520080566406, 33.02242436139129]),
            {
              "class": 2,
              "system:index": "926"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9271240234375, 33.0264543300468]),
            {
              "class": 2,
              "system:index": "927"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.67787170410156, 33.35743075133666]),
            {
              "class": 2,
              "system:index": "928"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.82893371582031, 33.45430251491847]),
            {
              "class": 2,
              "system:index": "929"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.04728698730469, 33.42164186325336]),
            {
              "class": 2,
              "system:index": "930"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02119445800781, 33.48065126787604]),
            {
              "class": 2,
              "system:index": "931"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.72044372558594, 33.649436391378146]),
            {
              "class": 2,
              "system:index": "932"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.62362670898438, 33.66429654076056]),
            {
              "class": 2,
              "system:index": "933"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.46707153320312, 33.65172273523148]),
            {
              "class": 2,
              "system:index": "934"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.54740905761719, 33.66772544155552]),
            {
              "class": 2,
              "system:index": "935"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.43960571289062, 33.502411586231794]),
            {
              "class": 2,
              "system:index": "936"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.39085388183594, 33.52531127594758]),
            {
              "class": 2,
              "system:index": "937"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.438232421875, 33.564226834906336]),
            {
              "class": 2,
              "system:index": "938"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.46089172363281, 33.40502032274112]),
            {
              "class": 2,
              "system:index": "939"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.49110412597656, 33.37176770045429]),
            {
              "class": 2,
              "system:index": "940"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.4052734375, 33.30350268905475]),
            {
              "class": 2,
              "system:index": "941"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.51033020019531, 33.28800654400263]),
            {
              "class": 2,
              "system:index": "942"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.57968139648438, 33.25643180981413]),
            {
              "class": 2,
              "system:index": "943"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.64010620117188, 33.27021127973254]),
            {
              "class": 2,
              "system:index": "944"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.74859619140625, 33.132893826530655]),
            {
              "class": 2,
              "system:index": "945"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.76507568359375, 33.08975820406585]),
            {
              "class": 2,
              "system:index": "946"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.84060668945312, 32.970018006992724]),
            {
              "class": 2,
              "system:index": "947"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90171813964844, 33.42164186325336]),
            {
              "class": 2,
              "system:index": "948"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.83717346191406, 33.308667459016185]),
            {
              "class": 2,
              "system:index": "949"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98274230957031, 33.35857779419739]),
            {
              "class": 2,
              "system:index": "950"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13449096679688, 33.57509716710238]),
            {
              "class": 2,
              "system:index": "951"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.65383911132812, 33.74312664897133]),
            {
              "class": 2,
              "system:index": "952"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.5096435546875, 33.77395352065997]),
            {
              "class": 2,
              "system:index": "953"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.12168884277344, 33.781373148748834]),
            {
              "class": 2,
              "system:index": "954"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.21987915039062, 33.76139576301482]),
            {
              "class": 2,
              "system:index": "955"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.25421142578125, 33.72885119544226]),
            {
              "class": 2,
              "system:index": "956"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.25901794433594, 33.64600674428308]),
            {
              "class": 2,
              "system:index": "957"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.18074035644531, 33.55793284170089]),
            {
              "class": 2,
              "system:index": "958"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.174560546875, 33.80533986208563]),
            {
              "class": 2,
              "system:index": "959"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.73554992675781, 33.935327721705406]),
            {
              "class": 2,
              "system:index": "960"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.45745849609375, 33.93931544406705]),
            {
              "class": 2,
              "system:index": "961"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.37643432617188, 33.914816485505376]),
            {
              "class": 2,
              "system:index": "962"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.28511047363281, 33.83956638227414]),
            {
              "class": 2,
              "system:index": "963"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.70121765136719, 33.78650943785745]),
            {
              "class": 2,
              "system:index": "964"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.10015869140625, 34.092984974821036]),
            {
              "class": 2,
              "system:index": "965"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.90789794921875, 34.249781545125145]),
            {
              "class": 2,
              "system:index": "966"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.74516296386719, 34.3813560017952]),
            {
              "class": 2,
              "system:index": "967"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.7623291015625, 34.32069857941571]),
            {
              "class": 2,
              "system:index": "968"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02737426757812, 34.44819832242275]),
            {
              "class": 2,
              "system:index": "969"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13929748535156, 34.57889588954424]),
            {
              "class": 2,
              "system:index": "970"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.93193054199219, 34.58794094083083]),
            {
              "class": 2,
              "system:index": "971"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.70808410644531, 34.62072099803888]),
            {
              "class": 2,
              "system:index": "972"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.73623657226562, 34.708823812755185]),
            {
              "class": 2,
              "system:index": "973"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.80146789550781, 34.65631225786976]),
            {
              "class": 2,
              "system:index": "974"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.78567504882812, 34.53309021391031]),
            {
              "class": 2,
              "system:index": "975"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.42974853515625, 34.764686601640825]),
            {
              "class": 2,
              "system:index": "976"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.58699035644531, 34.73986335794178]),
            {
              "class": 2,
              "system:index": "977"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46408081054688, 34.83178480151474]),
            {
              "class": 2,
              "system:index": "978"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.69410705566406, 34.88249505736076]),
            {
              "class": 2,
              "system:index": "979"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.72431945800781, 34.99113492877501]),
            {
              "class": 2,
              "system:index": "980"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.53961181640625, 35.00969624769977]),
            {
              "class": 2,
              "system:index": "981"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.87263488769531, 34.863904857848304]),
            {
              "class": 2,
              "system:index": "982"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96258544921875, 34.72575584961214]),
            {
              "class": 2,
              "system:index": "983"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02438354492188, 35.078280244375705]),
            {
              "class": 2,
              "system:index": "984"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00172424316406, 35.26126311210371]),
            {
              "class": 2,
              "system:index": "985"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.58561706542969, 35.2926542881823]),
            {
              "class": 2,
              "system:index": "986"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.53549194335938, 35.31843079366438]),
            {
              "class": 2,
              "system:index": "987"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.21963500976562, 35.3772376926754]),
            {
              "class": 2,
              "system:index": "988"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60140991210938, 35.04455757157317]),
            {
              "class": 2,
              "system:index": "989"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94953918457031, 35.03218910183664]),
            {
              "class": 2,
              "system:index": "990"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15484619140625, 35.11648243031855]),
            {
              "class": 2,
              "system:index": "991"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24960327148438, 35.239955028730606]),
            {
              "class": 2,
              "system:index": "992"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.43431091308594, 35.426490488648895]),
            {
              "class": 2,
              "system:index": "993"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.196044921875, 35.445511917670196]),
            {
              "class": 2,
              "system:index": "994"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03468322753906, 35.51372827756178]),
            {
              "class": 2,
              "system:index": "995"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.822509765625, 35.653892857954666]),
            {
              "class": 2,
              "system:index": "996"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48056030273438, 35.71468469816859]),
            {
              "class": 2,
              "system:index": "997"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.24092102050781, 35.828335708115304]),
            {
              "class": 2,
              "system:index": "998"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.031494140625, 35.84169573415934]),
            {
              "class": 2,
              "system:index": "999"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.50047302246094, 35.95294175731633]),
            {
              "class": 2,
              "system:index": "1000"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.1138916015625, 35.994618694639136]),
            {
              "class": 2,
              "system:index": "1001"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.03904724121094, 36.090114670756705]),
            {
              "class": 2,
              "system:index": "1002"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98342895507812, 36.03793936138222]),
            {
              "class": 2,
              "system:index": "1003"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.98548889160156, 36.15057248963096]),
            {
              "class": 2,
              "system:index": "1004"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.34666442871094, 36.21209176644931]),
            {
              "class": 2,
              "system:index": "1005"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.55540466308594, 36.21209176644931]),
            {
              "class": 2,
              "system:index": "1006"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.69479370117188, 36.2730091390538]),
            {
              "class": 2,
              "system:index": "1007"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.7950439453125, 36.11341585711324]),
            {
              "class": 2,
              "system:index": "1008"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.74560546875, 36.202118949677185]),
            {
              "class": 2,
              "system:index": "1009"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05116271972656, 36.12284532486864]),
            {
              "class": 2,
              "system:index": "1010"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01545715332031, 36.19934849727767]),
            {
              "class": 2,
              "system:index": "1011"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.23518371582031, 36.224279038862065]),
            {
              "class": 2,
              "system:index": "1012"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.33749389648438, 36.07957138783587]),
            {
              "class": 2,
              "system:index": "1013"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4212646484375, 36.2896147267423]),
            {
              "class": 2,
              "system:index": "1014"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.57369995117188, 36.361531437522316]),
            {
              "class": 2,
              "system:index": "1015"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.79617309570312, 36.21984752310905]),
            {
              "class": 2,
              "system:index": "1016"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84835815429688, 36.40299164816345]),
            {
              "class": 2,
              "system:index": "1017"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91358947753906, 36.50958091381436]),
            {
              "class": 2,
              "system:index": "1018"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28118896484375, 36.80318215867702]),
            {
              "class": 2,
              "system:index": "1019"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30659484863281, 36.6777261757802]),
            {
              "class": 2,
              "system:index": "1020"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28530883789062, 36.594526282771994]),
            {
              "class": 2,
              "system:index": "1021"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.91520690917969, 36.91470933596121]),
            {
              "class": 2,
              "system:index": "1022"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81358337402344, 36.93227512116726]),
            {
              "class": 2,
              "system:index": "1023"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.712646484375, 36.83506367250744]),
            {
              "class": 2,
              "system:index": "1024"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.7620849609375, 36.95916488602421]),
            {
              "class": 2,
              "system:index": "1025"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.58905029296875, 36.953129234378785]),
            {
              "class": 2,
              "system:index": "1026"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.72569274902344, 37.09128042558171]),
            {
              "class": 2,
              "system:index": "1027"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88911437988281, 37.084159725243936]),
            {
              "class": 2,
              "system:index": "1028"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.93168640136719, 37.03594047274636]),
            {
              "class": 2,
              "system:index": "1029"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94473266601562, 36.89878684784146]),
            {
              "class": 2,
              "system:index": "1030"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.90422058105469, 36.76303655282213]),
            {
              "class": 2,
              "system:index": "1031"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.87606811523438, 36.725071376779994]),
            {
              "class": 2,
              "system:index": "1032"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85134887695312, 36.63751492916811]),
            {
              "class": 2,
              "system:index": "1033"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.61170959472656, 36.855394940434834]),
            {
              "class": 2,
              "system:index": "1034"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.19741821289062, 36.94654434158736]),
            {
              "class": 2,
              "system:index": "1035"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24822998046875, 36.92623733896604]),
            {
              "class": 2,
              "system:index": "1036"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.064208984375, 36.967394549157845]),
            {
              "class": 2,
              "system:index": "1037"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.60871887207031, 37.03045907328054]),
            {
              "class": 2,
              "system:index": "1038"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.41096496582031, 37.03484422450442]),
            {
              "class": 2,
              "system:index": "1039"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.41851806640625, 36.947641863249764]),
            {
              "class": 2,
              "system:index": "1040"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.864501953125, 33.98800666261025]),
            {
              "class": 2,
              "system:index": "1041"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.600830078125, 35.145963695380615]),
            {
              "class": 2,
              "system:index": "1042"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.1064453125, 36.20793576898224]),
            {
              "class": 2,
              "system:index": "1043"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.656005859375, 36.499921315784256]),
            {
              "class": 2,
              "system:index": "1044"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.73291015625, 33.15502763877673]),
            {
              "class": 2,
              "system:index": "1045"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.007568359375, 32.98931316197111]),
            {
              "class": 2,
              "system:index": "1046"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29296875, 32.57366500399322]),
            {
              "class": 2,
              "system:index": "1047"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.611572265625, 32.961663755392216]),
            {
              "class": 2,
              "system:index": "1048"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.744384765625, 30.844703261362984]),
            {
              "class": 2,
              "system:index": "1049"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14013671875, 29.963500132262414]),
            {
              "class": 2,
              "system:index": "1050"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.382080078125, 30.03961444248583]),
            {
              "class": 2,
              "system:index": "1051"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.613037109375, 29.953981739834077]),
            {
              "class": 2,
              "system:index": "1052"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.535888671875, 29.562945016318288]),
            {
              "class": 2,
              "system:index": "1053"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.953857421875, 29.696641235861854]),
            {
              "class": 2,
              "system:index": "1054"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.60205078125, 29.725267325290105]),
            {
              "class": 2,
              "system:index": "1055"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.800048828125, 30.589690367893517]),
            {
              "class": 2,
              "system:index": "1056"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.82525634765625, 32.79397019445094]),
            {
              "class": 2,
              "system:index": "1057"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5860595703125, 32.74085098420697]),
            {
              "class": 2,
              "system:index": "1058"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9541015625, 32.694634610717294]),
            {
              "class": 2,
              "system:index": "1059"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.734375, 32.990004961134794]),
            {
              "class": 2,
              "system:index": "1060"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47869873046875, 32.796279006175]),
            {
              "class": 2,
              "system:index": "1061"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72314453125, 32.77318819163784]),
            {
              "class": 2,
              "system:index": "1062"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.899169921875, 32.10793656855038]),
            {
              "class": 2,
              "system:index": "1063"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.987060546875, 31.9006446749435]),
            {
              "class": 2,
              "system:index": "1064"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.349853515625, 32.43769908129017]),
            {
              "class": 2,
              "system:index": "1065"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2454833984375, 32.55352688444716]),
            {
              "class": 2,
              "system:index": "1066"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.27569580078125, 32.01017183352464]),
            {
              "class": 2,
              "system:index": "1067"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.0367431640625, 32.17073012103842]),
            {
              "class": 2,
              "system:index": "1068"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.28143310546875, 31.545537096161002]),
            {
              "class": 2,
              "system:index": "1069"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.39404296875, 31.332290199821944]),
            {
              "class": 2,
              "system:index": "1070"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.251220703125, 31.90530806490649]),
            {
              "class": 2,
              "system:index": "1071"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9820556640625, 32.14050158546303]),
            {
              "class": 2,
              "system:index": "1072"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.03424072265625, 32.43769908129017]),
            {
              "class": 2,
              "system:index": "1073"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.02874755859375, 32.81474734165644]),
            {
              "class": 2,
              "system:index": "1074"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.13861083984375, 32.67845322316471]),
            {
              "class": 2,
              "system:index": "1075"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.921630859375, 32.694634610717294]),
            {
              "class": 2,
              "system:index": "1076"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.68243408203125, 32.88627588237998]),
            {
              "class": 2,
              "system:index": "1077"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04498291015625, 32.74778137427633]),
            {
              "class": 2,
              "system:index": "1078"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.19329833984375, 32.84475020102665]),
            {
              "class": 2,
              "system:index": "1079"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8057861328125, 32.823980070295406]),
            {
              "class": 2,
              "system:index": "1080"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4542236328125, 32.733920055080596]),
            {
              "class": 2,
              "system:index": "1081"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7783203125, 32.34957028003212]),
            {
              "class": 2,
              "system:index": "1082"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84468078613281, 32.9930575304961]),
            {
              "class": 2,
              "system:index": "1083"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85841369628906, 32.70520888789139]),
            {
              "class": 2,
              "system:index": "1084"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.88725280761719, 32.75430716791167]),
            {
              "class": 2,
              "system:index": "1085"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.86871337890625, 32.96368099444361]),
            {
              "class": 2,
              "system:index": "1086"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01840209960938, 33.046601339023596]),
            {
              "class": 2,
              "system:index": "1087"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.16627502441406, 33.038543060176956]),
            {
              "class": 2,
              "system:index": "1088"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1683349609375, 33.10816525653547]),
            {
              "class": 2,
              "system:index": "1089"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25897216796875, 32.79587513755171]),
            {
              "class": 2,
              "system:index": "1090"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51371765136719, 32.62948684923938]),
            {
              "class": 2,
              "system:index": "1091"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62701416015625, 32.50565034398413]),
            {
              "class": 2,
              "system:index": "1092"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58375549316406, 32.43961161961671]),
            {
              "class": 2,
              "system:index": "1093"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20541381835938, 32.46568532354689]),
            {
              "class": 2,
              "system:index": "1094"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.90740966796875, 32.45409794221771]),
            {
              "class": 2,
              "system:index": "1095"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85385131835938, 32.642786201616076]),
            {
              "class": 2,
              "system:index": "1096"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83668518066406, 32.79529793761915]),
            {
              "class": 2,
              "system:index": "1097"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.77763366699219, 32.79010296962898]),
            {
              "class": 2,
              "system:index": "1098"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.79342651367188, 32.7398693045607]),
            {
              "class": 2,
              "system:index": "1099"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0859375, 32.807995470589915]),
            {
              "class": 2,
              "system:index": "1100"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8167724609375, 32.762391349241554]),
            {
              "class": 2,
              "system:index": "1101"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83187866210938, 33.05005466141842]),
            {
              "class": 2,
              "system:index": "1102"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.19442749023438, 33.0943602758982]),
            {
              "class": 2,
              "system:index": "1103"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51646423339844, 33.06214022332175]),
            {
              "class": 2,
              "system:index": "1104"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.80691528320312, 33.06789466965199]),
            {
              "class": 2,
              "system:index": "1105"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14199829101562, 32.93026051039307]),
            {
              "class": 2,
              "system:index": "1106"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.08638000488281, 32.705786671892305]),
            {
              "class": 2,
              "system:index": "1107"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9373779296875, 32.443088549403335]),
            {
              "class": 2,
              "system:index": "1108"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98956298828125, 32.50275492456082]),
            {
              "class": 2,
              "system:index": "1109"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.67645263671875, 32.89625085193699]),
            {
              "class": 2,
              "system:index": "1110"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.800048828125, 33.24724421886505]),
            {
              "class": 2,
              "system:index": "1111"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75473022460938, 33.36660660091273]),
            {
              "class": 2,
              "system:index": "1112"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87351989746094, 33.34997453425236]),
            {
              "class": 2,
              "system:index": "1113"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10079956054688, 33.39011547778059]),
            {
              "class": 2,
              "system:index": "1114"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64418029785156, 33.465759408776776]),
            {
              "class": 2,
              "system:index": "1115"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.54598999023438, 33.49725825092823]),
            {
              "class": 2,
              "system:index": "1116"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.34480285644531, 33.4858054517564]),
            {
              "class": 2,
              "system:index": "1117"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95753479003906, 33.39240868647285]),
            {
              "class": 2,
              "system:index": "1118"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37501525878906, 33.3132580387976]),
            {
              "class": 2,
              "system:index": "1119"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.05984497070312, 33.16968606817618]),
            {
              "class": 2,
              "system:index": "1120"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82089233398438, 33.26217344970268]),
            {
              "class": 2,
              "system:index": "1121"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.69317626953125, 33.35800420464677]),
            {
              "class": 2,
              "system:index": "1122"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.59567260742188, 33.22656876556942]),
            {
              "class": 2,
              "system:index": "1123"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.69729614257812, 33.1357687113688]),
            {
              "class": 2,
              "system:index": "1124"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50778198242188, 33.13174374796323]),
            {
              "class": 2,
              "system:index": "1125"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44461059570312, 33.01493957480549]),
            {
              "class": 2,
              "system:index": "1126"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.65060424804688, 33.014363801078986]),
            {
              "class": 2,
              "system:index": "1127"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63206481933594, 32.935447275642105]),
            {
              "class": 2,
              "system:index": "1128"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.43980407714844, 32.956767448145904]),
            {
              "class": 2,
              "system:index": "1129"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39242553710938, 33.00399923114617]),
            {
              "class": 2,
              "system:index": "1130"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39105224609375, 33.288006473936434]),
            {
              "class": 2,
              "system:index": "1131"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31483459472656, 33.37119419784859]),
            {
              "class": 2,
              "system:index": "1132"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40135192871094, 33.4245072546138]),
            {
              "class": 2,
              "system:index": "1133"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.48374938964844, 33.455448209495984]),
            {
              "class": 2,
              "system:index": "1134"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.65678405761719, 33.54477117612137]),
            {
              "class": 2,
              "system:index": "1135"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.54898071289062, 33.60369669360674]),
            {
              "class": 2,
              "system:index": "1136"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38761901855469, 33.547632566939015]),
            {
              "class": 2,
              "system:index": "1137"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26333618164062, 33.55449951830907]),
            {
              "class": 2,
              "system:index": "1138"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.19741821289062, 33.43826015234574]),
            {
              "class": 2,
              "system:index": "1139"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.17132568359375, 33.39756818482044]),
            {
              "class": 2,
              "system:index": "1140"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.09098815917969, 33.34366498790975]),
            {
              "class": 2,
              "system:index": "1141"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15690612792969, 33.21508029028679]),
            {
              "class": 2,
              "system:index": "1142"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.06832885742188, 33.15244159345406]),
            {
              "class": 2,
              "system:index": "1143"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03399658203125, 33.055234391096235]),
            {
              "class": 2,
              "system:index": "1144"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.76963806152344, 32.94985336095343]),
            {
              "class": 2,
              "system:index": "1145"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.82594299316406, 32.945243669023505]),
            {
              "class": 2,
              "system:index": "1146"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.77238464355469, 33.04084550078558]),
            {
              "class": 2,
              "system:index": "1147"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.87469482421875, 32.99708884122961]),
            {
              "class": 2,
              "system:index": "1148"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.119140625, 32.966561479081356]),
            {
              "class": 2,
              "system:index": "1149"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94404602050781, 32.83107724708938]),
            {
              "class": 2,
              "system:index": "1150"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81083679199219, 32.72080774259828]),
            {
              "class": 2,
              "system:index": "1151"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.17819213867188, 32.661864427477894]),
            {
              "class": 2,
              "system:index": "1152"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.43087768554688, 32.77278421816904]),
            {
              "class": 2,
              "system:index": "1153"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50091552734375, 32.825307365200665]),
            {
              "class": 2,
              "system:index": "1154"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.71171569824219, 32.895097753207324]),
            {
              "class": 2,
              "system:index": "1155"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.75634765625, 32.883565940385736]),
            {
              "class": 2,
              "system:index": "1156"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83462524414062, 32.899133533089]),
            {
              "class": 2,
              "system:index": "1157"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98980712890625, 32.87376271950073]),
            {
              "class": 2,
              "system:index": "1158"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.06877136230469, 33.14956718464493]),
            {
              "class": 2,
              "system:index": "1159"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93281555175781, 33.30235485080225]),
            {
              "class": 2,
              "system:index": "1160"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98088073730469, 33.34309137011572]),
            {
              "class": 2,
              "system:index": "1161"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.591552734375, 33.30579811008309]),
            {
              "class": 2,
              "system:index": "1162"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.61421203613281, 32.76181393205765]),
            {
              "class": 2,
              "system:index": "1163"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.56546020507812, 32.6722690164961]),
            {
              "class": 2,
              "system:index": "1164"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70004272460938, 32.65145862711125]),
            {
              "class": 2,
              "system:index": "1165"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.25921630859375, 33.19841932175855]),
            {
              "class": 2,
              "system:index": "1166"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35671997070312, 33.23001501396103]),
            {
              "class": 2,
              "system:index": "1167"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.25578308105469, 33.32530734451983]),
            {
              "class": 2,
              "system:index": "1168"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30178833007812, 33.086881672725006]),
            {
              "class": 2,
              "system:index": "1169"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.36839294433594, 33.0247271529072]),
            {
              "class": 2,
              "system:index": "1170"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.37525939941406, 32.970593999788164]),
            {
              "class": 2,
              "system:index": "1171"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40959167480469, 33.1754334727431]),
            {
              "class": 2,
              "system:index": "1172"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38418579101562, 33.25872846899935]),
            {
              "class": 2,
              "system:index": "1173"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.73599243164062, 33.46404096073092]),
            {
              "class": 2,
              "system:index": "1174"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.70166015625, 33.31842223093008]),
            {
              "class": 2,
              "system:index": "1175"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57257080078125, 33.42164179329464]),
            {
              "class": 2,
              "system:index": "1176"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45172119140625, 33.44112506505502]),
            {
              "class": 2,
              "system:index": "1177"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4874267578125, 33.62199545887287]),
            {
              "class": 2,
              "system:index": "1178"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.77650451660156, 33.24666996673916]),
            {
              "class": 2,
              "system:index": "1179"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.70166015625, 33.178307033694054]),
            {
              "class": 2,
              "system:index": "1180"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.78817749023438, 33.12369326750269]),
            {
              "class": 2,
              "system:index": "1181"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8719482421875, 33.292598211283696]),
            {
              "class": 2,
              "system:index": "1182"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81015014648438, 33.49783085112312]),
            {
              "class": 2,
              "system:index": "1183"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.910400390625, 33.55964937364407]),
            {
              "class": 2,
              "system:index": "1184"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.71470642089844, 33.62313900271035]),
            {
              "class": 2,
              "system:index": "1185"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.63436889648438, 33.79050406415959]),
            {
              "class": 2,
              "system:index": "1186"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.74354553222656, 33.79050406415959]),
            {
              "class": 2,
              "system:index": "1187"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.38648986816406, 33.78422662848051]),
            {
              "class": 2,
              "system:index": "1188"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40090942382812, 33.304076497436]),
            {
              "class": 2,
              "system:index": "1189"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36726379394531, 33.20473937277394]),
            {
              "class": 2,
              "system:index": "1190"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.2567138671875, 33.30005926909067]),
            {
              "class": 2,
              "system:index": "1191"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.16058349609375, 33.25815429234063]),
            {
              "class": 2,
              "system:index": "1192"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.38168334960938, 33.077101001125094]),
            {
              "class": 2,
              "system:index": "1193"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.43867492675781, 32.96886579916958]),
            {
              "class": 2,
              "system:index": "1194"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.51763916015625, 32.91181621551082]),
            {
              "class": 2,
              "system:index": "1195"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47506713867188, 32.85357620415167]),
            {
              "class": 2,
              "system:index": "1196"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30340576171875, 32.79760671486897]),
            {
              "class": 2,
              "system:index": "1197"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30546569824219, 32.889908623174584]),
            {
              "class": 2,
              "system:index": "1198"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47850036621094, 32.73929174135897]),
            {
              "class": 2,
              "system:index": "1199"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40846252441406, 32.71040880920785]),
            {
              "class": 2,
              "system:index": "1200"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17774963378906, 32.92103884347887]),
            {
              "class": 2,
              "system:index": "1201"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.24229431152344, 33.11794247239917]),
            {
              "class": 2,
              "system:index": "1202"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.17225646972656, 33.182329860722845]),
            {
              "class": 2,
              "system:index": "1203"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.06376647949219, 33.34366498790975]),
            {
              "class": 2,
              "system:index": "1204"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.91819763183594, 33.181755182455]),
            {
              "class": 2,
              "system:index": "1205"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.9820556640625, 32.79876108101308]),
            {
              "class": 2,
              "system:index": "1206"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.119384765625, 32.578584123801086]),
            {
              "class": 2,
              "system:index": "1207"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.22581481933594, 32.45641553773014]),
            {
              "class": 2,
              "system:index": "1208"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.33636474609375, 32.461050549889606]),
            {
              "class": 2,
              "system:index": "1209"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.57600402832031, 32.460471186412384]),
            {
              "class": 2,
              "system:index": "1210"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6522216796875, 32.32247677117433]),
            {
              "class": 2,
              "system:index": "1211"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.66526794433594, 32.151141018317645]),
            {
              "class": 2,
              "system:index": "1212"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.76345825195312, 32.21680949844539]),
            {
              "class": 2,
              "system:index": "1213"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.92893981933594, 32.26036860935617]),
            {
              "class": 2,
              "system:index": "1214"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.91314697265625, 32.23830127002243]),
            {
              "class": 2,
              "system:index": "1215"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.68998718261719, 32.338142199805304]),
            {
              "class": 2,
              "system:index": "1216"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.49429321289062, 32.36424522226677]),
            {
              "class": 2,
              "system:index": "1217"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.48811340332031, 32.036543852989766]),
            {
              "class": 2,
              "system:index": "1218"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.51832580566406, 32.106947976343626]),
            {
              "class": 2,
              "system:index": "1219"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.79779052734375, 31.89848794796282]),
            {
              "class": 2,
              "system:index": "1220"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.83349609375, 31.712338573918164]),
            {
              "class": 2,
              "system:index": "1221"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.73873901367188, 31.63870925964232]),
            {
              "class": 2,
              "system:index": "1222"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36039733886719, 31.708833740210977]),
            {
              "class": 2,
              "system:index": "1223"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.30271911621094, 31.874000701212047]),
            {
              "class": 2,
              "system:index": "1224"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.97381591796875, 32.09298783241451]),
            {
              "class": 2,
              "system:index": "1225"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.09878540039062, 32.27604477549895]),
            {
              "class": 2,
              "system:index": "1226"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.13169860839844, 31.71350682238293]),
            {
              "class": 2,
              "system:index": "1227"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.79386901855469, 31.749131328353094]),
            {
              "class": 2,
              "system:index": "1228"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63319396972656, 31.757305511675895]),
            {
              "class": 2,
              "system:index": "1229"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.54667663574219, 31.828507118322417]),
            {
              "class": 2,
              "system:index": "1230"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.71009826660156, 31.832007421355407]),
            {
              "class": 2,
              "system:index": "1231"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89686584472656, 31.922968682669605]),
            {
              "class": 2,
              "system:index": "1232"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.05136108398438, 31.63227853342568]),
            {
              "class": 2,
              "system:index": "1233"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07402038574219, 31.491275673602402]),
            {
              "class": 2,
              "system:index": "1234"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51852416992188, 31.559170877316106]),
            {
              "class": 2,
              "system:index": "1235"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35853576660156, 31.596609165472294]),
            {
              "class": 2,
              "system:index": "1236"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41690063476562, 31.5661917016413]),
            {
              "class": 2,
              "system:index": "1237"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29673767089844, 31.797582010859802]),
            {
              "class": 2,
              "system:index": "1238"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18275451660156, 31.850673462057518]),
            {
              "class": 2,
              "system:index": "1239"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.734130859375, 32.01733332313614]),
            {
              "class": 2,
              "system:index": "1240"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.68949890136719, 31.98996591746462]),
            {
              "class": 2,
              "system:index": "1241"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.42445373535156, 32.02199079124651]),
            {
              "class": 2,
              "system:index": "1242"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51165771484375, 31.922968682669605]),
            {
              "class": 2,
              "system:index": "1243"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98544311523438, 32.016168919116446]),
            {
              "class": 2,
              "system:index": "1244"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.34661865234375, 32.04643861398601]),
            {
              "class": 2,
              "system:index": "1245"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.30335998535156, 32.08542519696996]),
            {
              "class": 2,
              "system:index": "1246"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.53843688964844, 32.11160088346924]),
            {
              "class": 2,
              "system:index": "1247"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.34205627441406, 32.09240611344877]),
            {
              "class": 2,
              "system:index": "1248"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20335388183594, 32.08251632437186]),
            {
              "class": 2,
              "system:index": "1249"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29055786132812, 31.897322036237455]),
            {
              "class": 2,
              "system:index": "1250"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24935913085938, 31.950356066128595]),
            {
              "class": 2,
              "system:index": "1251"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18663024902344, 31.617076867706647]),
            {
              "class": 2,
              "system:index": "1252"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.35417175292969, 31.571456973044093]),
            {
              "class": 2,
              "system:index": "1253"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2724609375, 31.811587115893914]),
            {
              "class": 2,
              "system:index": "1254"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.44000244140625, 31.830257286431753]),
            {
              "class": 2,
              "system:index": "1255"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.547119140625, 31.76314377213888]),
            {
              "class": 2,
              "system:index": "1256"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98544311523438, 31.85825546224665]),
            {
              "class": 2,
              "system:index": "1257"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03694152832031, 31.961425245071162]),
            {
              "class": 2,
              "system:index": "1258"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07127380371094, 32.0650611447472]),
            {
              "class": 2,
              "system:index": "1259"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.83094787597656, 32.02839442330369]),
            {
              "class": 2,
              "system:index": "1260"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.79867553710938, 32.11683512054846]),
            {
              "class": 2,
              "system:index": "1261"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73275756835938, 31.69013905681802]),
            {
              "class": 2,
              "system:index": "1262"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35372924804688, 31.563266422399195]),
            {
              "class": 2,
              "system:index": "1263"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.34136962890625, 31.415713604194732]),
            {
              "class": 2,
              "system:index": "1264"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40316772460938, 31.76314377213888]),
            {
              "class": 2,
              "system:index": "1265"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21914672851562, 31.931710223512635]),
            {
              "class": 2,
              "system:index": "1266"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58100891113281, 32.0819345387424]),
            {
              "class": 2,
              "system:index": "1267"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58650207519531, 32.12613968981965]),
            {
              "class": 2,
              "system:index": "1268"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45123291015625, 31.868752587084114]),
            {
              "class": 2,
              "system:index": "1269"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51371765136719, 31.964337965171403]),
            {
              "class": 2,
              "system:index": "1270"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45466613769531, 31.97482299246843]),
            {
              "class": 2,
              "system:index": "1271"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96003723144531, 32.16392974499771]),
            {
              "class": 2,
              "system:index": "1272"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66409301757812, 32.21739042395355]),
            {
              "class": 2,
              "system:index": "1273"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82888793945312, 32.26965851619532]),
            {
              "class": 2,
              "system:index": "1274"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03900146484375, 32.294620428112786]),
            {
              "class": 2,
              "system:index": "1275"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98887634277344, 32.056914253937855]),
            {
              "class": 2,
              "system:index": "1276"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20791625976562, 32.15637298705275]),
            {
              "class": 2,
              "system:index": "1277"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.59062194824219, 32.1697422092731]),
            {
              "class": 2,
              "system:index": "1278"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35716247558594, 32.141257591367705]),
            {
              "class": 2,
              "system:index": "1279"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22944641113281, 32.21971408886955]),
            {
              "class": 2,
              "system:index": "1280"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00216674804688, 32.19647476761276]),
            {
              "class": 2,
              "system:index": "1281"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85934448242188, 32.050512616466285]),
            {
              "class": 2,
              "system:index": "1282"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.17863464355469, 32.06389734762631]),
            {
              "class": 2,
              "system:index": "1283"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8936767578125, 31.864087345844514]),
            {
              "class": 2,
              "system:index": "1284"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.0914306640625, 31.816838482922414]),
            {
              "class": 2,
              "system:index": "1285"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9046630859375, 31.703576241284644]),
            {
              "class": 2,
              "system:index": "1286"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9815673828125, 31.648062249414554]),
            {
              "class": 2,
              "system:index": "1287"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.855224609375, 31.822672984963116]),
            {
              "class": 2,
              "system:index": "1288"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.59817504882812, 32.29403999656675]),
            {
              "class": 2,
              "system:index": "1289"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51371765136719, 32.46858193596025]),
            {
              "class": 2,
              "system:index": "1290"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41690063476562, 32.48364281840714]),
            {
              "class": 2,
              "system:index": "1291"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.28300476074219, 32.584948546198824]),
            {
              "class": 2,
              "system:index": "1292"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.09005737304688, 32.525915669186276]),
            {
              "class": 2,
              "system:index": "1293"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00559997558594, 32.443088549403335]),
            {
              "class": 2,
              "system:index": "1294"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.89573669433594, 32.606931255920365]),
            {
              "class": 2,
              "system:index": "1295"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.68768310546875, 32.51781008740997]),
            {
              "class": 2,
              "system:index": "1296"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63893127441406, 32.556594461535354]),
            {
              "class": 2,
              "system:index": "1297"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.67257690429688, 32.360765254521034]),
            {
              "class": 2,
              "system:index": "1298"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.68287658691406, 32.26965851619532]),
            {
              "class": 2,
              "system:index": "1299"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93119549751282, 32.379018243227584]),
            {
              "class": 2,
              "system:index": "1300"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93586254119873, 32.387353758354166]),
            {
              "class": 2,
              "system:index": "1301"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94027209281921, 32.37352725553609]),
            {
              "class": 2,
              "system:index": "1302"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92276263237, 32.36546232998132]),
            {
              "class": 2,
              "system:index": "1303"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91893243789673, 32.357768263071335]),
            {
              "class": 2,
              "system:index": "1304"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.91998386383057, 32.351695922398754]),
            {
              "class": 2,
              "system:index": "1305"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92023062705994, 32.34516996724482]),
            {
              "class": 2,
              "system:index": "1306"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.89907836914062, 32.831135000359815]),
            {
              "class": 2,
              "system:index": "1307"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.99864196777344, 32.92801287395168]),
            {
              "class": 2,
              "system:index": "1308"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.06867980957031, 32.7999732056984]),
            {
              "class": 2,
              "system:index": "1309"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.02610778808594, 32.488334404292736]),
            {
              "class": 2,
              "system:index": "1310"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80500793457031, 32.466322642847096]),
            {
              "class": 2,
              "system:index": "1311"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.74526977539062, 32.431556273661045]),
            {
              "class": 2,
              "system:index": "1312"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.75213623046875, 32.4048929758226]),
            {
              "class": 2,
              "system:index": "1313"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.81118774414062, 32.33820027152775]),
            {
              "class": 2,
              "system:index": "1314"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.75144958496094, 32.68215231030691]),
            {
              "class": 2,
              "system:index": "1315"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80294799804688, 32.70237774863286]),
            {
              "class": 2,
              "system:index": "1316"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.82835388183594, 32.75840715084112]),
            {
              "class": 2,
              "system:index": "1317"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.77891540527344, 32.81382424144306]),
            {
              "class": 2,
              "system:index": "1318"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.9581298828125, 33.0535654565654]),
            {
              "class": 2,
              "system:index": "1319"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.92723083496094, 33.0909662756286]),
            {
              "class": 2,
              "system:index": "1320"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.93821716308594, 32.839212199942395]),
            {
              "class": 2,
              "system:index": "1321"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.03160095214844, 32.85940198367639]),
            {
              "class": 2,
              "system:index": "1322"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.94508361816406, 32.72548692347244]),
            {
              "class": 2,
              "system:index": "1323"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.99246215820312, 32.70468893551646]),
            {
              "class": 2,
              "system:index": "1324"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80363464355469, 32.602361666817515]),
            {
              "class": 2,
              "system:index": "1325"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.74458312988281, 32.61682177211042]),
            {
              "class": 2,
              "system:index": "1326"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.61343383789062, 32.633592568907]),
            {
              "class": 2,
              "system:index": "1327"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.61480712890625, 32.56359707439351]),
            {
              "class": 2,
              "system:index": "1328"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.95538330078125, 32.80112754111693]),
            {
              "class": 2,
              "system:index": "1329"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.90731811523438, 33.014997208199034]),
            {
              "class": 2,
              "system:index": "1330"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.150390625, 32.72490926707168]),
            {
              "class": 2,
              "system:index": "1331"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.92242431640625, 32.54391908027477]),
            {
              "class": 2,
              "system:index": "1332"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.82698059082031, 32.41880524478671]),
            {
              "class": 2,
              "system:index": "1333"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79127502441406, 32.11282228909441]),
            {
              "class": 2,
              "system:index": "1334"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.73977661132812, 32.23255132369509]),
            {
              "class": 2,
              "system:index": "1335"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.75831604003906, 32.3115094150107]),
            {
              "class": 2,
              "system:index": "1336"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.89083862304688, 32.300482635077685]),
            {
              "class": 2,
              "system:index": "1337"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.82080078125, 32.297000215277286]),
            {
              "class": 2,
              "system:index": "1338"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.68621826171875, 32.36488325846306]),
            {
              "class": 2,
              "system:index": "1339"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6724853515625, 32.411849378403595]),
            {
              "class": 2,
              "system:index": "1340"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.77685546875, 32.09013743090249]),
            {
              "class": 2,
              "system:index": "1341"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.92311096191406, 32.08781046022499]),
            {
              "class": 2,
              "system:index": "1342"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.31748962402344, 32.03310959573873]),
            {
              "class": 2,
              "system:index": "1343"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.33328247070312, 32.31034876452581]),
            {
              "class": 2,
              "system:index": "1344"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29277038574219, 32.45705292262463]),
            {
              "class": 2,
              "system:index": "1345"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.21586608886719, 32.3236953472848]),
            {
              "class": 2,
              "system:index": "1346"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29551696777344, 32.272561417059165]),
            {
              "class": 2,
              "system:index": "1347"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.13827514648438, 32.36772505606795]),
            {
              "class": 2,
              "system:index": "1348"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.26255798339844, 32.04120034432912]),
            {
              "class": 2,
              "system:index": "1349"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.21174621582031, 32.02548373695413]),
            {
              "class": 2,
              "system:index": "1350"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.172607421875, 32.09007920054763]),
            {
              "class": 2,
              "system:index": "1351"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.55300903320312, 31.970163128182183]),
            {
              "class": 2,
              "system:index": "1352"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.59626770019531, 31.964920498104213]),
            {
              "class": 2,
              "system:index": "1353"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.55644226074219, 31.949773440811793]),
            {
              "class": 2,
              "system:index": "1354"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.47610473632812, 32.005106343006595]),
            {
              "class": 2,
              "system:index": "1355"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.699951171875, 31.966085552882248]),
            {
              "class": 2,
              "system:index": "1356"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.51112365722656, 32.131373093124246]),
            {
              "class": 2,
              "system:index": "1357"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.56948852539062, 32.20228515456695]),
            {
              "class": 2,
              "system:index": "1358"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.952880859375, 32.23772047815561]),
            {
              "class": 2,
              "system:index": "1359"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.96180725097656, 32.15462903084364]),
            {
              "class": 2,
              "system:index": "1360"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.9803466796875, 32.14765287232118]),
            {
              "class": 2,
              "system:index": "1361"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.85331726074219, 32.04643861398601]),
            {
              "class": 2,
              "system:index": "1362"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.89451599121094, 32.03421551851058]),
            {
              "class": 2,
              "system:index": "1363"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.81005859375, 32.21680949844539]),
            {
              "class": 2,
              "system:index": "1364"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.82859802246094, 32.245270482805914]),
            {
              "class": 2,
              "system:index": "1365"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.03665161132812, 32.50043852189759]),
            {
              "class": 2,
              "system:index": "1366"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.39738464355469, 32.15521035328777]),
            {
              "class": 2,
              "system:index": "1367"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.44064331054688, 32.0860069603795]),
            {
              "class": 2,
              "system:index": "1368"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.48458862304688, 32.10578471251395]),
            {
              "class": 2,
              "system:index": "1369"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.25387573242188, 32.44366802466207]),
            {
              "class": 2,
              "system:index": "1370"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.48733520507812, 32.36018524687488]),
            {
              "class": 2,
              "system:index": "1371"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.34691619873047, 32.40400888044343]),
            {
              "class": 2,
              "system:index": "1372"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6947021484375, 32.21596717823171]),
            {
              "class": 2,
              "system:index": "1373"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.58174896240234, 32.25168752169967]),
            {
              "class": 2,
              "system:index": "1374"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4200439453125, 32.14215880013135]),
            {
              "class": 2,
              "system:index": "1375"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.44098663330078, 32.16105246634999]),
            {
              "class": 2,
              "system:index": "1376"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.36923217773438, 32.20231423393956]),
            {
              "class": 2,
              "system:index": "1377"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.48115539550781, 32.278708052687115]),
            {
              "class": 2,
              "system:index": "1378"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.40579605102539, 32.26709667865111]),
            {
              "class": 2,
              "system:index": "1379"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.42055892944336, 32.240021893762034]),
            {
              "class": 2,
              "system:index": "1380"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.42493629455566, 32.26107269302459]),
            {
              "class": 2,
              "system:index": "1381"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4365234375, 32.25831459027339]),
            {
              "class": 2,
              "system:index": "1382"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3222827911377, 32.26172591561213]),
            {
              "class": 2,
              "system:index": "1383"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3072624206543, 32.254903136738]),
            {
              "class": 2,
              "system:index": "1384"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.30134010314941, 32.25591932779221]),
            {
              "class": 2,
              "system:index": "1385"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.29936599731445, 32.311211992656894]),
            {
              "class": 2,
              "system:index": "1386"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3292350769043, 32.314113563339596]),
            {
              "class": 2,
              "system:index": "1387"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.32382774353027, 32.35436326360582]),
            {
              "class": 2,
              "system:index": "1388"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38888740539551, 32.34493701118314]),
            {
              "class": 2,
              "system:index": "1389"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.34442710876465, 32.38270860941943]),
            {
              "class": 2,
              "system:index": "1390"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3541259765625, 32.411262445570976]),
            {
              "class": 2,
              "system:index": "1391"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.22821235656738, 32.420319516707956]),
            {
              "class": 2,
              "system:index": "1392"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2303581237793, 32.441183547751656]),
            {
              "class": 2,
              "system:index": "1393"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.25756645202637, 32.45175860829869]),
            {
              "class": 2,
              "system:index": "1394"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.23979949951172, 32.3922758750446]),
            {
              "class": 2,
              "system:index": "1395"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26820945739746, 32.38944928839858]),
            {
              "class": 2,
              "system:index": "1396"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.18014717102051, 32.34493701118314]),
            {
              "class": 2,
              "system:index": "1397"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.16083526611328, 32.36516599088368]),
            {
              "class": 2,
              "system:index": "1398"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28812217712402, 32.31382341045354]),
            {
              "class": 2,
              "system:index": "1399"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.17903137207031, 32.25139716902659]),
            {
              "class": 2,
              "system:index": "1400"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1347427368164, 32.365434208865814]),
            {
              "class": 2,
              "system:index": "1401"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.08667755126953, 32.398776667366874]),
            {
              "class": 2,
              "system:index": "1402"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.96617126464844, 32.330628962698604]),
            {
              "class": 2,
              "system:index": "1403"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.01011657714844, 32.4048639613834]),
            {
              "class": 2,
              "system:index": "1404"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.20821380615234, 32.460210499921274]),
            {
              "class": 2,
              "system:index": "1405"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.29679107666016, 32.49149088462503]),
            {
              "class": 2,
              "system:index": "1406"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.35481262207031, 32.479327582175806]),
            {
              "class": 2,
              "system:index": "1407"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.34382629394531, 32.47266602943626]),
            {
              "class": 2,
              "system:index": "1408"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28202819824219, 32.18255741086168]),
            {
              "class": 2,
              "system:index": "1409"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2061538696289, 32.19766595554568]),
            {
              "class": 2,
              "system:index": "1410"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31078147888184, 32.077840167359184]),
            {
              "class": 2,
              "system:index": "1411"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.34253883361816, 32.077840167359184]),
            {
              "class": 2,
              "system:index": "1412"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.88799285888672, 32.253139271138394]),
            {
              "class": 2,
              "system:index": "1413"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.96283721923828, 32.320765042114104]),
            {
              "class": 2,
              "system:index": "1414"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.95940399169922, 32.3593442575006]),
            {
              "class": 2,
              "system:index": "1415"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.93022155761719, 32.311770530984624]),
            {
              "class": 2,
              "system:index": "1416"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.52598571777344, 33.14010974308566]),
            {
              "class": 2,
              "system:index": "1417"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60289001464844, 33.237510163374225]),
            {
              "class": 2,
              "system:index": "1418"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.66331481933594, 33.04835682293315]),
            {
              "class": 2,
              "system:index": "1419"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.6670913696289, 33.0756913721743]),
            {
              "class": 2,
              "system:index": "1420"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46727752685547, 33.03454245461793]),
            {
              "class": 2,
              "system:index": "1421"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.47071075439453, 32.98329526479892]),
            {
              "class": 2,
              "system:index": "1422"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.52255249023438, 32.99366226696715]),
            {
              "class": 2,
              "system:index": "1423"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.41268920898438, 33.035693734720624]),
            {
              "class": 2,
              "system:index": "1424"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.381103515625, 33.06878660324987]),
            {
              "class": 2,
              "system:index": "1425"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.29149627685547, 33.06907431277336]),
            {
              "class": 2,
              "system:index": "1426"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.07588958740234, 33.18436996619126]),
            {
              "class": 2,
              "system:index": "1427"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.0683364868164, 33.12918495334972]),
            {
              "class": 2,
              "system:index": "1428"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68151092529297, 32.989054860771205]),
            {
              "class": 2,
              "system:index": "1429"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.63104248046875, 32.98819094533243]),
            {
              "class": 2,
              "system:index": "1430"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.6554183959961, 33.01093789778858]),
            {
              "class": 2,
              "system:index": "1431"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.66434478759766, 32.87609835444746]),
            {
              "class": 2,
              "system:index": "1432"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.65438842773438, 32.86023832551353]),
            {
              "class": 2,
              "system:index": "1433"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.6451187133789, 32.938357557354706]),
            {
              "class": 2,
              "system:index": "1434"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.65267181396484, 32.81754634632573]),
            {
              "class": 2,
              "system:index": "1435"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68048095703125, 32.83601026220441]),
            {
              "class": 2,
              "system:index": "1436"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.52598571777344, 32.83716412948896]),
            {
              "class": 2,
              "system:index": "1437"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.622802734375, 32.90463925668853]),
            {
              "class": 2,
              "system:index": "1438"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68391418457031, 32.96399788048109]),
            {
              "class": 2,
              "system:index": "1439"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.62657928466797, 33.02216524350748]),
            {
              "class": 2,
              "system:index": "1440"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60941314697266, 33.06849889278566]),
            {
              "class": 2,
              "system:index": "1441"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68494415283203, 33.10761887868894]),
            {
              "class": 2,
              "system:index": "1442"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46109771728516, 33.11509571757079]),
            {
              "class": 2,
              "system:index": "1443"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.48830604553223, 33.10728098912099]),
            {
              "class": 2,
              "system:index": "1444"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46229934692383, 33.082904868207855]),
            {
              "class": 2,
              "system:index": "1445"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46118354797363, 33.07024674920671]),
            {
              "class": 2,
              "system:index": "1446"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.47088241577148, 33.07873364384397]),
            {
              "class": 2,
              "system:index": "1447"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.4510555267334, 33.094123041771674]),
            {
              "class": 2,
              "system:index": "1448"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.4594669342041, 33.050105079329896]),
            {
              "class": 2,
              "system:index": "1449"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.45551872253418, 33.0578026186837]),
            {
              "class": 2,
              "system:index": "1450"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.44642066955566, 33.02945508543793]),
            {
              "class": 2,
              "system:index": "1451"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.59877014160156, 33.23231250755892]),
            {
              "class": 2,
              "system:index": "1452"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69490051269531, 33.3276023315401]),
            {
              "class": 2,
              "system:index": "1453"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.70657348632812, 33.36431278173219]),
            {
              "class": 2,
              "system:index": "1454"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.04808044433594, 33.68258243214168]),
            {
              "class": 2,
              "system:index": "1455"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.05288696289062, 33.54820490358907]),
            {
              "class": 2,
              "system:index": "1456"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.84689331054688, 33.283988575619134]),
            {
              "class": 2,
              "system:index": "1457"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.85444641113281, 33.3000593391472]),
            {
              "class": 2,
              "system:index": "1458"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.85856628417969, 33.36087183456589]),
            {
              "class": 2,
              "system:index": "1459"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.85650634765625, 33.45544827942742]),
            {
              "class": 2,
              "system:index": "1460"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.88534545898438, 33.512717196654364]),
            {
              "class": 2,
              "system:index": "1461"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.82904052734375, 33.5876821575234]),
            {
              "class": 2,
              "system:index": "1462"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.78921508789062, 33.57395298606109]),
            {
              "class": 2,
              "system:index": "1463"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.82766723632812, 33.53847585268269]),
            {
              "class": 2,
              "system:index": "1464"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.77273559570312, 33.54190976041825]),
            {
              "class": 2,
              "system:index": "1465"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80569458007812, 33.47263293017821]),
            {
              "class": 2,
              "system:index": "1466"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.43971252441406, 33.62599786569771]),
            {
              "class": 2,
              "system:index": "1467"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4088134765625, 33.65458057964155]),
            {
              "class": 2,
              "system:index": "1468"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.25775146484375, 33.68848164909642]),
            {
              "class": 2,
              "system:index": "1469"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.28659057617188, 33.71400222174381]),
            {
              "class": 2,
              "system:index": "1470"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.45001220703125, 33.60083723045299]),
            {
              "class": 2,
              "system:index": "1471"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.28041076660156, 33.42221494559324]),
            {
              "class": 2,
              "system:index": "1472"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.44245910644531, 33.36545971638256]),
            {
              "class": 2,
              "system:index": "1473"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80294799804688, 33.766533249935456]),
            {
              "class": 2,
              "system:index": "1474"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.93341064453125, 33.85553408697566]),
            {
              "class": 2,
              "system:index": "1475"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.10026550292969, 34.021876262532814]),
            {
              "class": 2,
              "system:index": "1476"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.16343688964844, 33.626569595504606]),
            {
              "class": 2,
              "system:index": "1477"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.43672180175781, 33.702006930863206]),
            {
              "class": 2,
              "system:index": "1478"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65325927734375, 34.36588406794246]),
            {
              "class": 2,
              "system:index": "1479"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58734130859375, 34.352279970990956]),
            {
              "class": 2,
              "system:index": "1480"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.77410888671875, 34.02056734507911]),
            {
              "class": 2,
              "system:index": "1481"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.25250244140625, 32.31243791052451]),
            {
              "class": 2,
              "system:index": "1482"
            })]),
    prev = ee.Image("users/images/SPrairies_2010_v1"),
    input = ee.Image("users/images/input/SPrairies_2010_InputSR"),
    cdl = ee.Image("users/images/reference/CDL_composite_08_12_wo_fallow"),
    change = ee.Image("users/images/NA_2010_2010_change_v1_asset"),
    NonCropClass2 = /* color: #d63000 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-98.48304390907288, 32.53666587697051]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.48673462867737, 32.57600317611073]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.24520969390869, 32.975588245827]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2613673210144, 33.009511315489405]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18354034423828, 33.96415736366566]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18946266174316, 34.0124083695931]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16783332824707, 34.00308767054516]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.13710594177246, 33.992485021305875]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11294460296631, 34.01155045625453]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.17461395263672, 33.8829656260716]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12657022476196, 33.907129142211964]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.04964447021484, 33.95276670086537]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9882755279541, 33.99984593716435]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.88416290283203, 33.96857914252689]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87763977050781, 33.99590908868565]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81996154785156, 33.977120694619515]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.88021469116211, 33.93981627791793]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.86356353759766, 33.95718907181347]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78949165344238, 33.94165933641658]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7702226638794, 33.9423672356478]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.76485824584961, 33.746903304463586]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75344276428223, 33.77544582701344]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78777503967285, 33.78800152546045]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.76957893371582, 33.80690293973455]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.56573104858398, 33.652653917321736]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58083724975586, 33.64465153471107]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55955123901367, 33.59932996848721]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57311248779297, 33.58495912884243]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52848052978516, 33.628350331479375]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.3804549574852, 33.711632102975145]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-95.12987226247787, 33.47442886616599]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.47423297166824, 31.622114845380068]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45787954330444, 31.50679938808967]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45966857671738, 31.508223782288205]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46818459033966, 31.509195916228006]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.5538302063942, 31.411970393342997]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26348102092743, 29.407633750327918]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26164907217026, 29.412696768272575]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.37280786037445, 29.30266153888733]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38715767860413, 29.284219656198204]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.49638795852661, 29.28520330557202]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.53349900245667, 29.337657045022027]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5341708958149, 29.31928780499693]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.67329847812653, 30.0464131010147]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.42751693725586, 30.259165048383238]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.46858155727386, 30.26890890463856]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.49066686630249, 30.017206336606485]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.54725074768066, 29.992031797580506]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05021858215332, 29.617257730381695]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3223340511322, 29.58802299336291]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84039735794067, 29.09243126213482]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83769905567169, 29.076751489421465]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.47939079999924, 29.129479440846122]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.48905345797539, 29.13827208797415]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96482229232788, 32.046820237494146]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96175384521484, 32.19281257687464]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84068965911865, 32.642033103142516]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89223098754883, 32.314094151513615]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62984657287598, 31.54756454238371]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60197305679321, 31.655283133561355]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60344290733337, 31.664432492666503]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74335765838623, 31.42662210691092]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.88218879699707, 31.396984265968737]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18963432312012, 31.790073813886913]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.17784333229065, 31.678713390532945]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.09157276153564, 31.76902398446731]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0234124660492, 31.40332940803032]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01598811149597, 31.36521822568588]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96448969841003, 31.429332484387317]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91735792160034, 31.481272323809186]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92692804336548, 31.48789644919821]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9490294456482, 31.496587614903394]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89050364494324, 31.45494342355035]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92490029335022, 31.42236546562928]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0743637084961, 31.25306066768016]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0942120552063, 31.243372490911177]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01737213134766, 31.195553624560908]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94737720489502, 31.099140896166276]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.95862102508545, 31.112881259535644]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94212007522583, 31.11987009867543]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91995429992676, 31.06227617671024]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3973822593689, 28.94756750002503]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44699776172638, 28.87664504831983]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35839366912842, 28.920894379267413]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24226474761963, 28.97642563353384]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26638317108154, 28.993315393212416]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.83618366718292, 29.67665365954985]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94914221763611, 29.630156789478196]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00193881988525, 29.676159615108606]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.02983379364014, 29.449763841017287]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.95745706558228, 29.567598046999297]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96351885795593, 29.457993460404197]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.63609886169434, 28.73127990817649]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70262837409973, 28.689487589170508]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28084564208984, 28.472632330178506]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28513717651367, 28.554538183878183]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20273971557617, 28.537196950424505]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.31311798095703, 28.60066703227084]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38452911376953, 28.583484139535347]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29878425598145, 28.63840551724557]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39757537841797, 28.60299429190185]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4183464050293, 28.582947754514745]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44950294494629, 28.62296166408659]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.47465133666992, 28.674704056023838]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.45830059051514, 28.699965584717738]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39813327789307, 28.728306955848932]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40530014038086, 28.765180634325926]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4453616142273, 28.770557888618992]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40976333618164, 28.42809921778365]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.36847877502441, 28.41896564539698]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.35028266906738, 28.45866453135384]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40167379379272, 28.527548383351093]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.83654308319092, 30.21291054469857]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81564331054688, 30.23868178907641]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.79411053657532, 30.288523952458586]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.90428495407104, 30.306579513572387]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.92001342773438, 30.26785416911425]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.00050115585327, 30.18926336112956]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.12409973144531, 32.086098996829584]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.08187103271484, 32.15995276135309]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14675903320312, 32.153558343279485]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.27035522460938, 32.151523661626335]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.37266540527344, 32.102968507564995]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31876373291016, 32.00083129133003]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.18315124511719, 31.998210889773876]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.15259552001953, 31.96413885638791]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14641571044922, 32.25958949314203]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95209503173828, 32.13640746189499]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9253158569336, 32.09278900310654]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92497253417969, 31.92335228073537]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.81819915771484, 31.86155530576323]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92085266113281, 31.800884024152182]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.97338104248047, 31.744260458306186]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02384948730469, 31.736961086583914]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73099517822266, 31.818389448051985]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.68670654296875, 32.00636300424293]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.62731170654297, 32.05758826392387]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.54800415039062, 31.953070004505776]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49066925048828, 32.02906864331461]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.70318603515625, 32.08144479054686]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7495346069336, 32.12216105760576]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.48551940917969, 32.09598839817331]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.34441375732422, 32.03663593922034]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31214141845703, 32.13146508385685]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8429183959961, 32.22096779942454]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.81562423706055, 32.22734060801954]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.94351196289062, 32.194225554596066]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.00428009033203, 32.16967196808319]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.81751251220703, 32.26189520978327]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.75210952758789, 32.363160153921285]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.91329956054688, 32.380413222367515]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89081192016602, 32.43316686276787]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.898193359375, 32.35242969443858]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.68670654296875, 32.61091021530767]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69099807739258, 32.63765702039522]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5934944152832, 32.66078294568561]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.53770446777344, 32.7442754978647]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.40981674194336, 32.754526114759635]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.42904281616211, 32.66266166438728]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.51178359985352, 32.6834694452154]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4836311340332, 32.7278142936568]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31900787353516, 32.74239849659081]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.36621475219727, 32.81975589481094]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.38338088989258, 32.80691576048297]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.25566482543945, 32.86576315146573]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.24073028564453, 32.89776666408838]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.28776550292969, 32.66222811742273]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.36587142944336, 32.61177780465343]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.32484436035156, 32.62956153373921]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.19626998901367, 32.547987600463905]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.09996795654297, 32.57677836833252]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02907180786133, 32.62160989643487]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1100959777832, 32.656013713169656]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.13807678222656, 32.81124410294537]),
            {
              "class": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.04366302490234, 32.84802650118814]),
            {
              "class": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.84453582763672, 32.795083882297234]),
            {
              "class": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73982238769531, 32.89964038544274]),
            {
              "class": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6541633605957, 32.905549554673236]),
            {
              "class": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.96212387084961, 33.051280069319354]),
            {
              "class": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02598190307617, 33.12132363734348]),
            {
              "class": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.09430313110352, 33.1839845651322]),
            {
              "class": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14992141723633, 33.03170972434911]),
            {
              "class": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.24038696289062, 33.08882582242469]),
            {
              "class": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38274002075195, 32.38345768117041]),
            {
              "class": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51140022277832, 32.49703025897148]),
            {
              "class": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62649917602539, 32.50919116817633]),
            {
              "class": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81150722503662, 32.472952702447316]),
            {
              "class": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91592025756836, 32.54920920863125]),
            {
              "class": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38160276412964, 32.02716321995026]),
            {
              "class": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8939905166626, 30.742024464389313]),
            {
              "class": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92484664916992, 30.734467111354682]),
            {
              "class": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91544818878174, 30.81981988933832]),
            {
              "class": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11646366119385, 30.7177881190932]),
            {
              "class": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14242744445801, 30.716902657774927]),
            {
              "class": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.18011474609375, 32.30809542796482]),
            {
              "class": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.03935241699219, 32.56135005846137]),
            {
              "class": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.17290496826172, 32.546268277151306]),
            {
              "class": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.21856689453125, 32.37564621917569]),
            {
              "class": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.11488342285156, 32.666580568197006]),
            {
              "class": 2,
              "system:index": "198"
            })]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var zones=ee.FeatureCollection("ft:1emWmrrMBzdiKOitmcYSBmoCozs4Fpqq_f6A86pnR"); 
var zones2=ee.FeatureCollection("ft:13cK2cS_HzpvNGVZlIfH9zInVbJOMQgjXQKwgLHpL");
var countries = ee.FeatureCollection("ft:1tdSwUL7MVpOauSgRzqVTOwdfy17KDbw-1d9omPw"); 

//Map.addLayer(zones)


/*
function radians(img) {return img.toFloat().multiply(Math.PI).divide(180).divide(1.5708).toFloat();}
var terrain = ee.Algorithms.Terrain(ee.Image('USGS/SRTMGL1_003'));
var slope = radians(terrain.select('slope'));
var elevation = terrain.select('elevation').divide(4000.00).float();
*/

//input=input.select(ee.List.sequence(0,43)).addBands(slope).addBands(elevation);

//visual parameters for FCC display 
var vizParams = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  gamma: [1.5,1.6, 1.7]
};



//add all max val to map
//Map.addLayer(FCC,vizParams,'FCC');
//Map.addLayer(cdl,{palette:'ffff00'},'cdl')



//create bounds for training samples inside area of interest
function buffer(geometry) {
  return geometry.buffer(60).bounds();
} 

//buffer function of 1km********************************************************
function buffer1(geometry) {
  return geometry.buffer(10000);
}

function buffer2(geometry) {
  return geometry.buffer(10000);
}

var studyArea = zones.filterMetadata('name','equals','SPrairies');

var region= ee.FeatureCollection(countries.filterMetadata('Country','equals','United States'))
              .map(buffer2)
studyArea=buffer1(studyArea.geometry());

//----------------
var outline =ee.Image().byte().paint({
  featureCollection: ee.FeatureCollection([studyArea]),
  color: 1,
  width: 3
});
Map.addLayer(outline, {palette: '000000'}, 'edges');

Map.addLayer(change,{min:0,max:2,palette:'00ff00,ffff00,ff0000'},'prev')

//throw('stop')
//--------------------

var CropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea);
/*
var CropSamplesArea2 = Cropclass2.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea2);

var CropSamplesArea2 = Cropclass3.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea3);
*/
var NonCropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea);

var NonCropSamplesArea2 = NonCropClass2.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea2);
/*
var NonCropSamplesArea2 = NonCropClass3.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea3);
*/
//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                   // .merge(CropSamplesArea2)
                   // .merge(CropSamplesArea3)
                    .merge(NonCropSamplesArea)
                   .merge(NonCropSamplesArea2)
                  // .merge(NonCropSamplesArea3);
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);

//print(input)

var training = input.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});
 

//build classifier
var classifier = ee.Classifier.randomForest(330,5).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input.classify(classifier);

classified = classified.updateMask(classified.eq(1)).clip(studyArea).clipToCollection(region);

////Export the classified image
Export.image.toAsset({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  description: 'SPrairies_v1_asset',
  assetId: 'SPrairies_2010_v1',
  region: studyArea, 
});


Export.image.toDrive({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  folder: 'data',
  description: 'SPrairies',
  fileNamePrefix: 'SPrairies_2010_v2',
  region: studyArea, 
});
 

Export.table.toDrive({
  collection: training,
  description: 'RandomForestTrainingTable_SPrairies_v2',
  folder: 'data',
  fileNamePrefix: 'RFtable_SPrairies_2010_v2',
  fileFormat: 'CSV'
});


//print('Classified',classified);

//add layer to map
Map.addLayer(classified, {palette: '00FF00'}, 'cropland');



