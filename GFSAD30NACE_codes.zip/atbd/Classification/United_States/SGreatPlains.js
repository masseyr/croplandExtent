/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var Cropclass = /* color: #0b4a8b */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-103.34564208984375, 46.02492672704749]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.83889770507812, 45.97532050159483]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91374206542969, 45.88792463747512]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.10394287109375, 45.8788428583212]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.16299438476562, 46.02206603832763]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.55462646484375, 45.83389010905223]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.29850769042969, 45.99726720204629]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70912170410156, 45.432980478148025]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.90000915527344, 45.51291068642853]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.47360229492188, 45.49751127365729]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.94969177246094, 45.97770643399684]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.52809143066406, 45.8525451285809]),
            {
              "class": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22459411621094, 45.98104656665315]),
            {
              "class": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.88264465332031, 45.77022466719502]),
            {
              "class": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.61210632324219, 45.64219545920302]),
            {
              "class": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.03257751464844, 45.64747586225673]),
            {
              "class": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.21865844726562, 45.64315556950627]),
            {
              "class": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37727355957031, 45.56292968537373]),
            {
              "class": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37109375, 45.97532050159483]),
            {
              "class": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.46859741210938, 45.95527461077373]),
            {
              "class": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83757019042969, 45.922412156467075]),
            {
              "class": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.51141357421875, 46.00069186162333]),
            {
              "class": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.31915283203125, 46.02453562599708]),
            {
              "class": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40052032470703, 45.902347125384225]),
            {
              "class": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.77189636230469, 45.998783916387104]),
            {
              "class": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55525970458984, 45.943663619959516]),
            {
              "class": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.34617614746094, 46.003792132312036]),
            {
              "class": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.10653686523438, 46.04717768070043]),
            {
              "class": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98019409179688, 46.017621992623425]),
            {
              "class": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.74398803710938, 45.86697680098374]),
            {
              "class": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.71377563476562, 45.73509603857534]),
            {
              "class": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.2616195678711, 45.927188475609654]),
            {
              "class": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01786041259766, 46.01166126997666]),
            {
              "class": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.81770324707031, 45.763844391586396]),
            {
              "class": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6573715209961, 45.92384509538917]),
            {
              "class": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.58252716064453, 45.99663739935518]),
            {
              "class": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45584106445312, 45.89302875219796]),
            {
              "class": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.54476165771484, 45.805742531504436]),
            {
              "class": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.492919921875, 45.77629741287357]),
            {
              "class": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.68243408203125, 45.756898229731064]),
            {
              "class": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6961669921875, 45.779889113862204]),
            {
              "class": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.03571319580078, 45.8086143931498]),
            {
              "class": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.07107543945312, 45.828474049189865]),
            {
              "class": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04928517341614, 45.780264288292244]),
            {
              "class": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.07450866699219, 45.60218249281742]),
            {
              "class": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.7950439453125, 45.36798009176715]),
            {
              "class": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.64741516113281, 45.44703892221777]),
            {
              "class": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.427001953125, 45.34144168253701]),
            {
              "class": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60175323486328, 45.27262518247265]),
            {
              "class": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.70509338378906, 45.24966778357221]),
            {
              "class": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.74491882324219, 45.34481998943397]),
            {
              "class": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8609619140625, 45.18364380123935]),
            {
              "class": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.80706024169922, 45.037538942467386]),
            {
              "class": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.53377532958984, 45.195983774613616]),
            {
              "class": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88671112060547, 44.91586387396043]),
            {
              "class": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.94988250732422, 44.83630796129819]),
            {
              "class": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05322265625, 44.69468500868759]),
            {
              "class": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3659896850586, 44.755179274627096]),
            {
              "class": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51602172851562, 44.729818413403294]),
            {
              "class": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.62382507324219, 44.63559333063253]),
            {
              "class": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.77729034423828, 44.59282421665493]),
            {
              "class": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.54932403564453, 44.532405064508715]),
            {
              "class": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30213165283203, 44.53852321736826]),
            {
              "class": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28771209716797, 44.6111576938828]),
            {
              "class": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.97254180908203, 44.545374785438035]),
            {
              "class": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.72740936279297, 44.57693052333347]),
            {
              "class": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.67797088623047, 44.72152494959243]),
            {
              "class": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40228271484375, 44.86527223138224]),
            {
              "class": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.74835205078125, 44.89300585445523]),
            {
              "class": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52450561523438, 45.008904185885065]),
            {
              "class": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.60518646240234, 45.117785425707005]),
            {
              "class": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.75899505615234, 45.14491279659656]),
            {
              "class": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85787200927734, 45.28663671488426]),
            {
              "class": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.99520111083984, 45.44005342372823]),
            {
              "class": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.97185516357422, 45.63484031850827]),
            {
              "class": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.8063735961914, 45.738930007827086]),
            {
              "class": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.91383361816406, 45.989243203333345]),
            {
              "class": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.15965270996094, 45.952973492977875]),
            {
              "class": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30384826660156, 45.9954448539133]),
            {
              "class": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51190185546875, 45.91906848838407]),
            {
              "class": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23651123046875, 44.616202204405944]),
            {
              "class": 1,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.82795715332031, 44.80358775457754]),
            {
              "class": 1,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14999389648438, 44.90775290112518]),
            {
              "class": 1,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90348815917969, 45.08837656782492]),
            {
              "class": 1,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.58076477050781, 45.2983845592322]),
            {
              "class": 1,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.19737243652344, 45.48271883430667]),
            {
              "class": 1,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23839950561523, 45.46297699705332]),
            {
              "class": 1,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01953125, 45.56197759072022]),
            {
              "class": 1,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.08750915527344, 45.583967421890634]),
            {
              "class": 1,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.2725601196289, 45.59814209144038]),
            {
              "class": 1,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.09300231933594, 45.69150920301081]),
            {
              "class": 1,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00905990600586, 45.73334183499101]),
            {
              "class": 1,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.10536193847656, 45.80375121238874]),
            {
              "class": 1,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14965057373047, 45.86570488720109]),
            {
              "class": 1,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23702621459961, 45.89378854189473]),
            {
              "class": 1,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.97740173339844, 45.994490799055896]),
            {
              "class": 1,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.82633972167969, 45.99735291428439]),
            {
              "class": 1,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.89946746826172, 45.87510440855953]),
            {
              "class": 1,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22905731201172, 45.409692593912865]),
            {
              "class": 1,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.33068084716797, 45.359778639599156]),
            {
              "class": 1,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23146057128906, 45.509147693493794]),
            {
              "class": 1,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.0519027709961, 45.6216354002916]),
            {
              "class": 1,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.82805633544922, 45.525506047699196]),
            {
              "class": 1,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70755004882812, 45.46197053486656]),
            {
              "class": 1,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94959259033203, 45.411861766121]),
            {
              "class": 1,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9420394897461, 45.46100732432234]),
            {
              "class": 1,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23043060302734, 45.31199361819813]),
            {
              "class": 1,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29261779785156, 45.445025410897536]),
            {
              "class": 1,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40385437011719, 45.70121163330259]),
            {
              "class": 1,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89583587646484, 45.84210850569381]),
            {
              "class": 1,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58684539794922, 45.854544043406584]),
            {
              "class": 1,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63731384277344, 45.666999278992655]),
            {
              "class": 1,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89652252197266, 45.540176407274224]),
            {
              "class": 1,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55388641357422, 45.49928227009159]),
            {
              "class": 1,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60332489013672, 45.43427166740862]),
            {
              "class": 1,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78082275390625, 45.30040329803624]),
            {
              "class": 1,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89068603515625, 45.298471347612605]),
            {
              "class": 1,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01496887207031, 45.19380632665722]),
            {
              "class": 1,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14920806884766, 45.1783198495102]),
            {
              "class": 1,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56737518310547, 45.15387168199499]),
            {
              "class": 1,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.5969009399414, 45.08797889353943]),
            {
              "class": 1,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.45476531982422, 45.00938964006162]),
            {
              "class": 1,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20242309570312, 44.96568228577233]),
            {
              "class": 1,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98269653320312, 44.85724158245591]),
            {
              "class": 1,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82854461669922, 44.71225437707906]),
            {
              "class": 1,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36849212646484, 44.86673222902233]),
            {
              "class": 1,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.19580078125, 44.8526173673691]),
            {
              "class": 1,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30394744873047, 45.00016530713494]),
            {
              "class": 1,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36471557617188, 44.98772698502732]),
            {
              "class": 1,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3932113647461, 44.97843845005409]),
            {
              "class": 1,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24901580810547, 44.808790591723714]),
            {
              "class": 1,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22601318359375, 44.670518420945754]),
            {
              "class": 1,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.41484069824219, 44.554672052383715]),
            {
              "class": 1,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18893432617188, 44.45428100433486]),
            {
              "class": 1,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4320068359375, 44.41628325818404]),
            {
              "class": 1,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52916717529297, 44.43124015835633]),
            {
              "class": 1,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.77670288085938, 44.44864419023738]),
            {
              "class": 1,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9370346069336, 44.430504662573455]),
            {
              "class": 1,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.93943786621094, 44.58108775506322]),
            {
              "class": 1,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14714813232422, 44.641700632744644]),
            {
              "class": 1,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18148040771484, 44.52506243258378]),
            {
              "class": 1,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.04895782470703, 44.50890538415223]),
            {
              "class": 1,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03316497802734, 44.59282421665493]),
            {
              "class": 1,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01737213134766, 44.7042024117775]),
            {
              "class": 1,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1519546508789, 44.798315930392924]),
            {
              "class": 1,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.00432586669922, 44.75469167067195]),
            {
              "class": 1,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.61053466796875, 44.73006232080955]),
            {
              "class": 1,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.349609375, 44.72274465119453]),
            {
              "class": 1,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40934753417969, 44.59233524473335]),
            {
              "class": 1,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24798583984375, 44.54782157862245]),
            {
              "class": 1,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.05366516113281, 44.6280193832488]),
            {
              "class": 1,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84080505371094, 44.592579731208396]),
            {
              "class": 1,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.95719146728516, 44.504742994579836]),
            {
              "class": 1,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85762786865234, 44.3077927132464]),
            {
              "class": 1,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85968780517578, 44.17916092622333]),
            {
              "class": 1,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.05023193359375, 44.20550044791675]),
            {
              "class": 1,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1082534790039, 44.30042182093681]),
            {
              "class": 1,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21640014648438, 44.10130446293759]),
            {
              "class": 1,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4261703491211, 44.04876734200178]),
            {
              "class": 1,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.48522186279297, 43.92946107692384]),
            {
              "class": 1,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30188751220703, 43.822301509861575]),
            {
              "class": 1,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25691223144531, 43.9344060543489]),
            {
              "class": 1,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.54976654052734, 43.75587987783479]),
            {
              "class": 1,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3382797241211, 43.588756889257574]),
            {
              "class": 1,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27476501464844, 43.71221954900552]),
            {
              "class": 1,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.44642639160156, 43.82799843455612]),
            {
              "class": 1,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.67919921875, 43.79133045608105]),
            {
              "class": 1,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78562927246094, 43.80867622456515]),
            {
              "class": 1,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8985824584961, 43.688639666640825]),
            {
              "class": 1,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03522491455078, 43.784638599601266]),
            {
              "class": 1,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12483215332031, 43.68988094427988]),
            {
              "class": 1,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.34696197509766, 43.684170854440396]),
            {
              "class": 1,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20036315917969, 43.90002996012072]),
            {
              "class": 1,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.23538208007812, 43.953934695538805]),
            {
              "class": 1,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.09942626953125, 44.06751833355619]),
            {
              "class": 1,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12895202636719, 44.20673097878858]),
            {
              "class": 1,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07848358154297, 44.34536986802258]),
            {
              "class": 1,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.67610931396484, 44.54243849785678]),
            {
              "class": 1,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.43406677246094, 44.678819193688355]),
            {
              "class": 1,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31047058105469, 44.24289709901912]),
            {
              "class": 1,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.54564666748047, 44.12866447531249]),
            {
              "class": 1,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.71593475341797, 44.11412334317301]),
            {
              "class": 1,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89274597167969, 44.07417844050549]),
            {
              "class": 1,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1135025024414, 43.95690051017069]),
            {
              "class": 1,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82923126220703, 43.80743740810581]),
            {
              "class": 1,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63971710205078, 43.711723225992706]),
            {
              "class": 1,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40110778808594, 43.662070168247624]),
            {
              "class": 1,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.50135803222656, 43.449339977112956]),
            {
              "class": 1,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.77155303955078, 43.44360703855232]),
            {
              "class": 1,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.15779113769531, 43.47301374894633]),
            {
              "class": 1,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.23881530761719, 43.603426697937046]),
            {
              "class": 1,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16671752929688, 43.669520747096406]),
            {
              "class": 1,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.99059295654297, 43.496180146211245]),
            {
              "class": 1,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01153564453125, 43.35080753221696]),
            {
              "class": 1,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89102935791016, 43.330082874460786]),
            {
              "class": 1,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0472412109375, 43.43263816389223]),
            {
              "class": 1,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73069763183594, 43.263866439074434]),
            {
              "class": 1,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.69121551513672, 43.216346123467495]),
            {
              "class": 1,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.70323181152344, 43.17279500752022]),
            {
              "class": 1,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85292053222656, 43.16953994073713]),
            {
              "class": 1,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55628967285156, 43.09136629655056]),
            {
              "class": 1,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37638854980469, 43.064784563786404]),
            {
              "class": 1,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40007781982422, 42.99149978097288]),
            {
              "class": 1,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31733703613281, 42.92441280659362]),
            {
              "class": 1,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22498321533203, 42.97768634846502]),
            {
              "class": 1,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39252471923828, 42.85448423134834]),
            {
              "class": 1,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58856201171875, 42.946531950026184]),
            {
              "class": 1,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84674072265625, 42.808660715325]),
            {
              "class": 1,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89789581298828, 42.83661206621467]),
            {
              "class": 1,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75473022460938, 42.881660145207285]),
            {
              "class": 1,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92433166503906, 42.941505569619046]),
            {
              "class": 1,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10663604736328, 42.887446062999565]),
            {
              "class": 1,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.24911499023438, 42.89348296387308]),
            {
              "class": 1,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.21684265136719, 42.981453956060044]),
            {
              "class": 1,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1739273071289, 43.10465283852661]),
            {
              "class": 1,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.21478271484375, 43.1297139338965]),
            {
              "class": 1,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.22679901123047, 43.27211618984179]),
            {
              "class": 1,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.22473907470703, 43.33832364581098]),
            {
              "class": 1,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.55707550048828, 43.331581279701254]),
            {
              "class": 1,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.61063385009766, 43.43413403661519]),
            {
              "class": 1,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74109649658203, 43.43587917472658]),
            {
              "class": 1,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.70882415771484, 43.552439954449945]),
            {
              "class": 1,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91241455078125, 43.49344049796546]),
            {
              "class": 1,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.03292083740234, 43.43288747858041]),
            {
              "class": 1,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93541717529297, 43.317095147206395]),
            {
              "class": 1,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7064208984375, 43.22535281865032]),
            {
              "class": 1,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.6786117553711, 43.115179748727364]),
            {
              "class": 1,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.88494873046875, 43.01058232528119]),
            {
              "class": 1,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.66144561767578, 43.05048584557401]),
            {
              "class": 1,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.50042724609375, 43.06403208279672]),
            {
              "class": 1,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.48051452636719, 43.18531287836307]),
            {
              "class": 1,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.3819808959961, 43.3665335737934]),
            {
              "class": 1,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.52720642089844, 43.376266699807566]),
            {
              "class": 1,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47090148925781, 43.507635510394294]),
            {
              "class": 1,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.65526580810547, 43.597211113946656]),
            {
              "class": 1,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74761962890625, 43.62057837789682]),
            {
              "class": 1,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.89696502685547, 43.619335666923234]),
            {
              "class": 1,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01644134521484, 43.60218363250835]),
            {
              "class": 1,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.05077362060547, 43.67672209428634]),
            {
              "class": 1,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.07343292236328, 43.51834182002643]),
            {
              "class": 1,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.162353515625, 43.51161947539451]),
            {
              "class": 1,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.29865264892578, 43.45008771165074]),
            {
              "class": 1,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.45658111572266, 43.48920625165954]),
            {
              "class": 1,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.52387237548828, 43.540495357083095]),
            {
              "class": 1,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.14175415039062, 43.46977472763274]),
            {
              "class": 1,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9752426147461, 43.52556128199441]),
            {
              "class": 1,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93301391601562, 43.38350313990141]),
            {
              "class": 1,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.15033721923828, 43.378263045409156]),
            {
              "class": 1,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.2667236328125, 43.27936504777711]),
            {
              "class": 1,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25779724121094, 43.14574764830263]),
            {
              "class": 1,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0851058959961, 43.136228137435644]),
            {
              "class": 1,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.69313049316406, 43.11333532051462]),
            {
              "class": 1,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.93002319335938, 43.09177762720493]),
            {
              "class": 1,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.98014831542969, 42.781614103059525]),
            {
              "class": 1,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99618530273438, 42.8626988152673]),
            {
              "class": 1,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99687194824219, 42.6105353125112]),
            {
              "class": 1,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.75105285644531, 42.645899927016416]),
            {
              "class": 1,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.54849243164062, 42.78816526240243]),
            {
              "class": 1,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.62127685546875, 42.50938285980563]),
            {
              "class": 1,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97651672363281, 42.598405676746495]),
            {
              "class": 1,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.712158203125, 42.53215645841752]),
            {
              "class": 1,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33518981933594, 42.564025550868394]),
            {
              "class": 1,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57139587402344, 42.89549513285785]),
            {
              "class": 1,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65962982177734, 42.82503015684572]),
            {
              "class": 1,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4756088256836, 42.75070328369649]),
            {
              "class": 1,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35819244384766, 42.70152296900574]),
            {
              "class": 1,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2009506225586, 42.671491210587185]),
            {
              "class": 1,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4869384765625, 42.634120532230604]),
            {
              "class": 1,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55594635009766, 42.61770063784718]),
            {
              "class": 1,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60607147216797, 42.40334095009897]),
            {
              "class": 1,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2672119140625, 42.28001168691287]),
            {
              "class": 1,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27442169189453, 42.3376462032796]),
            {
              "class": 1,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3334732055664, 42.15109562120427]),
            {
              "class": 1,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49895477294922, 42.19257071055314]),
            {
              "class": 1,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65653991699219, 42.14905933386892]),
            {
              "class": 1,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7282943725586, 42.010183046411385]),
            {
              "class": 1,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.82064819335938, 42.17094598972554]),
            {
              "class": 1,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78185272216797, 42.23147656955193]),
            {
              "class": 1,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.46633911132812, 42.46786295967953]),
            {
              "class": 1,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40660095214844, 42.3816973344096]),
            {
              "class": 1,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.86734008789062, 42.48913269286206]),
            {
              "class": 1,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8055419921875, 42.6847777957013]),
            {
              "class": 1,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14131164550781, 42.640343961035036]),
            {
              "class": 1,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.31640625, 42.702441516341075]),
            {
              "class": 1,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.57321166992188, 42.61862042431041]),
            {
              "class": 1,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8382568359375, 42.65398044635424]),
            {
              "class": 1,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67552185058594, 42.81134072100115]),
            {
              "class": 1,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.250244140625, 42.37155241655813]),
            {
              "class": 1,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70274353027344, 42.93110987018423]),
            {
              "class": 1,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22940063476562, 42.8219179356209]),
            {
              "class": 1,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.61598205566406, 42.818392398437794]),
            {
              "class": 1,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.44436645507812, 41.78853696052838]),
            {
              "class": 1,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.68949890136719, 41.90975883972651]),
            {
              "class": 1,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8498306274414, 41.750732086885066]),
            {
              "class": 1,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1512680053711, 41.76584230558817]),
            {
              "class": 1,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.08157348632812, 41.88020581864756]),
            {
              "class": 1,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2776107788086, 41.7440722171113]),
            {
              "class": 1,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.52617645263672, 41.78350906484826]),
            {
              "class": 1,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.61200714111328, 41.73049418923488]),
            {
              "class": 1,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.21385192871094, 41.79263258410306]),
            {
              "class": 1,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.51666259765625, 41.41268059255831]),
            {
              "class": 1,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.21110534667969, 41.37250130399895]),
            {
              "class": 1,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.60661315917969, 41.49193600220801]),
            {
              "class": 1,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87165832519531, 41.59163938101106]),
            {
              "class": 1,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.91354370117188, 41.414225453846434]),
            {
              "class": 1,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.46099853515625, 44.615556867548555]),
            {
              "class": 1,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4414291381836, 44.56641384572139]),
            {
              "class": 1,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.32916259765625, 44.564457044724136]),
            {
              "class": 1,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.30066680908203, 44.65855345103367]),
            {
              "class": 1,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.47644805908203, 44.76883051496027]),
            {
              "class": 1,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.46649169921875, 44.795392429656786]),
            {
              "class": 1,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.38340759277344, 44.75956752507949]),
            {
              "class": 1,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.57051849365234, 44.79612331872674]),
            {
              "class": 1,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.66081237792969, 44.827055798339394]),
            {
              "class": 1,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65325927734375, 44.7680992802859]),
            {
              "class": 1,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6838150024414, 44.6729599481193]),
            {
              "class": 1,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.87641906738281, 44.57277299436663]),
            {
              "class": 1,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.04739379882812, 44.5399914784059]),
            {
              "class": 1,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.26883697509766, 44.485151288530474]),
            {
              "class": 1,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.28943634033203, 44.42045195924912]),
            {
              "class": 1,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48091125488281, 44.49960080886999]),
            {
              "class": 1,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.24333190917969, 44.5221251206384]),
            {
              "class": 1,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.19629669189453, 44.41505711307341]),
            {
              "class": 1,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.93537139892578, 44.40941651442008]),
            {
              "class": 1,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75100708007812, 44.390774145709656]),
            {
              "class": 1,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.64457702636719, 44.307055665662055]),
            {
              "class": 1,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50244140625, 44.20303930905671]),
            {
              "class": 1,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.36957550048828, 44.36083581728442]),
            {
              "class": 1,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.27825164794922, 44.33530253400328]),
            {
              "class": 1,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.15190887451172, 44.272403989861694]),
            {
              "class": 1,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2006607055664, 44.16167680251456]),
            {
              "class": 1,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.04822540283203, 44.106235130486425]),
            {
              "class": 1,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26383209228516, 44.03272559871982]),
            {
              "class": 1,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.33352661132812, 43.93020284974902]),
            {
              "class": 1,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0296859741211, 43.98012760358372]),
            {
              "class": 1,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.84566497802734, 43.88939160676933]),
            {
              "class": 1,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.56757354736328, 43.90002996012072]),
            {
              "class": 1,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.44363403320312, 44.002604753910035]),
            {
              "class": 1,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.44672393798828, 44.05913046610528]),
            {
              "class": 1,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.59435272216797, 44.19959354191239]),
            {
              "class": 1,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.72138214111328, 44.17694491571548]),
            {
              "class": 1,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.66748046875, 44.351998631770876]),
            {
              "class": 1,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.69254302978516, 44.50621210719167]),
            {
              "class": 1,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.58370971679688, 44.53485240278845]),
            {
              "class": 1,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8161392211914, 44.4672681133898]),
            {
              "class": 1,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.80068969726562, 44.51061922287941]),
            {
              "class": 1,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.38046264648438, 44.569348923797655]),
            {
              "class": 1,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3100814819336, 44.64072350760506]),
            {
              "class": 1,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.28467559814453, 44.44937945771156]),
            {
              "class": 1,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.11095428466797, 44.40720917555359]),
            {
              "class": 1,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.08657836914062, 44.57424039147193]),
            {
              "class": 1,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.11473083496094, 44.44741872387862]),
            {
              "class": 1,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.05396270751953, 44.276337123211164]),
            {
              "class": 1,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.93791961669922, 44.20550044791675]),
            {
              "class": 1,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.16107940673828, 44.17645245762588]),
            {
              "class": 1,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.22116088867188, 44.236501987694695]),
            {
              "class": 1,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35608673095703, 44.16340081967155]),
            {
              "class": 1,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.85287475585938, 44.943068110071444]),
            {
              "class": 1,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4532470703125, 45.27647190405079]),
            {
              "class": 1,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.33651733398438, 44.80974585318468]),
            {
              "class": 1,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.2939453125, 44.94372878141947]),
            {
              "class": 1,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31935119628906, 45.08352854006976]),
            {
              "class": 1,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4642333984375, 45.14991072685174]),
            {
              "class": 1,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.08245849609375, 45.04069274317544]),
            {
              "class": 1,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94993591308594, 45.01545747011128]),
            {
              "class": 1,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.80436706542969, 45.09331128597891]),
            {
              "class": 1,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.74222564697266, 45.046029548357595]),
            {
              "class": 1,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.76042175292969, 45.14733425583556]),
            {
              "class": 1,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1844253540039, 45.04918288104669]),
            {
              "class": 1,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.47247314453125, 44.955479107707056]),
            {
              "class": 1,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.65580749511719, 45.03050291446229]),
            {
              "class": 1,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82025909423828, 45.06518942695245]),
            {
              "class": 1,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.93115234375, 45.0496679937235]),
            {
              "class": 1,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.13645935058594, 45.64795587421751]),
            {
              "class": 1,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.04513549804688, 45.53263502774925]),
            {
              "class": 1,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.87004089355469, 45.42141492368429]),
            {
              "class": 1,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.54364013671875, 44.91067070373829]),
            {
              "class": 1,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26829528808594, 44.64356704869724]),
            {
              "class": 1,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.30125427246094, 44.833298888712804]),
            {
              "class": 1,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.149658203125, 44.75094688754851]),
            {
              "class": 1,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.99310302734375, 44.735340377545874]),
            {
              "class": 1,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.19085693359375, 44.89997137001637]),
            {
              "class": 1,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.35565185546875, 44.98599593324817]),
            {
              "class": 1,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.91413879394531, 44.95927894074217]),
            {
              "class": 1,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.79328918457031, 44.48653287255083]),
            {
              "class": 1,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.31641387939453, 44.713474274108385]),
            {
              "class": 1,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.072998046875, 44.84750596078722]),
            {
              "class": 1,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9576416015625, 44.71713381091184]),
            {
              "class": 1,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.89412689208984, 44.81268765463098]),
            {
              "class": 1,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.743408203125, 44.63363885819047]),
            {
              "class": 1,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.69877624511719, 44.678819193688355]),
            {
              "class": 1,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01154327392578, 44.650982500799465]),
            {
              "class": 1,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.11591339111328, 44.68272502826526]),
            {
              "class": 1,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.116943359375, 44.495437754913105]),
            {
              "class": 1,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5848388671875, 42.51646886886577]),
            {
              "class": 1,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5906753540039, 42.70656889822076]),
            {
              "class": 1,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5137710571289, 42.70404598487887]),
            {
              "class": 1,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.27859497070312, 42.72573968882174]),
            {
              "class": 1,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.19036102294922, 42.824274739544265]),
            {
              "class": 1,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.22846984863281, 42.66568507885776]),
            {
              "class": 1,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.52372741699219, 42.44541032899833]),
            {
              "class": 1,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76336669921875, 42.37595535368091]),
            {
              "class": 1,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.84095764160156, 42.493527378010405]),
            {
              "class": 1,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91683197021484, 42.561334853987944]),
            {
              "class": 1,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.16402435302734, 42.16891034109415]),
            {
              "class": 1,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.94670104980469, 42.24596478181689]),
            {
              "class": 1,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.80078887939453, 42.317594362820856]),
            {
              "class": 1,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91648864746094, 42.38736747086365]),
            {
              "class": 1,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.05793762207031, 42.33891509203362]),
            {
              "class": 1,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.14170837402344, 42.47200590207504]),
            {
              "class": 1,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29036712646484, 42.34221408296478]),
            {
              "class": 1,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.40984344482422, 42.327240349708646]),
            {
              "class": 1,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.44932556152344, 42.28483774484909]),
            {
              "class": 1,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.32263946533203, 42.223849858587016]),
            {
              "class": 1,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0459213256836, 42.02089624728898]),
            {
              "class": 1,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.91202545166016, 42.071377028123614]),
            {
              "class": 1,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.83306121826172, 42.15669507360935]),
            {
              "class": 1,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.9147720336914, 42.12869285778453]),
            {
              "class": 1,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76782989501953, 42.071377028123614]),
            {
              "class": 1,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.88078308105469, 42.003039909931424]),
            {
              "class": 1,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72903442382812, 42.58829584293554]),
            {
              "class": 1,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.34519958496094, 42.78111013901041]),
            {
              "class": 1,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31498718261719, 42.839542606109156]),
            {
              "class": 1,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.66929626464844, 42.506851947584664]),
            {
              "class": 1,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.99819946289062, 42.1275828557574]),
            {
              "class": 1,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.51799011230469, 41.85301263422478]),
            {
              "class": 1,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.95606994628906, 41.99759033742702]),
            {
              "class": 1,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.99932861328125, 41.88880439893737]),
            {
              "class": 1,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.99932861328125, 42.12299941562883]),
            {
              "class": 1,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.27947998046875, 42.11230343248086]),
            {
              "class": 1,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.4525146484375, 42.14031289401401]),
            {
              "class": 1,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69284057617188, 42.10873770359144]),
            {
              "class": 1,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.40650939941406, 41.89647145538402]),
            {
              "class": 1,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.18266296386719, 41.94245446628888]),
            {
              "class": 1,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.13528442382812, 41.66862422317039]),
            {
              "class": 1,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.92242431640625, 41.65066931668763]),
            {
              "class": 1,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.62510681152344, 41.780344928366034]),
            {
              "class": 1,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.60450744628906, 41.594207023526586]),
            {
              "class": 1,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.40538024902344, 41.87039970869706]),
            {
              "class": 1,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.00712585449219, 41.657338866323116]),
            {
              "class": 1,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.94876098632812, 41.812083222489456]),
            {
              "class": 1,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02223205566406, 41.960838392480184]),
            {
              "class": 1,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70706176757812, 41.6465646351942]),
            {
              "class": 1,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.90206909179688, 41.53101337250705]),
            {
              "class": 1,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.11973571777344, 41.53923718137237]),
            {
              "class": 1,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.24333190917969, 41.42812755209064]),
            {
              "class": 1,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29139709472656, 41.27246052457538]),
            {
              "class": 1,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48503112792969, 41.338484048907596]),
            {
              "class": 1,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.90206909179688, 41.27297659244486]),
            {
              "class": 1,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.92678833007812, 41.38692749564556]),
            {
              "class": 1,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02703857421875, 41.39929025574977]),
            {
              "class": 1,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69058227539062, 41.14486683283192]),
            {
              "class": 1,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69607543945312, 41.400835435444414]),
            {
              "class": 1,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.54844665527344, 41.25439557901571]),
            {
              "class": 1,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.46192932128906, 41.32559408284315]),
            {
              "class": 1,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28134155273438, 41.27349265623466]),
            {
              "class": 1,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2003173828125, 41.131421445137406]),
            {
              "class": 1,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.29232788085938, 41.08485843768273]),
            {
              "class": 1,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.38845825195312, 41.12573218220248]),
            {
              "class": 1,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.52372741699219, 41.049137772170496]),
            {
              "class": 1,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28271484375, 40.98593201374999]),
            {
              "class": 1,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.28752136230469, 41.15210551535379]),
            {
              "class": 1,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.02247619628906, 41.159860359792326]),
            {
              "class": 1,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.98745727539062, 41.231678271899]),
            {
              "class": 1,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.06470489501953, 41.326718028249886]),
            {
              "class": 1,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.98677062988281, 41.445207449362705]),
            {
              "class": 1,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2384262084961, 41.39938280660957]),
            {
              "class": 1,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.392578125, 41.42796264302182]),
            {
              "class": 1,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50656127929688, 41.55859995986896]),
            {
              "class": 1,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.5680160522461, 41.5742690047407]),
            {
              "class": 1,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.70932006835938, 42.08326237840814]),
            {
              "class": 1,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.76356506347656, 41.85505841778353]),
            {
              "class": 1,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.03341674804688, 42.07103058754557]),
            {
              "class": 1,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.94003295898438, 42.18713740015286]),
            {
              "class": 1,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.996337890625, 42.01085666019561]),
            {
              "class": 1,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.106201171875, 41.91946710266237]),
            {
              "class": 1,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.84939575195312, 42.055227701771564]),
            {
              "class": 1,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.01168823242188, 41.51816157795011]),
            {
              "class": 1,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.8592529296875, 41.370955450814144]),
            {
              "class": 1,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6669921875, 41.353433214190524]),
            {
              "class": 1,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.46992492675781, 41.47496085201217]),
            {
              "class": 1,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.47679138183594, 41.51970392807518]),
            {
              "class": 1,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.68440246582031, 41.054833671156985]),
            {
              "class": 1,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.98995971679688, 41.07812994082104]),
            {
              "class": 1,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.34451293945312, 41.03929823971501]),
            {
              "class": 1,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.05062866210938, 41.13193862639695]),
            {
              "class": 1,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.93252563476562, 41.1583094642994]),
            {
              "class": 1,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.964111328125, 41.05120906522179]),
            {
              "class": 1,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.10006713867188, 41.00977081575338]),
            {
              "class": 1,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.14057922363281, 40.95949196028937]),
            {
              "class": 1,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.12821960449219, 40.87543563299478]),
            {
              "class": 1,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.01629638671875, 40.70960495999854]),
            {
              "class": 1,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.36305236816406, 40.6971119211115]),
            {
              "class": 1,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31155395507812, 40.86089654641057]),
            {
              "class": 1,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.48390197753906, 40.75643298366911]),
            {
              "class": 1,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.60612487792969, 40.78139445228818]),
            {
              "class": 1,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.58071899414062, 40.60698861895812]),
            {
              "class": 1,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.65830993652344, 40.66743156275298]),
            {
              "class": 1,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.92472839355469, 40.63200612926902]),
            {
              "class": 1,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75306701660156, 40.618456140853354]),
            {
              "class": 1,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70225524902344, 40.594997741823214]),
            {
              "class": 1,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.60063171386719, 40.39657637662607]),
            {
              "class": 1,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76405334472656, 40.43212646045327]),
            {
              "class": 1,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.86361694335938, 40.53605480129276]),
            {
              "class": 1,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69676208496094, 40.55118670199323]),
            {
              "class": 1,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.95082092285156, 40.454074481577585]),
            {
              "class": 1,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.11424255371094, 40.37304025938538]),
            {
              "class": 1,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.27766418457031, 40.50525865879244]),
            {
              "class": 1,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4417724609375, 40.48698307539798]),
            {
              "class": 1,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58253479003906, 40.5684016029568]),
            {
              "class": 1,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.24607849121094, 40.575703556806324]),
            {
              "class": 1,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.16642761230469, 40.644511370853714]),
            {
              "class": 1,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.13346862792969, 40.72677906210499]),
            {
              "class": 1,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.27354431152344, 40.73146213915348]),
            {
              "class": 1,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.00369262695312, 40.843757096330684]),
            {
              "class": 1,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.66448974609375, 40.8572612759859]),
            {
              "class": 1,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75238037109375, 40.92733488050902]),
            {
              "class": 1,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.47291564941406, 40.96312161460074]),
            {
              "class": 1,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.41043090820312, 40.889971527219515]),
            {
              "class": 1,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3211669921875, 40.961566072909136]),
            {
              "class": 1,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.61549377441406, 40.33693557510991]),
            {
              "class": 1,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.70132446289062, 40.45302950021815]),
            {
              "class": 1,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.93409729003906, 40.564228700149165]),
            {
              "class": 1,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.0020751953125, 40.414353766294035]),
            {
              "class": 1,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.19296264648438, 40.45564192314601]),
            {
              "class": 1,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46762084960938, 40.4828051002519]),
            {
              "class": 1,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.18815612792969, 40.646595350036954]),
            {
              "class": 1,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.72305297851562, 40.505780745169844]),
            {
              "class": 1,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.01419067382812, 40.6122013728884]),
            {
              "class": 1,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.09040832519531, 40.8229760613632]),
            {
              "class": 1,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.84046936035156, 40.71637104428822]),
            {
              "class": 1,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.40719604492188, 40.601254119991836]),
            {
              "class": 1,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.89608764648438, 40.39657637662607]),
            {
              "class": 1,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.00595092773438, 40.268335816992916]),
            {
              "class": 1,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.92698669433594, 40.046351283228574]),
            {
              "class": 1,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.12199401855469, 40.07893340485828]),
            {
              "class": 1,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69970703125, 39.949564236790785]),
            {
              "class": 1,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.4305419921875, 39.98692766613728]),
            {
              "class": 1,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.09751892089844, 40.10047108695759]),
            {
              "class": 1,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.17442321777344, 40.034786140006894]),
            {
              "class": 1,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.44633483886719, 40.083136414557146]),
            {
              "class": 1,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.29389953613281, 40.227457077182606]),
            {
              "class": 1,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.04945373535156, 40.2950508738441]),
            {
              "class": 1,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.89907836914062, 40.25418827793497]),
            {
              "class": 1,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80569458007812, 40.19179905984614]),
            {
              "class": 1,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.67935180664062, 40.30081156083504]),
            {
              "class": 1,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.53309631347656, 40.324372892813955]),
            {
              "class": 1,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.39370727539062, 40.42533157304251]),
            {
              "class": 1,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.36898803710938, 40.629921694597485]),
            {
              "class": 1,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.56193542480469, 40.79699060843727]),
            {
              "class": 1,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.43284606933594, 41.076059495510634]),
            {
              "class": 1,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.62716674804688, 41.10555718419363]),
            {
              "class": 1,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80638122558594, 41.13193862639695]),
            {
              "class": 1,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.71574401855469, 41.0645050516869]),
            {
              "class": 1,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.7765121459961, 40.979545735019016]),
            {
              "class": 1,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.9138412475586, 40.95076944139497]),
            {
              "class": 1,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.97161865234375, 40.01690887861705]),
            {
              "class": 1,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.95582580566406, 40.20700844973546]),
            {
              "class": 1,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.77043151855469, 40.659618745600724]),
            {
              "class": 1,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.67018127441406, 40.46086646429032]),
            {
              "class": 1,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.58847045898438, 40.40128261317668]),
            {
              "class": 1,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.18746948242188, 40.57466046932723]),
            {
              "class": 1,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.68690490722656, 40.2568084157797]),
            {
              "class": 1,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.90138244628906, 40.790232723851915]),
            {
              "class": 1,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.76679992675781, 41.080717905749864]),
            {
              "class": 1,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.83477783203125, 41.21721769213736]),
            {
              "class": 1,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.33352661132812, 41.234776551520355]),
            {
              "class": 1,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50518798828125, 41.18828693986754]),
            {
              "class": 1,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.11517333984375, 41.21360204755517]),
            {
              "class": 1,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.98265075683594, 40.96778801969595]),
            {
              "class": 1,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95793151855469, 40.74602960448277]),
            {
              "class": 1,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.16461181640625, 40.74602960448277]),
            {
              "class": 1,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.24014282226562, 40.72677906210499]),
            {
              "class": 1,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49375915527344, 41.473931912110096]),
            {
              "class": 1,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.23283386230469, 41.71989636971691]),
            {
              "class": 1,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14494323730469, 42.1667831773189]),
            {
              "class": 1,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.34524536132812, 45.49895514755589]),
            {
              "class": 1,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9813232421875, 45.67195122769811]),
            {
              "class": 1,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47776794433594, 45.71463751405315]),
            {
              "class": 1,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01840209960938, 45.47729315148685]),
            {
              "class": 1,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.66590881347656, 45.54273506110328]),
            {
              "class": 1,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.78538513183594, 45.55427573495764]),
            {
              "class": 1,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.68307495117188, 45.886490771045466]),
            {
              "class": 1,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.99667358398438, 45.18476675872514]),
            {
              "class": 1,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80097961425781, 45.47729315148685]),
            {
              "class": 1,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82638549804688, 45.62067492125561]),
            {
              "class": 1,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22154998779297, 45.902108212272466]),
            {
              "class": 1,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74202728271484, 45.948438109144725]),
            {
              "class": 1,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.01545715332031, 45.057827123906094]),
            {
              "class": 1,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20565795898438, 45.2050895941694]),
            {
              "class": 1,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.196044921875, 44.98842413358035]),
            {
              "class": 1,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.20291137695312, 44.845957997436734]),
            {
              "class": 1,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.64270782470703, 45.141038247865055]),
            {
              "class": 1,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5259780883789, 45.300886275356575]),
            {
              "class": 1,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.79411315917969, 45.26368498339995]),
            {
              "class": 1,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.89470672607422, 45.34385477946279]),
            {
              "class": 1,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.62931823730469, 45.52502498751168]),
            {
              "class": 1,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6190185546875, 45.79521110538338]),
            {
              "class": 1,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87808227539062, 44.73662837892016]),
            {
              "class": 1,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.76547241210938, 44.65267307590262]),
            {
              "class": 1,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.5361328125, 43.93678954113476]),
            {
              "class": 1,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.53956604003906, 44.112062803264166]),
            {
              "class": 1,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27520751953125, 44.143606226055624]),
            {
              "class": 1,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.22027587890625, 44.27059481377268]),
            {
              "class": 1,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.96940612792969, 44.015850089018905]),
            {
              "class": 1,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.19256591796875, 44.00300991287454]),
            {
              "class": 1,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.17059326171875, 43.747606860913]),
            {
              "class": 1,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.88906860351562, 43.880889608845386]),
            {
              "class": 1,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.45761108398438, 43.99066096828016]),
            {
              "class": 1,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57502746582031, 44.09233961002336]),
            {
              "class": 1,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92658996582031, 43.94667786611075]),
            {
              "class": 1,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73707580566406, 43.23401816115676]),
            {
              "class": 1,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.12321472167969, 43.3344882365187]),
            {
              "class": 1,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90966796875, 44.718265933236296]),
            {
              "class": 1,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11222839355469, 44.65333708063547]),
            {
              "class": 1,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91104125976562, 44.90775290112518]),
            {
              "class": 1,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.09300231933594, 44.542350559876915]),
            {
              "class": 1,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.85885620117188, 44.429190706966025]),
            {
              "class": 1,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.23445129394531, 44.370810569717065]),
            {
              "class": 1,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01771545410156, 45.39393723461099]),
            {
              "class": 1,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35853576660156, 45.24958092052426]),
            {
              "class": 1,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.08387756347656, 45.461883997092016]),
            {
              "class": 1,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80097961425781, 45.5042490350858]),
            {
              "class": 1,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.53912353515625, 45.14700509476115]),
            {
              "class": 1,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72451782226562, 45.19638069625248]),
            {
              "class": 1,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45809936523438, 44.97385338866614]),
            {
              "class": 1,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3660888671875, 45.130537048451686]),
            {
              "class": 1,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.56727600097656, 44.992794634967495]),
            {
              "class": 1,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.02801513671875, 45.07674060998666]),
            {
              "class": 1,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93968200683594, 45.116971556650455]),
            {
              "class": 1,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.89505004882812, 44.96802405385763]),
            {
              "class": 1,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.93006896972656, 44.80854701654898]),
            {
              "class": 1,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.74707794189453, 44.77248654947365]),
            {
              "class": 1,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80303955078125, 44.65513443461444]),
            {
              "class": 1,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6907730102539, 44.64121207223193]),
            {
              "class": 1,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.52254486083984, 44.990939488889246]),
            {
              "class": 1,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.47756958007812, 44.92364325373275]),
            {
              "class": 1,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.75566101074219, 44.97418354810338]),
            {
              "class": 1,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92766571044922, 45.06858417884918]),
            {
              "class": 1,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.80647277832031, 45.089918002937715]),
            {
              "class": 1,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.48505783081055, 45.00154412071485]),
            {
              "class": 1,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.42583465576172, 44.99061891052703]),
            {
              "class": 1,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.41210174560547, 45.0188987817413]),
            {
              "class": 1,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.49243927001953, 45.0582003772129]),
            {
              "class": 1,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81858825683594, 43.55103643145803]),
            {
              "class": 1,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60092163085938, 43.55203173091178]),
            {
              "class": 1,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57002258300781, 43.529633517604296]),
            {
              "class": 1,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60177993774414, 43.515194704453215]),
            {
              "class": 1,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52075576782227, 43.51880473170812]),
            {
              "class": 1,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49689483642578, 43.57243174740972]),
            {
              "class": 1,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47509384155273, 43.598295002627175]),
            {
              "class": 1,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49466323852539, 43.63421156039935]),
            {
              "class": 1,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.42977523803711, 43.66215942544593]),
            {
              "class": 1,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4675407409668, 43.680163381222954]),
            {
              "class": 1,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3906364440918, 43.68537731137408]),
            {
              "class": 1,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36952209472656, 43.64899449575356]),
            {
              "class": 1,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35269927978516, 43.66824412502010]),
            {
              "class": 1,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31184387207031, 43.633466105990486]),
            {
              "class": 1,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3884048461914, 43.562978940066884]),
            {
              "class": 1,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40608596801758, 43.51743543644933]),
            {
              "class": 1,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36814880371094, 43.49539795818203]),
            {
              "class": 1,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3964729309082, 43.454912713790264]),
            {
              "class": 1,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32815170288086, 43.47522101136771]),
            {
              "class": 1,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.23802947998047, 43.517559919120544]),
            {
              "class": 1,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21348190307617, 43.566212962151326]),
            {
              "class": 1,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30188751220703, 43.603888956341585]),
            {
              "class": 1,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.28369140625, 43.47609299405864]),
            {
              "class": 1,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26068878173828, 43.56123747164742]),
            {
              "class": 1,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.23099136352539, 43.65421113388417]),
            {
              "class": 1,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.2339096069336, 43.70473937032096]),
            {
              "class": 1,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21039199829102, 43.75051320325138]),
            {
              "class": 1,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20232391357422, 43.68214969375954]),
            {
              "class": 1,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21142196655273, 43.79290649613756]),
            {
              "class": 1,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20764541625977, 43.85978208946686]),
            {
              "class": 1,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.338623046875, 43.73476301342663]),
            {
              "class": 1,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4074592590332, 43.590835588611185]),
            {
              "class": 1,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4151840209961, 43.50237113774067]),
            {
              "class": 1,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40436935424805, 43.444942955261254]),
            {
              "class": 1,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55148315429688, 43.57230737799699]),
            {
              "class": 1,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66340637207031, 43.45827713637714]),
            {
              "class": 1,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74923706054688, 43.509966006217816]),
            {
              "class": 1,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74374389648438, 43.43796314649063]),
            {
              "class": 1,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81515502929688, 43.50834750781285]),
            {
              "class": 1,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8688850402832, 43.49514890116052]),
            {
              "class": 1,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91729354858398, 43.50784949957228]),
            {
              "class": 1,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92862319946289, 43.561859430433024]),
            {
              "class": 1,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9974594116211, 43.56061550644105]),
            {
              "class": 1,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.90888214111328, 43.610601014243]),
            {
              "class": 1,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94939422607422, 43.62787490317682]),
            {
              "class": 1,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.876953125, 43.6779287010138]),
            {
              "class": 1,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.86837005615234, 43.74220456437031]),
            {
              "class": 1,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89223098754883, 43.81817941490989]),
            {
              "class": 1,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8191032409668, 43.875128129336716]),
            {
              "class": 1,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65224838256836, 43.9180512910269]),
            {
              "class": 1,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.61379623413086, 43.95513571382928]),
            {
              "class": 1,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51646423339844, 43.98256329668287]),
            {
              "class": 1,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52607727050781, 44.05045995529442]),
            {
              "class": 1,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52195739746094, 43.88465553661863]),
            {
              "class": 1,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57860565185547, 43.84604155734398]),
            {
              "class": 1,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4788703918457, 43.82115199650536]),
            {
              "class": 1,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49191665649414, 43.757580838861195]),
            {
              "class": 1,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.31167221069336, 43.756092984940786]),
            {
              "class": 1,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22052001953125, 43.80777421387378]),
            {
              "class": 1,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27836990356445, 43.91236296786708]),
            {
              "class": 1,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29587936401367, 44.0298522798673]),
            {
              "class": 1,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36746215820312, 44.11556760401951]),
            {
              "class": 1,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26858520507812, 44.20165102756234]),
            {
              "class": 1,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24970245361328, 44.26044549430247]),
            {
              "class": 1,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.19185256958008, 44.294858487869526]),
            {
              "class": 1,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88990020751953, 44.24728949212235]),
            {
              "class": 1,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82072067260742, 44.271754843913456]),
            {
              "class": 1,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7786636352539, 44.23400755212855]),
            {
              "class": 1,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.74810791015625, 44.32974250695349]),
            {
              "class": 1,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.81883239746094, 44.37135508631362]),
            {
              "class": 1,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82930374145508, 44.42054008115568]),
            {
              "class": 1,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.69798278808594, 44.49185223953623]),
            {
              "class": 1,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.82947540283203, 44.49515842171878]),
            {
              "class": 1,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7285385131836, 44.6780524901661]),
            {
              "class": 1,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.58417129516602, 44.569314529209066]),
            {
              "class": 1,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.37543106079102, 44.55170182879025]),
            {
              "class": 1,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94036865234375, 44.44456558540571]),
            {
              "class": 1,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98774719238281, 44.40999516065441]),
            {
              "class": 1,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.01521301269531, 44.451183121531336]),
            {
              "class": 1,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02894592285156, 44.34349388385858]),
            {
              "class": 1,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9046630859375, 44.137131033285044]),
            {
              "class": 1,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.77420043945312, 44.14181233770329]),
            {
              "class": 1,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94294357299805, 44.26462529002011]),
            {
              "class": 1,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.19734573364258, 44.13195652815869]),
            {
              "class": 1,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.18550109863281, 44.071800467511565]),
            {
              "class": 1,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33587646484375, 44.00034738902637]),
            {
              "class": 1,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40763092041016, 43.98466308500906]),
            {
              "class": 1,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39698791503906, 43.876241801024364]),
            {
              "class": 1,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39784622192383, 43.765143524274045]),
            {
              "class": 1,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7611083984375, 44.45534933372025]),
            {
              "class": 1,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.32205200195312, 42.80043894556554]),
            {
              "class": 1,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.1668701171875, 42.66173644170873]),
            {
              "class": 1,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.66218566894531, 41.920672548686824]),
            {
              "class": 1,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.09271240234375, 41.74518891415656]),
            {
              "class": 1,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.46099853515625, 44.766724381691816]),
            {
              "class": 1,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.30307006835938, 44.5263742310922]),
            {
              "class": 1,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.23165893554688, 44.60757930079818]),
            {
              "class": 1,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.16230773925781, 44.93418248087229]),
            {
              "class": 1,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.35250854492188, 44.94779136337911]),
            {
              "class": 1,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.36761474609375, 44.98665611039464]),
            {
              "class": 1,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4197998046875, 45.008505958683955]),
            {
              "class": 1,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.11012268066406, 44.91473562450239]),
            {
              "class": 1,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69332885742188, 45.3627600954673]),
            {
              "class": 1,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69950866699219, 45.346837074327055]),
            {
              "class": 1,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.41043090820312, 45.454350939222046]),
            {
              "class": 1,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9091796875, 45.96976535445165]),
            {
              "class": 1,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.00555419921875, 45.968333602063694]),
            {
              "class": 1,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70205688476562, 45.84984741373355]),
            {
              "class": 1,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.63407897949219, 45.98264946055033]),
            {
              "class": 1,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14356994628906, 45.97549199391512]),
            {
              "class": 1,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.89981079101562, 45.82736386003367]),
            {
              "class": 1,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.20811462402344, 45.821621922335794]),
            {
              "class": 1,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3763427734375, 45.88714049635727]),
            {
              "class": 1,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.0799560546875, 45.82210043976411]),
            {
              "class": 1,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.86778259277344, 45.53954142228416]),
            {
              "class": 1,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9481201171875, 45.82114340079471]),
            {
              "class": 1,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.26373291015625, 44.33170718680922]),
            {
              "class": 1,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.75262451171875, 44.26683800273895]),
            {
              "class": 1,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.96710205078125, 44.34938634389529]),
            {
              "class": 1,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.041259765625, 44.40042951858466]),
            {
              "class": 1,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.17034912109375, 45.323185535165635]),
            {
              "class": 1,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9808349609375, 44.46123053905879]),
            {
              "class": 1,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8157958984375, 44.98034238084972]),
            {
              "class": 1,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1785888671875, 45.31546044422575]),
            {
              "class": 1,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.3323974609375, 44.33170718680922]),
            {
              "class": 1,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1566162109375, 44.33170718680922]),
            {
              "class": 1,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.06597900390625, 44.42004966190147]),
            {
              "class": 1,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.38276672363281, 43.87463315746136]),
            {
              "class": 1,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.1181640625, 43.884036920060474]),
            {
              "class": 1,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.44113159179688, 43.782001151745845]),
            {
              "class": 1,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.53657531738281, 43.655949912568225]),
            {
              "class": 1,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.31890869140625, 43.86374273605402]),
            {
              "class": 1,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.51254272460938, 44.04811573082351]),
            {
              "class": 1,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9039306640625, 43.92757183247525]),
            {
              "class": 1,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.37384033203125, 43.84245116699039]),
            {
              "class": 1,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.27702331542969, 43.85780166750444]),
            {
              "class": 1,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.33470153808594, 43.82808744469062]),
            {
              "class": 1,
              "system:index": "780"
            })]),
    NonCropClass = /* color: #ffc82d */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-104.97711181640625, 39.78388874847879]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.43441772460938, 39.90409048287759]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.65277099609375, 40.179545481030274]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.77911376953125, 40.40266337363073]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.71044921875, 40.58333878787656]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.66513061523438, 40.618790037782716]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.88760375976562, 40.86226783543717]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.12518310546875, 40.77912783103293]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.13955974578857, 40.77705256583811]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.10243797302246, 40.75280468524527]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.08394145965576, 40.742108103811496]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.97171783447266, 40.81423552846405]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99197387695312, 40.933134523145824]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.86631774902344, 41.00960484846885]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7815170288086, 41.047677309553634]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.03179931640625, 41.024629265203075]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.08535766601562, 41.02281615536596]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.07540130615234, 40.970732707945636]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0396957397461, 40.92535291527663]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7159423828125, 40.33222484329471]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.57106018066406, 40.48959417780064]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.67680358886719, 40.51674362030912]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.83541870117188, 40.518309599021165]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.59989929199219, 40.27933741302928]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.57861328125, 40.10047108695759]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.6060791015625, 40.009020362256855]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.67680358886719, 40.08050956389998]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.68641662597656, 39.92850542461652]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.6829833984375, 40.00218291058078]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.36026000976562, 39.76507997502624]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28129577636719, 39.708581552166926]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.97230529785156, 39.89321739688029]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.12336730957031, 39.83207873058317]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.95170593261719, 39.761913064931434]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.04646301269531, 39.62612705619507]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.96337890625, 39.618722482628044]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.06706237792969, 39.71914552424002]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.93385314941406, 39.78829953164669]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.0018310546875, 39.74977189362929]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.70794677734375, 40.199477933653824]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.49234008789062, 40.20891757714069]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.22592163085938, 40.40580061754368]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30831909179688, 40.4256664333354]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.85694885253906, 40.38490332695034]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.87892150878906, 40.42830033726561]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.76356506347656, 40.428561680247505]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.70588684082031, 40.417845785259495]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68048095703125, 40.40921955669895]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.74811553955078, 40.402945241366794]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.72236633300781, 40.3749651360426]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.75395202636719, 40.36554865551543]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.78776931762695, 40.33212772188296]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.75163459777832, 40.35371590646708]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.78665351867676, 40.349791295874454]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.71936225891113, 40.35593975108527]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.70039367675781, 40.352800184424474]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69704627990723, 40.372158516737024]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.67824935913086, 40.392272251654425]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.63310241699219, 40.39514850804535]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68957901000977, 40.42939266251187]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.77815628051758, 40.437232382857104]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.70760345458984, 40.525710800245804]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60872650146484, 40.56353998316891]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.37183380126953, 40.669608408665134]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.38591003417969, 40.799163219668294]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60494995117188, 40.727913275071444]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.688720703125, 40.69408184346589]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.88166809082031, 40.912122078769436]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.03376007080078, 40.857614262997906]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.00595092773438, 40.752885451707655]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.16799926757812, 40.72687256426344]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18207550048828, 40.786686996079865]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28438568115234, 40.67143120814669]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3592300415039, 40.6899167870226]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.49585103988647, 40.853757930074615]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.47484397888184, 40.87223570555838]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.52162170410156, 41.02686725382042]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.91575622558594, 41.02531321554518]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.16569519042969, 40.92110912111607]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.22474670410156, 41.05845807739249]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84228515625, 40.940303328817194]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.80108642578125, 40.68930258186818]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.75096130371094, 40.6304428093654]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.42686462402344, 40.5245731480872]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29296875, 40.3442627264809]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29983520507812, 40.48437187140762]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.38360595703125, 40.125152240359924]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.40077209472656, 40.01270178335517]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.64041137695312, 40.07000114780217]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.30120849609375, 39.8078190041754]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18585205078125, 39.51497528444997]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.19065856933594, 39.58645045204754]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.15495300292969, 39.44395676267875]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.14139175415039, 39.4884946666345]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.19769668579102, 39.38641020971094]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27219772338867, 39.36318833652452]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3091049194336, 39.38402203056647]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.20679473876953, 39.35177361413344]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27219772338867, 39.32190069237686]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.24850845336914, 39.28670066035282]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29279708862305, 39.23805566225876]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.33897399902344, 39.1876472640614]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.21039962768555, 39.16143124586438]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.19340515136719, 39.21278948461795]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.17709732055664, 39.261319094419854]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28043746948242, 39.172344684584665]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.34669876098633, 39.11869283841007]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3947639465332, 39.18711505634243]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.88372802734375, 40.07403640716729]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.8974609375, 40.13705884157158]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.76116180419922, 40.04197762271282]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.81163024902344, 40.092686625178594]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.81300354003906, 40.018843891017696]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.02157211303711, 40.126475071178675]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98414993286133, 40.16689000616551]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98929977416992, 40.21173815301475]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.9714469909668, 40.217637017177424]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.90381240844727, 40.21304905609294]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.8780632019043, 40.26218961508881]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.84458923339844, 40.301869133597414]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.81746673583984, 40.310901807719304]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98466491699219, 41.24974949957454]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.13435363769531, 41.298258920245004]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.10414123535156, 41.23580927876249]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.75326538085938, 41.13927165625932]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.8208999633789, 41.161245633851365]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.81884002685547, 41.133324490452935]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.77489471435547, 41.11418647285739]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.87686157226562, 41.05958661847121]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.90398406982422, 41.09556034223798]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.10276794433594, 41.13099719184148]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.1168441772461, 41.047936230497925]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.22602081298828, 40.99613176839009]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.05195617675781, 40.9536217062938]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.11238098144531, 40.91782982324253]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.16937255859375, 40.895774448067286]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18001556396484, 40.8672212790918]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18516540527344, 40.83346074529004]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.16619682312012, 40.850023613288904]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18525123596191, 40.87086107349015]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.18877029418945, 40.86889896621716]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.17995119094849, 40.87722262704906]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.19426345825195, 40.939146403499855]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.19289016723633, 40.9514642871654]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.16988754272461, 40.958724279034044]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27460098266602, 40.906460466179446]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.15993118286133, 40.92799349587807]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.89540100097656, 40.68826126747952]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.72511291503906, 40.74082730450724]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27168273925781, 40.64711633466518]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.43441772460938, 40.81881907275406]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.68984985351562, 40.9045042288504]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.30738830566406, 41.176400961570074]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.26962280273438, 41.317858878996944]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.76312255859375, 40.61774762232908]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.87367248535156, 40.65701426984853]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.963623046875, 40.81933871057781]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.74252319335938, 40.81466182361933]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.67935180664062, 40.88426137808196]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.40126037597656, 40.95430639358934]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.38409423828125, 40.86245445837613]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4747314453125, 40.836484475020875]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.45344543457031, 40.74238803722561]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.23509216308594, 40.70648191996444]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.13484191894531, 40.67524346471915]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.21311950683594, 40.62679492058999]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.20213317871094, 40.629921694597485]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.37654113769531, 40.53709849039906]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.51387023925781, 40.47967144822859]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.52691650390625, 40.42742238074961]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.85787963867188, 40.43735282976399]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.95401000976562, 40.51674362030912]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.00070190429688, 40.5188315837968]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.93890380859375, 40.62835832589364]),
            {
              "class": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.97117614746094, 40.60594601937759]),
            {
              "class": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.21699523925781, 40.58978364609806]),
            {
              "class": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.88671875, 40.530314220591]),
            {
              "class": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.17579650878906, 40.39709930804434]),
            {
              "class": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.25956726074219, 40.384547833070066]),
            {
              "class": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.84346008300781, 40.169240926282015]),
            {
              "class": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6175537109375, 40.177635526570015]),
            {
              "class": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6395263671875, 40.19914194989696]),
            {
              "class": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.65806579589844, 40.141426396536126]),
            {
              "class": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.63300323486328, 40.1751117221013]),
            {
              "class": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6296558380127, 40.188685672115206]),
            {
              "class": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.61969947814941, 40.201004686400515]),
            {
              "class": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.60828399658203, 40.16829093480049]),
            {
              "class": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5981559753418, 40.18284986217152]),
            {
              "class": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6285400390625, 40.172200469306006]),
            {
              "class": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.3704605102539, 40.20054733428433]),
            {
              "class": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.40616607666016, 40.21260867741848]),
            {
              "class": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.35981750488281, 40.19897395739419]),
            {
              "class": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.3313217163086, 40.21496825439223]),
            {
              "class": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.31655883789062, 40.199236189411394]),
            {
              "class": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.19605255126953, 40.158578123184]),
            {
              "class": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.20051574707031, 40.229123990872104]),
            {
              "class": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.1778564453125, 40.23436610560434]),
            {
              "class": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.28153991699219, 40.211297765821904]),
            {
              "class": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30248260498047, 40.19530260266261]),
            {
              "class": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.24480438232422, 40.16749875266518]),
            {
              "class": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.1939926147461, 40.20841367105333]),
            {
              "class": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.21493530273438, 40.26581027247923]),
            {
              "class": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.34471130371094, 40.27628841484668]),
            {
              "class": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.315185546875, 40.32001712016489]),
            {
              "class": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.20223236083984, 40.33912317293564]),
            {
              "class": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.96980285644531, 40.683054451461295]),
            {
              "class": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.13528442382812, 40.86660871113223]),
            {
              "class": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.941650390625, 40.86816648873292]),
            {
              "class": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.82011413574219, 40.77671489115775]),
            {
              "class": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79745483398438, 40.720014035647516]),
            {
              "class": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.97941589355469, 40.757473232062395]),
            {
              "class": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.10232543945312, 40.812583101356616]),
            {
              "class": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.21287536621094, 40.790232723851915]),
            {
              "class": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.55757141113281, 40.91799602148601]),
            {
              "class": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68528747558594, 40.92525969254434]),
            {
              "class": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.53834533691406, 40.79283199163449]),
            {
              "class": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.43946838378906, 40.73458400742054]),
            {
              "class": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.447021484375, 40.8625477696484]),
            {
              "class": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.5180892944336, 40.89266015550331]),
            {
              "class": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.61284637451172, 41.06605816470459]),
            {
              "class": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.6780776977539, 41.090902984113434]),
            {
              "class": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.55928802490234, 41.092455473507904]),
            {
              "class": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.01693725585938, 41.08622507943507]),
            {
              "class": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.96337890625, 41.311484703423496]),
            {
              "class": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.66400146484375, 41.41764493800355]),
            {
              "class": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.45388793945312, 41.460883859179006]),
            {
              "class": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.27536010742188, 41.565772712005696]),
            {
              "class": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.33578491210938, 41.5965900253486]),
            {
              "class": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.50332641601562, 41.590427739230776]),
            {
              "class": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.55001831054688, 41.545219666468704]),
            {
              "class": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.66812133789062, 41.51951916932097]),
            {
              "class": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.72030639648438, 41.494837086173746]),
            {
              "class": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.9468994140625, 41.502036999056095]),
            {
              "class": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.97161865234375, 41.58631922165653]),
            {
              "class": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.02105712890625, 41.7227872214791]),
            {
              "class": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.09521484375, 41.78937690466099]),
            {
              "class": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27511596679688, 41.77401618700201]),
            {
              "class": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.73541259765625, 41.80985213739828]),
            {
              "class": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.46659088134766, 41.7748043133637]),
            {
              "class": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.43363189697266, 41.73920495230302]),
            {
              "class": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.57061767578125, 41.81857211966617]),
            {
              "class": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.49474334716797, 41.83341055182496]),
            {
              "class": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.40959930419922, 41.84134002767767]),
            {
              "class": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.66434478759766, 41.892474318388686]),
            {
              "class": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.62108612060547, 41.88634036301103]),
            {
              "class": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.56890106201172, 41.91036165727263]),
            {
              "class": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.61662292480469, 41.96475945095378]),
            {
              "class": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.7048568725586, 41.98339214923438]),
            {
              "class": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.73575592041016, 41.963227753880865]),
            {
              "class": 2,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.63550567626953, 42.02727229576706]),
            {
              "class": 2,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.5404052734375, 42.040277451914896]),
            {
              "class": 2,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.49817657470703, 41.997682031241524]),
            {
              "class": 2,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.5792007446289, 42.01324414509411]),
            {
              "class": 2,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.44805145263672, 42.035942695543866]),
            {
              "class": 2,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.41886901855469, 42.00839733748238]),
            {
              "class": 2,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.4308853149414, 42.00691253017174]),
            {
              "class": 2,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.45096969604492, 42.010356432889665]),
            {
              "class": 2,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.42556381225586, 42.031908476964645]),
            {
              "class": 2,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.41268920898438, 42.00678497463868]),
            {
              "class": 2,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.51826095581055, 42.091935089083336]),
            {
              "class": 2,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.57559585571289, 42.096520775843196]),
            {
              "class": 2,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.60872650146484, 42.1269104794792]),
            {
              "class": 2,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.64031219482422, 42.15364088825545]),
            {
              "class": 2,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.62966918945312, 42.17934234785779]),
            {
              "class": 2,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.6670913696289, 42.20884797242227]),
            {
              "class": 2,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.76150512695312, 42.217239297098686]),
            {
              "class": 2,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.82295989990234, 42.23249339472837]),
            {
              "class": 2,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.71790313720703, 42.200964197331]),
            {
              "class": 2,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.69593048095703, 42.30312260973006]),
            {
              "class": 2,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.72442626953125, 42.27721748441349]),
            {
              "class": 2,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.7381591796875, 42.26680163809834]),
            {
              "class": 2,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.5572280883789, 42.23808564038522]),
            {
              "class": 2,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.52667236328125, 42.32520973852236]),
            {
              "class": 2,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.54967498779297, 42.40486202178982]),
            {
              "class": 2,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.45491790771484, 42.3665705034607]),
            {
              "class": 2,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.39483642578125, 42.404608512402326]),
            {
              "class": 2,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.5187759399414, 42.50719599948285]),
            {
              "class": 2,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30591583251953, 42.524910135558905]),
            {
              "class": 2,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.39071655273438, 42.50515143338313]),
            {
              "class": 2,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2984619140625, 42.704278570242955]),
            {
              "class": 2,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28335571289062, 42.62652292235489]),
            {
              "class": 2,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28884887695312, 42.606310739963845]),
            {
              "class": 2,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27374267578125, 42.70024171075451]),
            {
              "class": 2,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.86288452148438, 43.00026891468749]),
            {
              "class": 2,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.93017578125, 43.01232001746044]),
            {
              "class": 2,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.90957641601562, 42.97415008173814]),
            {
              "class": 2,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.1776123046875, 43.10062252651018]),
            {
              "class": 2,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.029296875, 43.14372409344203]),
            {
              "class": 2,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.79995727539062, 43.200811921815394]),
            {
              "class": 2,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.8095703125, 43.146730046334476]),
            {
              "class": 2,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.98809814453125, 43.404688932858996]),
            {
              "class": 2,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2984619140625, 43.511351032890694]),
            {
              "class": 2,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29022216796875, 43.57704878009714]),
            {
              "class": 2,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.31631469726562, 43.572533769001865]),
            {
              "class": 2,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2706527709961, 43.58055018248203]),
            {
              "class": 2,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.35133361816406, 43.50340225944673]),
            {
              "class": 2,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.37124633789062, 43.492195162220575]),
            {
              "class": 2,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2322006225586, 43.56438218491436]),
            {
              "class": 2,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27923583984375, 43.64418500607884]),
            {
              "class": 2,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.31322479248047, 43.677467011916356]),
            {
              "class": 2,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29640197753906, 43.72809971515939]),
            {
              "class": 2,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.31597137451172, 43.70402969369175]),
            {
              "class": 2,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.20267486572266, 43.55642096092969]),
            {
              "class": 2,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.281982421875, 43.50190809999934]),
            {
              "class": 2,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2768325805664, 43.54771216767767]),
            {
              "class": 2,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.24147033691406, 43.54721448433896]),
            {
              "class": 2,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.31116485595703, 43.54373058591151]),
            {
              "class": 2,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.2926254272461, 43.56388463923485]),
            {
              "class": 2,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3757095336914, 43.559655335046905]),
            {
              "class": 2,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.32901763916016, 43.60914446808784]),
            {
              "class": 2,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.40592193603516, 43.583285875717564]),
            {
              "class": 2,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.4361343383789, 43.55318641319733]),
            {
              "class": 2,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.40214538574219, 43.661325059501664]),
            {
              "class": 2,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.4141616821289, 43.70502246302563]),
            {
              "class": 2,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29605865478516, 43.668030705306656]),
            {
              "class": 2,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.25039672851562, 43.633004074918325]),
            {
              "class": 2,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.26447296142578, 43.72264138279025]),
            {
              "class": 2,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.25211334228516, 43.75835962264717]),
            {
              "class": 2,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.32249450683594, 43.80520747373245]),
            {
              "class": 2,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29949188232422, 43.89038130120662]),
            {
              "class": 2,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.27820587158203, 43.93193361703135]),
            {
              "class": 2,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.29125213623047, 43.95245173271468]),
            {
              "class": 2,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.37433624267578, 43.990008718196954]),
            {
              "class": 2,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.37193298339844, 44.016926407788446]),
            {
              "class": 2,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.39390563964844, 44.04580611631252]),
            {
              "class": 2,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.37433624267578, 43.95838336197832]),
            {
              "class": 2,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3643798828125, 43.97716294847452]),
            {
              "class": 2,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.32455444335938, 43.99988818805009]),
            {
              "class": 2,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.36712646484375, 43.930944613323135]),
            {
              "class": 2,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.391845703125, 43.88790703427814]),
            {
              "class": 2,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.40626525878906, 43.86513895595846]),
            {
              "class": 2,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.52780151367188, 43.86142594445332]),
            {
              "class": 2,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.48179626464844, 43.88939160676933]),
            {
              "class": 2,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.52986145019531, 43.93860896188488]),
            {
              "class": 2,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.57174682617188, 43.936136699311]),
            {
              "class": 2,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.53913116455078, 44.02828250187057]),
            {
              "class": 2,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.5013656616211, 44.02704824918996]),
            {
              "class": 2,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.71388244628906, 43.966538385442576]),
            {
              "class": 2,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.78254699707031, 43.94033948452606]),
            {
              "class": 2,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.79593658447266, 43.98605646972177]),
            {
              "class": 2,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.98064422607422, 43.987538593739124]),
            {
              "class": 2,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99128723144531, 44.04111720621248]),
            {
              "class": 2,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.05754852294922, 43.98803262685447]),
            {
              "class": 2,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.02424621582031, 43.892855465350806]),
            {
              "class": 2,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.10698699951172, 43.92377384459054]),
            {
              "class": 2,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.10801696777344, 43.84855238081213]),
            {
              "class": 2,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.02767944335938, 43.83220885554656]),
            {
              "class": 2,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.17839813232422, 43.81462218592093]),
            {
              "class": 2,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.1111068725586, 43.75885555927787]),
            {
              "class": 2,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.16294860839844, 43.79727814400046]),
            {
              "class": 2,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.11797332763672, 43.74124729168427]),
            {
              "class": 2,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.19041442871094, 43.71643812866073]),
            {
              "class": 2,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.20037078857422, 43.69856916847336]),
            {
              "class": 2,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.1385726928711, 43.719167639601906]),
            {
              "class": 2,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.09771728515625, 43.6968316243343]),
            {
              "class": 2,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.14303588867188, 43.68541222455755]),
            {
              "class": 2,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.05548858642578, 43.64095517300965]),
            {
              "class": 2,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0235595703125, 43.58975156556918]),
            {
              "class": 2,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.18389129638672, 43.5608992788629]),
            {
              "class": 2,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0561752319336, 43.556918568248165]),
            {
              "class": 2,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84915161132812, 43.63946442225876]),
            {
              "class": 2,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.53579711914062, 43.92492138022804]),
            {
              "class": 2,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.32774353027344, 44.034117854797515]),
            {
              "class": 2,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.568284034729, 44.06450022585362]),
            {
              "class": 2,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.63201332092285, 44.06949659460765]),
            {
              "class": 2,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5066146850586, 44.103897929772565]),
            {
              "class": 2,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.4915943145752, 44.11616166640199]),
            {
              "class": 2,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.48378372192383, 44.127498736585885]),
            {
              "class": 2,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.53888702392578, 44.120598170345474]),
            {
              "class": 2,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.52832984924316, 44.09341935542257]),
            {
              "class": 2,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.622314453125, 44.6272672790851]),
            {
              "class": 2,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.91482543945312, 44.59722477881743]),
            {
              "class": 2,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.93782806396484, 44.57228385377018]),
            {
              "class": 2,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.97765350341797, 44.56078786543891]),
            {
              "class": 2,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9852066040039, 44.569348923797655]),
            {
              "class": 2,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.07300066947937, 44.59095998914709]),
            {
              "class": 2,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1221923828125, 44.602358346831004]),
            {
              "class": 2,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.08543539047241, 44.595779209891774]),
            {
              "class": 2,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09331035614014, 44.59639038792959]),
            {
              "class": 2,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.08249568939209, 44.605053145243645]),
            {
              "class": 2,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09103584289551, 44.60832235106278]),
            {
              "class": 2,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.08249568939209, 44.61209545801243]),
            {
              "class": 2,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1051549911499, 44.61670839741741]),
            {
              "class": 2,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.11772918701172, 44.63136173843074]),
            {
              "class": 2,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.16991424560547, 44.63197254210555]),
            {
              "class": 2,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18193054199219, 44.636003685137425]),
            {
              "class": 2,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18424797058105, 44.626757837511846]),
            {
              "class": 2,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18733787536621, 44.621733334903176]),
            {
              "class": 2,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.19064235687256, 44.61987003495569]),
            {
              "class": 2,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18740224838257, 44.626834194379114]),
            {
              "class": 2,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18540668487549, 44.61380077036687]),
            {
              "class": 2,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20437526702881, 44.59950180520224]),
            {
              "class": 2,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.21450328826904, 44.596782159220524]),
            {
              "class": 2,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.22248554229736, 44.587980634620244]),
            {
              "class": 2,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20489025115967, 44.5936956652021]),
            {
              "class": 2,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18068599700928, 44.58501593216199]),
            {
              "class": 2,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18321800231934, 44.59644601436155]),
            {
              "class": 2,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.17862606048584, 44.59821839262301]),
            {
              "class": 2,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15858459472656, 44.69143401480481]),
            {
              "class": 2,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15789794921875, 44.73693513241398]),
            {
              "class": 2,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04151153564453, 44.71364010187547]),
            {
              "class": 2,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02056884765625, 44.752541211958736]),
            {
              "class": 2,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.05284118652344, 44.788735964371355]),
            {
              "class": 2,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02314376831055, 44.84097722870044]),
            {
              "class": 2,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.11858749389648, 44.82807353287832]),
            {
              "class": 2,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.16081619262695, 44.803353672965514]),
            {
              "class": 2,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.22501754760742, 44.836716893927566]),
            {
              "class": 2,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.24475860595703, 44.80067403692787]),
            {
              "class": 2,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.27582931518555, 44.84645433911049]),
            {
              "class": 2,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.2620964050293, 44.87346712930621]),
            {
              "class": 2,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.23651885986328, 44.900710432763155]),
            {
              "class": 2,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.17849731445312, 44.942523240336634]),
            {
              "class": 2,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09592819213867, 44.92660392744312]),
            {
              "class": 2,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.12717056274414, 44.97276992106745]),
            {
              "class": 2,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1884536743164, 44.97714161595229]),
            {
              "class": 2,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.12648391723633, 44.989404869707165]),
            {
              "class": 2,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.08717346191406, 45.02096157353313]),
            {
              "class": 2,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9460678100586, 44.9914687238003]),
            {
              "class": 2,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.87594413757324, 44.97789201877765]),
            {
              "class": 2,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.86718940734863, 44.95548385291022]),
            {
              "class": 2,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9050407409668, 44.93586193220062]),
            {
              "class": 2,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.88881874084473, 44.912586380956206]),
            {
              "class": 2,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.84255599975586, 44.93002873710491]),
            {
              "class": 2,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.8087387084961, 44.94272732978031]),
            {
              "class": 2,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.81783676147461, 44.920426980169616]),
            {
              "class": 2,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.78316116333008, 44.90717635163852]),
            {
              "class": 2,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.79818153381348, 44.921460157648724]),
            {
              "class": 2,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.75466537475586, 44.929421078543015]),
            {
              "class": 2,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.7665958404541, 44.889909482219394]),
            {
              "class": 2,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.73406600952148, 44.90194819909201]),
            {
              "class": 2,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.67604446411133, 44.90362859284993]),
            {
              "class": 2,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.73337936401367, 44.754735479008005]),
            {
              "class": 2,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.7816162109375, 44.76290229636188]),
            {
              "class": 2,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.68153762817383, 44.77545500308018]),
            {
              "class": 2,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6917085647583, 44.788220565470816]),
            {
              "class": 2,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.67900562286377, 44.80146813948996]),
            {
              "class": 2,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.65402889251709, 44.76461103018953]),
            {
              "class": 2,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.62759304046631, 44.77362948881931]),
            {
              "class": 2,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59935474395752, 44.78672811942866]),
            {
              "class": 2,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.61729335784912, 44.810480841895824]),
            {
              "class": 2,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.62034034729004, 44.83881904713948]),
            {
              "class": 2,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59360408782959, 44.854945207910895]),
            {
              "class": 2,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59368991851807, 44.87976458398232]),
            {
              "class": 2,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59622192382812, 44.89995284582803]),
            {
              "class": 2,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.60849571228027, 44.90784503452704]),
            {
              "class": 2,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.65149688720703, 44.992396295780274]),
            {
              "class": 2,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59004211425781, 45.02710590167471]),
            {
              "class": 2,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.50833129882812, 45.00356391838879]),
            {
              "class": 2,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5234375, 45.045301831511864]),
            {
              "class": 2,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9686279296875, 44.74030550307439]),
            {
              "class": 2,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96725463867188, 44.767124286319984]),
            {
              "class": 2,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.98682403564453, 44.79514879790964]),
            {
              "class": 2,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0129165649414, 44.842394100592834]),
            {
              "class": 2,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.93841552734375, 44.83484719220788]),
            {
              "class": 2,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96691131591797, 44.851643801087825]),
            {
              "class": 2,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.88279724121094, 44.79393062374496]),
            {
              "class": 2,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84674835205078, 44.76566176451365]),
            {
              "class": 2,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9188461303711, 44.72567183012582]),
            {
              "class": 2,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01737976074219, 44.696881471332816]),
            {
              "class": 2,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.91438293457031, 44.6736923862147]),
            {
              "class": 2,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.90133666992188, 44.697613607033865]),
            {
              "class": 2,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.88056564331055, 44.67849687428937]),
            {
              "class": 2,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.83473205566406, 44.6520033392899]),
            {
              "class": 2,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.79473495483398, 44.649560929418115]),
            {
              "class": 2,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.76812744140625, 44.65786470333837]),
            {
              "class": 2,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.765380859375, 44.68545399762207]),
            {
              "class": 2,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.80297470092773, 44.69289841469607]),
            {
              "class": 2,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.83953857421875, 44.53598808577065]),
            {
              "class": 2,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.00914001464844, 44.487512590973715]),
            {
              "class": 2,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.19522094726562, 44.58833545276299]),
            {
              "class": 2,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9466552734375, 44.42379666715624]),
            {
              "class": 2,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7763671875, 44.402706099271796]),
            {
              "class": 2,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.61912536621094, 44.526198306476836]),
            {
              "class": 2,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.64590454101562, 44.58099987548252]),
            {
              "class": 2,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.63560485839844, 44.67775496069377]),
            {
              "class": 2,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.50376892089844, 44.65773305811076]),
            {
              "class": 2,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.4522705078125, 44.67775496069377]),
            {
              "class": 2,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.42068481445312, 44.67384879106689]),
            {
              "class": 2,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.260009765625, 44.78848278653915]),
            {
              "class": 2,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.13984680175781, 44.86688811199913]),
            {
              "class": 2,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3863525390625, 44.890242974934914]),
            {
              "class": 2,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.35545349121094, 44.93705527166638]),
            {
              "class": 2,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.32129287719727, 44.93887798574922]),
            {
              "class": 2,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28953552246094, 44.91979737853281]),
            {
              "class": 2,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.3508186340332, 44.95940989953291]),
            {
              "class": 2,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.40592193603516, 44.97580585565166]),
            {
              "class": 2,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.4086685180664, 45.00045169342856]),
            {
              "class": 2,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.19203186035156, 44.971424571165564]),
            {
              "class": 2,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.9139404296875, 44.96170827254956]),
            {
              "class": 2,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.82879638671875, 45.040848154341035]),
            {
              "class": 2,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.79789733886719, 45.06704216810028]),
            {
              "class": 2,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.67430114746094, 45.02095209396142]),
            {
              "class": 2,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.68185424804688, 45.05346158455151]),
            {
              "class": 2,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.82192993164062, 44.90191685153999]),
            {
              "class": 2,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.62898254394531, 44.83816810583491]),
            {
              "class": 2,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.61250305175781, 44.7211933387735]),
            {
              "class": 2,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.64202880859375, 44.74899630419865]),
            {
              "class": 2,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.75051879882812, 44.66408221502728]),
            {
              "class": 2,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.44839477539062, 44.59615904824871]),
            {
              "class": 2,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.34059143066406, 44.68117264312197]),
            {
              "class": 2,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.22317504882812, 44.618489464858555]),
            {
              "class": 2,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.13288116455078, 44.65659975205051]),
            {
              "class": 2,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.1448974609375, 44.69492906420684]),
            {
              "class": 2,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.16824340820312, 44.758348600049246]),
            {
              "class": 2,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.02233123779297, 44.861622075277026]),
            {
              "class": 2,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.20703887939453, 44.86308216549139]),
            {
              "class": 2,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30213928222656, 44.863812196712416]),
            {
              "class": 2,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.01615142822266, 44.69736956282874]),
            {
              "class": 2,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.89118194580078, 44.715426055869976]),
            {
              "class": 2,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.03228759765625, 44.615801256314604]),
            {
              "class": 2,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.98731231689453, 44.52653103301895]),
            {
              "class": 2,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.8595962524414, 44.48955999626852]),
            {
              "class": 2,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79608154296875, 44.4795174548409]),
            {
              "class": 2,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.71162414550781, 44.443742170539025]),
            {
              "class": 2,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.62064361572266, 44.45746678904238]),
            {
              "class": 2,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.55472564697266, 44.49886617388695]),
            {
              "class": 2,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5516357421875, 44.59135728854798]),
            {
              "class": 2,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.50460052490234, 44.62704202771839]),
            {
              "class": 2,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.45138549804688, 44.654645987240784]),
            {
              "class": 2,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.62648010253906, 44.68882736765906]),
            {
              "class": 2,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.32813262939453, 44.60700261276946]),
            {
              "class": 2,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.34632873535156, 44.673936530189394]),
            {
              "class": 2,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.1777572631836, 44.71225437707906]),
            {
              "class": 2,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.28144073486328, 44.679551557728246]),
            {
              "class": 2,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.20384979248047, 44.81195697539341]),
            {
              "class": 2,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.01124572753906, 44.685898324977124]),
            {
              "class": 2,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02703857421875, 44.52873386424971]),
            {
              "class": 2,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.19355010986328, 44.44913436958192]),
            {
              "class": 2,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.03047180175781, 44.44766381920723]),
            {
              "class": 2,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.31439971923828, 44.44962454481276]),
            {
              "class": 2,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.35559844970703, 44.399605481854394]),
            {
              "class": 2,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48159790039062, 44.44447749971852]),
            {
              "class": 2,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.35765838623047, 44.33824924972076]),
            {
              "class": 2,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.31096649169922, 44.28764341525178]),
            {
              "class": 2,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.22616577148438, 44.19934740797619]),
            {
              "class": 2,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.1396484375, 44.26576623041691]),
            {
              "class": 2,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.00094604492188, 44.219526976027964]),
            {
              "class": 2,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.98274993896484, 44.306072921153216]),
            {
              "class": 2,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.09982299804688, 44.151577976017784]),
            {
              "class": 2,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.14926147460938, 44.10031828007854]),
            {
              "class": 2,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.15475463867188, 44.12891090433528]),
            {
              "class": 2,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.0352783203125, 44.09735963280326]),
            {
              "class": 2,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.98961639404297, 44.120531740776954]),
            {
              "class": 2,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.86361694335938, 44.17152765052842]),
            {
              "class": 2,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.90035247802734, 44.11856000015468]),
            {
              "class": 2,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.9470443725586, 44.10031828007854]),
            {
              "class": 2,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.7001953125, 44.17792981955643]),
            {
              "class": 2,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6287841796875, 44.18039200718543]),
            {
              "class": 2,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6397705078125, 44.09908552837234]),
            {
              "class": 2,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.78053283691406, 43.99593659748132]),
            {
              "class": 2,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.645263671875, 43.95665336460499]),
            {
              "class": 2,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72663116455078, 43.889144180590385]),
            {
              "class": 2,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72422790527344, 43.85721758518546]),
            {
              "class": 2,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.78018951416016, 43.81536538946728]),
            {
              "class": 2,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6009750366211, 43.730828694834706]),
            {
              "class": 2,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.67478942871094, 43.69087394789544]),
            {
              "class": 2,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.65247344970703, 43.633252562659116]),
            {
              "class": 2,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.74036407470703, 43.605415549198504]),
            {
              "class": 2,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.80078887939453, 43.59795701792922]),
            {
              "class": 2,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.54329681396484, 43.68044658995972]),
            {
              "class": 2,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4966049194336, 43.765550301466625]),
            {
              "class": 2,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.83512115478516, 43.73157294043919]),
            {
              "class": 2,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.94532775878906, 43.71147506294494]),
            {
              "class": 2,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.00884246826172, 43.714949252104304]),
            {
              "class": 2,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02669525146484, 43.64269433546971]),
            {
              "class": 2,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.82482147216797, 43.53277988004326]),
            {
              "class": 2,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.87220001220703, 43.501410038632535]),
            {
              "class": 2,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.86052703857422, 43.462299400554684]),
            {
              "class": 2,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.7822494506836, 43.490451649035734]),
            {
              "class": 2,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.64732360839844, 43.532530977250815]),
            {
              "class": 2,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.72817611694336, 43.53888253844586]),
            {
              "class": 2,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70448684692383, 43.554497553379555]),
            {
              "class": 2,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.69787788391113, 43.56202366535329]),
            {
              "class": 2,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.68946647644043, 43.577073069105786]),
            {
              "class": 2,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.70980834960938, 43.572591095344485]),
            {
              "class": 2,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.64320373535156, 43.57209361746876]),
            {
              "class": 2,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.60818481445312, 43.49344049796546]),
            {
              "class": 2,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6068115234375, 43.44585042704435]),
            {
              "class": 2,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.53952026367188, 43.44983846783193]),
            {
              "class": 2,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.45506286621094, 43.45282932586845]),
            {
              "class": 2,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.41386413574219, 43.451832389623405]),
            {
              "class": 2,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.40150451660156, 43.57557587630237]),
            {
              "class": 2,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3318099975586, 43.549702859940744]),
            {
              "class": 2,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.11880493164062, 44.35492532995328]),
            {
              "class": 2,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58734130859375, 44.10991360285311]),
            {
              "class": 2,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.90594482421875, 43.95490400801023]),
            {
              "class": 2,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.90869140625, 43.83912367266654]),
            {
              "class": 2,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80294799804688, 44.042388039695034]),
            {
              "class": 2,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79455804824829, 44.0535696205839]),
            {
              "class": 2,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79352807998657, 44.063130125702564]),
            {
              "class": 2,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.78567457199097, 44.068788600593706]),
            {
              "class": 2,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.7792158126831, 44.07564896857322]),
            {
              "class": 2,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.88362884521484, 44.25912772135859]),
            {
              "class": 2,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.91178131103516, 44.323514190331075]),
            {
              "class": 2,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.92345428466797, 44.36770826238641]),
            {
              "class": 2,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.0017318725586, 44.342177973662515]),
            {
              "class": 2,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.06455993652344, 44.37335288201362]),
            {
              "class": 2,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.40950012207031, 44.1128908793388]),
            {
              "class": 2,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.21346282958984, 44.06085747714423]),
            {
              "class": 2,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.216552734375, 44.09390769053387]),
            {
              "class": 2,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.14170837402344, 44.06579151682141]),
            {
              "class": 2,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.37173461914062, 43.961843205618486]),
            {
              "class": 2,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.43868255615234, 43.957147654708464]),
            {
              "class": 2,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.37860107421875, 43.87899882228715]),
            {
              "class": 2,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.42941284179688, 43.825521577579615]),
            {
              "class": 2,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.3894157409668, 43.81016760935743]),
            {
              "class": 2,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.37894439697266, 43.832770932015144]),
            {
              "class": 2,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.42177391052246, 43.77894237983043]),
            {
              "class": 2,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.43576431274414, 43.75681463745862]),
            {
              "class": 2,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48211288452148, 43.73356239532792]),
            {
              "class": 2,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.51816177368164, 43.72252217005289]),
            {
              "class": 2,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5102653503418, 43.679644485034636]),
            {
              "class": 2,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48786354064941, 43.662137111158785]),
            {
              "class": 2,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.46108436584473, 43.61996187996025]),
            {
              "class": 2,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.490966796875, 43.67709067447787]),
            {
              "class": 2,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.10919189453125, 43.16239931283448]),
            {
              "class": 2,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.13665771484375, 42.762421201227305]),
            {
              "class": 2,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.2110595703125, 42.89938959372931]),
            {
              "class": 2,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.9638671875, 43.350429152140755]),
            {
              "class": 2,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58734130859375, 43.10828341722099]),
            {
              "class": 2,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.2220458984375, 43.56176613702453]),
            {
              "class": 2,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58184814453125, 43.496051727976244]),
            {
              "class": 2,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.88922119140625, 43.758479732677145]),
            {
              "class": 2,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.578857421875, 42.99589038957521]),
            {
              "class": 2,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.22454833984375, 42.873227927997405]),
            {
              "class": 2,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4857177734375, 42.55235317106699]),
            {
              "class": 2,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.8155517578125, 42.760404695630854]),
            {
              "class": 2,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6507568359375, 42.905425325527034]),
            {
              "class": 2,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.4417724609375, 42.03224118517247]),
            {
              "class": 2,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.88421630859375, 41.93785765629011]),
            {
              "class": 2,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.85125732421875, 42.05063903048904]),
            {
              "class": 2,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.87460327148438, 42.10619063157895]),
            {
              "class": 2,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.98858642578125, 42.182558271201124]),
            {
              "class": 2,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.2220458984375, 42.246635893045756]),
            {
              "class": 2,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.29483032226562, 42.20595922347042]),
            {
              "class": 2,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.128662109375, 42.37662508034477]),
            {
              "class": 2,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.73727416992188, 42.2725535892152]),
            {
              "class": 2,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.57316589355469, 42.27306167284775]),
            {
              "class": 2,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.43721008300781, 42.25273513287137]),
            {
              "class": 2,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.2552490234375, 42.213588095390804]),
            {
              "class": 2,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.15499877929688, 42.25832558462443]),
            {
              "class": 2,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.18521118164062, 42.00932607181961]),
            {
              "class": 2,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.95655822753906, 41.896982559758044]),
            {
              "class": 2,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.66748046875, 42.0939632614029]),
            {
              "class": 2,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.66147232055664, 42.09919809436954]),
            {
              "class": 2,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.66638612747192, 42.11139324054867]),
            {
              "class": 2,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.67917490005493, 42.13874278710913]),
            {
              "class": 2,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73528671264648, 42.151546021616355]),
            {
              "class": 2,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.72979354858398, 42.207327124154546]),
            {
              "class": 2,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64628028869629, 42.2093615360364]),
            {
              "class": 2,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.67091369628906, 42.23274759846293]),
            {
              "class": 2,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.94548606872559, 42.23504035072857]),
            {
              "class": 2,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.98153495788574, 42.23885314537131]),
            {
              "class": 2,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92737579345703, 42.182654666872864]),
            {
              "class": 2,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92780494689941, 42.20917081270576]),
            {
              "class": 2,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89750671386719, 42.16649789337296]),
            {
              "class": 2,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.85502052307129, 42.13888188690164]),
            {
              "class": 2,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.83382034301758, 42.10596875288231]),
            {
              "class": 2,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.80180549621582, 42.089219147350235]),
            {
              "class": 2,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.77983283996582, 42.04531802719905]),
            {
              "class": 2,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7733097076416, 42.026639700781054]),
            {
              "class": 2,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.76206588745117, 42.00042979435735]),
            {
              "class": 2,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73254013061523, 41.96329656137522]),
            {
              "class": 2,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6949462890625, 41.94184895926941]),
            {
              "class": 2,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.53976440429688, 42.032372674163675]),
            {
              "class": 2,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.6400146484375, 41.95914304833372]),
            {
              "class": 2,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.58885955810547, 42.00610135234547]),
            {
              "class": 2,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.52568817138672, 42.08870460809357]),
            {
              "class": 2,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.47968292236328, 42.113413702196944]),
            {
              "class": 2,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.48234367370605, 42.081893785232246]),
            {
              "class": 2,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.45444869995117, 42.03722263484048]),
            {
              "class": 2,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46011352539062, 41.99360451882952]),
            {
              "class": 2,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41548156738281, 41.964253875327074]),
            {
              "class": 2,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.44638061523438, 41.91815884863576]),
            {
              "class": 2,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.4598560333252, 41.93686901952479]),
            {
              "class": 2,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46054267883301, 41.88730382435411]),
            {
              "class": 2,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50895118713379, 41.89178797162585]),
            {
              "class": 2,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50045394897461, 41.90734401931901]),
            {
              "class": 2,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.52040958404541, 41.879902770469414]),
            {
              "class": 2,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50774955749512, 41.86507511975509]),
            {
              "class": 2,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.51710510253906, 41.78056994322841]),
            {
              "class": 2,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.48423194885254, 41.78556206988294]),
            {
              "class": 2,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.54345512390137, 41.728065092811285]),
            {
              "class": 2,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.49144172668457, 41.7313959441332]),
            {
              "class": 2,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.43118858337402, 41.70256554988395]),
            {
              "class": 2,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50225639343262, 41.6962852157907]),
            {
              "class": 2,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.45127296447754, 41.675645514118784]),
            {
              "class": 2,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.41136169433594, 41.64159477458839]),
            {
              "class": 2,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35685920715332, 41.659423960906366]),
            {
              "class": 2,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.31196975708008, 41.641787202217195]),
            {
              "class": 2,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.29463195800781, 41.661668292896216]),
            {
              "class": 2,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.24279022216797, 41.66878551409319]),
            {
              "class": 2,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.568115234375, 41.25885582702496]),
            {
              "class": 2,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5076904296875, 41.44647408633684]),
            {
              "class": 2,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.37722778320312, 41.5102644908024]),
            {
              "class": 2,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.96224975585938, 41.58118320701399]),
            {
              "class": 2,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.94989013671875, 41.536996618332566]),
            {
              "class": 2,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.43353271484375, 41.65305023277831]),
            {
              "class": 2,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.77960205078125, 41.73611068509009]),
            {
              "class": 2,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.1890869140625, 41.63970955477197]),
            {
              "class": 2,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.12042236328125, 41.48249251622283]),
            {
              "class": 2,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.238525390625, 41.40219548508769]),
            {
              "class": 2,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.99957275390625, 41.26917856000175]),
            {
              "class": 2,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.8924560546875, 41.1813833224168]),
            {
              "class": 2,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.25088500976562, 41.10071458542731]),
            {
              "class": 2,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.35113525390625, 40.976415139187985]),
            {
              "class": 2,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.23165893554688, 40.86746062529802]),
            {
              "class": 2,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.05999755859375, 40.90587461464532]),
            {
              "class": 2,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.95562744140625, 40.95774997941324]),
            {
              "class": 2,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.81829833984375, 40.95152708627705]),
            {
              "class": 2,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.68096923828125, 40.997148013190646]),
            {
              "class": 2,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.75650024414062, 41.17518155783299]),
            {
              "class": 2,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.78945922851562, 41.47426149620047]),
            {
              "class": 2,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.88534545898438, 41.18241689275646]),
            {
              "class": 2,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.38796997070312, 41.14106135671863]),
            {
              "class": 2,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.9910888671875, 41.16587780994559]),
            {
              "class": 2,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.52716064453125, 41.330049465782984]),
            {
              "class": 2,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.26898193359375, 41.124511835701874]),
            {
              "class": 2,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.1343994140625, 41.058272007828315]),
            {
              "class": 2,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0135498046875, 41.08208463360907]),
            {
              "class": 2,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.05886840820312, 41.261952818257264]),
            {
              "class": 2,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.19894409179688, 41.43514987638637]),
            {
              "class": 2,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.32803344726562, 41.666388148372135]),
            {
              "class": 2,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.45437622070312, 41.67869761848302]),
            {
              "class": 2,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.30606079101562, 41.819063857717516]),
            {
              "class": 2,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.97235107421875, 41.8057576142226]),
            {
              "class": 2,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.84326171875, 41.7104861871423]),
            {
              "class": 2,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.74688720703125, 41.79142472232583]),
            {
              "class": 2,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.40081787109375, 40.73231578955833]),
            {
              "class": 2,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.06024169921875, 40.711499858206516]),
            {
              "class": 2,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.02566528320312, 40.38592893671095]),
            {
              "class": 2,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.3978271484375, 40.24351835655678]),
            {
              "class": 2,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48846435546875, 40.14176266612325]),
            {
              "class": 2,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.84002685546875, 40.11236149738583]),
            {
              "class": 2,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.96224975585938, 40.129163722392356]),
            {
              "class": 2,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.64776611328125, 40.003045847889375]),
            {
              "class": 2,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48846435546875, 40.01251278666085]),
            {
              "class": 2,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.56375122070312, 40.161706216324816]),
            {
              "class": 2,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.28610229492188, 40.27914915672145]),
            {
              "class": 2,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.07186889648438, 40.435074509338094]),
            {
              "class": 2,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.10345458984375, 40.549955732216276]),
            {
              "class": 2,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.50332641601562, 40.645887130035895]),
            {
              "class": 2,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.16549682617188, 41.19378508988893]),
            {
              "class": 2,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.30831909179688, 41.338298773713696]),
            {
              "class": 2,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.99383544921875, 41.30632688647925]),
            {
              "class": 2,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.58871459960938, 41.453679372889226]),
            {
              "class": 2,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.62579345703125, 41.69203022132222]),
            {
              "class": 2,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.61642456054688, 41.92643602221482]),
            {
              "class": 2,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.92703247070312, 42.3987577064538]),
            {
              "class": 2,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.55075073242188, 42.59013627071408]),
            {
              "class": 2,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.94650268554688, 42.73555533133328]),
            {
              "class": 2,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.00830078125, 42.95003053975203]),
            {
              "class": 2,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.09756469726562, 43.05448025844195]),
            {
              "class": 2,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.84625244140625, 43.10363059791023]),
            {
              "class": 2,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.47821044921875, 43.13570749644015]),
            {
              "class": 2,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.52421569824219, 43.45785854075407]),
            {
              "class": 2,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.55940628051758, 43.48987371000921]),
            {
              "class": 2,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.61279296875, 43.502948957167895]),
            {
              "class": 2,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.53520202636719, 43.517017250595266]),
            {
              "class": 2,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43272018432617, 43.51788862993978]),
            {
              "class": 2,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73776245117188, 43.40486821062996]),
            {
              "class": 2,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.79681396484375, 43.54787158100319]),
            {
              "class": 2,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.71304321289062, 43.670673175924485]),
            {
              "class": 2,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50498962402344, 43.69351541263169]),
            {
              "class": 2,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87989807128906, 43.41733840550032]),
            {
              "class": 2,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92109680175781, 43.395389145347465]),
            {
              "class": 2,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.10305786132812, 43.528956775433585]),
            {
              "class": 2,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.97259521484375, 43.642356600270396]),
            {
              "class": 2,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.90324401855469, 43.27402612897451]),
            {
              "class": 2,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.98495483398438, 43.185973907070135]),
            {
              "class": 2,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.85861206054688, 43.17696139633571]),
            {
              "class": 2,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.20330810546875, 43.20249338802082]),
            {
              "class": 2,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.99525451660156, 43.06068107874388]),
            {
              "class": 2,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.88058471679688, 43.0084836924366]),
            {
              "class": 2,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.78514099121094, 42.97935432822303]),
            {
              "class": 2,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.61210632324219, 43.0942847257432]),
            {
              "class": 2,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.40885925292969, 43.1589323837362]),
            {
              "class": 2,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.35942077636719, 43.27802548013184]),
            {
              "class": 2,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.16029357910156, 43.43363541648251]),
            {
              "class": 2,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.12321472167969, 43.514856253325085]),
            {
              "class": 2,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.99378204345703, 43.59596792009477]),
            {
              "class": 2,
              "system:index": "780"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.98519897460938, 43.646669374897016]),
            {
              "class": 2,
              "system:index": "781"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84134674072266, 43.64194898629444]),
            {
              "class": 2,
              "system:index": "782"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.71466064453125, 43.618838575341854]),
            {
              "class": 2,
              "system:index": "783"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.67105865478516, 43.57706821130483]),
            {
              "class": 2,
              "system:index": "784"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.79122161865234, 43.56164563282469]),
            {
              "class": 2,
              "system:index": "785"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.80083465576172, 43.55492811431894]),
            {
              "class": 2,
              "system:index": "786"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9086594581604, 43.547935978034936]),
            {
              "class": 2,
              "system:index": "787"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90005493164062, 43.55177731877241]),
            {
              "class": 2,
              "system:index": "788"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91664171218872, 43.46429899510901]),
            {
              "class": 2,
              "system:index": "789"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9027156829834, 43.46266369817344]),
            {
              "class": 2,
              "system:index": "790"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9116849899292, 43.47038814035075]),
            {
              "class": 2,
              "system:index": "791"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8741340637207, 43.23690438082695]),
            {
              "class": 2,
              "system:index": "792"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93352890014648, 43.24778363326225]),
            {
              "class": 2,
              "system:index": "793"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.82366561889648, 43.2479086708473]),
            {
              "class": 2,
              "system:index": "794"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83036041259766, 43.272536069126666]),
            {
              "class": 2,
              "system:index": "795"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84615325927734, 43.29827792217708]),
            {
              "class": 2,
              "system:index": "796"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.84546661376953, 43.27316100037237]),
            {
              "class": 2,
              "system:index": "797"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.8434066772461, 43.238530139706114]),
            {
              "class": 2,
              "system:index": "798"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87396240234375, 43.182729321771944]),
            {
              "class": 2,
              "system:index": "799"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91601943969727, 43.15656294148894]),
            {
              "class": 2,
              "system:index": "800"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.85078811645508, 43.137150013437555]),
            {
              "class": 2,
              "system:index": "801"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.91498947143555, 43.08576996648579]),
            {
              "class": 2,
              "system:index": "802"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.93644714355469, 43.077495001609925]),
            {
              "class": 2,
              "system:index": "803"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.00494003295898, 43.10206587088021]),
            {
              "class": 2,
              "system:index": "804"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.90348815917969, 43.020919497048375]),
            {
              "class": 2,
              "system:index": "805"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.83739852905273, 43.04877471474168]),
            {
              "class": 2,
              "system:index": "806"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.80169296264648, 43.0683410872132]),
            {
              "class": 2,
              "system:index": "807"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.76873397827148, 43.02782174268858]),
            {
              "class": 2,
              "system:index": "808"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.74092483520508, 43.074360253362634]),
            {
              "class": 2,
              "system:index": "809"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.71860885620117, 43.00271894783454]),
            {
              "class": 2,
              "system:index": "810"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7254753112793, 42.95687989634377]),
            {
              "class": 2,
              "system:index": "811"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.66625213623047, 42.97986648704542]),
            {
              "class": 2,
              "system:index": "812"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.65045928955078, 43.02543741829586]),
            {
              "class": 2,
              "system:index": "813"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.569091796875, 43.041122063362806]),
            {
              "class": 2,
              "system:index": "814"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.56686019897461, 43.068466492537375]),
            {
              "class": 2,
              "system:index": "815"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.5222282409668, 43.01213369841743]),
            {
              "class": 2,
              "system:index": "816"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.48566436767578, 43.09467057476407]),
            {
              "class": 2,
              "system:index": "817"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.45047378540039, 43.13677421852877]),
            {
              "class": 2,
              "system:index": "818"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.34455871582031, 43.17884889207053]),
            {
              "class": 2,
              "system:index": "819"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2915153503418, 43.18210346269494]),
            {
              "class": 2,
              "system:index": "820"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27658081054688, 43.25203476716026]),
            {
              "class": 2,
              "system:index": "821"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.21976089477539, 43.25841091166326]),
            {
              "class": 2,
              "system:index": "822"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16379928588867, 43.23002569021938]),
            {
              "class": 2,
              "system:index": "823"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11487579345703, 43.16219779807455]),
            {
              "class": 2,
              "system:index": "824"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10062789916992, 43.14003103101167]),
            {
              "class": 2,
              "system:index": "825"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.05221939086914, 43.18147759720206]),
            {
              "class": 2,
              "system:index": "826"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01599884033203, 43.1199863572104]),
            {
              "class": 2,
              "system:index": "827"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.04294967651367, 43.08777585026142]),
            {
              "class": 2,
              "system:index": "828"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07350540161133, 43.04927649459461]),
            {
              "class": 2,
              "system:index": "829"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01531219482422, 42.985643186124534]),
            {
              "class": 2,
              "system:index": "830"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11333084106445, 42.94795928870442]),
            {
              "class": 2,
              "system:index": "831"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14440155029297, 42.930742630728126]),
            {
              "class": 2,
              "system:index": "832"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.09236669540405, 42.86875607584353]),
            {
              "class": 2,
              "system:index": "833"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.11049842834473, 42.86493315818012]),
            {
              "class": 2,
              "system:index": "834"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.13496017456055, 42.89977568606003]),
            {
              "class": 2,
              "system:index": "835"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0750503540039, 42.90241637489334]),
            {
              "class": 2,
              "system:index": "836"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10672187805176, 42.91253796766036]),
            {
              "class": 2,
              "system:index": "837"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.22576904296875, 42.87486728842568]),
            {
              "class": 2,
              "system:index": "838"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.06028747558594, 42.857756039570305]),
            {
              "class": 2,
              "system:index": "839"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94355773925781, 42.88467895262855]),
            {
              "class": 2,
              "system:index": "840"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84742736816406, 42.85171564284088]),
            {
              "class": 2,
              "system:index": "841"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89137268066406, 42.7955620422044]),
            {
              "class": 2,
              "system:index": "842"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96896362304688, 42.76557579805521]),
            {
              "class": 2,
              "system:index": "843"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91952514648438, 42.736331532242986]),
            {
              "class": 2,
              "system:index": "844"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.83747100830078, 42.773892766355345]),
            {
              "class": 2,
              "system:index": "845"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7619400024414, 42.75272010500701]),
            {
              "class": 2,
              "system:index": "846"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62632751464844, 42.73557503198413]),
            {
              "class": 2,
              "system:index": "847"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6410903930664, 42.758266025211014]),
            {
              "class": 2,
              "system:index": "848"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64864349365234, 42.65179865176901]),
            {
              "class": 2,
              "system:index": "849"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47904205322266, 42.656091151274566]),
            {
              "class": 2,
              "system:index": "850"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.43029022216797, 42.731288022866266]),
            {
              "class": 2,
              "system:index": "851"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6740493774414, 42.60759393481873]),
            {
              "class": 2,
              "system:index": "852"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.53775024414062, 42.57094338848848]),
            {
              "class": 2,
              "system:index": "853"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.56830596923828, 42.53528322625352]),
            {
              "class": 2,
              "system:index": "854"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5638427734375, 42.550460253788934]),
            {
              "class": 2,
              "system:index": "855"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55628967285156, 42.59268355426699]),
            {
              "class": 2,
              "system:index": "856"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6407470703125, 42.589144974091845]),
            {
              "class": 2,
              "system:index": "857"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64933013916016, 42.57928644144265]),
            {
              "class": 2,
              "system:index": "858"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5909652709961, 42.53123539581947]),
            {
              "class": 2,
              "system:index": "859"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62152099609375, 42.50567741132145]),
            {
              "class": 2,
              "system:index": "860"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.56075286865234, 42.53047639840628]),
            {
              "class": 2,
              "system:index": "861"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.536376953125, 42.55880604630202]),
            {
              "class": 2,
              "system:index": "862"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5525131225586, 42.634373112162294]),
            {
              "class": 2,
              "system:index": "863"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64383697509766, 42.72775732225932]),
            {
              "class": 2,
              "system:index": "864"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.68915557861328, 42.71968639476657]),
            {
              "class": 2,
              "system:index": "865"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7506103515625, 42.64876847373989]),
            {
              "class": 2,
              "system:index": "866"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81515502929688, 42.60633048162334]),
            {
              "class": 2,
              "system:index": "867"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.97994995117188, 42.53528322625352]),
            {
              "class": 2,
              "system:index": "868"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.02629852294922, 42.439583123901826]),
            {
              "class": 2,
              "system:index": "869"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03419494628906, 42.418043098301226]),
            {
              "class": 2,
              "system:index": "870"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98029327392578, 42.39725629455633]),
            {
              "class": 2,
              "system:index": "871"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.99883270263672, 42.38381725668498]),
            {
              "class": 2,
              "system:index": "872"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8937759399414, 42.358960136049575]),
            {
              "class": 2,
              "system:index": "873"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8333511352539, 42.3576916518589]),
            {
              "class": 2,
              "system:index": "874"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8663101196289, 42.373926315694135]),
            {
              "class": 2,
              "system:index": "875"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89274597167969, 42.32495590751544]),
            {
              "class": 2,
              "system:index": "876"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9044189453125, 42.27848759181831]),
            {
              "class": 2,
              "system:index": "877"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9699935913086, 42.2345269959379]),
            {
              "class": 2,
              "system:index": "878"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.0468978881836, 42.23045972799447]),
            {
              "class": 2,
              "system:index": "879"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9425277709961, 42.1821408861844]),
            {
              "class": 2,
              "system:index": "880"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03762817382812, 42.18112325021475]),
            {
              "class": 2,
              "system:index": "881"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10526275634766, 42.30870859291399]),
            {
              "class": 2,
              "system:index": "882"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1732406616211, 42.332062788583194]),
            {
              "class": 2,
              "system:index": "883"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2288589477539, 42.31429408044388]),
            {
              "class": 2,
              "system:index": "884"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.24224853515625, 42.356423142062155]),
            {
              "class": 2,
              "system:index": "885"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.25357818603516, 42.24367739050464]),
            {
              "class": 2,
              "system:index": "886"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33391571044922, 42.299567635094824]),
            {
              "class": 2,
              "system:index": "887"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.40155029296875, 42.35566202389325]),
            {
              "class": 2,
              "system:index": "888"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.32842254638672, 42.363019113385874]),
            {
              "class": 2,
              "system:index": "889"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.46678161621094, 42.34094526078267]),
            {
              "class": 2,
              "system:index": "890"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.404296875, 42.4264065754722]),
            {
              "class": 2,
              "system:index": "891"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.41116333007812, 42.44338353652286]),
            {
              "class": 2,
              "system:index": "892"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.39262390136719, 42.489223675072616]),
            {
              "class": 2,
              "system:index": "893"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.35279846191406, 42.439583123901826]),
            {
              "class": 2,
              "system:index": "894"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33082580566406, 42.374179949027535]),
            {
              "class": 2,
              "system:index": "895"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.23744201660156, 42.28737762686255]),
            {
              "class": 2,
              "system:index": "896"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.12208557128906, 42.34348287954214]),
            {
              "class": 2,
              "system:index": "897"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92879486083984, 42.265531295184076]),
            {
              "class": 2,
              "system:index": "898"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.84262084960938, 42.2345269959379]),
            {
              "class": 2,
              "system:index": "899"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.83103370666504, 42.24025111235479]),
            {
              "class": 2,
              "system:index": "900"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85772705078125, 42.244889599094584]),
            {
              "class": 2,
              "system:index": "901"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.83918762207031, 42.18468490445346]),
            {
              "class": 2,
              "system:index": "902"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78116607666016, 42.13022057070303]),
            {
              "class": 2,
              "system:index": "903"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89617919921875, 42.10806512733194]),
            {
              "class": 2,
              "system:index": "904"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9208984375, 42.05837823809584]),
            {
              "class": 2,
              "system:index": "905"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.83163452148438, 42.007887125724125]),
            {
              "class": 2,
              "system:index": "906"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.86528015136719, 42.010183046411385]),
            {
              "class": 2,
              "system:index": "907"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.95008087158203, 42.07494485785452]),
            {
              "class": 2,
              "system:index": "908"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9432144165039, 42.1162151565327]),
            {
              "class": 2,
              "system:index": "909"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.05204772949219, 42.11468710588243]),
            {
              "class": 2,
              "system:index": "910"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.96175384521484, 41.93871559302958]),
            {
              "class": 2,
              "system:index": "911"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91231536865234, 41.9029517962453]),
            {
              "class": 2,
              "system:index": "912"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87592315673828, 41.877138325600455]),
            {
              "class": 2,
              "system:index": "913"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9926528930664, 41.93386311048254]),
            {
              "class": 2,
              "system:index": "914"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01359558105469, 41.96450417066539]),
            {
              "class": 2,
              "system:index": "915"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.9981460571289, 41.99819232483904]),
            {
              "class": 2,
              "system:index": "916"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10835266113281, 41.97650123850642]),
            {
              "class": 2,
              "system:index": "917"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.15813446044922, 41.96348303928345]),
            {
              "class": 2,
              "system:index": "918"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.15950775146484, 42.00227452631054]),
            {
              "class": 2,
              "system:index": "919"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1926383972168, 41.99188213738353]),
            {
              "class": 2,
              "system:index": "920"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19984817504883, 42.00750944680646]),
            {
              "class": 2,
              "system:index": "921"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.21392440795898, 42.00859364833828]),
            {
              "class": 2,
              "system:index": "922"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.1724681854248, 42.0071267830306]),
            {
              "class": 2,
              "system:index": "923"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.17555809020996, 42.02396181165554]),
            {
              "class": 2,
              "system:index": "924"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16388511657715, 41.97561290278764]),
            {
              "class": 2,
              "system:index": "925"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16757583618164, 41.96961456764437]),
            {
              "class": 2,
              "system:index": "926"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20937538146973, 41.96406241368741]),
            {
              "class": 2,
              "system:index": "927"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.15495872497559, 41.94063593285216]),
            {
              "class": 2,
              "system:index": "928"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20182228088379, 41.93865673494761]),
            {
              "class": 2,
              "system:index": "929"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19954776763916, 41.97157236429095]),
            {
              "class": 2,
              "system:index": "930"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19547080993652, 41.97926138103187]),
            {
              "class": 2,
              "system:index": "931"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19435501098633, 41.98426990918526]),
            {
              "class": 2,
              "system:index": "932"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19594287872314, 41.98921424796027]),
            {
              "class": 2,
              "system:index": "933"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19731616973877, 41.99849580805573]),
            {
              "class": 2,
              "system:index": "934"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.18843269348145, 41.99945259295923]),
            {
              "class": 2,
              "system:index": "935"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20753002166748, 42.001557469109486]),
            {
              "class": 2,
              "system:index": "936"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.37751770019531, 42.03126098593897]),
            {
              "class": 2,
              "system:index": "937"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.55398559570312, 42.00932607181961]),
            {
              "class": 2,
              "system:index": "938"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.46815490722656, 42.10109618054359]),
            {
              "class": 2,
              "system:index": "939"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.36309814453125, 42.1845934805702]),
            {
              "class": 2,
              "system:index": "940"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.25392150878906, 42.18001416736191]),
            {
              "class": 2,
              "system:index": "941"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.4097900390625, 41.90158231505797]),
            {
              "class": 2,
              "system:index": "942"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.36721801757812, 41.82334141968055]),
            {
              "class": 2,
              "system:index": "943"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33700561523438, 41.791608702741414]),
            {
              "class": 2,
              "system:index": "944"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16740417480469, 41.85301263422478]),
            {
              "class": 2,
              "system:index": "945"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.03144836425781, 41.74961548625407]),
            {
              "class": 2,
              "system:index": "946"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16877746582031, 41.70298107969273]),
            {
              "class": 2,
              "system:index": "947"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.28619384765625, 41.72758366642181]),
            {
              "class": 2,
              "system:index": "948"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.38301086425781, 41.70041776866661]),
            {
              "class": 2,
              "system:index": "949"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.5635986328125, 41.79877552882002]),
            {
              "class": 2,
              "system:index": "950"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.95248413085938, 41.70862000427166]),
            {
              "class": 2,
              "system:index": "951"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.88313293457031, 41.7383443366732]),
            {
              "class": 2,
              "system:index": "952"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.69979858398438, 41.72655874666656]),
            {
              "class": 2,
              "system:index": "953"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66340637207031, 41.80491788475041]),
            {
              "class": 2,
              "system:index": "954"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.50822448730469, 41.81617734136617]),
            {
              "class": 2,
              "system:index": "955"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45672607421875, 41.8688657452443]),
            {
              "class": 2,
              "system:index": "956"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36746215820312, 41.83715559304479]),
            {
              "class": 2,
              "system:index": "957"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22944641113281, 41.910269837749034]),
            {
              "class": 2,
              "system:index": "958"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40522766113281, 42.05675718519668]),
            {
              "class": 2,
              "system:index": "959"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.55354309082031, 42.07702931733726]),
            {
              "class": 2,
              "system:index": "960"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.54547500610352, 42.114732868351105]),
            {
              "class": 2,
              "system:index": "961"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.60143661499023, 42.07256964530969]),
            {
              "class": 2,
              "system:index": "962"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57328414916992, 41.98981780979098]),
            {
              "class": 2,
              "system:index": "963"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47646713256836, 41.964294760290166]),
            {
              "class": 2,
              "system:index": "964"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37793350219727, 41.939399938943964]),
            {
              "class": 2,
              "system:index": "965"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30429077148438, 41.91079081199047]),
            {
              "class": 2,
              "system:index": "966"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.30446243286133, 41.84522247468107]),
            {
              "class": 2,
              "system:index": "967"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24249267578125, 41.876545180074245]),
            {
              "class": 2,
              "system:index": "968"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.16764831542969, 41.82821229529284]),
            {
              "class": 2,
              "system:index": "969"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29107284545898, 41.81055785640751]),
            {
              "class": 2,
              "system:index": "970"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29999923706055, 41.77830675778086]),
            {
              "class": 2,
              "system:index": "971"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.34892272949219, 41.77049750473685]),
            {
              "class": 2,
              "system:index": "972"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29948425292969, 41.75807755414359]),
            {
              "class": 2,
              "system:index": "973"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32059860229492, 41.705426142876576]),
            {
              "class": 2,
              "system:index": "974"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3877182006836, 41.730027793832484]),
            {
              "class": 2,
              "system:index": "975"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.26187133789062, 45.45882122683876]),
            {
              "class": 2,
              "system:index": "976"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.22479248046875, 45.63194075501726]),
            {
              "class": 2,
              "system:index": "977"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.5076904296875, 45.86385019424345]),
            {
              "class": 2,
              "system:index": "978"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.84689331054688, 45.90495643759242]),
            {
              "class": 2,
              "system:index": "979"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79608154296875, 45.88392913629146]),
            {
              "class": 2,
              "system:index": "980"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.25912475585938, 45.95653515019272]),
            {
              "class": 2,
              "system:index": "981"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.99957275390625, 45.9250205254659]),
            {
              "class": 2,
              "system:index": "982"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.74276733398438, 45.86958777508745]),
            {
              "class": 2,
              "system:index": "983"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.68783569335938, 45.82175650577819]),
            {
              "class": 2,
              "system:index": "984"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.3980712890625, 45.74322419011665]),
            {
              "class": 2,
              "system:index": "985"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.07534790039062, 45.357588620604574]),
            {
              "class": 2,
              "system:index": "986"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7718505859375, 45.34214676993083]),
            {
              "class": 2,
              "system:index": "987"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.71554565429688, 45.58967188049731]),
            {
              "class": 2,
              "system:index": "988"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.20993041992188, 45.12648742074596]),
            {
              "class": 2,
              "system:index": "989"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.32528686523438, 45.06444300915311]),
            {
              "class": 2,
              "system:index": "990"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.40768432617188, 45.05765281188251]),
            {
              "class": 2,
              "system:index": "991"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50244140625, 45.066382917396055]),
            {
              "class": 2,
              "system:index": "992"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.68096923828125, 45.16232609501319]),
            {
              "class": 2,
              "system:index": "993"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.80319213867188, 45.145862474901556]),
            {
              "class": 2,
              "system:index": "994"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.71804809570312, 45.30835303398164]),
            {
              "class": 2,
              "system:index": "995"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.15911865234375, 45.353728552894324]),
            {
              "class": 2,
              "system:index": "996"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.73614501953125, 45.120673620802094]),
            {
              "class": 2,
              "system:index": "997"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.64138793945312, 45.18556075570019]),
            {
              "class": 2,
              "system:index": "998"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.634521484375, 45.338285648997285]),
            {
              "class": 2,
              "system:index": "999"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.65924072265625, 45.4530413939227]),
            {
              "class": 2,
              "system:index": "1000"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.05612182617188, 44.95084380587185]),
            {
              "class": 2,
              "system:index": "1001"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.84713745117188, 45.001360154383825]),
            {
              "class": 2,
              "system:index": "1002"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.81005859375, 45.10419797014932]),
            {
              "class": 2,
              "system:index": "1003"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.6397705078125, 45.139081954769686]),
            {
              "class": 2,
              "system:index": "1004"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.249755859375, 45.27260630684659]),
            {
              "class": 2,
              "system:index": "1005"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.94900512695312, 45.47615717115966]),
            {
              "class": 2,
              "system:index": "1006"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.45437622070312, 45.370132022216744]),
            {
              "class": 2,
              "system:index": "1007"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.0355224609375, 45.11485922838168]),
            {
              "class": 2,
              "system:index": "1008"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.35986328125, 45.248440358614545]),
            {
              "class": 2,
              "system:index": "1009"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.10992431640625, 45.253274371118955]),
            {
              "class": 2,
              "system:index": "1010"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.25411987304688, 45.10419797014932]),
            {
              "class": 2,
              "system:index": "1011"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.45599365234375, 45.08480876237753]),
            {
              "class": 2,
              "system:index": "1012"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.5191650390625, 44.969306861970246]),
            {
              "class": 2,
              "system:index": "1013"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.53839111328125, 44.90028295546896]),
            {
              "class": 2,
              "system:index": "1014"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7059326171875, 44.79123151500772]),
            {
              "class": 2,
              "system:index": "1015"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.86935424804688, 44.7044273635165]),
            {
              "class": 2,
              "system:index": "1016"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.60980224609375, 44.90611917091729]),
            {
              "class": 2,
              "system:index": "1017"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.4644775390625, 45.10703006109518]),
            {
              "class": 2,
              "system:index": "1018"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.87646484375, 45.6549080861824]),
            {
              "class": 2,
              "system:index": "1019"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43701171875, 45.69712778787354]),
            {
              "class": 2,
              "system:index": "1020"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5084228515625, 44.3263655596836]),
            {
              "class": 2,
              "system:index": "1021"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.239013671875, 43.86083416187951]),
            {
              "class": 2,
              "system:index": "1022"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.8157958984375, 43.773634908543755]),
            {
              "class": 2,
              "system:index": "1023"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.590576171875, 43.65054711398592]),
            {
              "class": 2,
              "system:index": "1024"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7064208984375, 43.97558405481298]),
            {
              "class": 2,
              "system:index": "1025"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.3438720703125, 44.09405794667996]),
            {
              "class": 2,
              "system:index": "1026"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.6514892578125, 45.017789621241185]),
            {
              "class": 2,
              "system:index": "1027"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16259765625, 44.91674138600208]),
            {
              "class": 2,
              "system:index": "1028"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.65560913085938, 44.82630627767528]),
            {
              "class": 2,
              "system:index": "1029"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.46609497070312, 44.64094870587389]),
            {
              "class": 2,
              "system:index": "1030"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.11016845703125, 44.77173631959746]),
            {
              "class": 2,
              "system:index": "1031"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.1239013671875, 45.080930130851314]),
            {
              "class": 2,
              "system:index": "1032"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.72976684570312, 45.21652555738777]),
            {
              "class": 2,
              "system:index": "1033"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.38644409179688, 45.10129000865577]),
            {
              "class": 2,
              "system:index": "1034"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.16259765625, 45.20104526309409]),
            {
              "class": 2,
              "system:index": "1035"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87258911132812, 44.46871902899218]),
            {
              "class": 2,
              "system:index": "1036"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.107421875, 44.341176634453134]),
            {
              "class": 2,
              "system:index": "1037"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.36148071289062, 44.39811452078663]),
            {
              "class": 2,
              "system:index": "1038"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.32852172851562, 44.36179846836184]),
            {
              "class": 2,
              "system:index": "1039"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.71328735351562, 44.80974585318468]),
            {
              "class": 2,
              "system:index": "1040"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.239501953125, 44.707355469119086]),
            {
              "class": 2,
              "system:index": "1041"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.19692993164062, 44.632153873209056]),
            {
              "class": 2,
              "system:index": "1042"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.20516967773438, 45.026601640404856]),
            {
              "class": 2,
              "system:index": "1043"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2724609375, 45.01883621428491]),
            {
              "class": 2,
              "system:index": "1044"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.5361328125, 45.41738600030446]),
            {
              "class": 2,
              "system:index": "1045"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.15573120117188, 45.541600400793456]),
            {
              "class": 2,
              "system:index": "1046"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.02801513671875, 45.767178691165384]),
            {
              "class": 2,
              "system:index": "1047"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.96322631835938, 45.58390547493344]),
            {
              "class": 2,
              "system:index": "1048"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.25711059570312, 45.71350632820462]),
            {
              "class": 2,
              "system:index": "1049"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.21041870117188, 45.938392553972044]),
            {
              "class": 2,
              "system:index": "1050"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.92477416992188, 45.73459805255046]),
            {
              "class": 2,
              "system:index": "1051"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.01541137695312, 45.802612482426284]),
            {
              "class": 2,
              "system:index": "1052"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.92202758789062, 45.87245634343089]),
            {
              "class": 2,
              "system:index": "1053"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.87327575683594, 45.836760519212355]),
            {
              "class": 2,
              "system:index": "1054"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.72702026367188, 45.77501407194396]),
            {
              "class": 2,
              "system:index": "1055"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.64118957519531, 45.8788428583212]),
            {
              "class": 2,
              "system:index": "1056"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.70367431640625, 45.94477148729162]),
            {
              "class": 2,
              "system:index": "1057"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.47296142578125, 45.92471454289131]),
            {
              "class": 2,
              "system:index": "1058"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.45785522460938, 45.99011162533328]),
            {
              "class": 2,
              "system:index": "1059"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.24156188964844, 45.987726227496026]),
            {
              "class": 2,
              "system:index": "1060"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.29237365722656, 46.03112437813099]),
            {
              "class": 2,
              "system:index": "1061"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.94699096679688, 45.89557130000421]),
            {
              "class": 2,
              "system:index": "1062"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.90647888183594, 45.945248945173475]),
            {
              "class": 2,
              "system:index": "1063"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.88450622558594, 45.99345100960153]),
            {
              "class": 2,
              "system:index": "1064"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98475646972656, 45.956706700678]),
            {
              "class": 2,
              "system:index": "1065"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.99917602539062, 45.669072328243345]),
            {
              "class": 2,
              "system:index": "1066"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89411926269531, 45.62443045074518]),
            {
              "class": 2,
              "system:index": "1067"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.81721496582031, 45.655635506167975]),
            {
              "class": 2,
              "system:index": "1068"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85429382324219, 45.75537489867273]),
            {
              "class": 2,
              "system:index": "1069"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.71902465820312, 45.868325259289726]),
            {
              "class": 2,
              "system:index": "1070"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.5308837890625, 45.926147422345444]),
            {
              "class": 2,
              "system:index": "1071"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37844848632812, 45.621549107925944]),
            {
              "class": 2,
              "system:index": "1072"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.97264099121094, 45.86689088701921]),
            {
              "class": 2,
              "system:index": "1073"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.97607421875, 45.96148006640204]),
            {
              "class": 2,
              "system:index": "1074"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.00079345703125, 45.991542814691634]),
            {
              "class": 2,
              "system:index": "1075"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.03237915039062, 46.012529340180336]),
            {
              "class": 2,
              "system:index": "1076"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39836120605469, 45.86745492844751]),
            {
              "class": 2,
              "system:index": "1077"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3767318725586, 45.903780582464584]),
            {
              "class": 2,
              "system:index": "1078"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35338592529297, 45.95321218710969]),
            {
              "class": 2,
              "system:index": "1079"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29261779785156, 45.90736406323948]),
            {
              "class": 2,
              "system:index": "1080"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24386596679688, 45.91906848838407]),
            {
              "class": 2,
              "system:index": "1081"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38325500488281, 45.79784414853442]),
            {
              "class": 2,
              "system:index": "1082"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.46050262451172, 45.8086143931498]),
            {
              "class": 2,
              "system:index": "1083"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25176239013672, 45.768873831030085]),
            {
              "class": 2,
              "system:index": "1084"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.22154998779297, 45.815793399495256]),
            {
              "class": 2,
              "system:index": "1085"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.20953369140625, 45.8566960657807]),
            {
              "class": 2,
              "system:index": "1086"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.26480865478516, 45.70465457030899]),
            {
              "class": 2,
              "system:index": "1087"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36883544921875, 45.68642969636731]),
            {
              "class": 2,
              "system:index": "1088"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38943481445312, 45.60122168058631]),
            {
              "class": 2,
              "system:index": "1089"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21537017822266, 45.54185964639251]),
            {
              "class": 2,
              "system:index": "1090"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38600158691406, 45.53224045837947]),
            {
              "class": 2,
              "system:index": "1091"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47457885742188, 45.46293372895506]),
            {
              "class": 2,
              "system:index": "1092"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4872817993164, 45.47521301114367]),
            {
              "class": 2,
              "system:index": "1093"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.48968505859375, 45.46269293197565]),
            {
              "class": 2,
              "system:index": "1094"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49414825439453, 45.453301047562775]),
            {
              "class": 2,
              "system:index": "1095"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.46015930175781, 45.44992922030839]),
            {
              "class": 2,
              "system:index": "1096"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.44127655029297, 45.46148893165138]),
            {
              "class": 2,
              "system:index": "1097"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52058410644531, 45.46004409732242]),
            {
              "class": 2,
              "system:index": "1098"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49140167236328, 45.49206257229497]),
            {
              "class": 2,
              "system:index": "1099"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58409881591797, 45.51444062260158]),
            {
              "class": 2,
              "system:index": "1100"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66924285888672, 45.500966733058696]),
            {
              "class": 2,
              "system:index": "1101"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66443634033203, 45.559410422763094]),
            {
              "class": 2,
              "system:index": "1102"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73550415039062, 45.504335507809714]),
            {
              "class": 2,
              "system:index": "1103"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62529754638672, 45.65692159157757]),
            {
              "class": 2,
              "system:index": "1104"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.56658935546875, 45.80334920036384]),
            {
              "class": 2,
              "system:index": "1105"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65310668945312, 45.791859779616594]),
            {
              "class": 2,
              "system:index": "1106"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63834381103516, 45.946289639900016]),
            {
              "class": 2,
              "system:index": "1107"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.64177703857422, 46.00331517889851]),
            {
              "class": 2,
              "system:index": "1108"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52882385253906, 46.001168837652514]),
            {
              "class": 2,
              "system:index": "1109"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.58512878417969, 46.04217339363265]),
            {
              "class": 2,
              "system:index": "1110"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.4591293334961, 45.996160384262396]),
            {
              "class": 2,
              "system:index": "1111"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.13321685791016, 45.43836713933041]),
            {
              "class": 2,
              "system:index": "1112"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.13973999023438, 45.50866649343755]),
            {
              "class": 2,
              "system:index": "1113"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.21595764160156, 45.52237908294681]),
            {
              "class": 2,
              "system:index": "1114"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1744155883789, 45.550996350871046]),
            {
              "class": 2,
              "system:index": "1115"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.0803451538086, 45.52117635791598]),
            {
              "class": 2,
              "system:index": "1116"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.06214904785156, 45.45354188465302]),
            {
              "class": 2,
              "system:index": "1117"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.16068267822266, 45.34313086118473]),
            {
              "class": 2,
              "system:index": "1118"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.38658905029297, 45.257401838949704]),
            {
              "class": 2,
              "system:index": "1119"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28736877441406, 45.244108280695954]),
            {
              "class": 2,
              "system:index": "1120"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1854019165039, 45.249426077370174]),
            {
              "class": 2,
              "system:index": "1121"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.16102600097656, 45.227668307163164]),
            {
              "class": 2,
              "system:index": "1122"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.04086303710938, 45.186305590414236]),
            {
              "class": 2,
              "system:index": "1123"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1902084350586, 45.17130115249436]),
            {
              "class": 2,
              "system:index": "1124"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.50469207763672, 45.06906912694807]),
            {
              "class": 2,
              "system:index": "1125"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44529724121094, 45.023466021393084]),
            {
              "class": 2,
              "system:index": "1126"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.49610900878906, 45.02201000447777]),
            {
              "class": 2,
              "system:index": "1127"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.07691192626953, 45.03050291446229]),
            {
              "class": 2,
              "system:index": "1128"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1139907836914, 44.90103151361842]),
            {
              "class": 2,
              "system:index": "1129"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.0638656616211, 44.89495157165857]),
            {
              "class": 2,
              "system:index": "1130"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.12841033935547, 44.890816843913015]),
            {
              "class": 2,
              "system:index": "1131"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.90799713134766, 44.96203850190038]),
            {
              "class": 2,
              "system:index": "1132"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.95812225341797, 45.0729485636192]),
            {
              "class": 2,
              "system:index": "1133"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.90044403076172, 45.16984890028165]),
            {
              "class": 2,
              "system:index": "1134"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.86302185058594, 45.21944653683731]),
            {
              "class": 2,
              "system:index": "1135"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.69204711914062, 45.03365710295764]),
            {
              "class": 2,
              "system:index": "1136"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.73908233642578, 44.908326595368514]),
            {
              "class": 2,
              "system:index": "1137"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.65943145751953, 44.840933485792235]),
            {
              "class": 2,
              "system:index": "1138"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.63883209228516, 44.802700903778096]),
            {
              "class": 2,
              "system:index": "1139"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.45549774169922, 44.79246878080399]),
            {
              "class": 2,
              "system:index": "1140"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.36348724365234, 44.90978550062879]),
            {
              "class": 2,
              "system:index": "1141"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4108657836914, 45.0547614284202]),
            {
              "class": 2,
              "system:index": "1142"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.52175903320312, 45.20638598710888]),
            {
              "class": 2,
              "system:index": "1143"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.6360855102539, 45.21920470206281]),
            {
              "class": 2,
              "system:index": "1144"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.63127899169922, 45.21412593419534]),
            {
              "class": 2,
              "system:index": "1145"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.4434814453125, 45.304267001400476]),
            {
              "class": 2,
              "system:index": "1146"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.40228271484375, 45.25933518822232]),
            {
              "class": 2,
              "system:index": "1147"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.58149719238281, 45.43306706027613]),
            {
              "class": 2,
              "system:index": "1148"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.83074951171875, 45.59401506437426]),
            {
              "class": 2,
              "system:index": "1149"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.05116271972656, 45.66340031315453]),
            {
              "class": 2,
              "system:index": "1150"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.97357177734375, 45.66148077010046]),
            {
              "class": 2,
              "system:index": "1151"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.16480255126953, 45.66531979039496]),
            {
              "class": 2,
              "system:index": "1152"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.19295501708984, 45.71016882195874]),
            {
              "class": 2,
              "system:index": "1153"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.24960327148438, 45.764562910698174]),
            {
              "class": 2,
              "system:index": "1154"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26093292236328, 45.790184041158966]),
            {
              "class": 2,
              "system:index": "1155"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29595184326172, 45.75066990114111]),
            {
              "class": 2,
              "system:index": "1156"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.36152648925781, 45.82440698561206]),
            {
              "class": 2,
              "system:index": "1157"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44564056396484, 45.753544600710164]),
            {
              "class": 2,
              "system:index": "1158"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.42881774902344, 45.90449729712537]),
            {
              "class": 2,
              "system:index": "1159"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.4553394317627, 45.89912637816169]),
            {
              "class": 2,
              "system:index": "1160"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.47250556945801, 45.894048958821436]),
            {
              "class": 2,
              "system:index": "1161"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.51087188720703, 45.9011525495444]),
            {
              "class": 2,
              "system:index": "1162"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5204849243164, 45.97516764929649]),
            {
              "class": 2,
              "system:index": "1163"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.27500915527344, 46.02548916275505]),
            {
              "class": 2,
              "system:index": "1164"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3992919921875, 45.9787465192275]),
            {
              "class": 2,
              "system:index": "1165"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3769760131836, 45.94485728080785]),
            {
              "class": 2,
              "system:index": "1166"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5259780883789, 45.683551541742204]),
            {
              "class": 2,
              "system:index": "1167"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.40375518798828, 45.676835271756325]),
            {
              "class": 2,
              "system:index": "1168"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.6248550415039, 45.69818062426753]),
            {
              "class": 2,
              "system:index": "1169"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.64991760253906, 45.60146188518668]),
            {
              "class": 2,
              "system:index": "1170"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.5860595703125, 45.46148893165138]),
            {
              "class": 2,
              "system:index": "1171"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.49061584472656, 45.49663515504023]),
            {
              "class": 2,
              "system:index": "1172"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3007583618164, 45.55340049996432]),
            {
              "class": 2,
              "system:index": "1173"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.28118896484375, 45.45667267323398]),
            {
              "class": 2,
              "system:index": "1174"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.29011535644531, 45.38727293619383]),
            {
              "class": 2,
              "system:index": "1175"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.18677520751953, 45.34168299685801]),
            {
              "class": 2,
              "system:index": "1176"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.0858383178711, 45.37955658833005]),
            {
              "class": 2,
              "system:index": "1177"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.96945190429688, 45.360502344970115]),
            {
              "class": 2,
              "system:index": "1178"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9485092163086, 45.27117551611777]),
            {
              "class": 2,
              "system:index": "1179"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.9759750366211, 45.20396703764105]),
            {
              "class": 2,
              "system:index": "1180"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.88911437988281, 45.17299539994139]),
            {
              "class": 2,
              "system:index": "1181"
            }),
        ee.Feature(
            ee.Geometry.Point([-96.85066223144531, 45.05645913918175]),
            {
              "class": 2,
              "system:index": "1182"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.08721160888672, 44.91075808356346]),
            {
              "class": 2,
              "system:index": "1183"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.1579360961914, 44.926803325896685]),
            {
              "class": 2,
              "system:index": "1184"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3055648803711, 44.96519646129472]),
            {
              "class": 2,
              "system:index": "1185"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73265838623047, 44.87743774691913]),
            {
              "class": 2,
              "system:index": "1186"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.84732818603516, 44.889114222555975]),
            {
              "class": 2,
              "system:index": "1187"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.86312103271484, 44.9906966841406]),
            {
              "class": 2,
              "system:index": "1188"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.89539337158203, 45.05330620765156]),
            {
              "class": 2,
              "system:index": "1189"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.92182922363281, 45.11633180956917]),
            {
              "class": 2,
              "system:index": "1190"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94002532958984, 45.17444757192364]),
            {
              "class": 2,
              "system:index": "1191"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.94071197509766, 45.23806472564079]),
            {
              "class": 2,
              "system:index": "1192"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9098129272461, 45.31561510725682]),
            {
              "class": 2,
              "system:index": "1193"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8768539428711, 44.95863742814468]),
            {
              "class": 2,
              "system:index": "1194"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8335952758789, 44.8526173673691]),
            {
              "class": 2,
              "system:index": "1195"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.78072357177734, 44.71371825042854]),
            {
              "class": 2,
              "system:index": "1196"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.70999908447266, 44.48123215746985]),
            {
              "class": 2,
              "system:index": "1197"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.89230346679688, 44.46604303783433]),
            {
              "class": 2,
              "system:index": "1198"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.11546325683594, 44.47020818982234]),
            {
              "class": 2,
              "system:index": "1199"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1467056274414, 44.524817662244914]),
            {
              "class": 2,
              "system:index": "1200"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02860260009766, 44.546842873690515]),
            {
              "class": 2,
              "system:index": "1201"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.14945220947266, 44.56201095091302]),
            {
              "class": 2,
              "system:index": "1202"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27510833740234, 44.61091328557488]),
            {
              "class": 2,
              "system:index": "1203"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.35613250732422, 44.76054264658925]),
            {
              "class": 2,
              "system:index": "1204"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38462829589844, 44.845315219105416]),
            {
              "class": 2,
              "system:index": "1205"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51921081542969, 44.875248143899945]),
            {
              "class": 2,
              "system:index": "1206"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.49620819091797, 44.8387424941609]),
            {
              "class": 2,
              "system:index": "1207"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.52745056152344, 44.802700903778096]),
            {
              "class": 2,
              "system:index": "1208"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.61534118652344, 44.77273027687919]),
            {
              "class": 2,
              "system:index": "1209"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.29776763916016, 44.652936389033925]),
            {
              "class": 2,
              "system:index": "1210"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1796646118164, 44.54170440282058]),
            {
              "class": 2,
              "system:index": "1211"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3111572265625, 44.45134012572531]),
            {
              "class": 2,
              "system:index": "1212"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21468353271484, 44.366971967546206]),
            {
              "class": 2,
              "system:index": "1213"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.09898376464844, 44.248061873799045]),
            {
              "class": 2,
              "system:index": "1214"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.07323455810547, 44.17078889399142]),
            {
              "class": 2,
              "system:index": "1215"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.23631286621094, 44.07269848150764]),
            {
              "class": 2,
              "system:index": "1216"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.3218002319336, 44.13507129575876]),
            {
              "class": 2,
              "system:index": "1217"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.36437225341797, 44.181376853447624]),
            {
              "class": 2,
              "system:index": "1218"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.48968505859375, 44.10598860687603]),
            {
              "class": 2,
              "system:index": "1219"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.69293212890625, 44.21214500924288]),
            {
              "class": 2,
              "system:index": "1220"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.73001098632812, 44.31516268007338]),
            {
              "class": 2,
              "system:index": "1221"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.7890625, 44.41530234415234]),
            {
              "class": 2,
              "system:index": "1222"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.8388442993164, 44.46481793656798]),
            {
              "class": 2,
              "system:index": "1223"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.89823913574219, 44.464082863466956]),
            {
              "class": 2,
              "system:index": "1224"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.98818969726562, 44.52236990229044]),
            {
              "class": 2,
              "system:index": "1225"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.14165496826172, 44.49421327071367]),
            {
              "class": 2,
              "system:index": "1226"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.25392150878906, 44.47755773298688]),
            {
              "class": 2,
              "system:index": "1227"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.17049407958984, 44.3868486796158]),
            {
              "class": 2,
              "system:index": "1228"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2995834350586, 44.369671670045655]),
            {
              "class": 2,
              "system:index": "1229"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.31880950927734, 44.189008854182944]),
            {
              "class": 2,
              "system:index": "1230"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.31434631347656, 44.11905294147902]),
            {
              "class": 2,
              "system:index": "1231"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.2336654663086, 44.03864920972576]),
            {
              "class": 2,
              "system:index": "1232"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.239501953125, 44.01174138076244]),
            {
              "class": 2,
              "system:index": "1233"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.28413391113281, 44.04432544795348]),
            {
              "class": 2,
              "system:index": "1234"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.27967071533203, 44.013963590714454]),
            {
              "class": 2,
              "system:index": "1235"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.09770965576172, 44.01223521239225]),
            {
              "class": 2,
              "system:index": "1236"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.06440734863281, 43.995195644952155]),
            {
              "class": 2,
              "system:index": "1237"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.02801513671875, 44.02532025226023]),
            {
              "class": 2,
              "system:index": "1238"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.93360137939453, 44.02754195334628]),
            {
              "class": 2,
              "system:index": "1239"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.91643524169922, 43.95813622258022]),
            {
              "class": 2,
              "system:index": "1240"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78837585449219, 43.97271568826204]),
            {
              "class": 2,
              "system:index": "1241"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.74614715576172, 43.93193361703135]),
            {
              "class": 2,
              "system:index": "1242"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.56830596923828, 44.078864733163414]),
            {
              "class": 2,
              "system:index": "1243"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6301040649414, 44.145912023936674]),
            {
              "class": 2,
              "system:index": "1244"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.65276336669922, 44.0243328028268]),
            {
              "class": 2,
              "system:index": "1245"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.6301040649414, 43.963078815234354]),
            {
              "class": 2,
              "system:index": "1246"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.63216400146484, 43.84508594653219]),
            {
              "class": 2,
              "system:index": "1247"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.62358093261719, 43.813878973124964]),
            {
              "class": 2,
              "system:index": "1248"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.72966766357422, 43.803968585332605]),
            {
              "class": 2,
              "system:index": "1249"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.85154724121094, 43.8158608533595]),
            {
              "class": 2,
              "system:index": "1250"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.92398834228516, 43.86662409580871]),
            {
              "class": 2,
              "system:index": "1251"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01050567626953, 43.844590725190564]),
            {
              "class": 2,
              "system:index": "1252"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.95832061767578, 43.74571184970586]),
            {
              "class": 2,
              "system:index": "1253"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07917022705078, 43.62828261262934]),
            {
              "class": 2,
              "system:index": "1254"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07676696777344, 43.57856050932285]),
            {
              "class": 2,
              "system:index": "1255"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.07058715820312, 43.5322820734311]),
            {
              "class": 2,
              "system:index": "1256"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01222229003906, 43.47401033596583]),
            {
              "class": 2,
              "system:index": "1257"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.26490783691406, 43.46852890398275]),
            {
              "class": 2,
              "system:index": "1258"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.33631896972656, 43.475505185680355]),
            {
              "class": 2,
              "system:index": "1259"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.35142517089844, 43.539997614161834]),
            {
              "class": 2,
              "system:index": "1260"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.25460815429688, 43.555425733965095]),
            {
              "class": 2,
              "system:index": "1261"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.15367126464844, 43.354302560357596]),
            {
              "class": 2,
              "system:index": "1262"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10148620605469, 43.31834408778956]),
            {
              "class": 2,
              "system:index": "1263"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.10972595214844, 43.29411005878448]),
            {
              "class": 2,
              "system:index": "1264"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.02183532714844, 43.18731549953988]),
            {
              "class": 2,
              "system:index": "1265"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.01737213134766, 43.24161153720723]),
            {
              "class": 2,
              "system:index": "1266"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.80313873291016, 43.18280950950249]),
            {
              "class": 2,
              "system:index": "1267"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.75404357910156, 43.16503263879381]),
            {
              "class": 2,
              "system:index": "1268"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.78425598144531, 43.22885506300949]),
            {
              "class": 2,
              "system:index": "1269"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.87042999267578, 43.30760235985077]),
            {
              "class": 2,
              "system:index": "1270"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.92864990234375, 42.25763474597478]),
            {
              "class": 2,
              "system:index": "1271"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.02950096130371, 42.48201292456279]),
            {
              "class": 2,
              "system:index": "1272"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.97199440002441, 42.50796022293034]),
            {
              "class": 2,
              "system:index": "1273"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.9504508972168, 42.48783618198297]),
            {
              "class": 2,
              "system:index": "1274"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.909423828125, 42.48353208745136]),
            {
              "class": 2,
              "system:index": "1275"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.84118843078613, 42.53459246516229]),
            {
              "class": 2,
              "system:index": "1276"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.83312034606934, 42.49891153416194]),
            {
              "class": 2,
              "system:index": "1277"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.82324981689453, 42.46865536313625]),
            {
              "class": 2,
              "system:index": "1278"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.8134651184082, 42.428375513134526]),
            {
              "class": 2,
              "system:index": "1279"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.79655647277832, 42.40702176139834]),
            {
              "class": 2,
              "system:index": "1280"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73870658874512, 42.35395442967078]),
            {
              "class": 2,
              "system:index": "1281"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.73029518127441, 42.28001664809972]),
            {
              "class": 2,
              "system:index": "1282"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.75089454650879, 42.30058832218136]),
            {
              "class": 2,
              "system:index": "1283"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.69785118103027, 42.290303324962]),
            {
              "class": 2,
              "system:index": "1284"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.67931175231934, 42.306936247458694]),
            {
              "class": 2,
              "system:index": "1285"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.64412117004395, 42.305539758813104]),
            {
              "class": 2,
              "system:index": "1286"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.64343452453613, 42.30947523835766]),
            {
              "class": 2,
              "system:index": "1287"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.65922737121582, 42.267314730283324]),
            {
              "class": 2,
              "system:index": "1288"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.62395095825195, 42.30109617975691]),
            {
              "class": 2,
              "system:index": "1289"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.24901580810547, 44.28072701876842]),
            {
              "class": 2,
              "system:index": "1290"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.16524505615234, 44.291663844464374]),
            {
              "class": 2,
              "system:index": "1291"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.10653686523438, 44.2015279650204]),
            {
              "class": 2,
              "system:index": "1292"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.03564071655273, 44.16681407109046]),
            {
              "class": 2,
              "system:index": "1293"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.98362731933594, 44.13552944919728]),
            {
              "class": 2,
              "system:index": "1294"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8852653503418, 44.21235648470788]),
            {
              "class": 2,
              "system:index": "1295"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.8281021118164, 44.59914610031443]),
            {
              "class": 2,
              "system:index": "1296"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7292251586914, 44.53910058484967]),
            {
              "class": 2,
              "system:index": "1297"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.83205032348633, 44.503729132253305]),
            {
              "class": 2,
              "system:index": "1298"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.68613815307617, 44.59132290697642]),
            {
              "class": 2,
              "system:index": "1299"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73883819580078, 44.6580306903733]),
            {
              "class": 2,
              "system:index": "1300"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.39294052124023, 44.558674160243065]),
            {
              "class": 2,
              "system:index": "1301"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.44409561157227, 44.52429369728116]),
            {
              "class": 2,
              "system:index": "1302"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.3744010925293, 44.50323941130474]),
            {
              "class": 2,
              "system:index": "1303"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.30384826660156, 44.49528086931113]),
            {
              "class": 2,
              "system:index": "1304"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26144790649414, 44.54558506076681]),
            {
              "class": 2,
              "system:index": "1305"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.26299285888672, 44.5705374354195]),
            {
              "class": 2,
              "system:index": "1306"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.9486083984375, 44.343248351836074]),
            {
              "class": 2,
              "system:index": "1307"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.899169921875, 44.3647285121447]),
            {
              "class": 2,
              "system:index": "1308"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.88629531860352, 44.31426835323179]),
            {
              "class": 2,
              "system:index": "1309"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.02173614501953, 44.36509667482153]),
            {
              "class": 2,
              "system:index": "1310"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.99066543579102, 44.287854619432494]),
            {
              "class": 2,
              "system:index": "1311"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.85882949829102, 44.289083428693665]),
            {
              "class": 2,
              "system:index": "1312"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.73780822753906, 44.286625784463894]),
            {
              "class": 2,
              "system:index": "1313"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.7977180480957, 44.20595805458689]),
            {
              "class": 2,
              "system:index": "1314"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.76355743408203, 44.1466164484002]),
            {
              "class": 2,
              "system:index": "1315"
            }),
        ee.Feature(
            ee.Geometry.Point([-97.87908554077148, 44.12308489306967]),
            {
              "class": 2,
              "system:index": "1316"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21382522583008, 43.764275723684975]),
            {
              "class": 2,
              "system:index": "1317"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32815170288086, 43.8111189404879]),
            {
              "class": 2,
              "system:index": "1318"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.39990615844727, 43.79228692760883]),
            {
              "class": 2,
              "system:index": "1319"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32540512084961, 43.718388345893146]),
            {
              "class": 2,
              "system:index": "1320"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.23236465454102, 43.637938693738235]),
            {
              "class": 2,
              "system:index": "1321"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.38308334350586, 43.59207888849147]),
            {
              "class": 2,
              "system:index": "1322"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.33433151245117, 43.552653784723546]),
            {
              "class": 2,
              "system:index": "1323"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.27733993530273, 43.460146179150506]),
            {
              "class": 2,
              "system:index": "1324"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.37570190429688, 43.45952317131227]),
            {
              "class": 2,
              "system:index": "1325"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40986251831055, 43.425247854316304]),
            {
              "class": 2,
              "system:index": "1326"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.51011276245117, 43.49614512308334]),
            {
              "class": 2,
              "system:index": "1327"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.66804122924805, 43.51357634626471]),
            {
              "class": 2,
              "system:index": "1328"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.68864059448242, 43.51145996622458]),
            {
              "class": 2,
              "system:index": "1329"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.71593475341797, 43.437339910121175]),
            {
              "class": 2,
              "system:index": "1330"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.59697341918945, 43.43484690045063]),
            {
              "class": 2,
              "system:index": "1331"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.47732543945312, 43.43783849973027]),
            {
              "class": 2,
              "system:index": "1332"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.45552444458008, 43.471982108353195]),
            {
              "class": 2,
              "system:index": "1333"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.32077026367188, 43.79637596119878]),
            {
              "class": 2,
              "system:index": "1334"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.21571350097656, 43.594814057819235]),
            {
              "class": 2,
              "system:index": "1335"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.57620239257812, 43.72694838956604]),
            {
              "class": 2,
              "system:index": "1336"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.61808776855469, 43.77803507867666]),
            {
              "class": 2,
              "system:index": "1337"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.40179443359375, 43.917185711709344]),
            {
              "class": 2,
              "system:index": "1338"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.25759887695312, 44.14329056725031]),
            {
              "class": 2,
              "system:index": "1339"
            }),
        ee.Feature(
            ee.Geometry.Point([-98.1024169921875, 44.149203115302264]),
            {
              "class": 2,
              "system:index": "1340"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.47796630859375, 44.296332880058706]),
            {
              "class": 2,
              "system:index": "1341"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.78009033203125, 44.040218713142146]),
            {
              "class": 2,
              "system:index": "1342"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.39007568359375, 43.667871610117494]),
            {
              "class": 2,
              "system:index": "1343"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.91741943359375, 43.759192638860114]),
            {
              "class": 2,
              "system:index": "1344"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70068359375, 43.74728909225906]),
            {
              "class": 2,
              "system:index": "1345"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.03826904296875, 43.29519939210697]),
            {
              "class": 2,
              "system:index": "1346"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.4639892578125, 43.1811470593997]),
            {
              "class": 2,
              "system:index": "1347"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.00506591796875, 42.994603451901305]),
            {
              "class": 2,
              "system:index": "1348"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.87347412109375, 44.22748846630169]),
            {
              "class": 2,
              "system:index": "1349"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.50518798828125, 44.61393394730625]),
            {
              "class": 2,
              "system:index": "1350"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.31842041015625, 44.72722302245742]),
            {
              "class": 2,
              "system:index": "1351"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.9146728515625, 44.89090425391711]),
            {
              "class": 2,
              "system:index": "1352"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.43951416015625, 45.740693395533064]),
            {
              "class": 2,
              "system:index": "1353"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.53814697265625, 45.585211978094]),
            {
              "class": 2,
              "system:index": "1354"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.7501220703125, 45.37337295384522]),
            {
              "class": 2,
              "system:index": "1355"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.5633544921875, 44.873389196779264]),
            {
              "class": 2,
              "system:index": "1356"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.0137939453125, 44.867549659447214]),
            {
              "class": 2,
              "system:index": "1357"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.81329345703125, 44.5982904898401]),
            {
              "class": 2,
              "system:index": "1358"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.88465881347656, 42.0615286181226]),
            {
              "class": 2,
              "system:index": "1359"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.6614990234375, 41.860356373366606]),
            {
              "class": 2,
              "system:index": "1360"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.83659362792969, 41.84245503142379]),
            {
              "class": 2,
              "system:index": "1361"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.48846435546875, 41.74775043973815]),
            {
              "class": 2,
              "system:index": "1362"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.09477233886719, 41.98399427093563]),
            {
              "class": 2,
              "system:index": "1363"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.29527282714844, 42.052351854553045]),
            {
              "class": 2,
              "system:index": "1364"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.47242736816406, 42.06356771883278]),
            {
              "class": 2,
              "system:index": "1365"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.94508361816406, 41.934976500546604]),
            {
              "class": 2,
              "system:index": "1366"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80294799804688, 42.01410106690003]),
            {
              "class": 2,
              "system:index": "1367"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.80449295043945, 41.94404252327993]),
            {
              "class": 2,
              "system:index": "1368"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.81599426269531, 41.96459591213676]),
            {
              "class": 2,
              "system:index": "1369"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.83899688720703, 41.93216704883793]),
            {
              "class": 2,
              "system:index": "1370"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.8925552368164, 41.891927238219935]),
            {
              "class": 2,
              "system:index": "1371"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.79985809326172, 41.81943165932007]),
            {
              "class": 2,
              "system:index": "1372"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.69909286499023, 41.84309445132935]),
            {
              "class": 2,
              "system:index": "1373"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.64330291748047, 41.81904786629556]),
            {
              "class": 2,
              "system:index": "1374"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.66767883300781, 41.827107036777804]),
            {
              "class": 2,
              "system:index": "1375"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.55180740356445, 41.803566297058566]),
            {
              "class": 2,
              "system:index": "1376"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.56760025024414, 41.782449036516084]),
            {
              "class": 2,
              "system:index": "1377"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.46940994262695, 41.76913518876738]),
            {
              "class": 2,
              "system:index": "1378"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.45121383666992, 41.8226298450744]),
            {
              "class": 2,
              "system:index": "1379"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.53697204589844, 44.17333987346469]),
            {
              "class": 2,
              "system:index": "1380"
            }),
        ee.Feature(
            ee.Geometry.Point([-104.45114135742188, 44.33907415011681]),
            {
              "class": 2,
              "system:index": "1381"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.94439697265625, 44.55035619497771]),
            {
              "class": 2,
              "system:index": "1382"
            }),
        ee.Feature(
            ee.Geometry.Point([-103.93409729003906, 44.751609766121646]),
            {
              "class": 2,
              "system:index": "1383"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.80000305175781, 45.97119706983072]),
            {
              "class": 2,
              "system:index": "1384"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.62078857421875, 46.010316293096196]),
            {
              "class": 2,
              "system:index": "1385"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.82472229003906, 46.01985337287632]),
            {
              "class": 2,
              "system:index": "1386"
            }),
        ee.Feature(
            ee.Geometry.Point([-102.07534790039062, 45.99362244576693]),
            {
              "class": 2,
              "system:index": "1387"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.77322387695312, 45.87805858900894]),
            {
              "class": 2,
              "system:index": "1388"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.89544677734375, 45.84028105450088]),
            {
              "class": 2,
              "system:index": "1389"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.62628173828125, 45.89335357756639]),
            {
              "class": 2,
              "system:index": "1390"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.50955200195312, 45.91437731081979]),
            {
              "class": 2,
              "system:index": "1391"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.7498779296875, 45.79960567470238]),
            {
              "class": 2,
              "system:index": "1392"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.33445739746094, 45.909122123907295]),
            {
              "class": 2,
              "system:index": "1393"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.05430603027344, 45.979786584921676]),
            {
              "class": 2,
              "system:index": "1394"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.71372985839844, 46.01556189051301]),
            {
              "class": 2,
              "system:index": "1395"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.426025390625, 46.02795859751178]),
            {
              "class": 2,
              "system:index": "1396"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.36903381347656, 46.040352524928004]),
            {
              "class": 2,
              "system:index": "1397"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.8270263671875, 46.03272582161419]),
            {
              "class": 2,
              "system:index": "1398"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50636291503906, 45.889530225225606]),
            {
              "class": 2,
              "system:index": "1399"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.195068359375, 46.02223738582996]),
            {
              "class": 2,
              "system:index": "1400"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.33995056152344, 46.02700510334968]),
            {
              "class": 2,
              "system:index": "1401"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.46629333496094, 46.02176059146292]),
            {
              "class": 2,
              "system:index": "1402"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.57159423828125, 45.9568782506322]),
            {
              "class": 2,
              "system:index": "1403"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.70892333984375, 45.979786584921676]),
            {
              "class": 2,
              "system:index": "1404"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.50567626953125, 45.85941212790754]),
            {
              "class": 2,
              "system:index": "1405"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.52215576171875, 45.729191061299915]),
            {
              "class": 2,
              "system:index": "1406"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.14013671875, 45.79625461321962]),
            {
              "class": 2,
              "system:index": "1407"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.645751953125, 45.56214096905609]),
            {
              "class": 2,
              "system:index": "1408"
            }),
        ee.Feature(
            ee.Geometry.Point([-101.63726806640625, 45.729191061299915]),
            {
              "class": 2,
              "system:index": "1409"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.6402587890625, 45.24588722974014]),
            {
              "class": 2,
              "system:index": "1410"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.43426513671875, 45.22461173085719]),
            {
              "class": 2,
              "system:index": "1411"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.20904541015625, 45.321254361171476]),
            {
              "class": 2,
              "system:index": "1412"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.9810791015625, 45.33670190996813]),
            {
              "class": 2,
              "system:index": "1413"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.22552490234375, 45.84028105450088]),
            {
              "class": 2,
              "system:index": "1414"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.80255126953125, 45.706179285330855]),
            {
              "class": 2,
              "system:index": "1415"
            }),
        ee.Feature(
            ee.Geometry.Point([-99.7174072265625, 45.09679146394738]),
            {
              "class": 2,
              "system:index": "1416"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.41229248046875, 45.06770141120104]),
            {
              "class": 2,
              "system:index": "1417"
            }),
        ee.Feature(
            ee.Geometry.Point([-100.8929443359375, 44.85002749260051]),
            {
              "class": 2,
              "system:index": "1418"
            })]),
    prev = ee.Image("users/images/SGreatPlains_2010_v2"),
    cdl = ee.Image("users/images/CDL_composite_08_12_wo_fallow"),
    input = ee.Image("users/images/input/SGreatPlains_2010_InputSR");
/***** End of imports. If edited, may not auto-convert in the playground. *****/

var zones=ee.FeatureCollection("ft:1emWmrrMBzdiKOitmcYSBmoCozs4Fpqq_f6A86pnR"); 
var zones2=ee.FeatureCollection("ft:13cK2cS_HzpvNGVZlIfH9zInVbJOMQgjXQKwgLHpL");
var countries = ee.FeatureCollection("ft:1tdSwUL7MVpOauSgRzqVTOwdfy17KDbw-1d9omPw"); 

//Map.addLayer(zones)


/*
function radians(img) {return img.toFloat().multiply(Math.PI).divide(180).divide(1.5708).toFloat();}
var terrain = ee.Algorithms.Terrain(ee.Image('USGS/SRTMGL1_003'));
var slope = radians(terrain.select('slope'));
var elevation = terrain.select('elevation').divide(4000.00).float();
*/

//input=input.select(ee.List.sequence(0,43)).addBands(slope).addBands(elevation);

//visual parameters for FCC display 
var vizParams = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  gamma: [1.5,1.6, 1.7]
};



//add all max val to map
//Map.addLayer(FCC,vizParams,'FCC');
Map.addLayer(cdl,{palette:'ffff00'},'cdl')
Map.addLayer(prev,{palette:'00ff00'},'prev')

//throw('stop')

//create bounds for training samples inside area of interest
function buffer(geometry) {
  return geometry.buffer(60).bounds();
} 

//buffer function of 1km********************************************************
function buffer1(geometry) {
  return geometry.buffer(10000);
}

function buffer2(geometry) {
  return geometry.buffer(10000);
}

var studyArea = zones.filterMetadata('name','equals','SGreatPlains');

var region= ee.FeatureCollection(countries.filterMetadata('Country','equals','United States'))
              .map(buffer2)

studyArea=buffer1(studyArea.geometry());



var CropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea);
/*
var CropSamplesArea2 = Cropclass2.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea2);

var CropSamplesArea2 = Cropclass3.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea3);
*/
var NonCropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea);
/*
var NonCropSamplesArea2 = NonCropClass2.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea2);

var NonCropSamplesArea2 = NonCropClass3.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea3);
*/
//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                   // .merge(CropSamplesArea2)
                   // .merge(CropSamplesArea3)
                    .merge(NonCropSamplesArea)
                   //.merge(NonCropSamplesArea2)
                  // .merge(NonCropSamplesArea3);
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);

//print(input)

var training = input.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});
 

//build classifier
var classifier = ee.Classifier.randomForest(300,5).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input.classify(classifier);

classified = classified.updateMask(classified.eq(1)).clip(studyArea).clipToCollection(region);

////Export the classified image
Export.image.toAsset({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  description: 'SGreatPlains_v1_asset',
  assetId: 'SGreatPlains_2010_v1',
  region: studyArea, 
});


Export.image.toDrive({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  folder: 'data',
  description: 'SGreatPlains',
  fileNamePrefix: 'SGreatPlains_2010_v1',
  region: studyArea, 
});
 

Export.table.toDrive({
  collection: training,
  description: 'RandomForestTrainingTable_SGreatPlains_v1',
  folder: 'data',
  fileNamePrefix: 'RFtable_SGreatPlains_2010_v1',
  fileFormat: 'CSV'
});


//print('Classified',classified);

//add layer to map
Map.addLayer(classified, {palette: '00FF00'}, 'cropland');



