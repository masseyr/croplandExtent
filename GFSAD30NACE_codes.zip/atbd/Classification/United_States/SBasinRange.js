/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var Cropclass = /* color: #d63000 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-109.04067993164062, 37.657706645042225]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.92051696777344, 37.82874304738068]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.06059265136719, 37.779373131892065]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.30229187011719, 37.94200610343403]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.14985656738281, 38.05887950625364]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.28375244140625, 38.03562789250816]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.171142578125, 37.71693538532818]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.95828247070312, 37.74300276291078]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.9019775390625, 37.60169474764946]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.70285034179688, 37.579387005342106]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8140869140625, 37.568502753651345]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.97270202636719, 37.4988058814793]),
            {
              "class": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.72894287109375, 37.43613206695562]),
            {
              "class": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.66783142089844, 37.4552122682125]),
            {
              "class": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.63349914550781, 37.35867105932969]),
            {
              "class": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.55796813964844, 37.394138498695646]),
            {
              "class": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.63693237304688, 37.548362694612656]),
            {
              "class": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.71864318847656, 37.515159694601415]),
            {
              "class": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.67538452148438, 37.53040810931919]),
            {
              "class": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.58234405517578, 37.52469031901503]),
            {
              "class": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.51127624511719, 37.51298109524269]),
            {
              "class": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.7258529663086, 37.6074193797922]),
            {
              "class": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.74713897705078, 37.55273052184565]),
            {
              "class": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8470458984375, 37.530680374115825]),
            {
              "class": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.82301330566406, 37.495005224072315]),
            {
              "class": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.61495971679688, 37.38214880003343]),
            {
              "class": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.50784301757812, 37.43232822201059]),
            {
              "class": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.44810485839844, 37.39742435574512]),
            {
              "class": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.37806701660156, 37.310093551949265]),
            {
              "class": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.29498291015625, 37.31691992927826]),
            {
              "class": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.24588775634766, 37.38787749817921]),
            {
              "class": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.27198028564453, 37.1748036916256]),
            {
              "class": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.2534408569336, 37.10337129907453]),
            {
              "class": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.14323425292969, 37.127463320519254]),
            {
              "class": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.15593719482422, 37.20789697019244]),
            {
              "class": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.19679260253906, 37.068588619211]),
            {
              "class": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.0941390991211, 37.13512735600175]),
            {
              "class": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.0560302734375, 37.20789697019244]),
            {
              "class": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.02959442138672, 37.200513776761724]),
            {
              "class": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.1113052368164, 37.21828690766847]),
            {
              "class": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.20365905761719, 37.22730858727501]),
            {
              "class": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.18923950195312, 37.1748036916256]),
            {
              "class": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.18580627441406, 37.10966881734426]),
            {
              "class": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.1442642211914, 37.08392783121447]),
            {
              "class": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.84523010253906, 37.143611632699816]),
            {
              "class": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.84420013427734, 37.17945403620627]),
            {
              "class": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.76626586914062, 37.21117815765112]),
            {
              "class": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.64713287353516, 37.14552730542488]),
            {
              "class": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.58293151855469, 37.09406096514976]),
            {
              "class": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.60078430175781, 37.196685169899936]),
            {
              "class": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.53486633300781, 37.02461457710769]),
            {
              "class": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46740341186523, 37.03516673081827]),
            {
              "class": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5283432006836, 37.052156727867995]),
            {
              "class": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.55254745483398, 37.076401990089806]),
            {
              "class": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.58996963500977, 37.06791018118245]),
            {
              "class": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.66653060913086, 37.06338995966851]),
            {
              "class": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.69262313842773, 37.06927989209588]),
            {
              "class": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.69124984741211, 37.15784759876109]),
            {
              "class": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.86651611328125, 37.258609117206895]),
            {
              "class": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77450561523438, 37.23442222364201]),
            {
              "class": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.80179977416992, 37.17152733490313]),
            {
              "class": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.59408950805664, 37.17822950172629]),
            {
              "class": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5810432434082, 37.215559260373894]),
            {
              "class": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.61194229125977, 37.27718812246766]),
            {
              "class": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.60112762451172, 37.29357755520693]),
            {
              "class": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.65193939208984, 37.20380169428948]),
            {
              "class": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.07986450195312, 37.3750427307756]),
            {
              "class": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99884033203125, 37.31444970555456]),
            {
              "class": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95283508300781, 37.41050242876283]),
            {
              "class": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.97137451171875, 37.19147607265986]),
            {
              "class": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.8038330078125, 37.341204005927636]),
            {
              "class": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99815368652344, 37.62780263174725]),
            {
              "class": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.11625671386719, 37.650095856532424]),
            {
              "class": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.18972778320312, 37.53394747415446]),
            {
              "class": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.00776672363281, 37.540209015854806]),
            {
              "class": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84159851074219, 37.67321036341656]),
            {
              "class": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95146179199219, 37.73704252637134]),
            {
              "class": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01566314697266, 37.79566529161295]),
            {
              "class": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.18938446044922, 37.81628076688411]),
            {
              "class": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.12655639648438, 37.72862526120924]),
            {
              "class": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9521484375, 37.68516609994165]),
            {
              "class": 1,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.2264633178711, 37.67973191309942]),
            {
              "class": 1,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.39494895935059, 37.679605605976136]),
            {
              "class": 1,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.37975692749023, 37.69407327198053]),
            {
              "class": 1,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.42095565795898, 37.65582631770358]),
            {
              "class": 1,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.47168159484863, 37.690813199215775]),
            {
              "class": 1,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.50609970092773, 37.69461660350657]),
            {
              "class": 1,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.73543930053711, 34.73328296418887]),
            {
              "class": 1,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.71415328979492, 34.79180776029375]),
            {
              "class": 1,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.74762725830078, 34.77954214418151]),
            {
              "class": 1,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.75397872924805, 34.6850217169564]),
            {
              "class": 1,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.74676895141602, 34.64859548106035]),
            {
              "class": 1,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.75981521606445, 34.5976001135806]),
            {
              "class": 1,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.73784255981445, 34.53441285670798]),
            {
              "class": 1,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.7874526977539, 34.4738664366645]),
            {
              "class": 1,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.81251525878906, 34.45306114337048]),
            {
              "class": 1,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.03425598144531, 40.43909622353846]),
            {
              "class": 1,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.89452362060547, 40.43752839605532]),
            {
              "class": 1,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.01537322998047, 40.26851182387356]),
            {
              "class": 1,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.80937957763672, 40.362491286046755]),
            {
              "class": 1,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.06206512451172, 40.429950047810514]),
            {
              "class": 1,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.90997314453125, 40.34993336258575]),
            {
              "class": 1,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.9570083618164, 40.3101511763402]),
            {
              "class": 1,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.19012451171875, 40.29156067328612]),
            {
              "class": 1,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.21347045898438, 40.20325149050728]),
            {
              "class": 1,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.05142211914062, 40.122965924005655]),
            {
              "class": 1,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93022918701172, 40.182008669095474]),
            {
              "class": 1,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.093994140625, 40.16180870710859]),
            {
              "class": 1,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.19355773925781, 40.146326746031825]),
            {
              "class": 1,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.31475067138672, 40.18909034888749]),
            {
              "class": 1,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.40504455566406, 40.22134197866281]),
            {
              "class": 1,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.30891418457031, 40.42001850559196]),
            {
              "class": 1,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.28694152832031, 40.34103675175067]),
            {
              "class": 1,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.40538787841797, 40.336326306265214]),
            {
              "class": 1,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.20488739013672, 40.333447538795404]),
            {
              "class": 1,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.10051727294922, 40.37190819372033]),
            {
              "class": 1,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.4290771484375, 40.26694002527974]),
            {
              "class": 1,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.56331634521484, 40.2970598055509]),
            {
              "class": 1,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.7257080078125, 40.37504687056477]),
            {
              "class": 1,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.6869125366211, 40.3449618717661]),
            {
              "class": 1,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.80089569091797, 40.43308601963832]),
            {
              "class": 1,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.65684509277344, 39.174243133903]),
            {
              "class": 1,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.7540054321289, 39.20191765932845]),
            {
              "class": 1,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.68705749511719, 39.100746377832095]),
            {
              "class": 1,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.54595184326172, 39.110870050466666]),
            {
              "class": 1,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.83399963378906, 39.20963265120249]),
            {
              "class": 1,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.80035400390625, 39.2271877494371]),
            {
              "class": 1,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.85528564453125, 39.27185364342542]),
            {
              "class": 1,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.9129638671875, 39.276371821388146]),
            {
              "class": 1,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8192367553711, 39.25617064799601]),
            {
              "class": 1,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.75611877441406, 41.918604915378964]),
            {
              "class": 1,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.48077392578125, 42.03958024543132]),
            {
              "class": 1,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.44163513183594, 41.89203106401366]),
            {
              "class": 1,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.24319458007812, 42.00897530679644]),
            {
              "class": 1,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.93533325195312, 41.95231733594242]),
            {
              "class": 1,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.12828063964844, 41.78511307439815]),
            {
              "class": 1,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.36105346679688, 41.75131239137094]),
            {
              "class": 1,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.44413757324219, 41.77282397745144]),
            {
              "class": 1,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.34251403808594, 41.80610150025853]),
            {
              "class": 1,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.59519958496094, 41.977845184143185]),
            {
              "class": 1,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.60275268554688, 42.039070283845184]),
            {
              "class": 1,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.87147521972656, 41.98958455948941]),
            {
              "class": 1,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.75955200195312, 41.863400701299106]),
            {
              "class": 1,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.49794006347656, 41.94669983670803]),
            {
              "class": 1,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.68745422363281, 42.02580984616001]),
            {
              "class": 1,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.83920288085938, 41.947210538912316]),
            {
              "class": 1,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.42103576660156, 41.730306030123785]),
            {
              "class": 1,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.28851318359375, 41.75643485168844]),
            {
              "class": 1,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.18826293945312, 41.57228248938457]),
            {
              "class": 1,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.12852478027344, 41.69083648909552]),
            {
              "class": 1,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.97402954101562, 41.80200673737047]),
            {
              "class": 1,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.09007263183594, 41.8275947119649]),
            {
              "class": 1,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00218200683594, 42.01509747308709]),
            {
              "class": 1,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.86897277832031, 41.941592589655365]),
            {
              "class": 1,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.86485290527344, 42.03142036895727]),
            {
              "class": 1,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88133239746094, 41.88180740689644]),
            {
              "class": 1,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.03514099121094, 41.933420103439626]),
            {
              "class": 1,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.07359313964844, 42.01152628102922]),
            {
              "class": 1,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.97540283203125, 41.777944720705605]),
            {
              "class": 1,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95171356201172, 41.64545424184176]),
            {
              "class": 1,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88167572021484, 41.65494608450451]),
            {
              "class": 1,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.90742492675781, 41.67725923091461]),
            {
              "class": 1,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.86897277832031, 41.59129835830633]),
            {
              "class": 1,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.79584503173828, 41.58796025271154]),
            {
              "class": 1,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.81987762451172, 41.547632579313166]),
            {
              "class": 1,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.060546875, 41.35977912787913]),
            {
              "class": 1,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.18620300292969, 41.51626572223072]),
            {
              "class": 1,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.06192016601562, 41.128997103636664]),
            {
              "class": 1,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.16011047363281, 41.15743706945769]),
            {
              "class": 1,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.75636291503906, 41.28089651290853]),
            {
              "class": 1,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.7587661743164, 41.25638175781059]),
            {
              "class": 1,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.71670913696289, 41.246057002025026]),
            {
              "class": 1,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.81180953979492, 41.291215761226454]),
            {
              "class": 1,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.77919387817383, 41.24476629282323]),
            {
              "class": 1,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.76168441772461, 41.1356092840339]),
            {
              "class": 1,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.75172805786133, 41.09487105788163]),
            {
              "class": 1,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.69816970825195, 41.03701818746175]),
            {
              "class": 1,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.73730850219727, 41.02665883675413]),
            {
              "class": 1,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.62641525268555, 41.048411590516764]),
            {
              "class": 1,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.69147491455078, 40.997514424305805]),
            {
              "class": 1,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.66074752807617, 40.95643130983011]),
            {
              "class": 1,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.68731212615967, 40.97523100219997]),
            {
              "class": 1,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.6789436340332, 41.0162978560679]),
            {
              "class": 1,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.68460845947266, 41.00075332900894]),
            {
              "class": 1,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.81816101074219, 39.92525965248259]),
            {
              "class": 1,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.79035186767578, 39.956846938442304]),
            {
              "class": 1,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.76013946533203, 39.991313075941605]),
            {
              "class": 1,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.7803955078125, 40.028916572377625]),
            {
              "class": 1,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.78451538085938, 40.005778410746146]),
            {
              "class": 1,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.94347381591797, 39.97000400370894]),
            {
              "class": 1,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.94313049316406, 39.954478397811904]),
            {
              "class": 1,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.97059631347656, 40.08672764793543]),
            {
              "class": 1,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95171356201172, 40.122965924005655]),
            {
              "class": 1,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.76185607910156, 40.10721252371651]),
            {
              "class": 1,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.64512634277344, 40.07858451055515]),
            {
              "class": 1,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.6818618774414, 40.1479013439649]),
            {
              "class": 1,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.6983413696289, 40.103273603453346]),
            {
              "class": 1,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.67980194091797, 40.02944234850662]),
            {
              "class": 1,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.64993286132812, 40.02812790058541]),
            {
              "class": 1,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.79241180419922, 40.05125848374577]),
            {
              "class": 1,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.74434661865234, 40.10169797148943]),
            {
              "class": 1,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.85043334960938, 40.00157062939964]),
            {
              "class": 1,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8569564819336, 40.0365399295863]),
            {
              "class": 1,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95068359375, 39.89339437613285]),
            {
              "class": 1,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8463134765625, 39.88786252946934]),
            {
              "class": 1,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95171356201172, 40.034437019602564]),
            {
              "class": 1,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.71207427978516, 40.08935425867519]),
            {
              "class": 1,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.60907745361328, 40.12611616613682]),
            {
              "class": 1,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.7203140258789, 40.252268143756545]),
            {
              "class": 1,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.74571990966797, 40.300463806019664]),
            {
              "class": 1,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.80339813232422, 40.357520721012435]),
            {
              "class": 1,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.92459106445312, 40.35673586145459]),
            {
              "class": 1,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.92012786865234, 40.37687769787748]),
            {
              "class": 1,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.80442810058594, 40.43360866739166]),
            {
              "class": 1,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.90433502197266, 40.42054125489892]),
            {
              "class": 1,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00458526611328, 40.32821310147516]),
            {
              "class": 1,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.06912994384766, 40.370600368554776]),
            {
              "class": 1,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.10517883300781, 40.27348894511423]),
            {
              "class": 1,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.07633972167969, 40.29051316878334]),
            {
              "class": 1,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.09968566894531, 40.209282189778385]),
            {
              "class": 1,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.09110260009766, 40.13346616339707]),
            {
              "class": 1,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.0272445678711, 40.13451609812275]),
            {
              "class": 1,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.98226928710938, 40.1360909697968]),
            {
              "class": 1,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.0880126953125, 40.07227947723676]),
            {
              "class": 1,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.12715148925781, 40.1095757664007]),
            {
              "class": 1,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.98982238769531, 39.87574359116102]),
            {
              "class": 1,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.851806640625, 39.61624309568799]),
            {
              "class": 1,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.917724609375, 39.45419664659368]),
            {
              "class": 1,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.02072143554688, 39.671231550639106]),
            {
              "class": 1,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.85249328613281, 39.743073538130936]),
            {
              "class": 1,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.85111999511719, 39.8628195785334]),
            {
              "class": 1,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.86416625976562, 39.65643126822084]),
            {
              "class": 1,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88682556152344, 39.6902558270412]),
            {
              "class": 1,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.90811157226562, 39.70135090132441]),
            {
              "class": 1,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.89163208007812, 39.53950353490172]),
            {
              "class": 1,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93042755126953, 39.54638710037354]),
            {
              "class": 1,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.83292388916016, 39.735693869316115]),
            {
              "class": 1,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.83326721191406, 39.10766077054007]),
            {
              "class": 1,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.83601379394531, 38.99247968937393]),
            {
              "class": 1,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.72615051269531, 39.079416137699816]),
            {
              "class": 1,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8902587890625, 39.20243728399505]),
            {
              "class": 1,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93077087402344, 38.942295945481334]),
            {
              "class": 1,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00218200683594, 38.834334034435805]),
            {
              "class": 1,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.05162048339844, 38.800629185991156]),
            {
              "class": 1,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.12028503417969, 38.704777593892956]),
            {
              "class": 1,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.15461730957031, 38.6329385561378]),
            {
              "class": 1,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.90879821777344, 38.43958141238845]),
            {
              "class": 1,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.89849853515625, 38.464317114398646]),
            {
              "class": 1,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.59156799316406, 38.37339865363646]),
            {
              "class": 1,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.54281616210938, 38.32224041657504]),
            {
              "class": 1,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.62384033203125, 38.421293052533606]),
            {
              "class": 1,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.5606689453125, 38.42667246270709]),
            {
              "class": 1,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.58607482910156, 38.46646764424791]),
            {
              "class": 1,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.44771575927734, 38.269171887700566]),
            {
              "class": 1,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.52359008789062, 38.30124078219427]),
            {
              "class": 1,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.34712219238281, 38.238437139998005]),
            {
              "class": 1,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.39965057373047, 38.32359977440376]),
            {
              "class": 1,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.07074737548828, 38.08132568132671]),
            {
              "class": 1,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.11798095703125, 37.73324129930224]),
            {
              "class": 1,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.0987548828125, 37.72373737783166]),
            {
              "class": 1,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.08296203613281, 37.814653438601994]),
            {
              "class": 1,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.95455932617188, 37.81194114508439]),
            {
              "class": 1,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.9336166381836, 37.83038277596951]),
            {
              "class": 1,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.85259246826172, 37.89489219003429]),
            {
              "class": 1,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.8024673461914, 37.85478373111453]),
            {
              "class": 1,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.73208618164062, 37.96719476866012]),
            {
              "class": 1,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.7083969116211, 38.04699692789104]),
            {
              "class": 1,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.5992202758789, 39.35711827576595]),
            {
              "class": 1,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.6486587524414, 39.42265613022678]),
            {
              "class": 1,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.74375915527344, 39.408333274178]),
            {
              "class": 1,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.72384643554688, 39.44784660468499]),
            {
              "class": 1,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.5992202758789, 39.26414549095994]),
            {
              "class": 1,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.64934539794922, 39.34729556384775]),
            {
              "class": 1,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.5552749633789, 39.31728792274118]),
            {
              "class": 1,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.72109985351562, 39.255373113802335]),
            {
              "class": 1,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.67372131347656, 39.254841419299886]),
            {
              "class": 1,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.60643005371094, 39.313038012427725]),
            {
              "class": 1,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.59063720703125, 39.43936240958917]),
            {
              "class": 1,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.664794921875, 39.3825977910835]),
            {
              "class": 1,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.77774810791016, 39.37251326132316]),
            {
              "class": 1,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.26036071777344, 39.15108395875108]),
            {
              "class": 1,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.32044219970703, 39.158272104903084]),
            {
              "class": 1,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.38018035888672, 39.19420182004692]),
            {
              "class": 1,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.37503051757812, 39.10740685240098]),
            {
              "class": 1,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.23323822021484, 39.11939412068757]),
            {
              "class": 1,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.41382598876953, 39.05490525582318]),
            {
              "class": 1,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.41485595703125, 38.96019716876637]),
            {
              "class": 1,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.40936279296875, 38.9236139470074]),
            {
              "class": 1,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.49656677246094, 38.83274193969842]),
            {
              "class": 1,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.53467559814453, 38.810540836013864]),
            {
              "class": 1,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.54144287109375, 39.39480343053075]),
            {
              "class": 1,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.53491973876953, 39.495815874579186]),
            {
              "class": 1,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.59980773925781, 39.348092051391895]),
            {
              "class": 1,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.62315368652344, 39.28274992955739]),
            {
              "class": 1,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.48822784423828, 39.540575000113726]),
            {
              "class": 1,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.64752960205078, 39.53130772687594]),
            {
              "class": 1,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.64306640625, 39.564928789190404]),
            {
              "class": 1,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.40823364257812, 39.555664768294115]),
            {
              "class": 1,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.4284896850586, 39.602237024262614]),
            {
              "class": 1,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.42780303955078, 39.681285179527244]),
            {
              "class": 1,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.42745971679688, 39.730413353016964]),
            {
              "class": 1,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.47964477539062, 39.79190627033277]),
            {
              "class": 1,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.48256301879883, 39.775887814377555]),
            {
              "class": 1,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.51028633117676, 39.77674535948443]),
            {
              "class": 1,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.51457786560059, 39.783869167268904]),
            {
              "class": 1,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.38037109375, 32.52189378401301]),
            {
              "class": 1,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.30621337890625, 32.56993543575752]),
            {
              "class": 1,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.24235534667969, 32.71101730883751]),
            {
              "class": 1,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.31170654296875, 32.81783667078403]),
            {
              "class": 1,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.33779907226562, 32.52478858702678]),
            {
              "class": 1,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.18855285644531, 31.442696389157533]),
            {
              "class": 1,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.15628051757812, 31.470811532695]),
            {
              "class": 1,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.47694396972656, 31.535210222052985]),
            {
              "class": 1,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.06427001953125, 38.59699201146158]),
            {
              "class": 1,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.79647827148438, 38.7952777431904]),
            {
              "class": 1,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.08177947998047, 38.66593097295112]),
            {
              "class": 1,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.94273376464844, 38.723810053736244]),
            {
              "class": 1,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.006591796875, 38.757551219429466]),
            {
              "class": 1,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.11954498291016, 38.76477939500036]),
            {
              "class": 1,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.18134307861328, 38.791276441006204]),
            {
              "class": 1,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.92556762695312, 38.58627078846004]),
            {
              "class": 1,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.764892578125, 38.52881769991729]),
            {
              "class": 1,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.73365020751953, 38.457877742176684]),
            {
              "class": 1,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.87269592285156, 38.429105673669596]),
            {
              "class": 1,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.91080474853516, 38.48341342340715]),
            {
              "class": 1,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.962646484375, 38.48395091949744]),
            {
              "class": 1,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.04367065429688, 38.55620760978684]),
            {
              "class": 1,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.97740936279297, 38.43905619092644]),
            {
              "class": 1,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78583526611328, 38.328178476380685]),
            {
              "class": 1,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.75287628173828, 38.4067792548914]),
            {
              "class": 1,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81776428222656, 38.36937377686824]),
            {
              "class": 1,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.874755859375, 38.27725781857295]),
            {
              "class": 1,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.9018783569336, 38.294774246580396]),
            {
              "class": 1,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.92522430419922, 38.33518063757507]),
            {
              "class": 1,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.94239044189453, 38.33666808888977]),
            {
              "class": 1,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.00333023071289, 38.40907231778532]),
            {
              "class": 1,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.05809020996094, 38.40422968708246]),
            {
              "class": 1,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.1051254272461, 38.41082096579445]),
            {
              "class": 1,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.1190299987793, 38.44228939359987]),
            {
              "class": 1,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.39909553527832, 38.62853527634949]),
            {
              "class": 1,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.2757568359375, 36.58463176743834]),
            {
              "class": 1,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42544555664062, 36.61384835824413]),
            {
              "class": 1,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.29978942871094, 36.65131758824466]),
            {
              "class": 1,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.03749084472656, 36.597863292467665]),
            {
              "class": 1,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.04916381835938, 36.69456275071862]),
            {
              "class": 1,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.90874481201172, 36.695388608158865]),
            {
              "class": 1,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.2040023803711, 36.91282991970935]),
            {
              "class": 1,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3636474609375, 36.70199514830851]),
            {
              "class": 1,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.46355438232422, 36.75400180690166]),
            {
              "class": 1,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88648223876953, 41.77911483316238]),
            {
              "class": 1,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.85970306396484, 41.802792520265555]),
            {
              "class": 1,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.78537368774414, 41.79920943201278]),
            {
              "class": 1,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.80974960327148, 41.84756421763915]),
            {
              "class": 1,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8653678894043, 41.864697093533515]),
            {
              "class": 1,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.84820175170898, 41.89026001245793]),
            {
              "class": 1,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.84854507446289, 41.91389660850583]),
            {
              "class": 1,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.87000274658203, 41.92794665267001]),
            {
              "class": 1,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.80837631225586, 41.9482498850598]),
            {
              "class": 1,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.89146041870117, 41.93216106265813]),
            {
              "class": 1,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.81781768798828, 41.96497284853494]),
            {
              "class": 1,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.81524276733398, 41.98169142374006]),
            {
              "class": 1,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.87034606933594, 41.99330250739716]),
            {
              "class": 1,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.80013656616211, 41.993812836111104]),
            {
              "class": 1,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8082046508789, 42.00172240793041]),
            {
              "class": 1,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.84459686279297, 42.01511540825544]),
            {
              "class": 1,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.8569564819336, 42.02646536247374]),
            {
              "class": 1,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.83910369873047, 42.03845075469368]),
            {
              "class": 1,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.80562973022461, 42.04393268071733]),
            {
              "class": 1,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.86107635498047, 41.97888403069734]),
            {
              "class": 1,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.90193176269531, 41.963185871021835]),
            {
              "class": 1,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.94845199584961, 41.97084399319398]),
            {
              "class": 1,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.96819305419922, 41.8538297567953]),
            {
              "class": 1,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.97883605957031, 41.83937973205154]),
            {
              "class": 1,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.92184448242188, 41.782571040669374]),
            {
              "class": 1,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.99274063110352, 41.71725565116624]),
            {
              "class": 1,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.9917106628418, 41.73993146303147]),
            {
              "class": 1,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.99411392211914, 41.760422484063945]),
            {
              "class": 1,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.91411972045898, 41.70315930611312]),
            {
              "class": 1,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88837051391602, 41.6755984342504]),
            {
              "class": 1,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.13872528076172, 41.932544177032185]),
            {
              "class": 1,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.17855072021484, 41.680983346518325]),
            {
              "class": 1,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.1677360534668, 41.70046783431345]),
            {
              "class": 1,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.15365982055664, 41.738650557044636]),
            {
              "class": 1,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.10010147094727, 41.68200899300755]),
            {
              "class": 1,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.20035171508789, 41.63147648131008]),
            {
              "class": 1,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.15108489990234, 41.55213497038253]),
            {
              "class": 1,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.14387512207031, 41.52553761527854]),
            {
              "class": 1,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.15486145019531, 41.49057180493298]),
            {
              "class": 1,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.1600112915039, 41.48118438442331]),
            {
              "class": 1,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.14559173583984, 41.53286261596365]),
            {
              "class": 1,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.16464614868164, 41.58116113731963]),
            {
              "class": 1,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.22884750366211, 41.621082904634875]),
            {
              "class": 1,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.19726181030273, 41.674572685590405]),
            {
              "class": 1,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.19348526000977, 41.7087982150614]),
            {
              "class": 1,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.22283935546875, 41.67482912428798]),
            {
              "class": 1,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.170654296875, 41.7114893381643]),
            {
              "class": 1,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.12643003463745, 41.696868265297354]),
            {
              "class": 1,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.11825466156006, 41.71785352615553]),
            {
              "class": 1,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.1163878440857, 41.73044139464632]),
            {
              "class": 1,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.28498077392578, 40.68154317830389]),
            {
              "class": 1,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.33716583251953, 40.69807378942517]),
            {
              "class": 1,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.26558303833008, 40.708094288999455]),
            {
              "class": 1,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.24567031860352, 40.590616706650465]),
            {
              "class": 1,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.25408172607422, 40.59765555212832]),
            {
              "class": 1,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.43741607666016, 40.47984690396552]),
            {
              "class": 1,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.44256591796875, 40.39126103857886]),
            {
              "class": 1,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.42402648925781, 40.529184801294086]),
            {
              "class": 1,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.36909484863281, 40.48141374416727]),
            {
              "class": 1,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.41372680664062, 40.37740078225822]),
            {
              "class": 1,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.45698547363281, 40.51926792732642]),
            {
              "class": 1,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.830810546875, 38.83219451831986]),
            {
              "class": 1,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.59666442871094, 38.64527426129666]),
            {
              "class": 1,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.55735397338867, 38.708949095496564]),
            {
              "class": 1,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.65914916992188, 38.71711976109706]),
            {
              "class": 1,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.65296936035156, 38.768801005515535]),
            {
              "class": 1,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.68404006958008, 38.81014581772136]),
            {
              "class": 1,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.74532318115234, 38.805330180521196]),
            {
              "class": 1,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.79287338256836, 38.775492730615206]),
            {
              "class": 1,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8392219543457, 38.871516653882416]),
            {
              "class": 1,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78806686401367, 38.90345131551584]),
            {
              "class": 1,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8831672668457, 38.877396916595764]),
            {
              "class": 1,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.9490852355957, 38.916675275613876]),
            {
              "class": 1,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.84523010253906, 38.846252719883985]),
            {
              "class": 1,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.80712127685547, 38.84865919552723]),
            {
              "class": 1,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.48123550415039, 39.04597968213058]),
            {
              "class": 1,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.51024627685547, 39.043046598637716]),
            {
              "class": 1,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.43608856201172, 39.07876859346329]),
            {
              "class": 1,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42046737670898, 39.103283676567074]),
            {
              "class": 1,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.35111618041992, 39.10861191478263]),
            {
              "class": 1,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.36416244506836, 39.09315891436551]),
            {
              "class": 1,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5838623046875, 36.700212384653746]),
            {
              "class": 1,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.54386520385742, 36.73021063793657]),
            {
              "class": 1,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.55879974365234, 36.739978182326105]),
            {
              "class": 1,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.58437728881836, 36.72099223810437]),
            {
              "class": 1,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.56652450561523, 36.754283327756944]),
            {
              "class": 1,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59244537353516, 36.74272937893643]),
            {
              "class": 1,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5703010559082, 36.68754905694448]),
            {
              "class": 1,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.52961730957031, 36.703377890679384]),
            {
              "class": 1,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.62574768066406, 36.70117581333177]),
            {
              "class": 1,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.51931762695312, 36.74451760384933]),
            {
              "class": 1,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.50850296020508, 36.78591023557121]),
            {
              "class": 1,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.60703659057617, 36.77683602282321]),
            {
              "class": 1,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.65836334228516, 36.735438492322594]),
            {
              "class": 1,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6769027709961, 36.76501043666348]),
            {
              "class": 1,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46350884437561, 38.72041580774949]),
            {
              "class": 1,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5396728515625, 40.59727063442027]),
            {
              "class": 1,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.53246307373047, 40.667879144351105]),
            {
              "class": 1,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.67253875732422, 40.59283882963389]),
            {
              "class": 1,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.67356872558594, 40.483515047963]),
            {
              "class": 1,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.54962921142578, 40.48586516612557]),
            {
              "class": 1,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.50259399414062, 40.49056515559303]),
            {
              "class": 1,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.43839263916016, 40.6113461833302]),
            {
              "class": 1,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.4191665649414, 40.66319159533881]),
            {
              "class": 1,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.4184799194336, 40.47071851668331]),
            {
              "class": 1,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.49160766601562, 40.47306908282609]),
            {
              "class": 1,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.50465393066406, 40.61551614707258]),
            {
              "class": 1,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77965545654297, 40.47254674190491]),
            {
              "class": 1,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.65434265136719, 40.486648520560806]),
            {
              "class": 1,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.79647827148438, 40.327701904195926]),
            {
              "class": 1,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.01071166992188, 40.38578183826235]),
            {
              "class": 1,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.56576538085938, 40.46680072360456]),
            {
              "class": 1,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.63236999511719, 40.444856858961764]),
            {
              "class": 1,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.23342895507812, 40.452172276813535]),
            {
              "class": 1,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.35221862792969, 40.421337622988474]),
            {
              "class": 1,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.91139221191406, 40.18307014852534]),
            {
              "class": 1,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.820068359375, 40.06913905733146]),
            {
              "class": 1,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.91551208496094, 39.88128876522249]),
            {
              "class": 1,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.7156982421875, 39.94870062390347]),
            {
              "class": 1,
              "system:index": "467"
            })]),
    NonCropClass = /* color: #98ff00 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-113.6041259765625, 40.31085067505636]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.35418701171875, 40.01910271017195]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.82659912109375, 40.474015815389315]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.7908935546875, 40.79292133965548]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.42559814453125, 40.84072963998787]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.49700927734375, 41.083394724758286]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.83209228515625, 41.02125797421838]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.08502197265625, 41.11237178923261]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.84332275390625, 40.78668293442747]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.78839111328125, 40.73259220734207]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.6153564453125, 40.983947757475136]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.7197265625, 41.24054509236714]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.532958984375, 41.11030242286163]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.379150390625, 40.94246719077515]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.27203369140625, 40.78044394311388]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.15118408203125, 40.92171713127252]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00286865234375, 40.94869093780032]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.23883056640625, 41.4302753539028]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.8790283203125, 41.45086490307443]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.4228515625, 41.60918557650415]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.56842041015625, 41.734333315427726]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.61785888671875, 41.63587680602093]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.73870849609375, 41.707682887720395]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.86505126953125, 41.94509588599702]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.94744873046875, 41.70980539709283]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.8677978515625, 41.60258324705965]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.90556335449219, 41.59744852633223]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.89251708984375, 41.51318082135007]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.98796081542969, 41.615418261427635]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-114.0380859375, 41.6872471473548]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-114.0106201171875, 41.796376011115704]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-114.08203125, 41.816849007754826]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-114.04495239257812, 41.90889652128793]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-114.03877258300781, 41.98856383016755]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.79638671875, 41.99723950769961]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.66455078125, 42.014077152959715]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.59382629394531, 42.00081150179149]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.543701171875, 42.03397044289749]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.3953857421875, 42.04416971554282]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.36311340332031, 41.996729206461794]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.697509765625, 41.87362730324837]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.7689208984375, 42.06507310663371]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.44963073730469, 41.848057731029954]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.38096618652344, 41.788696950735456]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.24089050292969, 41.704679216976196]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.27865600585938, 41.83782703938092]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.24569702148438, 41.907363481968886]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.37203979492188, 41.903275197136495]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.41323852539062, 41.924224889630985]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.15231323242188, 41.89254220392225]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.02871704101562, 41.857775372908506]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.4722900390625, 41.67186198594323]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.19557189941406, 41.5871778592449]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.08708190917969, 41.96252970263594]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.15437316894531, 42.05691650426849]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.05755615234375, 42.058445947021795]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.88520812988281, 42.01560762701256]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.87765502929688, 41.86135518459581]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.78564453125, 42.01917858991016]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.67440795898438, 41.91502831041424]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.69912719726562, 41.84345412221819]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.82135009765625, 41.75899592854347]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.60231018066406, 41.99723950769961]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.50274658203125, 41.798935493472634]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.57484436035156, 41.784601075709894]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.48626708984375, 41.996729206461794]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.46429443359375, 41.84908071022518]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.30705261230469, 41.931887693182375]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.34619140625, 41.88231862860887]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.25761413574219, 41.783065055113696]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.34687805175781, 42.046719277920516]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.1484375, 42.05130823236508]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.03170776367188, 41.996729206461794]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.0111083984375, 42.0640535886378]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.76048278808594, 41.95538121778354]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93351745605469, 41.99228183769383]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93437576293945, 41.96050531077879]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.98896408081055, 41.957952291421506]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.01883316040039, 41.959867065528485]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.97385787963867, 41.90738144748661]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.92132949829102, 41.88016388125883]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.89180374145508, 41.91568496775381]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.96098327636719, 41.87569040175441]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.99068069458008, 41.859199730469726]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.94210052490234, 41.846796966588904]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.92562103271484, 41.86827651772684]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95171356201172, 41.80522378747537]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00990676879883, 41.80701518849127]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.9865608215332, 41.793194512039875]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95291519165039, 41.77578645728067]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.92991256713867, 41.75517228322251]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.88751220703125, 41.70764484210177]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95566177368164, 41.75197073045319]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93866729736328, 41.73544818030143]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93403244018555, 41.70328746862695]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93626403808594, 41.68931625105369]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.85009002685547, 41.737882001189064]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.85626983642578, 41.73967528387803]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.83481216430664, 41.73916292250525]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.82039260864258, 41.746591762309656]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.80854797363281, 41.7424931983579]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.83979034423828, 41.75965418881806]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.85541152954102, 41.78589906442836]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.74949645996094, 41.80228066278169]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.77335739135742, 41.83822870480365]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.73009872436523, 41.84219326705659]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.72237396240234, 41.825054363196855]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.79309844970703, 41.84948230500805]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.77318572998047, 41.919383279409914]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.7587661743164, 41.873894930627756]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.67156219482422, 41.88181938870214]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.61216735839844, 41.86699218265707]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.55448913574219, 41.947477857966184]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.48204803466797, 41.90609789833283]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.52702331542969, 41.90252059250902]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.38626098632812, 41.87491749656244]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.40857696533203, 41.814558116648776]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.35604858398438, 41.83323468537771]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.26781463623047, 41.880030080834615]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.41613006591797, 41.915295764371066]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.4178466796875, 41.8848866570496]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.43501281738281, 41.99674116669389]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.38282775878906, 42.05769317901991]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.20018005371094, 42.042141943670245]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.24755859375, 41.99648601458845]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.13700866699219, 42.027862047942534]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.1105728149414, 41.937007688975996]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.04053497314453, 42.00771173948712]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.02027893066406, 41.98807140216179]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.95813751220703, 42.013329837794224]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.9238052368164, 41.97416222691144]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.9864616394043, 41.91913380479279]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.9292984008789, 41.899332389342916]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.04070663452148, 41.997640171038235]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.07812881469727, 41.98794380885876]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.11211776733398, 42.01600817468777]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.16172790527344, 41.98232945035184]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.16121292114258, 42.039470683716964]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.13941192626953, 42.052600807694546]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.18232727050781, 42.004018551096586]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.17940902709961, 41.986923053228296]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.1929702758789, 41.980925783366935]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.26317977905273, 41.95399490928316]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.24103546142578, 41.921177472125514]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.14679336547852, 41.888854317645745]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.09203338623047, 41.865847644593735]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.04036331176758, 41.88105853958224]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.20086669921875, 41.81392440891645]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.25476837158203, 41.78641105275144]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.16104125976562, 41.788970933037696]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.13391876220703, 41.77527438412105]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.192626953125, 41.75158653338972]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.26283645629883, 41.71699938157338]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.25494003295898, 41.73224564387963]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.23056411743164, 41.65084768803002]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.26850128173828, 41.61800300459517]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.20378494262695, 41.619671302041965]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.33424758911133, 41.66739198725646]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.33527755737305, 41.64622991574721]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.14625692367554, 41.69286266619272]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.13763093948364, 41.6971566588058]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.08963012695312, 41.557897493102956]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.19537353515625, 41.55635605355503]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.07315063476562, 41.45299587001796]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.11640930175781, 41.24732953566907]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.25442504882812, 41.33709849990821]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.99281311035156, 41.26436417587962]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.95848083496094, 41.140374569991906]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.89187622070312, 40.96795004172303]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.0498046875, 40.942021457218125]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.10336303710938, 40.805469480878855]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.74630737304688, 41.02547509624335]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.77445983886719, 40.710957011977925]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.82406997680664, 40.713949727139784]),
            {
              "class": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.76278686523438, 40.74230878214987]),
            {
              "class": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.71369171142578, 40.75232262425658]),
            {
              "class": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.6821060180664, 40.76389518637726]),
            {
              "class": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.69635391235352, 40.70106708356051]),
            {
              "class": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.72072982788086, 40.72800067777736]),
            {
              "class": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.79883575439453, 40.68076210310659]),
            {
              "class": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.79694747924805, 40.711997971638766]),
            {
              "class": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.82029342651367, 40.76610544660787]),
            {
              "class": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.83196640014648, 40.770265737042365]),
            {
              "class": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.90595245361328, 40.73801667393962]),
            {
              "class": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.90097427368164, 40.69703261211068]),
            {
              "class": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.96551895141602, 40.726049334224555]),
            {
              "class": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.9813117980957, 40.699114950467084]),
            {
              "class": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.02560043334961, 40.708744918664884]),
            {
              "class": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.03435516357422, 40.68349582625469]),
            {
              "class": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.12842559814453, 40.740295874787805]),
            {
              "class": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.1201000213623, 40.72709310687767]),
            {
              "class": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.14662170410156, 40.73574349214926]),
            {
              "class": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.32532119750977, 40.61459788150325]),
            {
              "class": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.25288009643555, 40.61967974279391]),
            {
              "class": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.27862930297852, 40.64234795253296]),
            {
              "class": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.31982803344727, 40.6435202368274]),
            {
              "class": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.27107620239258, 40.65680468652003]),
            {
              "class": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.27777099609375, 40.63778887344497]),
            {
              "class": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.29596710205078, 40.58188229425215]),
            {
              "class": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.29940032958984, 40.599575652500505]),
            {
              "class": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.30274772644043, 40.59801971991705]),
            {
              "class": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.2980055809021, 40.60020290303777]),
            {
              "class": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.30628824234009, 40.601449240535175]),
            {
              "class": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.5885238647461, 37.34585688229762]),
            {
              "class": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.47591400146484, 37.33111680840518]),
            {
              "class": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.50269317626953, 37.30954741498439]),
            {
              "class": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.52020263671875, 37.299170058927785]),
            {
              "class": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.47591400146484, 37.28742553429143]),
            {
              "class": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.65306854248047, 37.315008606110524]),
            {
              "class": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.63418579101562, 37.31937727336677]),
            {
              "class": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.68362426757812, 37.31200500008517]),
            {
              "class": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.67744445800781, 37.350769597389245]),
            {
              "class": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.77632141113281, 37.34230861037428]),
            {
              "class": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.81786346435547, 37.360048293254245]),
            {
              "class": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8140869140625, 37.39878809328229]),
            {
              "class": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.78387451171875, 37.42851140390202]),
            {
              "class": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.76155853271484, 37.45631519355349]),
            {
              "class": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.82232666015625, 37.44023386899063]),
            {
              "class": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.81752010160156, 37.47130314528448]),
            {
              "class": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8199234008789, 37.460403114718055]),
            {
              "class": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.85116577148438, 37.484925948553126]),
            {
              "class": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.89717102050781, 37.44813868085134]),
            {
              "class": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.91674041748047, 37.437235273612934]),
            {
              "class": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.89991760253906, 37.46830579530284]),
            {
              "class": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90850067138672, 37.50344897531697]),
            {
              "class": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.97579193115234, 37.46231073478595]),
            {
              "class": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.98609161376953, 37.47675256459908]),
            {
              "class": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0011978149414, 37.49119160409569]),
            {
              "class": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.97819519042969, 37.52278429152068]),
            {
              "class": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.01905059814453, 37.53912008984962]),
            {
              "class": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0884017944336, 37.57422993907659]),
            {
              "class": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.15946960449219, 37.53367522128417]),
            {
              "class": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1440200805664, 37.561984196113805]),
            {
              "class": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.00806427001953, 37.438053084268184]),
            {
              "class": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.061279296875, 37.413514877375796]),
            {
              "class": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.13749694824219, 37.35677359039166]),
            {
              "class": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.18006896972656, 37.333846669966015]),
            {
              "class": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.10179138183594, 37.3731456758161]),
            {
              "class": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.95553588867188, 37.23386913097802]),
            {
              "class": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.00909423828125, 37.19941990890115]),
            {
              "class": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.93184661865234, 37.21035787416246]),
            {
              "class": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.92841339111328, 37.122809777433105]),
            {
              "class": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.87794494628906, 37.144706308769535]),
            {
              "class": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.04033660888672, 37.180274655534575]),
            {
              "class": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.01381492614746, 37.19731171162675]),
            {
              "class": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.01364326477051, 37.18076296254484]),
            {
              "class": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0239429473877, 37.172693204148445]),
            {
              "class": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.9884090423584, 37.18637025310645]),
            {
              "class": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.18212890625, 37.29806482027039]),
            {
              "class": 2,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.37232971191406, 37.2210080487424]),
            {
              "class": 2,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.40048217773438, 37.11102493991542]),
            {
              "class": 2,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.32632446289062, 37.045287112637844]),
            {
              "class": 2,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.61334228515625, 37.07268480063908]),
            {
              "class": 2,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.53849792480469, 37.21280588129361]),
            {
              "class": 2,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.73831176757812, 37.25052846667287]),
            {
              "class": 2,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.06466674804688, 40.099059526883686]),
            {
              "class": 2,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.26310729980469, 40.06438504819476]),
            {
              "class": 2,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.27203369140625, 40.2270966580181]),
            {
              "class": 2,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.08045959472656, 40.24020157632768]),
            {
              "class": 2,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.91017150878906, 40.271119127967744]),
            {
              "class": 2,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.11753845214844, 40.31354224581377]),
            {
              "class": 2,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.09968566894531, 40.358554923041005]),
            {
              "class": 2,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.04818725585938, 40.43385774028236]),
            {
              "class": 2,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.9781494140625, 40.316160084060705]),
            {
              "class": 2,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.83258056640625, 40.40040021888268]),
            {
              "class": 2,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.74674987792969, 40.38209610005048]),
            {
              "class": 2,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.68220520019531, 40.31040070595326]),
            {
              "class": 2,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.64718627929688, 40.26692774545943]),
            {
              "class": 2,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.69044494628906, 40.27269082944298]),
            {
              "class": 2,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.73027038574219, 40.303593534916594]),
            {
              "class": 2,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.64993286132812, 40.21765954657702]),
            {
              "class": 2,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.65130615234375, 40.135291234835904]),
            {
              "class": 2,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.65336608886719, 40.112189187439526]),
            {
              "class": 2,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.72615051269531, 40.03232172246472]),
            {
              "class": 2,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.81678771972656, 40.053348556430954]),
            {
              "class": 2,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.81747436523438, 40.10431169519691]),
            {
              "class": 2,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.02072143554688, 40.03442469767331]),
            {
              "class": 2,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.87034606933594, 40.02075419975271]),
            {
              "class": 2,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.69044494628906, 39.92709030334189]),
            {
              "class": 2,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.93489074707031, 39.860711321303704]),
            {
              "class": 2,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.72409057617188, 39.79479564683564]),
            {
              "class": 2,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.76460266113281, 39.81853257514526]),
            {
              "class": 2,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95205688476562, 39.656959904319336]),
            {
              "class": 2,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.91085815429688, 39.77421701371631]),
            {
              "class": 2,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.07771301269531, 39.72247944201909]),
            {
              "class": 2,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00630187988281, 39.53791492283308]),
            {
              "class": 2,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00424194335938, 39.444122468579316]),
            {
              "class": 2,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.11204528808594, 39.40487230480893]),
            {
              "class": 2,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.13882446289062, 39.531560110971554]),
            {
              "class": 2,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.13539123535156, 39.65325936672557]),
            {
              "class": 2,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.35374450683594, 39.709803094154175]),
            {
              "class": 2,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.16148376464844, 39.79532322316405]),
            {
              "class": 2,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.13401794433594, 39.81114863121955]),
            {
              "class": 2,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.00698852539062, 39.96499228270098]),
            {
              "class": 2,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.22808837890625, 39.93077613948325]),
            {
              "class": 2,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.38258361816406, 40.16153403145974]),
            {
              "class": 2,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.43408203125, 40.20192810631704]),
            {
              "class": 2,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.3406982421875, 40.34808953826487]),
            {
              "class": 2,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.4066162109375, 40.513252661114784]),
            {
              "class": 2,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.69912719726562, 40.38157305212412]),
            {
              "class": 2,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.69706726074219, 40.53047731205748]),
            {
              "class": 2,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.4835205078125, 40.6712399792906]),
            {
              "class": 2,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.43339538574219, 40.75607539452446]),
            {
              "class": 2,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.57759094238281, 40.75347468833848]),
            {
              "class": 2,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.76985168457031, 40.69831577947824]),
            {
              "class": 2,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.65243530273438, 40.77063746906778]),
            {
              "class": 2,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.50892639160156, 40.81274550387873]),
            {
              "class": 2,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.55218505859375, 40.828853858387845]),
            {
              "class": 2,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.2637939453125, 40.64467418407071]),
            {
              "class": 2,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.94313049316406, 40.52578011892881]),
            {
              "class": 2,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.851806640625, 40.60350236287864]),
            {
              "class": 2,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.89918518066406, 40.63998500442856]),
            {
              "class": 2,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.89369201660156, 40.69831577947824]),
            {
              "class": 2,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.90193176269531, 40.47879008224075]),
            {
              "class": 2,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.99256896972656, 40.67436467143694]),
            {
              "class": 2,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.95480346679688, 40.73162474007494]),
            {
              "class": 2,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.91085815429688, 40.79195475013362]),
            {
              "class": 2,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.90536499023438, 40.7482729707676]),
            {
              "class": 2,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.027587890625, 40.89947653482089]),
            {
              "class": 2,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.18482971191406, 40.641027072817636]),
            {
              "class": 2,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.0770263671875, 40.69831577947824]),
            {
              "class": 2,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-112.049560546875, 40.76439697065495]),
            {
              "class": 2,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.76254272460938, 40.84547773374318]),
            {
              "class": 2,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.30729675292969, 40.88130877818436]),
            {
              "class": 2,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.49337768554688, 40.818461819388894]),
            {
              "class": 2,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.24687194824219, 40.805469480878855]),
            {
              "class": 2,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.56204223632812, 40.6274789149138]),
            {
              "class": 2,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.4621353149414, 40.686874178899885]),
            {
              "class": 2,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.54521942138672, 40.72617332754848]),
            {
              "class": 2,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.40789031982422, 40.71628565928724]),
            {
              "class": 2,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.43672943115234, 40.655626531089936]),
            {
              "class": 2,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.36566162109375, 40.69650591660727]),
            {
              "class": 2,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.34712219238281, 40.63713144483657]),
            {
              "class": 2,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.45423889160156, 40.42864334972108]),
            {
              "class": 2,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.41304016113281, 40.40773272755936]),
            {
              "class": 2,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.45844459533691, 40.42447093360482]),
            {
              "class": 2,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.47621154785156, 40.341809527809396]),
            {
              "class": 2,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.44256591796875, 40.352275887076644]),
            {
              "class": 2,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.55654907226562, 40.46207458158932]),
            {
              "class": 2,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.368408203125, 40.534130456880234]),
            {
              "class": 2,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.40617370605469, 40.50751012726796]),
            {
              "class": 2,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.41921997070312, 40.50228921523541]),
            {
              "class": 2,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.34849548339844, 40.45893996202971]),
            {
              "class": 2,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.34368896484375, 40.55187147008724]),
            {
              "class": 2,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.10017395019531, 40.29364335861463]),
            {
              "class": 2,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.16368865966797, 40.37433833113026]),
            {
              "class": 2,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.16815185546875, 40.40799415044732]),
            {
              "class": 2,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.2371597290039, 40.3297834753004]),
            {
              "class": 2,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.14171600341797, 40.31591057572841]),
            {
              "class": 2,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.95138645172119, 40.33686043906487]),
            {
              "class": 2,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.9332332611084, 40.31565799873164]),
            {
              "class": 2,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.94293212890625, 40.29909833965231]),
            {
              "class": 2,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93606567382812, 40.27690334132034]),
            {
              "class": 2,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93658065795898, 40.25391499990326]),
            {
              "class": 2,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93091583251953, 40.21688535018804]),
            {
              "class": 2,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.78019714355469, 40.13845320887462]),
            {
              "class": 2,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.79633331298828, 40.18804125779043]),
            {
              "class": 2,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.83512878417969, 40.14973832875455]),
            {
              "class": 2,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.78946685791016, 40.24624127070896]),
            {
              "class": 2,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.74449157714844, 40.29339376709798]),
            {
              "class": 2,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.77401733398438, 40.33580290313306]),
            {
              "class": 2,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.71599578857422, 40.35882879997276]),
            {
              "class": 2,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.69985961914062, 40.147114049560884]),
            {
              "class": 2,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.64218139648438, 40.14947590539774]),
            {
              "class": 2,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.62467193603516, 40.17754945439488]),
            {
              "class": 2,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.61299896240234, 40.21976908443856]),
            {
              "class": 2,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.92267608642578, 40.03522561844552]),
            {
              "class": 2,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.99752044677734, 40.03759136026107]),
            {
              "class": 2,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.07614135742188, 40.08436361161334]),
            {
              "class": 2,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.01846313476562, 40.01761140538699]),
            {
              "class": 2,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.18016815185547, 40.06781305878625]),
            {
              "class": 2,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.15922546386719, 40.121128215348264]),
            {
              "class": 2,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.137939453125, 40.145276993798674]),
            {
              "class": 2,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.11940002441406, 40.30151115627605]),
            {
              "class": 2,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.14652252197266, 40.509610613944695]),
            {
              "class": 2,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.06858825683594, 40.515091962503455]),
            {
              "class": 2,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.21862030029297, 40.50386776821812]),
            {
              "class": 2,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.28762817382812, 40.47906347015083]),
            {
              "class": 2,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.09639739990234, 40.46287045780329]),
            {
              "class": 2,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.18978118896484, 40.439357524564365]),
            {
              "class": 2,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.1540756225586, 40.460780752440314]),
            {
              "class": 2,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.9951171875, 40.46287045780329]),
            {
              "class": 2,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93881225585938, 40.503606718092215]),
            {
              "class": 2,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.86637115478516, 40.55762243048867]),
            {
              "class": 2,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.97211456298828, 40.550318503806835]),
            {
              "class": 2,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.85650062561035, 40.48834269725553]),
            {
              "class": 2,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.82234001159668, 40.49395632810072]),
            {
              "class": 2,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.83169555664062, 40.46861681235468]),
            {
              "class": 2,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.74002838134766, 40.44484461150084]),
            {
              "class": 2,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6713638305664, 40.390738061818986]),
            {
              "class": 2,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.69539642333984, 40.48167488064544]),
            {
              "class": 2,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.65763092041016, 40.52344363203843]),
            {
              "class": 2,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.71290588378906, 40.531794261105794]),
            {
              "class": 2,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.13381958007812, 40.40276549975839]),
            {
              "class": 2,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.0888442993164, 40.40668702585319]),
            {
              "class": 2,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.01228332519531, 40.382892923069704]),
            {
              "class": 2,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.25020599365234, 40.36589198781105]),
            {
              "class": 2,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.33397674560547, 40.31198376579018]),
            {
              "class": 2,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.41362762451172, 40.44275434548035]),
            {
              "class": 2,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.5228042602539, 40.35804395564198]),
            {
              "class": 2,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.29792785644531, 40.467310865853726]),
            {
              "class": 2,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.13416290283203, 40.348101803338196]),
            {
              "class": 2,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81776428222656, 38.54036569840921]),
            {
              "class": 2,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.91664123535156, 38.66190985340407]),
            {
              "class": 2,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.05465698242188, 38.49926787293664]),
            {
              "class": 2,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8476333618164, 38.523177306044204]),
            {
              "class": 2,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8799057006836, 38.6686115938695]),
            {
              "class": 2,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.91492462158203, 38.71470256360928]),
            {
              "class": 2,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8970718383789, 38.769062412808985]),
            {
              "class": 2,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.06941986083984, 38.74175376942688]),
            {
              "class": 2,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.04950714111328, 38.785656678149934]),
            {
              "class": 2,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.182373046875, 38.73505888027897]),
            {
              "class": 2,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.15765380859375, 38.684425214399134]),
            {
              "class": 2,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.13533782958984, 38.69969946170272]),
            {
              "class": 2,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.06632995605469, 38.73345201349949]),
            {
              "class": 2,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.99903869628906, 38.73827250539301]),
            {
              "class": 2,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.92556762695312, 38.76370860037401]),
            {
              "class": 2,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.96693801879883, 38.74022341494506]),
            {
              "class": 2,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.96607971191406, 38.927493046799015]),
            {
              "class": 2,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.96470642089844, 38.915606764275815]),
            {
              "class": 2,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.90651321411133, 38.89516838901919]),
            {
              "class": 2,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.92917251586914, 38.90385207777541]),
            {
              "class": 2,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.85930633544922, 38.89770680787754]),
            {
              "class": 2,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.80729293823242, 38.89196183550855]),
            {
              "class": 2,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78085708618164, 38.88848790584049]),
            {
              "class": 2,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.74721145629883, 38.88741897022387]),
            {
              "class": 2,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.808837890625, 38.914805370214495]),
            {
              "class": 2,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81759262084961, 38.93189981403938]),
            {
              "class": 2,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8278923034668, 38.96167170091472]),
            {
              "class": 2,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.91217803955078, 38.971815316595894]),
            {
              "class": 2,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78051376342773, 38.95392954333778]),
            {
              "class": 2,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.01345825195312, 38.80434987422003]),
            {
              "class": 2,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.33755493164062, 38.903808244513456]),
            {
              "class": 2,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.40484619140625, 38.97110422641184]),
            {
              "class": 2,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3775520324707, 38.95646586053542]),
            {
              "class": 2,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42750549316406, 39.00543901686668]),
            {
              "class": 2,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.4566879272461, 39.005038828664475]),
            {
              "class": 2,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.47763061523438, 39.002370849461805]),
            {
              "class": 2,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.53702545166016, 39.08289944893097]),
            {
              "class": 2,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.4870719909668, 39.07357136723561]),
            {
              "class": 2,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.46115112304688, 39.08449842482212]),
            {
              "class": 2,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.55110168457031, 39.06104314623983]),
            {
              "class": 2,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.533935546875, 39.066907696722126]),
            {
              "class": 2,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.56620788574219, 39.06677441689447]),
            {
              "class": 2,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.5859489440918, 39.087163304099434]),
            {
              "class": 2,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3555793762207, 39.08583087704542]),
            {
              "class": 2,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.39025497436523, 39.062509329535246]),
            {
              "class": 2,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.40604782104492, 39.12219709913056]),
            {
              "class": 2,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.40879440307617, 39.08249969929519]),
            {
              "class": 2,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3914566040039, 39.0916933678132]),
            {
              "class": 2,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42424392700195, 39.07876859346329]),
            {
              "class": 2,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.48690032958984, 39.05944363882659]),
            {
              "class": 2,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.48535537719727, 39.06664113681516]),
            {
              "class": 2,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.5038948059082, 39.0761033970623]),
            {
              "class": 2,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.52518081665039, 39.05157886698337]),
            {
              "class": 2,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.56277465820312, 39.01450934220886]),
            {
              "class": 2,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.5555648803711, 39.03384659229766]),
            {
              "class": 2,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.49908828735352, 39.005839202804964]),
            {
              "class": 2,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.74095916748047, 39.21948092028007]),
            {
              "class": 2,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.77786636352539, 39.20445131288012]),
            {
              "class": 2,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.85734558105469, 39.23876198716958]),
            {
              "class": 2,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.73512268066406, 39.16865992474006]),
            {
              "class": 2,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.7478256225586, 39.25630980016798]),
            {
              "class": 2,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.87605667114258, 39.24766938034731]),
            {
              "class": 2,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90420913696289, 39.29351789762681]),
            {
              "class": 2,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.95467758178711, 39.251391537880046]),
            {
              "class": 2,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90626907348633, 39.254581801378556]),
            {
              "class": 2,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.80413055419922, 39.21402807173597]),
            {
              "class": 2,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.71503829956055, 39.17531397810483]),
            {
              "class": 2,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.66817474365234, 39.168926098963404]),
            {
              "class": 2,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.64036560058594, 39.14816148453401]),
            {
              "class": 2,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.62405776977539, 39.10701348560872]),
            {
              "class": 2,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.58577728271484, 39.10141869803869]),
            {
              "class": 2,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.55642318725586, 39.10461577388037]),
            {
              "class": 2,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.55865478515625, 39.059177050734675]),
            {
              "class": 2,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.58182907104492, 39.031713086405155]),
            {
              "class": 2,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42716217041016, 39.031313046879866]),
            {
              "class": 2,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.27006530761719, 37.726711727234836]),
            {
              "class": 2,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9466552734375, 37.81301336052475]),
            {
              "class": 2,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.25495910644531, 37.61094233825498]),
            {
              "class": 2,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.40876770019531, 37.75820449523439]),
            {
              "class": 2,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01531982421875, 37.47810208596506]),
            {
              "class": 2,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.86769104003906, 37.59244600739744]),
            {
              "class": 2,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.80245971679688, 37.75929021375168]),
            {
              "class": 2,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.68161010742188, 37.72725481950747]),
            {
              "class": 2,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.69053649902344, 37.55979420697399]),
            {
              "class": 2,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.5621337890625, 37.572312422695504]),
            {
              "class": 2,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.77980041503906, 37.39795706867408]),
            {
              "class": 2,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.82855224609375, 37.41650164104229]),
            {
              "class": 2,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.59165954589844, 37.30898847382676]),
            {
              "class": 2,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.85670471191406, 37.271841578471395]),
            {
              "class": 2,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.95970153808594, 37.127450489451896]),
            {
              "class": 2,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.12518310546875, 37.16631009012432]),
            {
              "class": 2,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96588134765625, 37.37667970143529]),
            {
              "class": 2,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.94802856445312, 37.560338520965715]),
            {
              "class": 2,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.05995178222656, 37.578298651759916]),
            {
              "class": 2,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.2158203125, 37.62508348818871]),
            {
              "class": 2,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0125732421875, 37.723453089965915]),
            {
              "class": 2,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.06269836425781, 37.84663826828908]),
            {
              "class": 2,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.985107421875, 37.89596319971573]),
            {
              "class": 2,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.85052490234375, 37.84718047993749]),
            {
              "class": 2,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.93360900878906, 38.02156519497826]),
            {
              "class": 2,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.98030090332031, 38.00912286633474]),
            {
              "class": 2,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0125732421875, 38.11886697114076]),
            {
              "class": 2,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.18972778320312, 38.01074589854809]),
            {
              "class": 2,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96931457519531, 38.07671875921947]),
            {
              "class": 2,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.54153442382812, 37.77828770819644]),
            {
              "class": 2,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.26251220703125, 37.546185064878365]),
            {
              "class": 2,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.96244812011719, 37.467203046815065]),
            {
              "class": 2,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.76675415039062, 37.55326212891376]),
            {
              "class": 2,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.67817687988281, 37.44430989189819]),
            {
              "class": 2,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.79696655273438, 37.22975604435477]),
            {
              "class": 2,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.0675048828125, 37.21335272020134]),
            {
              "class": 2,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.69602966308594, 37.07323265348072]),
            {
              "class": 2,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84915161132812, 36.97400683534959]),
            {
              "class": 2,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9466552734375, 37.09569121194163]),
            {
              "class": 2,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.37168884277344, 36.86256631432182]),
            {
              "class": 2,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.24465942382812, 36.940536898841245]),
            {
              "class": 2,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.53579711914062, 36.764185327703856]),
            {
              "class": 2,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.42524719238281, 36.796357998080445]),
            {
              "class": 2,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.41717910766602, 36.77821097260212]),
            {
              "class": 2,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.4491081237793, 36.79154670548874]),
            {
              "class": 2,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.44404411315918, 36.79399158869401]),
            {
              "class": 2,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59828186035156, 36.9394392748261]),
            {
              "class": 2,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.70814514160156, 36.86311568146496]),
            {
              "class": 2,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.54678344726562, 37.08144997113875]),
            {
              "class": 2,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.4849853515625, 37.111572515648334]),
            {
              "class": 2,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.31401062011719, 37.071589083082]),
            {
              "class": 2,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.16015625, 34.34322346452174]),
            {
              "class": 2,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.490234375, 36.26621372172312]),
            {
              "class": 2,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.5556640625, 36.24849565972352]),
            {
              "class": 2,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.775390625, 36.663806151084735]),
            {
              "class": 2,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5286865234375, 35.23194908676013]),
            {
              "class": 2,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.69921875, 35.91553888143533]),
            {
              "class": 2,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9134521484375, 33.091325821711344]),
            {
              "class": 2,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.830810546875, 32.44466766731571]),
            {
              "class": 2,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.40234375, 31.919311615137822]),
            {
              "class": 2,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.3751220703125, 33.728694155731525]),
            {
              "class": 2,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.41357421875, 34.723343291484696]),
            {
              "class": 2,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.17138671875, 35.15114389392723]),
            {
              "class": 2,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.5279541015625, 38.32852775886677]),
            {
              "class": 2,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.4453125, 37.34812137684661]),
            {
              "class": 2,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.6810302734375, 38.388831581020995]),
            {
              "class": 2,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.2965087890625, 37.904996313499225]),
            {
              "class": 2,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.170166015625, 38.84378558005624]),
            {
              "class": 2,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.13720703125, 39.001910195991925]),
            {
              "class": 2,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.4503173828125, 39.410534112657174]),
            {
              "class": 2,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.8677978515625, 39.31710116452751]),
            {
              "class": 2,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.0328369140625, 39.49536466042109]),
            {
              "class": 2,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.6707763671875, 38.9250287266408]),
            {
              "class": 2,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-113.3404541015625, 36.9804093702842]),
            {
              "class": 2,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.6650390625, 37.011120331121255]),
            {
              "class": 2,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.2203369140625, 37.164488992398745]),
            {
              "class": 2,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.555419921875, 37.505163995615966]),
            {
              "class": 2,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.1708984375, 38.52648017961075]),
            {
              "class": 2,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.5611572265625, 36.75628403018191]),
            {
              "class": 2,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.4180908203125, 38.620961170167796]),
            {
              "class": 2,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-111.0443115234375, 38.809550151074774]),
            {
              "class": 2,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6051025390625, 38.852341864783604]),
            {
              "class": 2,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.3853759765625, 39.00617894221535]),
            {
              "class": 2,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6600341796875, 39.652028563669205]),
            {
              "class": 2,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.7149658203125, 37.86164080990976]),
            {
              "class": 2,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6710205078125, 38.27248638596232]),
            {
              "class": 2,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2755126953125, 40.00217469207779]),
            {
              "class": 2,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.30322265625, 40.747061887498944]),
            {
              "class": 2,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.665771484375, 36.896988549588116]),
            {
              "class": 2,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.95166015625, 35.875489388904874]),
            {
              "class": 2,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.083740234375, 34.102494780763564]),
            {
              "class": 2,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.1658935546875, 33.81088834423236]),
            {
              "class": 2,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.479248046875, 33.70127857745441]),
            {
              "class": 2,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.41357421875, 33.99325950785322]),
            {
              "class": 2,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.468017578125, 32.26369282010198]),
            {
              "class": 2,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.478759765625, 33.60525515499839]),
            {
              "class": 2,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.4185791015625, 33.30736193482101]),
            {
              "class": 2,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.86288452148438, 38.8011392244074]),
            {
              "class": 2,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.732421875, 39.046869165628834]),
            {
              "class": 2,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.59783935546875, 39.034069523278696]),
            {
              "class": 2,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.66375732421875, 39.16728536838173]),
            {
              "class": 2,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.83816528320312, 39.25028446590748]),
            {
              "class": 2,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9576416015625, 39.117225741633625]),
            {
              "class": 2,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.86048126220703, 38.935632415484584]),
            {
              "class": 2,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.78083038330078, 38.907318994344294]),
            {
              "class": 2,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.78529357910156, 38.98288529834898]),
            {
              "class": 2,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.75164794921875, 39.051439309362024]),
            {
              "class": 2,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.93738555908203, 39.02930656447616]),
            {
              "class": 2,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.8367919921875, 39.14549267075442]),
            {
              "class": 2,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.8316421508789, 39.21920870350989]),
            {
              "class": 2,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.1678409576416, 38.75695825065963]),
            {
              "class": 2,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.10355377197266, 38.763048757011454]),
            {
              "class": 2,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.18191719055176, 38.839971894584]),
            {
              "class": 2,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.13685607910156, 38.83977133356921]),
            {
              "class": 2,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.98486328125, 38.544918088027934]),
            {
              "class": 2,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.96495056152344, 38.472918849031146]),
            {
              "class": 2,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89559936523438, 38.64688310978962]),
            {
              "class": 2,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.78230285644531, 38.54438104691745]),
            {
              "class": 2,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.93199157714844, 38.54599215821756]),
            {
              "class": 2,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.81114196777344, 38.479907002891366]),
            {
              "class": 2,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.16407775878906, 38.43474082672032]),
            {
              "class": 2,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.6168212890625, 38.48313207619919]),
            {
              "class": 2,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.88848876953125, 39.00717939235158]),
            {
              "class": 2,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.0831527709961, 38.94819537985111]),
            {
              "class": 2,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.12812805175781, 38.989302551359515]),
            {
              "class": 2,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.94960021972656, 39.00664582070642]),
            {
              "class": 2,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.10100555419922, 38.93324140329966]),
            {
              "class": 2,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.160400390625, 38.99063679991707]),
            {
              "class": 2,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.11748504638672, 38.90412551322715]),
            {
              "class": 2,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.1497573852539, 38.91855139233948]),
            {
              "class": 2,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.13018798828125, 38.91855139233948]),
            {
              "class": 2,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.16134452819824, 38.907799047712516]),
            {
              "class": 2,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.16855430603027, 38.91220703817358]),
            {
              "class": 2,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.13413619995117, 38.916214064685526]),
            {
              "class": 2,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.13199043273926, 38.93544464257532]),
            {
              "class": 2,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.15310478210449, 38.94886289454728]),
            {
              "class": 2,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.09800148010254, 38.942521251142416]),
            {
              "class": 2,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.07568550109863, 38.96501483340685]),
            {
              "class": 2,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.13224792480469, 39.000309349751724]),
            {
              "class": 2,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.04221153259277, 38.9944392703169]),
            {
              "class": 2,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.01955223083496, 38.98429889526596]),
            {
              "class": 2,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.00899505615234, 38.98249749249105]),
            {
              "class": 2,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.99509048461914, 38.9894359773471]),
            {
              "class": 2,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.98942565917969, 38.9993755060512]),
            {
              "class": 2,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.98161506652832, 38.997374370904396]),
            {
              "class": 2,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.96633720397949, 39.00537857191878]),
            {
              "class": 2,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.93054580688477, 39.00444479512753]),
            {
              "class": 2,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.9747486114502, 38.99597354262809]),
            {
              "class": 2,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.96934127807617, 39.01778329386056]),
            {
              "class": 2,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.90960311889648, 39.00371110471618]),
            {
              "class": 2,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8732967376709, 39.01631618213762]),
            {
              "class": 2,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.86110877990723, 39.0242515598362]),
            {
              "class": 2,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.84849166870117, 39.01798335219163]),
            {
              "class": 2,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.84359931945801, 39.01458228358464]),
            {
              "class": 2,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.83415794372559, 39.02018395647526]),
            {
              "class": 2,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.82488822937012, 39.0272521008364]),
            {
              "class": 2,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.84591674804688, 39.030519211742075]),
            {
              "class": 2,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8249740600586, 39.032586081464935]),
            {
              "class": 2,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.83535957336426, 39.0275854864189]),
            {
              "class": 2,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81742095947266, 39.00311080690176]),
            {
              "class": 2,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8139877319336, 39.00784635124819]),
            {
              "class": 2,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.82986640930176, 39.00211029922512]),
            {
              "class": 2,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81089782714844, 39.00424469849724]),
            {
              "class": 2,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.808837890625, 38.997908012477225]),
            {
              "class": 2,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81184196472168, 38.994505978500385]),
            {
              "class": 2,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.80600547790527, 38.992437995572864]),
            {
              "class": 2,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.80308723449707, 38.997441076321074]),
            {
              "class": 2,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.80162811279297, 39.000909671336494]),
            {
              "class": 2,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.83329963684082, 38.990436664236846]),
            {
              "class": 2,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.82299995422363, 38.98042915870608]),
            {
              "class": 2,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.79064178466797, 38.98596681992875]),
            {
              "class": 2,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78154373168945, 38.99110378097014]),
            {
              "class": 2,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77665138244629, 38.99470610267355]),
            {
              "class": 2,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77519226074219, 39.0045114938785]),
            {
              "class": 2,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.76317596435547, 38.995306471797456]),
            {
              "class": 2,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77124404907227, 38.99423914538917]),
            {
              "class": 2,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.76034355163574, 38.98863541764893]),
            {
              "class": 2,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.76695251464844, 38.9871677013526]),
            {
              "class": 2,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.74480819702148, 38.98803499193336]),
            {
              "class": 2,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.76248931884766, 38.98129653184325]),
            {
              "class": 2,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.7689266204834, 38.98223061410761]),
            {
              "class": 2,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.74206161499023, 38.9858333874019]),
            {
              "class": 2,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.7377700805664, 38.9828310890557]),
            {
              "class": 2,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.72858619689941, 38.99804142224162]),
            {
              "class": 2,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.72412300109863, 39.00724608852424]),
            {
              "class": 2,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.7260971069336, 39.00244380335614]),
            {
              "class": 2,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.73459434509277, 38.99877517144959]),
            {
              "class": 2,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.72729873657227, 38.9909703581265]),
            {
              "class": 2,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.7125358581543, 38.98843527630966]),
            {
              "class": 2,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.71442413330078, 38.968017887160684]),
            {
              "class": 2,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.68232345581055, 39.01198135604184]),
            {
              "class": 2,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.71116256713867, 39.02065074251834]),
            {
              "class": 2,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.70721435546875, 39.035319590517844]),
            {
              "class": 2,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.73347854614258, 39.01905032039765]),
            {
              "class": 2,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.64936447143555, 38.993705476148435]),
            {
              "class": 2,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.63734817504883, 38.995306471797456]),
            {
              "class": 2,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.67974853515625, 38.95847440916988]),
            {
              "class": 2,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.66824722290039, 38.953401827776155]),
            {
              "class": 2,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.65142440795898, 38.950865400919994]),
            {
              "class": 2,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.60541915893555, 38.97809387052251]),
            {
              "class": 2,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.6026725769043, 38.996373782108165]),
            {
              "class": 2,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.63099670410156, 38.97782697554024]),
            {
              "class": 2,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.57675170898438, 39.01144782062009]),
            {
              "class": 2,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.56731033325195, 39.038786327955975]),
            {
              "class": 2,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.6026725769043, 39.05531765880098]),
            {
              "class": 2,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5726318359375, 39.05825023273871]),
            {
              "class": 2,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.55718231201172, 39.06238228928981]),
            {
              "class": 2,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.53194808959961, 39.05118518880596]),
            {
              "class": 2,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.51358032226562, 39.04771905977191]),
            {
              "class": 2,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.47238159179688, 39.02491835773184]),
            {
              "class": 2,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.43186950683594, 38.995306471797456]),
            {
              "class": 2,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.41109848022461, 38.99664060717057]),
            {
              "class": 2,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.40921020507812, 38.96875194760377]),
            {
              "class": 2,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.457275390625, 38.98876884489408]),
            {
              "class": 2,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46465682983398, 39.008913472402256]),
            {
              "class": 2,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.41504669189453, 38.976892835180315]),
            {
              "class": 2,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.43684768676758, 38.99010310351224]),
            {
              "class": 2,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.42534637451172, 39.07584311858066]),
            {
              "class": 2,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.51495361328125, 39.09436422031014]),
            {
              "class": 2,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.55804061889648, 39.11407918425643]),
            {
              "class": 2,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.56868362426758, 39.15628795043201]),
            {
              "class": 2,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.59082794189453, 39.16028116027711]),
            {
              "class": 2,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.52920150756836, 39.15748593718304]),
            {
              "class": 2,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.51907348632812, 39.168932337409686]),
            {
              "class": 2,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.60009765625, 39.197806253452455]),
            {
              "class": 2,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.58258819580078, 39.21310328979648]),
            {
              "class": 2,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.65623092651367, 39.189557773413604]),
            {
              "class": 2,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5667953491211, 39.24089546070376]),
            {
              "class": 2,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.49435424804688, 39.214699310324086]),
            {
              "class": 2,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46826171875, 39.18609844524055]),
            {
              "class": 2,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.42517471313477, 39.226136395789844]),
            {
              "class": 2,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3994255065918, 39.17292482951875]),
            {
              "class": 2,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.37625122070312, 39.16746836684494]),
            {
              "class": 2,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.40903854370117, 39.11487832325068]),
            {
              "class": 2,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3829460144043, 39.10328992083197]),
            {
              "class": 2,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3939323425293, 39.10755254324836]),
            {
              "class": 2,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3202896118164, 39.13658479832135]),
            {
              "class": 2,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.27582931518555, 39.138315701555165]),
            {
              "class": 2,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.2705078125, 39.16746836684494]),
            {
              "class": 2,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18536376953125, 39.095962936305504]),
            {
              "class": 2,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.171630859375, 39.15628795043201]),
            {
              "class": 2,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15171813964844, 39.078508324812844]),
            {
              "class": 2,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0840835571289, 39.08557063444842]),
            {
              "class": 2,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02108383178711, 39.06144926540051]),
            {
              "class": 2,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1774673461914, 39.04691915968503]),
            {
              "class": 2,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.19480514526367, 39.00717939235158]),
            {
              "class": 2,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.2152328491211, 38.98076276501632]),
            {
              "class": 2,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.26947784423828, 38.98916912512044]),
            {
              "class": 2,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.14948654174805, 38.960877084149516]),
            {
              "class": 2,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1994400024414, 38.97902799503841]),
            {
              "class": 2,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.23136901855469, 38.914143795902376]),
            {
              "class": 2,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20081329345703, 38.885688179036116]),
            {
              "class": 2,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.14982986450195, 38.859092581794336]),
            {
              "class": 2,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.19034194946289, 38.83248703408409]),
            {
              "class": 2,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.22158432006836, 38.819514894178745]),
            {
              "class": 2,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.24784851074219, 38.82700425302337]),
            {
              "class": 2,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.29745864868164, 38.77375921583008]),
            {
              "class": 2,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.32303619384766, 38.759705526581776]),
            {
              "class": 2,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3558235168457, 38.78874676627095]),
            {
              "class": 2,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.39084243774414, 38.78098574947263]),
            {
              "class": 2,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.43152618408203, 38.76987799740829]),
            {
              "class": 2,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46912002563477, 38.77456220017233]),
            {
              "class": 2,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.41693496704102, 38.72355475847389]),
            {
              "class": 2,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.37350463867188, 38.78486636347008]),
            {
              "class": 2,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.34586715698242, 38.74136464617442]),
            {
              "class": 2,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.43186950683594, 38.74270355598839]),
            {
              "class": 2,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.47255325317383, 38.74256966613668]),
            {
              "class": 2,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.50019073486328, 38.756225137839074]),
            {
              "class": 2,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.51701354980469, 38.78700730147768]),
            {
              "class": 2,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.48044967651367, 38.73574095082179]),
            {
              "class": 2,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.52662658691406, 39.02625193465452]),
            {
              "class": 2,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5393295288086, 39.0882354732187]),
            {
              "class": 2,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.58550643920898, 39.1168761310861]),
            {
              "class": 2,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.63545989990234, 39.157086610532446]),
            {
              "class": 2,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.6963996887207, 39.1757194391286]),
            {
              "class": 2,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77214527130127, 39.21433355882403]),
            {
              "class": 2,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.7802562713623, 39.20352640482464]),
            {
              "class": 2,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.76575088500977, 39.22979321016197]),
            {
              "class": 2,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81810760498047, 39.186364553452776]),
            {
              "class": 2,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81390190124512, 39.16859961950263]),
            {
              "class": 2,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78360366821289, 39.18922515310363]),
            {
              "class": 2,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.75699615478516, 39.207450425336944]),
            {
              "class": 2,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46603012084961, 39.31052695776979]),
            {
              "class": 2,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.41865158081055, 39.279041894366785]),
            {
              "class": 2,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46397018432617, 39.2551197286439]),
            {
              "class": 2,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.48353958129883, 39.24953671509894]),
            {
              "class": 2,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.54070281982422, 39.23890117388681]),
            {
              "class": 2,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.55752563476562, 39.25339170052409]),
            {
              "class": 2,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.50499725341797, 39.22733319237749]),
            {
              "class": 2,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.48062133789062, 39.29485262004323]),
            {
              "class": 2,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.45573043823242, 39.30348722334712]),
            {
              "class": 2,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.34638214111328, 39.30162755262816]),
            {
              "class": 2,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.36749649047852, 39.35168857740785]),
            {
              "class": 2,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.39496231079102, 39.354077862592064]),
            {
              "class": 2,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.38037109375, 39.350361161445846]),
            {
              "class": 2,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.47735977172852, 39.34093578301682]),
            {
              "class": 2,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.48748779296875, 39.347839001645646]),
            {
              "class": 2,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.4821662902832, 39.35726344907423]),
            {
              "class": 2,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.42242813110352, 39.390040002576505]),
            {
              "class": 2,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.36526489257812, 39.38672323755121]),
            {
              "class": 2,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.33591079711914, 39.380354606793695]),
            {
              "class": 2,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.07405471801758, 39.100958690168945]),
            {
              "class": 2,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.07894706726074, 39.073177811678576]),
            {
              "class": 2,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.04298400878906, 39.09769483773057]),
            {
              "class": 2,
              "system:index": "780"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.96281814575195, 39.115810640622826]),
            {
              "class": 2,
              "system:index": "781"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.94839859008789, 39.1309257792633]),
            {
              "class": 2,
              "system:index": "782"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78823852539062, 39.1232687355091]),
            {
              "class": 2,
              "system:index": "783"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77025699615479, 39.11304694964225]),
            {
              "class": 2,
              "system:index": "784"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78716564178467, 39.10538796251601]),
            {
              "class": 2,
              "system:index": "785"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.76184558868408, 39.11214789427152]),
            {
              "class": 2,
              "system:index": "786"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.78042793273926, 39.09103344557164]),
            {
              "class": 2,
              "system:index": "787"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.57915496826172, 39.74547413202817]),
            {
              "class": 2,
              "system:index": "788"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.57349014282227, 39.762762536881596]),
            {
              "class": 2,
              "system:index": "789"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.5564956665039, 39.798513325055275]),
            {
              "class": 2,
              "system:index": "790"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.52920150756836, 39.80194231349059]),
            {
              "class": 2,
              "system:index": "791"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.59408950805664, 39.79376521264888]),
            {
              "class": 2,
              "system:index": "792"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.62704849243164, 39.7729223987651]),
            {
              "class": 2,
              "system:index": "793"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.66653060913086, 39.757748026545464]),
            {
              "class": 2,
              "system:index": "794"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.74738311767578, 39.75326104990142]),
            {
              "class": 2,
              "system:index": "795"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77175903320312, 39.773845948226]),
            {
              "class": 2,
              "system:index": "796"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.79767990112305, 39.78228925444413]),
            {
              "class": 2,
              "system:index": "797"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77467727661133, 39.81657953321114]),
            {
              "class": 2,
              "system:index": "798"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.84231185913086, 39.77780387699125]),
            {
              "class": 2,
              "system:index": "799"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.68610000610352, 39.809854711155005]),
            {
              "class": 2,
              "system:index": "800"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.66790390014648, 39.83859542426053]),
            {
              "class": 2,
              "system:index": "801"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.79012680053711, 39.84887587825816]),
            {
              "class": 2,
              "system:index": "802"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.85346984863281, 39.84821692096961]),
            {
              "class": 2,
              "system:index": "803"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.9190444946289, 39.87878587654644]),
            {
              "class": 2,
              "system:index": "804"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.83699035644531, 39.88563567053391]),
            {
              "class": 2,
              "system:index": "805"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77656555175781, 39.90947288620473]),
            {
              "class": 2,
              "system:index": "806"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.81347274780273, 39.83437735683739]),
            {
              "class": 2,
              "system:index": "807"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.77570724487305, 39.74705798323694]),
            {
              "class": 2,
              "system:index": "808"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.7484130859375, 39.791127230787914]),
            {
              "class": 2,
              "system:index": "809"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.7590560913086, 39.81288755549301]),
            {
              "class": 2,
              "system:index": "810"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.71373748779297, 39.78637860850151]),
            {
              "class": 2,
              "system:index": "811"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.68318176269531, 39.82752244475985]),
            {
              "class": 2,
              "system:index": "812"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.6191520690918, 39.80246983499714]),
            {
              "class": 2,
              "system:index": "813"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.57692337036133, 39.80721734644256]),
            {
              "class": 2,
              "system:index": "814"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.53915786743164, 39.765929407907926]),
            {
              "class": 2,
              "system:index": "815"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.51667022705078, 39.74890576362977]),
            {
              "class": 2,
              "system:index": "816"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46500015258789, 39.74349426681711]),
            {
              "class": 2,
              "system:index": "817"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.53143310546875, 39.70850726851062]),
            {
              "class": 2,
              "system:index": "818"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.48190879821777, 39.67373374043428]),
            {
              "class": 2,
              "system:index": "819"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.42929458618164, 39.71821298868932]),
            {
              "class": 2,
              "system:index": "820"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.41908073425293, 39.7273232382984]),
            {
              "class": 2,
              "system:index": "821"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.40062713623047, 39.74144834633472]),
            {
              "class": 2,
              "system:index": "822"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.4122142791748, 39.70956373965779]),
            {
              "class": 2,
              "system:index": "823"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.41195678710938, 39.68301499931131]),
            {
              "class": 2,
              "system:index": "824"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.42225646972656, 39.67541833201695]),
            {
              "class": 2,
              "system:index": "825"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.44560241699219, 39.66834937813084]),
            {
              "class": 2,
              "system:index": "826"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.38260269165039, 39.63570389518117]),
            {
              "class": 2,
              "system:index": "827"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.35221862792969, 39.62605268383714]),
            {
              "class": 2,
              "system:index": "828"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3444938659668, 39.62671376866023]),
            {
              "class": 2,
              "system:index": "829"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3257827758789, 39.623408281384584]),
            {
              "class": 2,
              "system:index": "830"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.30587005615234, 39.637554658558834]),
            {
              "class": 2,
              "system:index": "831"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.27119445800781, 39.64892254712529]),
            {
              "class": 2,
              "system:index": "832"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.30741500854492, 39.611374974303864]),
            {
              "class": 2,
              "system:index": "833"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.31428146362305, 39.59219670123917]),
            {
              "class": 2,
              "system:index": "834"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3298168182373, 39.5867729160621]),
            {
              "class": 2,
              "system:index": "835"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.29874610900879, 39.60608494668563]),
            {
              "class": 2,
              "system:index": "836"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.25771903991699, 39.61368923428937]),
            {
              "class": 2,
              "system:index": "837"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.22192764282227, 39.66768869127516]),
            {
              "class": 2,
              "system:index": "838"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20235824584961, 39.67786256831886]),
            {
              "class": 2,
              "system:index": "839"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20579147338867, 39.7016398117233]),
            {
              "class": 2,
              "system:index": "840"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1551513671875, 39.73900636172676]),
            {
              "class": 2,
              "system:index": "841"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20252990722656, 39.737950341582774]),
            {
              "class": 2,
              "system:index": "842"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.24098205566406, 39.82791793905047]),
            {
              "class": 2,
              "system:index": "843"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.19600677490234, 39.82765427644303]),
            {
              "class": 2,
              "system:index": "844"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.29024887084961, 39.833981899734674]),
            {
              "class": 2,
              "system:index": "845"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.32183456420898, 39.826995115497404]),
            {
              "class": 2,
              "system:index": "846"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.36028671264648, 39.850852712172525]),
            {
              "class": 2,
              "system:index": "847"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3745346069336, 39.79323762437003]),
            {
              "class": 2,
              "system:index": "848"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.32355117797852, 39.7462660621837]),
            {
              "class": 2,
              "system:index": "849"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.28509902954102, 39.713789462465364]),
            {
              "class": 2,
              "system:index": "850"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.21712112426758, 39.71497790036591]),
            {
              "class": 2,
              "system:index": "851"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.11575508117676, 39.765137703806396]),
            {
              "class": 2,
              "system:index": "852"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.06846237182617, 39.85889125027075]),
            {
              "class": 2,
              "system:index": "853"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0866584777832, 39.90302053580942]),
            {
              "class": 2,
              "system:index": "854"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.06314086914062, 39.881157036517074]),
            {
              "class": 2,
              "system:index": "855"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.083740234375, 39.9393564578778]),
            {
              "class": 2,
              "system:index": "856"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04485893249512, 39.969095425281346]),
            {
              "class": 2,
              "system:index": "857"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.01996803283691, 39.98007978100918]),
            {
              "class": 2,
              "system:index": "858"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.05086708068848, 39.968766525135926]),
            {
              "class": 2,
              "system:index": "859"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02486038208008, 39.984749241710226]),
            {
              "class": 2,
              "system:index": "860"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02254295349121, 39.96521430272994]),
            {
              "class": 2,
              "system:index": "861"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.99636459350586, 39.96955588282636]),
            {
              "class": 2,
              "system:index": "862"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.99275970458984, 39.97758050192535]),
            {
              "class": 2,
              "system:index": "863"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.01601982116699, 39.97593618951902]),
            {
              "class": 2,
              "system:index": "864"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0299243927002, 39.977712045208676]),
            {
              "class": 2,
              "system:index": "865"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04279899597168, 39.951332552969085]),
            {
              "class": 2,
              "system:index": "866"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04700469970703, 39.940211962765105]),
            {
              "class": 2,
              "system:index": "867"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.07455635070801, 39.93626338943423]),
            {
              "class": 2,
              "system:index": "868"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.00065612792969, 39.95021399548981]),
            {
              "class": 2,
              "system:index": "869"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.97190284729004, 39.981723993712606]),
            {
              "class": 2,
              "system:index": "870"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9782543182373, 39.97271322243591]),
            {
              "class": 2,
              "system:index": "871"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9522476196289, 39.961596108691495]),
            {
              "class": 2,
              "system:index": "872"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.93902969360352, 39.952714275189656]),
            {
              "class": 2,
              "system:index": "873"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.95027351379395, 39.97133190430241]),
            {
              "class": 2,
              "system:index": "874"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.88289642333984, 39.97041101003809]),
            {
              "class": 2,
              "system:index": "875"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.87517166137695, 39.96264869397873]),
            {
              "class": 2,
              "system:index": "876"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.87148094177246, 39.953043252556704]),
            {
              "class": 2,
              "system:index": "877"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.8636703491211, 39.95225370421749]),
            {
              "class": 2,
              "system:index": "878"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.85388565063477, 39.98435465174196]),
            {
              "class": 2,
              "system:index": "879"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.90349578857422, 39.98599876157459]),
            {
              "class": 2,
              "system:index": "880"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.86744689941406, 39.99605985169435]),
            {
              "class": 2,
              "system:index": "881"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.85766220092773, 39.999018713804524]),
            {
              "class": 2,
              "system:index": "882"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.91173553466797, 40.018872648749976]),
            {
              "class": 2,
              "system:index": "883"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.97593688964844, 40.00118846453713]),
            {
              "class": 2,
              "system:index": "884"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.01833724975586, 40.07491896000657]),
            {
              "class": 2,
              "system:index": "885"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.96065902709961, 40.073736747090734]),
            {
              "class": 2,
              "system:index": "886"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.94864273071289, 40.08371923330857]),
            {
              "class": 2,
              "system:index": "887"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.64541625976562, 40.06283314955389]),
            {
              "class": 2,
              "system:index": "888"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.6275634765625, 40.06151934529637]),
            {
              "class": 2,
              "system:index": "889"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.60215759277344, 40.04627736453682]),
            {
              "class": 2,
              "system:index": "890"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.55306243896484, 40.084375924515186]),
            {
              "class": 2,
              "system:index": "891"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.6436996459961, 40.09672054020729]),
            {
              "class": 2,
              "system:index": "892"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.65296936035156, 40.118515137824204]),
            {
              "class": 2,
              "system:index": "893"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.578125, 40.15080031292257]),
            {
              "class": 2,
              "system:index": "894"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.46208190917969, 40.14056521073614]),
            {
              "class": 2,
              "system:index": "895"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.50946044921875, 40.186217603789295]),
            {
              "class": 2,
              "system:index": "896"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.38449096679688, 40.22214070003113]),
            {
              "class": 2,
              "system:index": "897"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.28836059570312, 40.19697030740908]),
            {
              "class": 2,
              "system:index": "898"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.22827911376953, 40.22214070003113]),
            {
              "class": 2,
              "system:index": "899"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.2269058227539, 40.15080031292257]),
            {
              "class": 2,
              "system:index": "900"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.13626861572266, 40.22738335523682]),
            {
              "class": 2,
              "system:index": "901"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0730972290039, 40.25778275366141]),
            {
              "class": 2,
              "system:index": "902"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1661376953125, 40.29314417465945]),
            {
              "class": 2,
              "system:index": "903"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20355987548828, 40.30466538259176]),
            {
              "class": 2,
              "system:index": "904"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.16270446777344, 40.248873999337036]),
            {
              "class": 2,
              "system:index": "905"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04254150390625, 40.173758071693314]),
            {
              "class": 2,
              "system:index": "906"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.06339836120605, 40.16824891761024]),
            {
              "class": 2,
              "system:index": "907"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.07919120788574, 40.17939793281656]),
            {
              "class": 2,
              "system:index": "908"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.00546264648438, 40.25778275366141]),
            {
              "class": 2,
              "system:index": "909"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.90486907958984, 40.28266864446287]),
            {
              "class": 2,
              "system:index": "910"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.84444427490234, 40.32744016969029]),
            {
              "class": 2,
              "system:index": "911"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.4184799194336, 40.7519385984599]),
            {
              "class": 2,
              "system:index": "912"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.42929458618164, 40.758310295122065]),
            {
              "class": 2,
              "system:index": "913"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.35685348510742, 40.74023389131268]),
            {
              "class": 2,
              "system:index": "914"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.31050491333008, 40.73776263423316]),
            {
              "class": 2,
              "system:index": "915"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.2928237915039, 40.750508133646434]),
            {
              "class": 2,
              "system:index": "916"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.45161056518555, 40.798217025760515]),
            {
              "class": 2,
              "system:index": "917"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.44062423706055, 40.83589191603277]),
            {
              "class": 2,
              "system:index": "918"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.43341445922852, 40.90572865774617]),
            {
              "class": 2,
              "system:index": "919"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.34277725219727, 40.85563020812578]),
            {
              "class": 2,
              "system:index": "920"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.32646942138672, 40.84290487729679]),
            {
              "class": 2,
              "system:index": "921"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.23548889160156, 40.867704027332394]),
            {
              "class": 2,
              "system:index": "922"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20733642578125, 40.83069665155928]),
            {
              "class": 2,
              "system:index": "923"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.16047286987305, 40.83537240790504]),
            {
              "class": 2,
              "system:index": "924"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.18536376953125, 40.87030026003074]),
            {
              "class": 2,
              "system:index": "925"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.22570419311523, 40.881073537911995]),
            {
              "class": 2,
              "system:index": "926"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.28801727294922, 40.82264318710575]),
            {
              "class": 2,
              "system:index": "927"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.37350463867188, 40.867574213025414]),
            {
              "class": 2,
              "system:index": "928"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.4466323852539, 40.781581302919285]),
            {
              "class": 2,
              "system:index": "929"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.39667892456055, 40.75961056635002]),
            {
              "class": 2,
              "system:index": "930"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.3422622680664, 40.71629785715122]),
            {
              "class": 2,
              "system:index": "931"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.25797653198242, 40.71746884168838]),
            {
              "class": 2,
              "system:index": "932"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.22450256347656, 40.733470232684915]),
            {
              "class": 2,
              "system:index": "933"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.17695236206055, 40.75258879956551]),
            {
              "class": 2,
              "system:index": "934"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1910285949707, 40.737242357886416]),
            {
              "class": 2,
              "system:index": "935"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15909957885742, 40.762861133145016]),
            {
              "class": 2,
              "system:index": "936"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1415901184082, 40.78937981693921]),
            {
              "class": 2,
              "system:index": "937"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.14244842529297, 40.68779755192939]),
            {
              "class": 2,
              "system:index": "938"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1580696105957, 40.66970199110191]),
            {
              "class": 2,
              "system:index": "939"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.20802307128906, 40.685975199914836]),
            {
              "class": 2,
              "system:index": "940"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.08717346191406, 40.63518965195226]),
            {
              "class": 2,
              "system:index": "941"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.06520080566406, 40.651210806634026]),
            {
              "class": 2,
              "system:index": "942"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04717636108398, 40.67816455543811]),
            {
              "class": 2,
              "system:index": "943"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02005386352539, 40.63518965195226]),
            {
              "class": 2,
              "system:index": "944"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04391479492188, 40.62190089969493]),
            {
              "class": 2,
              "system:index": "945"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.07756042480469, 40.61629798630161]),
            {
              "class": 2,
              "system:index": "946"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.01370239257812, 40.69925119494625]),
            {
              "class": 2,
              "system:index": "947"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09197998046875, 40.73438076524639]),
            {
              "class": 2,
              "system:index": "948"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.99705123901367, 40.74920768438413]),
            {
              "class": 2,
              "system:index": "949"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.06073760986328, 40.907804458911215]),
            {
              "class": 2,
              "system:index": "950"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.00065612792969, 40.97004819103926]),
            {
              "class": 2,
              "system:index": "951"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.962890625, 40.93426521177941]),
            {
              "class": 2,
              "system:index": "952"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.04425811767578, 40.939711698787335]),
            {
              "class": 2,
              "system:index": "953"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.02211380004883, 41.048223469728455]),
            {
              "class": 2,
              "system:index": "954"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.06588745117188, 41.06725128650972]),
            {
              "class": 2,
              "system:index": "955"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.03378677368164, 41.056508365821294]),
            {
              "class": 2,
              "system:index": "956"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.06442832946777, 41.02103132661676]),
            {
              "class": 2,
              "system:index": "957"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0451807975769, 41.001682460417506]),
            {
              "class": 2,
              "system:index": "958"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.87714576721191, 40.80360974431232]),
            {
              "class": 2,
              "system:index": "959"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.84907913208008, 40.806728224963216]),
            {
              "class": 2,
              "system:index": "960"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.82573318481445, 40.81413402921381]),
            {
              "class": 2,
              "system:index": "961"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.83809280395508, 40.80861223601287]),
            {
              "class": 2,
              "system:index": "962"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.87697410583496, 40.83017710272148]),
            {
              "class": 2,
              "system:index": "963"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89122200012207, 40.83913874959545]),
            {
              "class": 2,
              "system:index": "964"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.90847396850586, 40.84628122364842]),
            {
              "class": 2,
              "system:index": "965"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89611434936523, 40.84959247318091]),
            {
              "class": 2,
              "system:index": "966"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.93757057189941, 40.859849803727606]),
            {
              "class": 2,
              "system:index": "967"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.94289207458496, 40.87763406742235]),
            {
              "class": 2,
              "system:index": "968"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.95911407470703, 40.88788705544882]),
            {
              "class": 2,
              "system:index": "969"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.92572593688965, 40.88814660415106]),
            {
              "class": 2,
              "system:index": "970"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.97233200073242, 40.86835309505017]),
            {
              "class": 2,
              "system:index": "971"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.94177627563477, 40.86854781412488]),
            {
              "class": 2,
              "system:index": "972"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15858459472656, 40.76156092550281]),
            {
              "class": 2,
              "system:index": "973"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1771240234375, 40.7532389943128]),
            {
              "class": 2,
              "system:index": "974"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.19085693359375, 40.73711228816394]),
            {
              "class": 2,
              "system:index": "975"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1829605102539, 40.71942043681212]),
            {
              "class": 2,
              "system:index": "976"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.14622497558594, 40.73321007823572]),
            {
              "class": 2,
              "system:index": "977"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1170425415039, 40.78444086438881]),
            {
              "class": 2,
              "system:index": "978"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9354248046875, 40.749077638059084]),
            {
              "class": 2,
              "system:index": "979"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9186019897461, 40.73841297394456]),
            {
              "class": 2,
              "system:index": "980"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.97113037109375, 40.73945350425846]),
            {
              "class": 2,
              "system:index": "981"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.96426391601562, 40.7475170623211]),
            {
              "class": 2,
              "system:index": "982"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9467544555664, 40.83355409739852]),
            {
              "class": 2,
              "system:index": "983"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.97868347167969, 40.84861859343548]),
            {
              "class": 2,
              "system:index": "984"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9735336303711, 40.853293085675126]),
            {
              "class": 2,
              "system:index": "985"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.98074340820312, 40.909880194915445]),
            {
              "class": 2,
              "system:index": "986"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.96529388427734, 40.8997603664366]),
            {
              "class": 2,
              "system:index": "987"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.91654205322266, 40.87951606398253]),
            {
              "class": 2,
              "system:index": "988"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.8801498413086, 40.901576859936284]),
            {
              "class": 2,
              "system:index": "989"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.85405731201172, 40.75844032338938]),
            {
              "class": 2,
              "system:index": "990"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.13523864746094, 40.71525696471578]),
            {
              "class": 2,
              "system:index": "991"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0394515991211, 40.68844837985795]),
            {
              "class": 2,
              "system:index": "992"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0339584350586, 40.694175391548754]),
            {
              "class": 2,
              "system:index": "993"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.12356567382812, 40.82744940453421]),
            {
              "class": 2,
              "system:index": "994"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.11515426635742, 40.82062966817709]),
            {
              "class": 2,
              "system:index": "995"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.11627006530762, 40.81263994228455]),
            {
              "class": 2,
              "system:index": "996"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.12227821350098, 40.82439684733685]),
            {
              "class": 2,
              "system:index": "997"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.11318016052246, 40.83069665155928]),
            {
              "class": 2,
              "system:index": "998"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1438217163086, 40.84303473995247]),
            {
              "class": 2,
              "system:index": "999"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.13987350463867, 40.85413705607076]),
            {
              "class": 2,
              "system:index": "1000"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15206146240234, 40.85822691415107]),
            {
              "class": 2,
              "system:index": "1001"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1178150177002, 40.86634096441661]),
            {
              "class": 2,
              "system:index": "1002"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.10193634033203, 40.84874844489519]),
            {
              "class": 2,
              "system:index": "1003"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09017753601074, 40.860693690593706]),
            {
              "class": 2,
              "system:index": "1004"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.13729858398438, 40.86711986094687]),
            {
              "class": 2,
              "system:index": "1005"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.08176612854004, 40.85524069344284]),
            {
              "class": 2,
              "system:index": "1006"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.07962036132812, 40.840112768653775]),
            {
              "class": 2,
              "system:index": "1007"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.07730293273926, 40.863549843285796]),
            {
              "class": 2,
              "system:index": "1008"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.1346378326416, 40.863484932092426]),
            {
              "class": 2,
              "system:index": "1009"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.0961856842041, 40.87036516454396]),
            {
              "class": 2,
              "system:index": "1010"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.13781356811523, 40.81588791441588]),
            {
              "class": 2,
              "system:index": "1011"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.14219093322754, 40.82751435103308]),
            {
              "class": 2,
              "system:index": "1012"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15386390686035, 40.8252411857252]),
            {
              "class": 2,
              "system:index": "1013"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15025901794434, 40.822902991547366]),
            {
              "class": 2,
              "system:index": "1014"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15815544128418, 40.834333379436444]),
            {
              "class": 2,
              "system:index": "1015"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.15154647827148, 40.816667404066834]),
            {
              "class": 2,
              "system:index": "1016"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09601402282715, 40.82329269630161]),
            {
              "class": 2,
              "system:index": "1017"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.10476875305176, 40.82699477726091]),
            {
              "class": 2,
              "system:index": "1018"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.09206581115723, 40.825111288211296]),
            {
              "class": 2,
              "system:index": "1019"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.13000297546387, 40.85043649071569]),
            {
              "class": 2,
              "system:index": "1020"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.59278869628906, 39.48125549646666]),
            {
              "class": 2,
              "system:index": "1021"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.53717041015625, 39.47860556892209]),
            {
              "class": 2,
              "system:index": "1022"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.48567199707031, 39.46641460192054]),
            {
              "class": 2,
              "system:index": "1023"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.65802001953125, 39.761047087593965]),
            {
              "class": 2,
              "system:index": "1024"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89697265625, 39.67231336658968]),
            {
              "class": 2,
              "system:index": "1025"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.76994323730469, 39.42187292509996]),
            {
              "class": 2,
              "system:index": "1026"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.84890747070312, 39.429828885207755]),
            {
              "class": 2,
              "system:index": "1027"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.89628601074219, 39.43990513074365]),
            {
              "class": 2,
              "system:index": "1028"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.34971618652344, 39.77160302089718]),
            {
              "class": 2,
              "system:index": "1029"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.03704833984375, 39.83701367933542]),
            {
              "class": 2,
              "system:index": "1030"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.75827026367188, 39.85388374694187]),
            {
              "class": 2,
              "system:index": "1031"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.8255615234375, 39.78743388622441]),
            {
              "class": 2,
              "system:index": "1032"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.76925659179688, 39.81433799896192]),
            {
              "class": 2,
              "system:index": "1033"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.84959411621094, 39.761047087593965]),
            {
              "class": 2,
              "system:index": "1034"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5673828125, 39.684996601181275]),
            {
              "class": 2,
              "system:index": "1035"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.55776977539062, 39.66332799957865]),
            {
              "class": 2,
              "system:index": "1036"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.65252685546875, 39.6464111976869]),
            {
              "class": 2,
              "system:index": "1037"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.732177734375, 39.68288289049806]),
            {
              "class": 2,
              "system:index": "1038"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.820068359375, 39.56547053068434]),
            {
              "class": 2,
              "system:index": "1039"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.87774658203125, 39.55011817080809]),
            {
              "class": 2,
              "system:index": "1040"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.9573974609375, 39.48602511162973]),
            {
              "class": 2,
              "system:index": "1041"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.35452270507812, 39.57552713084889]),
            {
              "class": 2,
              "system:index": "1042"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.3970947265625, 39.48920467334085]),
            {
              "class": 2,
              "system:index": "1043"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.5509033203125, 39.55170650354268]),
            {
              "class": 2,
              "system:index": "1044"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42561721801758, 39.71550608841585]),
            {
              "class": 2,
              "system:index": "1045"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.45823287963867, 39.72224013150843]),
            {
              "class": 2,
              "system:index": "1046"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.34527969360352, 39.69992284073077]),
            {
              "class": 2,
              "system:index": "1047"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.36158752441406, 39.70071529418928]),
            {
              "class": 2,
              "system:index": "1048"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.38407516479492, 39.75695622837771]),
            {
              "class": 2,
              "system:index": "1049"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42287063598633, 39.797194437822405]),
            {
              "class": 2,
              "system:index": "1050"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.36277842521667, 39.82432544899391]),
            {
              "class": 2,
              "system:index": "1051"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3350658416748, 39.847076086209654]),
            {
              "class": 2,
              "system:index": "1052"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.32206785678864, 39.829800625446246]),
            {
              "class": 2,
              "system:index": "1053"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.33187937736511, 39.8172387940778]),
            {
              "class": 2,
              "system:index": "1054"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3350658416748, 39.798579268752974]),
            {
              "class": 2,
              "system:index": "1055"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.37600708007812, 39.813414993022995]),
            {
              "class": 2,
              "system:index": "1056"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.40437412261963, 39.82207592724787]),
            {
              "class": 2,
              "system:index": "1057"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.45952033996582, 39.819546157310086]),
            {
              "class": 2,
              "system:index": "1058"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.42151880264282, 39.819488474173426]),
            {
              "class": 2,
              "system:index": "1059"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.40963125228882, 39.832696648426364]),
            {
              "class": 2,
              "system:index": "1060"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.51814270019531, 39.72303232864369]),
            {
              "class": 2,
              "system:index": "1061"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.7045669555664, 39.60343978131027]),
            {
              "class": 2,
              "system:index": "1062"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8056755065918, 39.58981557954328]),
            {
              "class": 2,
              "system:index": "1063"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.75263214111328, 39.517681761576696]),
            {
              "class": 2,
              "system:index": "1064"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.83726119995117, 39.531717333387014]),
            {
              "class": 2,
              "system:index": "1065"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.85391235351562, 39.48523019848537]),
            {
              "class": 2,
              "system:index": "1066"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.85178804397583, 39.47517707536482]),
            {
              "class": 2,
              "system:index": "1067"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.83563041687012, 39.47588928841462]),
            {
              "class": 2,
              "system:index": "1068"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.87039184570312, 39.46800484919317]),
            {
              "class": 2,
              "system:index": "1069"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.88704299926758, 39.470125122358176]),
            {
              "class": 2,
              "system:index": "1070"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.87811660766602, 39.46084845027994]),
            {
              "class": 2,
              "system:index": "1071"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8719367980957, 39.476021792363575]),
            {
              "class": 2,
              "system:index": "1072"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.53197479248047, 39.179844612221665]),
            {
              "class": 2,
              "system:index": "1073"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.58003997802734, 39.15668728161543]),
            {
              "class": 2,
              "system:index": "1074"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.63119506835938, 39.2170932730948]),
            {
              "class": 2,
              "system:index": "1075"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.62604522705078, 39.26841082880196]),
            {
              "class": 2,
              "system:index": "1076"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.58759307861328, 39.30853465194964]),
            {
              "class": 2,
              "system:index": "1077"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.53300476074219, 39.25219534841646]),
            {
              "class": 2,
              "system:index": "1078"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.43000793457031, 39.3072064165576]),
            {
              "class": 2,
              "system:index": "1079"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.67308044433594, 39.390040002576505]),
            {
              "class": 2,
              "system:index": "1080"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.67205047607422, 39.38393703310132]),
            {
              "class": 2,
              "system:index": "1081"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.78294372558594, 39.38526381099777]),
            {
              "class": 2,
              "system:index": "1082"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.79341506958008, 39.397336330701755]),
            {
              "class": 2,
              "system:index": "1083"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.86757278442383, 39.42213813840356]),
            {
              "class": 2,
              "system:index": "1084"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.86928939819336, 39.46204123453636]),
            {
              "class": 2,
              "system:index": "1085"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.88525390625, 39.500994278748976]),
            {
              "class": 2,
              "system:index": "1086"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.7702407836914, 39.54886071493852]),
            {
              "class": 2,
              "system:index": "1087"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.76745128631592, 39.56044168359341]),
            {
              "class": 2,
              "system:index": "1088"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.765305519104, 39.56629760877144]),
            {
              "class": 2,
              "system:index": "1089"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.94379043579102, 39.59021243884238]),
            {
              "class": 2,
              "system:index": "1090"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.95426177978516, 39.5993395752953]),
            {
              "class": 2,
              "system:index": "1091"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.94842529296875, 39.577908743543716]),
            {
              "class": 2,
              "system:index": "1092"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.97520446777344, 39.556735983975706]),
            {
              "class": 2,
              "system:index": "1093"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.95855331420898, 39.54071979144129]),
            {
              "class": 2,
              "system:index": "1094"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.90859985351562, 39.57698257055259]),
            {
              "class": 2,
              "system:index": "1095"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.87838745117188, 39.61692906829493]),
            {
              "class": 2,
              "system:index": "1096"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.89967346191406, 39.61573894281141]),
            {
              "class": 2,
              "system:index": "1097"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.84817504882812, 39.63927318021028]),
            {
              "class": 2,
              "system:index": "1098"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.83856201171875, 39.64958341339568]),
            {
              "class": 2,
              "system:index": "1099"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.808349609375, 39.604630118233196]),
            {
              "class": 2,
              "system:index": "1100"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.80903625488281, 39.56202977996505]),
            {
              "class": 2,
              "system:index": "1101"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.85383987426758, 39.54349972635452]),
            {
              "class": 2,
              "system:index": "1102"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.85006332397461, 39.560044653818515]),
            {
              "class": 2,
              "system:index": "1103"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.87512588500977, 39.5785702881034]),
            {
              "class": 2,
              "system:index": "1104"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.7999382019043, 39.51066291191801]),
            {
              "class": 2,
              "system:index": "1105"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.81143951416016, 39.532908902224136]),
            {
              "class": 2,
              "system:index": "1106"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.76217269897461, 39.51397377841747]),
            {
              "class": 2,
              "system:index": "1107"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.72406387329102, 39.47383544493175]),
            {
              "class": 2,
              "system:index": "1108"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.64932680130005, 39.399840121987246]),
            {
              "class": 2,
              "system:index": "1109"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.62913513183594, 39.42134249546521]),
            {
              "class": 2,
              "system:index": "1110"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.68767166137695, 39.3773027652817]),
            {
              "class": 2,
              "system:index": "1111"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.54484939575195, 39.4604508509853]),
            {
              "class": 2,
              "system:index": "1112"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.54648017883301, 39.46316773423119]),
            {
              "class": 2,
              "system:index": "1113"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.55819606781006, 39.46750790082436]),
            {
              "class": 2,
              "system:index": "1114"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.56849575042725, 39.468700570947156]),
            {
              "class": 2,
              "system:index": "1115"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.5241641998291, 39.46681216714573]),
            {
              "class": 2,
              "system:index": "1116"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.52073097229004, 39.485462049091105]),
            {
              "class": 2,
              "system:index": "1117"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.54158782958984, 39.48956898883632]),
            {
              "class": 2,
              "system:index": "1118"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.55660820007324, 39.49291397824881]),
            {
              "class": 2,
              "system:index": "1119"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.57566261291504, 39.499073636679654]),
            {
              "class": 2,
              "system:index": "1120"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.54145908355713, 39.50612676866733]),
            {
              "class": 2,
              "system:index": "1121"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.5759630203247, 39.51251701659638]),
            {
              "class": 2,
              "system:index": "1122"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.57240104675293, 39.53045954409425]),
            {
              "class": 2,
              "system:index": "1123"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.58746433258057, 39.52973133987831]),
            {
              "class": 2,
              "system:index": "1124"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.57489013671875, 39.53946216525686]),
            {
              "class": 2,
              "system:index": "1125"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.61591720581055, 39.54475727937686]),
            {
              "class": 2,
              "system:index": "1126"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6560001373291, 39.53237931859914]),
            {
              "class": 2,
              "system:index": "1127"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6487045288086, 39.56202977996505]),
            {
              "class": 2,
              "system:index": "1128"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.67050552368164, 39.53522578308446]),
            {
              "class": 2,
              "system:index": "1129"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.52751159667969, 39.55805947085244]),
            {
              "class": 2,
              "system:index": "1130"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.38932418823242, 39.65724900047557]),
            {
              "class": 2,
              "system:index": "1131"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.42914962768555, 39.64680773260988]),
            {
              "class": 2,
              "system:index": "1132"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.3857192993164, 39.672445495621204]),
            {
              "class": 2,
              "system:index": "1133"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.41438674926758, 39.640330710772]),
            {
              "class": 2,
              "system:index": "1134"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.36838150024414, 39.640991659161436]),
            {
              "class": 2,
              "system:index": "1135"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.29302215576172, 39.637686854048]),
            {
              "class": 2,
              "system:index": "1136"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.26807761192322, 39.64517201139544]),
            {
              "class": 2,
              "system:index": "1137"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.26997661590576, 39.64081816082063]),
            {
              "class": 2,
              "system:index": "1138"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.286949634552, 39.638025603835715]),
            {
              "class": 2,
              "system:index": "1139"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.28961038589478, 39.64096687371082]),
            {
              "class": 2,
              "system:index": "1140"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2899215221405, 39.63924013211965]),
            {
              "class": 2,
              "system:index": "1141"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.32078838348389, 39.66658202663809]),
            {
              "class": 2,
              "system:index": "1142"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.32872772216797, 39.66260119087392]),
            {
              "class": 2,
              "system:index": "1143"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.30460929870605, 39.668431963543576]),
            {
              "class": 2,
              "system:index": "1144"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.31287050247192, 39.65696816422631]),
            {
              "class": 2,
              "system:index": "1145"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.31724786758423, 39.65153293208855]),
            {
              "class": 2,
              "system:index": "1146"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.15972709655762, 39.70745078118559]),
            {
              "class": 2,
              "system:index": "1147"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.17860984802246, 39.7085732984313]),
            {
              "class": 2,
              "system:index": "1148"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12157535552979, 39.717189660831586]),
            {
              "class": 2,
              "system:index": "1149"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1192364692688, 39.721051818741444]),
            {
              "class": 2,
              "system:index": "1150"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1136360168457, 39.7185761013762]),
            {
              "class": 2,
              "system:index": "1151"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12084579467773, 39.711594099720024]),
            {
              "class": 2,
              "system:index": "1152"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12101745605469, 39.715109947757554]),
            {
              "class": 2,
              "system:index": "1153"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.14444923400879, 39.70665840507515]),
            {
              "class": 2,
              "system:index": "1154"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1502857208252, 39.68433607354312]),
            {
              "class": 2,
              "system:index": "1155"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.11159753799438, 39.66762262224213]),
            {
              "class": 2,
              "system:index": "1156"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1175627708435, 39.67434482252152]),
            {
              "class": 2,
              "system:index": "1157"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.11018133163452, 39.67416315003322]),
            {
              "class": 2,
              "system:index": "1158"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.11599636077881, 39.67685515707811]),
            {
              "class": 2,
              "system:index": "1159"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.17869567871094, 39.44454501684116]),
            {
              "class": 2,
              "system:index": "1160"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.23568725585938, 39.44295423357212]),
            {
              "class": 2,
              "system:index": "1161"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1659927368164, 39.417098913067754]),
            {
              "class": 2,
              "system:index": "1162"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.10831451416016, 39.4528960328567]),
            {
              "class": 2,
              "system:index": "1163"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.08102035522461, 39.476750559571435]),
            {
              "class": 2,
              "system:index": "1164"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0202522277832, 39.47837369545861]),
            {
              "class": 2,
              "system:index": "1165"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.01647567749023, 39.48125549646666]),
            {
              "class": 2,
              "system:index": "1166"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0208101272583, 39.46614955717525]),
            {
              "class": 2,
              "system:index": "1167"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.02415752410889, 39.46224002992506]),
            {
              "class": 2,
              "system:index": "1168"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.13427829742432, 39.63795124426835]),
            {
              "class": 2,
              "system:index": "1169"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12957906723022, 39.634844595351005]),
            {
              "class": 2,
              "system:index": "1170"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12996530532837, 39.644676330660715]),
            {
              "class": 2,
              "system:index": "1171"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.16556358337402, 39.66983590045654]),
            {
              "class": 2,
              "system:index": "1172"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.18466091156006, 39.663724437468346]),
            {
              "class": 2,
              "system:index": "1173"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.19139862060547, 39.664616414404556]),
            {
              "class": 2,
              "system:index": "1174"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.21770572662354, 39.72247118994634]),
            {
              "class": 2,
              "system:index": "1175"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.21628952026367, 39.718708141879254]),
            {
              "class": 2,
              "system:index": "1176"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.23075199127197, 39.70768188917033]),
            {
              "class": 2,
              "system:index": "1177"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.23877716064453, 39.706493325573405]),
            {
              "class": 2,
              "system:index": "1178"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.25628662109375, 39.70269638802469]),
            {
              "class": 2,
              "system:index": "1179"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1162109375, 40.11287021944206]),
            {
              "class": 2,
              "system:index": "1180"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.08050537109375, 40.114183032973855]),
            {
              "class": 2,
              "system:index": "1181"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.03072357177734, 40.130853560108214]),
            {
              "class": 2,
              "system:index": "1182"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12891387939453, 40.100265920161036]),
            {
              "class": 2,
              "system:index": "1183"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1356086730957, 40.12022164880845]),
            {
              "class": 2,
              "system:index": "1184"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.09698486328125, 40.1578852495065]),
            {
              "class": 2,
              "system:index": "1185"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.17217254638672, 40.244681238556815]),
            {
              "class": 2,
              "system:index": "1186"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.16719436645508, 40.28332341266529]),
            {
              "class": 2,
              "system:index": "1187"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1000747680664, 40.312650521488564]),
            {
              "class": 2,
              "system:index": "1188"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.15225982666016, 40.32037295438762]),
            {
              "class": 2,
              "system:index": "1189"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12445068359375, 40.323383155065734]),
            {
              "class": 2,
              "system:index": "1190"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1927719116211, 40.31160334394532]),
            {
              "class": 2,
              "system:index": "1191"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0803337097168, 40.28319245953215]),
            {
              "class": 2,
              "system:index": "1192"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.05080795288086, 40.28816850025504]),
            {
              "class": 2,
              "system:index": "1193"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.04977798461914, 40.29615558909888]),
            {
              "class": 2,
              "system:index": "1194"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.99913787841797, 40.23773640724092]),
            {
              "class": 2,
              "system:index": "1195"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.984375, 40.23236350185715]),
            {
              "class": 2,
              "system:index": "1196"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.94145965576172, 40.20981886323868]),
            {
              "class": 2,
              "system:index": "1197"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90352249145508, 40.23380505490233]),
            {
              "class": 2,
              "system:index": "1198"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8631820678711, 40.245991504199026]),
            {
              "class": 2,
              "system:index": "1199"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.93716812133789, 40.16326405954085]),
            {
              "class": 2,
              "system:index": "1200"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.00806427001953, 40.18897150735162]),
            {
              "class": 2,
              "system:index": "1201"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.9927864074707, 40.203525997305476]),
            {
              "class": 2,
              "system:index": "1202"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.9404296875, 40.14883214380619]),
            {
              "class": 2,
              "system:index": "1203"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.86112213134766, 40.16418235037417]),
            {
              "class": 2,
              "system:index": "1204"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.92043113708496, 40.131641042944715]),
            {
              "class": 2,
              "system:index": "1205"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.88309478759766, 40.12842543059151]),
            {
              "class": 2,
              "system:index": "1206"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.86687278747559, 40.14660148319568]),
            {
              "class": 2,
              "system:index": "1207"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.88730049133301, 40.165690944063]),
            {
              "class": 2,
              "system:index": "1208"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.85983467102051, 40.15729486635644]),
            {
              "class": 2,
              "system:index": "1209"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90532493591309, 40.183266868757606]),
            {
              "class": 2,
              "system:index": "1210"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.92995834350586, 40.16542858235145]),
            {
              "class": 2,
              "system:index": "1211"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90549659729004, 40.157754053694546]),
            {
              "class": 2,
              "system:index": "1212"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.9003574848175, 40.17726254635587]),
            {
              "class": 2,
              "system:index": "1213"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90038967132568, 40.176430506182534]),
            {
              "class": 2,
              "system:index": "1214"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.90000343322754, 40.207524656870106]),
            {
              "class": 2,
              "system:index": "1215"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.93270492553711, 40.21434149977176]),
            {
              "class": 2,
              "system:index": "1216"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.95047187805176, 40.22522080912914]),
            {
              "class": 2,
              "system:index": "1217"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.92154693603516, 40.222533913245705]),
            {
              "class": 2,
              "system:index": "1218"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.95896911621094, 40.20162491249384]),
            {
              "class": 2,
              "system:index": "1219"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.95845413208008, 40.189758316404536]),
            {
              "class": 2,
              "system:index": "1220"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.9675521850586, 40.19428229133014]),
            {
              "class": 2,
              "system:index": "1221"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.94163131713867, 40.21604560336331]),
            {
              "class": 2,
              "system:index": "1222"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0037727355957, 40.16306728131765]),
            {
              "class": 2,
              "system:index": "1223"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.67333793640137, 39.50476917917323]),
            {
              "class": 2,
              "system:index": "1224"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.69728469848633, 39.4956958270616]),
            {
              "class": 2,
              "system:index": "1225"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.7014045715332, 39.505166525185054]),
            {
              "class": 2,
              "system:index": "1226"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.67840194702148, 39.49655685294358]),
            {
              "class": 2,
              "system:index": "1227"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.69985961914062, 39.56328699713585]),
            {
              "class": 2,
              "system:index": "1228"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.70492362976074, 39.57380702634555]),
            {
              "class": 2,
              "system:index": "1229"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.66320991516113, 39.56275764531551]),
            {
              "class": 2,
              "system:index": "1230"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.61102485656738, 39.550184352064676]),
            {
              "class": 2,
              "system:index": "1231"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.61179733276367, 39.557331556195265]),
            {
              "class": 2,
              "system:index": "1232"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.60939407348633, 39.574931714889395]),
            {
              "class": 2,
              "system:index": "1233"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.4264030456543, 39.45024502516818]),
            {
              "class": 2,
              "system:index": "1234"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.41335678100586, 39.434469442478466]),
            {
              "class": 2,
              "system:index": "1235"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.38563346862793, 39.4165684471033]),
            {
              "class": 2,
              "system:index": "1236"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2125129699707, 39.55666980896899]),
            {
              "class": 2,
              "system:index": "1237"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.21225547790527, 39.55005198948838]),
            {
              "class": 2,
              "system:index": "1238"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.12110328674316, 39.60925901175838]),
            {
              "class": 2,
              "system:index": "1239"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.52196216583252, 39.66286548583284]),
            {
              "class": 2,
              "system:index": "1240"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.50423812866211, 39.64459371685947]),
            {
              "class": 2,
              "system:index": "1241"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.55170249938965, 39.65404409548925]),
            {
              "class": 2,
              "system:index": "1242"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.53320598602295, 39.67422921281153]),
            {
              "class": 2,
              "system:index": "1243"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.55144500732422, 39.68585527766476]),
            {
              "class": 2,
              "system:index": "1244"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.50089073181152, 39.705337758002344]),
            {
              "class": 2,
              "system:index": "1245"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.51513862609863, 39.715175971358605]),
            {
              "class": 2,
              "system:index": "1246"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.48239421844482, 39.72524383081255]),
            {
              "class": 2,
              "system:index": "1247"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.48788738250732, 39.742636307558634]),
            {
              "class": 2,
              "system:index": "1248"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.51423740386963, 39.74742094401099]),
            {
              "class": 2,
              "system:index": "1249"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.49998950958252, 39.76292748167637]),
            {
              "class": 2,
              "system:index": "1250"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.49883079528809, 39.74953267786071]),
            {
              "class": 2,
              "system:index": "1251"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.50329399108887, 39.735475230966046]),
            {
              "class": 2,
              "system:index": "1252"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.47029209136963, 39.7582099046062]),
            {
              "class": 2,
              "system:index": "1253"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.45926284790039, 39.74167934039883]),
            {
              "class": 2,
              "system:index": "1254"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.43548774719238, 39.73059075192764]),
            {
              "class": 2,
              "system:index": "1255"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.45162391662598, 39.72738925020742]),
            {
              "class": 2,
              "system:index": "1256"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.40476036071777, 39.71577018092406]),
            {
              "class": 2,
              "system:index": "1257"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.39566230773926, 39.729897655916886]),
            {
              "class": 2,
              "system:index": "1258"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.37120056152344, 39.72039163613398]),
            {
              "class": 2,
              "system:index": "1259"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.36167335510254, 39.7279503488823]),
            {
              "class": 2,
              "system:index": "1260"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.38677883148193, 39.69761146616883]),
            {
              "class": 2,
              "system:index": "1261"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.41295719146729, 39.70150773854818]),
            {
              "class": 2,
              "system:index": "1262"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.4381914138794, 39.70735173466944]),
            {
              "class": 2,
              "system:index": "1263"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.41536045074463, 39.697941667274115]),
            {
              "class": 2,
              "system:index": "1264"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.36292862892151, 39.704578374489536]),
            {
              "class": 2,
              "system:index": "1265"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.36541771888733, 39.710628448117696]),
            {
              "class": 2,
              "system:index": "1266"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.16057205200195, 39.770415559194596]),
            {
              "class": 2,
              "system:index": "1267"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.10770034790039, 39.7354422288907]),
            {
              "class": 2,
              "system:index": "1268"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.10220718383789, 39.76995376300068]),
            {
              "class": 2,
              "system:index": "1269"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.08717608451843, 39.76834569850845]),
            {
              "class": 2,
              "system:index": "1270"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.94942855834961, 39.733726099198165]),
            {
              "class": 2,
              "system:index": "1271"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.90410995483398, 39.66768869127516]),
            {
              "class": 2,
              "system:index": "1272"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.88333892822266, 39.64839384956074]),
            {
              "class": 2,
              "system:index": "1273"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.85454273223877, 39.621656309108225]),
            {
              "class": 2,
              "system:index": "1274"
            })]),
    input = ee.Image("users/images/input/SBasinRange_2010_InputSR"),
    change = ee.Image("users/images/NA_2010_2010_change_v1_asset"),
    NonCropClass2 = /* color: #98ff00 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-109.35516357421875, 36.30208524279803]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2755126953125, 36.63780898341343]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1217041015625, 36.754528314530745]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.05853271484375, 36.0026924124376]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.5721435546875, 35.780184053607435]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.01434326171875, 36.59812815823348]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.05279541015625, 36.67967213781464]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.48699951171875, 35.523527491165076]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.35540771484375, 35.47657078640627]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.87725830078125, 35.18527626708548]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.83880615234375, 35.120152094922275]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8690185546875, 34.99424765728937]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.380126953125, 35.120152094922275]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.8909912109375, 34.93572606754174]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.42657470703125, 35.75566997843822]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.42657470703125, 36.04045661028945]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.33392333984375, 35.15833465591928]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.941162109375, 35.56598846955403]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.73516845703125, 35.398248636874534]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84228515625, 35.234646028669616]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.787353515625, 35.52799812649516]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.85601806640625, 35.07520851219359]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.72898864746094, 35.4710463181148]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.87730407714844, 35.507666241989945]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.787353515625, 35.52080061969191]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7650375366211, 35.41958252616365]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.66925048828125, 35.50179699574888]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.673370026052, 35.40223405516096]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.63354458659887, 35.29946585384259]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.81413269042969, 35.24536882671654]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.74752807617188, 35.262750996946195]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.7320785522461, 35.18057341982401]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.71697235107422, 35.20862972746598]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.60813903808594, 35.19404165673732]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.63217163085938, 35.22994603999618]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.62427520751953, 35.261349347205595]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.81825256347656, 35.34820576955128]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.8199691772461, 35.365565862094854]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.80520629882812, 35.45986133658652]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.93360900878906, 35.55013561480738]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.92365264892578, 35.57862219360644]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.94871520996094, 35.521918339848256]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.92880249023438, 35.51101990439944]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.78246116638184, 35.539319276957876]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.9136962890625, 35.553578335490506]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01737976074219, 35.73929712078987]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.051025390625, 35.796125354444584]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.91609954833984, 35.770501962004296]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.78907012939453, 35.87378082715255]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99128723144531, 35.85907814147881]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.99523544311523, 35.871667928634395]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.01823806762695, 35.89364306021466]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.04141235351562, 35.895207515099166]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.45065307617188, 35.94694318887816]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.94047546386719, 35.60712890160707]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.85121154785156, 34.22719320387534]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.89584350585938, 34.27316660839213]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.86219787597656, 34.22094796523177]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.18766784667969, 34.31627930264504]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.19316101074219, 34.33102330215768]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.13616943359375, 34.345197781609244]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.94459533691406, 34.33726036823951]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.875244140625, 34.30323437469862]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-105.84365844726562, 34.20618465153633]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.34353637695312, 34.50661740500618]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.38954162597656, 34.50265644752991]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.534423828125, 34.32762107065748]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.36619567871094, 34.57675172743839]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.22131339274347, 34.91311852007896]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.20843878947198, 34.92874204888528]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.19161597453058, 34.88594620460813]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.15110388956964, 34.903123532166056]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.17444983683527, 34.937326685621514]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.26611701212823, 34.97489148879163]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.29976264201105, 34.98108029065787]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.25083923339844, 35.083549251040694]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.2733268737793, 35.06669074446788]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.2710952758789, 35.15291354590134]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.26148223876953, 35.136630912193496]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.29581451416016, 35.13985962433508]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.32654190063477, 35.13241935609205]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.20586395263672, 35.16778965562439]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-106.23899459838867, 35.153194252398016]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.59597778320312, 34.95693079447822]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.89741516113281, 35.06209987499297]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.8363037109375, 35.04127128139217]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.90290832519531, 35.078085983720314]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.99732208251953, 34.94620709539652]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.9842758178711, 34.94029709823379]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.66841888427734, 34.923127548153396]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.58979797363281, 34.94564425687584]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.86548614501953, 35.052233118915346]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-107.95989990234375, 35.15391122831673]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.10360717773438, 37.537558452876404]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.05622863769531, 37.71593338590237]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.06927490234375, 37.7968219916402]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.2093505859375, 37.649636614778025]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.09605407714844, 37.81580984126168]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.09056091308594, 37.771316343048575]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.1654052734375, 37.599059122565876]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.87014770507812, 37.532657986433826]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.22514343261719, 37.45911235645938]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.71427917480469, 37.46401765155211]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.6875, 37.95616759531654]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.55429077148438, 37.97511440605757]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.00335693359375, 37.89387937306559]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.20179748535156, 38.09463704152116]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.13381958007812, 38.14757558737827]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.30479431152344, 37.99892631674033]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.13862609863281, 38.16593305256283]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.88456726074219, 37.9945974532646]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.654541015625, 38.06166612035893]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.49249267578125, 38.002172796675126]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.40460205078125, 38.03354802570316]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.5831298828125, 38.17942824028894]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.27122116088867, 37.94055699019842]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.23757553100586, 37.966951462308344]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2864990234375, 37.93392304219214]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.16307440958917, 37.965327460967686]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.18865195475519, 37.9830541979038]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1065978165716, 37.96681613023522]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.27585593424737, 37.9830541979038]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.97544844076037, 38.07623260855332]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.91399366781116, 37.98266269236326]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.07355308532715, 37.904597249158336]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.13809776306152, 37.899179177749566]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.05501365661621, 37.89945009079339]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.13990016561002, 37.910150358378786]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.18264384847134, 37.90629031467079]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2077064095065, 37.894573503438885]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.18367381673306, 37.92105219500629]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2183494148776, 37.8890869564931]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.16762347798795, 37.877638400123104]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.36649322509766, 37.909833589530095]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.0884017944336, 37.86958320125839]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.08342361450195, 37.83461301211713]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.1110610961914, 37.80383108451275]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.15311813354492, 37.94651336229631]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.13372039794922, 37.96925220154241]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.09080505371094, 38.05608090607804]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.10762786865234, 38.096755014161296]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.15861129760742, 38.06229834704287]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.16187286376953, 38.12214796217569]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.19603339396417, 38.17425687392173]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.24804679118097, 38.18248829550791]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.2095947265625, 38.203939860608905]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.23379898071289, 38.25949496165986]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.19431686401367, 37.887739731847816]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.21577453613281, 37.910361051893254]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.14496421813959, 37.89864488879976]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.74404907226562, 38.11679052537191]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.20547485351562, 38.24632848191469]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.73786926269531, 38.18104854907955]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.43299865722656, 38.11138811342445]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.28237915039062, 38.325016972489955]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.32426452636719, 38.336328313097994]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.27963256835938, 38.27813689871722]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.3084716796875, 38.26843379109725]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.20135498046875, 38.27274644343469]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.23818969726562, 38.237698731161224]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.21759033203125, 38.13731499119863]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.1544189453125, 38.21234600997321]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.09056074544787, 37.89767339630553]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.98893721029162, 37.87653867450759]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.66106406413019, 37.92175162322479]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.63600150309503, 38.005931643533145]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.57866660319269, 37.98807514064522]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.7774504777044, 37.96182360331024]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.4015121459961, 37.98239261442461]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.09536743164062, 37.79543585697685]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.01502990722656, 37.809270604061915]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.0332260131836, 37.74224291247038]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.08197784423828, 37.74007095919651]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.04215232096612, 37.67624140559937]),
            {
              "class": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.03219596110284, 37.63193585806835]),
            {
              "class": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.980354225263, 37.64607301461988]),
            {
              "class": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.21278381347656, 37.594133478188084]),
            {
              "class": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.84851837158203, 37.56801324382227]),
            {
              "class": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.90345001220703, 37.59386091386626]),
            {
              "class": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.76234436035156, 37.579169654750565]),
            {
              "class": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.94636535644531, 37.625682026959275]),
            {
              "class": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93366241455078, 37.56719685545251]),
            {
              "class": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.95391845703125, 37.528544238660736]),
            {
              "class": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.92164611816406, 37.46180775375019]),
            {
              "class": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.96250144205987, 37.383009837672944]),
            {
              "class": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93194571696222, 37.30330922541604]),
            {
              "class": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.81212607584894, 37.35899938054719]),
            {
              "class": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.94293204508722, 37.28063916296949]),
            {
              "class": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.98413077555597, 37.29921273190938]),
            {
              "class": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.98653403483331, 37.33170544319304]),
            {
              "class": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.7365951538086, 37.438912947161434]),
            {
              "class": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.70878601074219, 37.48251606389771]),
            {
              "class": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.52074432373047, 37.246355904447654]),
            {
              "class": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.52117347717285, 37.23289473573234]),
            {
              "class": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.5887222290039, 37.210126633781314]),
            {
              "class": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.60726165771484, 37.21067349210711]),
            {
              "class": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.9130630493164, 37.38819237207772]),
            {
              "class": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.93366241455078, 37.3985574316066]),
            {
              "class": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.76612091064453, 37.41137539088934]),
            {
              "class": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.31327819824219, 36.340631273861106]),
            {
              "class": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.37576293945312, 36.25485381769938]),
            {
              "class": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.41215515136719, 36.24931654982353]),
            {
              "class": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.40322875976562, 36.15734059954166]),
            {
              "class": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.04548645019531, 36.42631436177518]),
            {
              "class": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.27001953125, 36.377680064261796]),
            {
              "class": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.30160522460938, 36.101326466169034]),
            {
              "class": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.04067993164062, 36.05915086647052]),
            {
              "class": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.4183349609375, 36.003066715605655]),
            {
              "class": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.99192810058594, 35.97306475156882]),
            {
              "class": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.93905639648438, 35.94805440098514]),
            {
              "class": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.48631286621094, 35.8000537545412]),
            {
              "class": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.39910888671875, 35.70309182284438]),
            {
              "class": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.66484036296606, 35.75325983962563]),
            {
              "class": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.63188137859106, 35.491485200327595]),
            {
              "class": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.01228298991919, 35.76496103606994]),
            {
              "class": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.00953640788794, 35.83902863819006]),
            {
              "class": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.02876248210669, 35.87186303204498]),
            {
              "class": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.72595181316137, 35.75214480602683]),
            {
              "class": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-110.05348172038794, 35.825110884040654]),
            {
              "class": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.10453796386719, 35.63838547890818]),
            {
              "class": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.09561157226562, 35.52166920093685]),
            {
              "class": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.89717102050781, 35.255773169278456]),
            {
              "class": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.79486083984375, 35.12390084546948]),
            {
              "class": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.33549465984106, 35.48030306209947]),
            {
              "class": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.310088776052, 35.5574281373843]),
            {
              "class": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.03955044597387, 35.37735442159271]),
            {
              "class": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.20365872234106, 35.42380950235888]),
            {
              "class": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.22906460613012, 35.440034484378394]),
            {
              "class": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.26683010905981, 35.43388056567982]),
            {
              "class": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-109.09286465495825, 35.715357900496606]),
            {
              "class": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.35918409749866, 37.05958865581275]),
            {
              "class": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.38218672201037, 37.08506402494136]),
            {
              "class": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.37394697591662, 37.11710152531735]),
            {
              "class": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.37085707113147, 37.04177820982559]),
            {
              "class": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.27541334554553, 37.014095224806816]),
            {
              "class": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.2791898958385, 37.05136896933918]),
            {
              "class": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.35952742025256, 37.01574004043626]),
            {
              "class": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.35952742025256, 36.9820102050748]),
            {
              "class": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.34030134603381, 37.04808084544853]),
            {
              "class": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.34579451009631, 37.10395957448048]),
            {
              "class": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.22734815999866, 37.02999361786624]),
            {
              "class": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.22700483724475, 37.07054685266784]),
            {
              "class": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.30390913411975, 37.06150645453779]),
            {
              "class": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.38218672201037, 37.03054177897577]),
            {
              "class": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.36090071126819, 36.968848846021096]),
            {
              "class": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.28330976888537, 37.0160141729133]),
            {
              "class": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.35678100585938, 37.08040787625738]),
            {
              "class": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.37669372558594, 37.05821876989989]),
            {
              "class": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-108.3358383178711, 37.142283889096426]),
            {
              "class": 2,
              "system:index": "248"
            })]);
/***** End of imports. If edited, may not auto-convert in the playground. *****/


var zones=ee.FeatureCollection("ft:1emWmrrMBzdiKOitmcYSBmoCozs4Fpqq_f6A86pnR"); 
var zones2=ee.FeatureCollection("ft:13cK2cS_HzpvNGVZlIfH9zInVbJOMQgjXQKwgLHpL");
var countries = ee.FeatureCollection("ft:1tdSwUL7MVpOauSgRzqVTOwdfy17KDbw-1d9omPw"); 

//Map.addLayer(zones)


/*
function radians(img) {return img.toFloat().multiply(Math.PI).divide(180).divide(1.5708).toFloat();}
var terrain = ee.Algorithms.Terrain(ee.Image('USGS/SRTMGL1_003'));
var slope = radians(terrain.select('slope'));
var elevation = terrain.select('elevation').divide(4000.00).float();
*/

//input=input.select(ee.List.sequence(0,43)).addBands(slope).addBands(elevation);

//visual parameters for FCC display 
var vizParams = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  gamma: [1.5,1.6, 1.7]
};



//add all max val to map
//Map.addLayer(FCC,vizParams,'FCC');
Map.addLayer(input,{palette:'00ff00'},'crop')

//throw('stop')

//create bounds for training samples inside area of interest
function buffer(geometry) {
  return geometry.buffer(60).bounds();
} 

//buffer function of 1km********************************************************
function buffer1(geometry) {
  return geometry.buffer(10000);
}

function buffer2(geometry) {
  return geometry.buffer(10000);
}

var studyArea = zones.filterMetadata('name','equals','SBasinRange');

var region= ee.FeatureCollection(countries.filterMetadata('Country','equals','United States'))
              .map(buffer2)

studyArea=buffer1(studyArea.geometry());

//----------------
var outline =ee.Image().byte().paint({
  featureCollection: ee.FeatureCollection([studyArea]),
  color: 1,
  width: 3
});
Map.addLayer(outline, {palette: '000000'}, 'edges');

Map.addLayer(change,{min:0,max:2,palette:'00ff00,ffff00,ff0000'},'prev')

//throw('stop')
//--------------------

var CropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea);
/*
var CropSamplesArea2 = Cropclass2.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea2);

var CropSamplesArea2 = Cropclass3.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea3);
*/
var NonCropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea);

var NonCropSamplesArea2 = NonCropClass2.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea2);
/*
var NonCropSamplesArea2 = NonCropClass3.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea3);
*/
//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                   // .merge(CropSamplesArea2)
                   // .merge(CropSamplesArea3)
                    .merge(NonCropSamplesArea)
                   .merge(NonCropSamplesArea2)
                  // .merge(NonCropSamplesArea3);
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);

//print(input)

var training = input.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});
 

//build classifier
var classifier = ee.Classifier.randomForest(300,5).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input.classify(classifier);

classified = classified.updateMask(classified.eq(1)).clip(studyArea).clipToCollection(region);

////Export the classified image
Export.image.toAsset({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  description: 'SBasinRange_v1_asset',
  assetId: 'SBasinRange_2010_v1',
  region: studyArea, 
});


Export.image.toDrive({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  folder: 'data',
  description: 'SBasinRange',
  fileNamePrefix: 'SBasinRange_2010_v1',
  region: studyArea, 
});
 

Export.table.toDrive({
  collection: training,
  description: 'RandomForestTrainingTable_SBasinRange_v1',
  folder: 'data',
  fileNamePrefix: 'RFtable_SBasinRange_2010_v1',
  fileFormat: 'CSV'
});


//print('Classified',classified);

//add layer to map
Map.addLayer(classified, {palette: '00FF00'}, 'cropland');



