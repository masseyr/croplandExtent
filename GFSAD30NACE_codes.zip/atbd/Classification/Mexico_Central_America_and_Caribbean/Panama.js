/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var Cropclass = /* color: #ffc82d */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-82.90871143341064, 8.397561377219967]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.88991451263428, 8.412929865834185]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8812026977539, 8.394080032789331]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.87708282470703, 8.411826072043157]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85545349121094, 8.420359165277924]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85845756530762, 8.386098296053017]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.84283638000488, 8.391023216820944]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85416603088379, 8.368733207029408]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8627061843872, 8.353660191512503]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.83227920532227, 8.343894264920554]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81305313110352, 8.357311736079044]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82163619995117, 8.364402428445578]),
            {
              "class": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.84691333770752, 8.3293723053447]),
            {
              "class": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81228065490723, 8.312344409128132]),
            {
              "class": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85322189331055, 8.30312950350347]),
            {
              "class": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.88751125335693, 8.312938911735559]),
            {
              "class": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.87665367126465, 8.309499277030584]),
            {
              "class": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.79575824737549, 8.32915999199503]),
            {
              "class": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80685186386108, 8.332202074675985]),
            {
              "class": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78863430023193, 8.351664565504917]),
            {
              "class": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77687549591064, 8.328862753111974]),
            {
              "class": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77601718902588, 8.318528958742215]),
            {
              "class": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7695369720459, 8.325153260872542]),
            {
              "class": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75728464126587, 8.339165838294926]),
            {
              "class": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74827241897583, 8.339314453849683]),
            {
              "class": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75389432907104, 8.328083204918743]),
            {
              "class": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75915145874023, 8.350014625234362]),
            {
              "class": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.76709079742432, 8.352095180067018]),
            {
              "class": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77751922607422, 8.347466991969736]),
            {
              "class": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77552366256714, 8.335747664941715]),
            {
              "class": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77796983718872, 8.359398264314526]),
            {
              "class": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.76775598526001, 8.358103250628046]),
            {
              "class": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77590990066528, 8.368633073245263]),
            {
              "class": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.79736757278442, 8.374067709044326]),
            {
              "class": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.79640197753906, 8.380393869199604]),
            {
              "class": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78895616531372, 8.384045163130397]),
            {
              "class": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.76447296142578, 8.398992828929629]),
            {
              "class": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75245666503906, 8.409776267554548]),
            {
              "class": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72808074951172, 8.412917842856869]),
            {
              "class": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7435302734375, 8.399244366863101]),
            {
              "class": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74925947189331, 8.397652299395169]),
            {
              "class": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73767232894897, 8.393767627367602]),
            {
              "class": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73215770721436, 8.380500011948865]),
            {
              "class": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73700714111328, 8.370437550574687]),
            {
              "class": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72456169128418, 8.38062738320974]),
            {
              "class": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.71619319915771, 8.375298983175833]),
            {
              "class": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69359827041626, 8.458379728186097]),
            {
              "class": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68010139465332, 8.462030286436105]),
            {
              "class": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73765087127686, 8.474637180712383]),
            {
              "class": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74320840835571, 8.466975464223971]),
            {
              "class": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7593445777893, 8.470074126941364]),
            {
              "class": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75428056716919, 8.491191060571357]),
            {
              "class": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74194240570068, 8.494162194237683]),
            {
              "class": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72788763046265, 8.506322379989536]),
            {
              "class": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72198677062988, 8.505303740490909]),
            {
              "class": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72711515426636, 8.533803401470454]),
            {
              "class": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72252321243286, 8.54318257185455]),
            {
              "class": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73604154586792, 8.554407565315387]),
            {
              "class": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.71986246109009, 8.557632833089535]),
            {
              "class": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6952075958252, 8.571446006267035]),
            {
              "class": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69977807998657, 8.577258897894133]),
            {
              "class": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69599616527557, 8.576479147276434]),
            {
              "class": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66870737075806, 8.620757955720297]),
            {
              "class": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61646866798401, 8.587928683114738]),
            {
              "class": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61927425861359, 8.600477760110905]),
            {
              "class": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6282811164856, 8.612189644234698]),
            {
              "class": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62815237045288, 8.608667817144415]),
            {
              "class": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63750791549683, 8.636608157289478]),
            {
              "class": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66235589981079, 8.641360143044626]),
            {
              "class": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65997409820557, 8.647607640316075]),
            {
              "class": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67067074775696, 8.645030162480902]),
            {
              "class": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66854643821716, 8.590580809566154]),
            {
              "class": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65357971191406, 8.601846835944674]),
            {
              "class": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63014793395996, 8.646451489887514]),
            {
              "class": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61732697486877, 8.66639193558231]),
            {
              "class": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5866961479187, 8.643407297021628]),
            {
              "class": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58023738861084, 8.62286100439386]),
            {
              "class": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57870316505432, 8.593190483891744]),
            {
              "class": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57624626159668, 8.571209251364884]),
            {
              "class": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56494879722595, 8.536898156548608]),
            {
              "class": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56590366363525, 8.552112543803435]),
            {
              "class": 1,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57980823516846, 8.541852978316328]),
            {
              "class": 1,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58275866508484, 8.544144694242611]),
            {
              "class": 1,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57463693618774, 8.52231978557992]),
            {
              "class": 1,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57009863853455, 8.519571689748473]),
            {
              "class": 1,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56691217422485, 8.513247811227474]),
            {
              "class": 1,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56395101547241, 8.487144791745653]),
            {
              "class": 1,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56181597709656, 8.484237272319376]),
            {
              "class": 1,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56985187530518, 8.481764802352599]),
            {
              "class": 1,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56974458694458, 8.476459024290952]),
            {
              "class": 1,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56412267684937, 8.472033945063561]),
            {
              "class": 1,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56903648376465, 8.468786732238014]),
            {
              "class": 1,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56559252738953, 8.466643132285354]),
            {
              "class": 1,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56806015968323, 8.459363292856299]),
            {
              "class": 1,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56985187530518, 8.453717608378852]),
            {
              "class": 1,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57211565971375, 8.449929010591738]),
            {
              "class": 1,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57720112800598, 8.4493665545259]),
            {
              "class": 1,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56346821784973, 8.444824426433543]),
            {
              "class": 1,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55783557891846, 8.45232739894869]),
            {
              "class": 1,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55772829055786, 8.441428407884327]),
            {
              "class": 1,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56234169006348, 8.437501724198919]),
            {
              "class": 1,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56294250488281, 8.430783818743196]),
            {
              "class": 1,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56266355514526, 8.428777975993619]),
            {
              "class": 1,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5660753250122, 8.42417192733956]),
            {
              "class": 1,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56324291229248, 8.422081145221705]),
            {
              "class": 1,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55767464637756, 8.413590543411654]),
            {
              "class": 1,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56489515304565, 8.413845264174707]),
            {
              "class": 1,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55044341087341, 8.417199071931327]),
            {
              "class": 1,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54650592803955, 8.405874547604554]),
            {
              "class": 1,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55021810531616, 8.40142743211645]),
            {
              "class": 1,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56323218345642, 8.404452325286059]),
            {
              "class": 1,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54257917404175, 8.355627849771949]),
            {
              "class": 1,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56223440170288, 8.337093704886305]),
            {
              "class": 1,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53966093063354, 8.351445536553166]),
            {
              "class": 1,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.64010429382324, 8.338009110580018]),
            {
              "class": 1,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65993118286133, 8.354993429692543]),
            {
              "class": 1,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65516757965088, 8.36972672765053]),
            {
              "class": 1,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63079166412354, 8.399361470630293]),
            {
              "class": 1,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.650146484375, 8.414621277367932]),
            {
              "class": 1,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66795635223389, 8.409059847093507]),
            {
              "class": 1,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67276287078857, 8.41362362208792]),
            {
              "class": 1,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67709732055664, 8.405005471673046]),
            {
              "class": 1,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.71039962768555, 8.429691927319912]),
            {
              "class": 1,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.70334005355835, 8.432408827095816]),
            {
              "class": 1,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.70994901657104, 8.400590187395053]),
            {
              "class": 1,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.71278142929077, 8.391271225379969]),
            {
              "class": 1,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72786617279053, 8.366646013523498]),
            {
              "class": 1,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7370285987854, 8.363886194420498]),
            {
              "class": 1,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72220134735107, 8.35520325148982]),
            {
              "class": 1,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7166223526001, 8.353080253147718]),
            {
              "class": 1,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72859573364258, 8.351721528146983]),
            {
              "class": 1,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7026481628418, 8.03208160900165]),
            {
              "class": 1,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68397998809814, 8.018841925543608]),
            {
              "class": 1,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68397998809814, 8.030145632200506]),
            {
              "class": 1,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.69889307022095, 8.018948164851302]),
            {
              "class": 1,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.70784091949463, 8.017503307889013]),
            {
              "class": 1,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.66988229751587, 8.038516971595811]),
            {
              "class": 1,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67561149597168, 8.051201133802753]),
            {
              "class": 1,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68666219711304, 8.054281816790375]),
            {
              "class": 1,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.66726446151733, 8.065074645325787]),
            {
              "class": 1,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67715644836426, 8.069684879963152]),
            {
              "class": 1,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68737030029297, 8.064607245330564]),
            {
              "class": 1,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.69556713104248, 8.08119961409636]),
            {
              "class": 1,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68565368652344, 8.090082235799619]),
            {
              "class": 1,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71277618408203, 8.072576696078897]),
            {
              "class": 1,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6929063796997, 8.107119664573542]),
            {
              "class": 1,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7006311416626, 8.105080309594776]),
            {
              "class": 1,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67410945892334, 8.106184961491634]),
            {
              "class": 1,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.66350936889648, 8.093991136039]),
            {
              "class": 1,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.65248012542725, 8.11005121923981]),
            {
              "class": 1,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63638687133789, 8.105037822922785]),
            {
              "class": 1,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62570095062256, 8.12751264524848]),
            {
              "class": 1,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.65793037414551, 8.12313673873862]),
            {
              "class": 1,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63861846923828, 8.137326397911158]),
            {
              "class": 1,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6680154800415, 8.123604070835691]),
            {
              "class": 1,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.65943241119385, 8.135499613664507]),
            {
              "class": 1,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68363666534424, 8.133332951787473]),
            {
              "class": 1,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87486743927002, 7.424224286449972]),
            {
              "class": 1,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88666915893555, 7.44392707286656]),
            {
              "class": 1,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87194919586182, 7.440778090783634]),
            {
              "class": 1,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85104942321777, 7.43830995389046]),
            {
              "class": 1,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8524227142334, 7.428096826135452]),
            {
              "class": 1,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87113380432129, 7.432692763017248]),
            {
              "class": 1,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8247423171997, 7.434011958239884]),
            {
              "class": 1,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.82221031188965, 7.425756284250175]),
            {
              "class": 1,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.83465576171875, 7.430777795159588]),
            {
              "class": 1,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84611415863037, 7.425200580342847]),
            {
              "class": 1,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.83148002624512, 7.423498358083892]),
            {
              "class": 1,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84577083587646, 7.3932001840175365]),
            {
              "class": 1,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.83645820617676, 7.371196858262727]),
            {
              "class": 1,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86615562438965, 7.376516911622415]),
            {
              "class": 1,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85978269577026, 7.372322231521475]),
            {
              "class": 1,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86231470108032, 7.388516233756465]),
            {
              "class": 1,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.89319229125977, 7.367576702053321]),
            {
              "class": 1,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.89553117752075, 7.384707185383372]),
            {
              "class": 1,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.90192556381226, 7.382238734273762]),
            {
              "class": 1,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85641384124756, 7.3584259860819285]),
            {
              "class": 1,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78789949417114, 7.368534324201538]),
            {
              "class": 1,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7770848274231, 7.36276727952899]),
            {
              "class": 1,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44764518737793, 7.3072235458598245]),
            {
              "class": 1,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48218131065369, 7.253348290410496]),
            {
              "class": 1,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47847986221313, 7.260691886231961]),
            {
              "class": 1,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48706293106079, 7.27257974290605]),
            {
              "class": 1,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4956728219986, 7.268572193726818]),
            {
              "class": 1,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42450308799744, 7.382567329543374]),
            {
              "class": 1,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42807579040527, 7.398675840386069]),
            {
              "class": 1,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4384183883667, 7.378134195170412]),
            {
              "class": 1,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.43904066085815, 7.399207815528308]),
            {
              "class": 1,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44776856899261, 7.401840462228964]),
            {
              "class": 1,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45000553131104, 7.404612646601463]),
            {
              "class": 1,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44465184211731, 7.40883645468487]),
            {
              "class": 1,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4523229598999, 7.405346762247452]),
            {
              "class": 1,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47251462936401, 7.419699009354192]),
            {
              "class": 1,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.37988185882568, 7.432990646155853]),
            {
              "class": 1,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36529064178467, 7.4290092787736794]),
            {
              "class": 1,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33212780952454, 7.418635107907143]),
            {
              "class": 1,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32711744308472, 7.461222310994539]),
            {
              "class": 1,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34376859664917, 7.424477136688017]),
            {
              "class": 1,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33779799938202, 7.425597675411692]),
            {
              "class": 1,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42129516601562, 7.462784851983296]),
            {
              "class": 1,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.28352618217468, 7.810293026784238]),
            {
              "class": 1,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2949845790863, 7.804680713723867]),
            {
              "class": 1,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.29707670211792, 7.801842640361447]),
            {
              "class": 1,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.28903007507324, 7.798547474840012]),
            {
              "class": 1,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.28503894805908, 7.798388030688637]),
            {
              "class": 1,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2586030960083, 7.792659871019305]),
            {
              "class": 1,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.25729417800903, 7.819360969674329]),
            {
              "class": 1,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.25611400604248, 7.82930966850804]),
            {
              "class": 1,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.23598670959473, 7.820636457147619]),
            {
              "class": 1,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2240777015686, 7.803013126856033]),
            {
              "class": 1,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.23386240005493, 7.79321261804993]),
            {
              "class": 1,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.20933628082275, 7.793659067041871]),
            {
              "class": 1,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.23493528366089, 7.765510590876497]),
            {
              "class": 1,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.24999856948853, 7.763852238071964]),
            {
              "class": 1,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.25068521499634, 7.768954841169501]),
            {
              "class": 1,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.19067883491516, 7.760736253063846]),
            {
              "class": 1,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.1828145980835, 7.756813555735719]),
            {
              "class": 1,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.19047498703003, 7.757302566071058]),
            {
              "class": 1,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18313646316528, 7.770718236432412]),
            {
              "class": 1,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.17684936523438, 7.763500191261712]),
            {
              "class": 1,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21367073059082, 7.783560699669479]),
            {
              "class": 1,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21124601364136, 7.799845525477208]),
            {
              "class": 1,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21254420280457, 7.805839322404591]),
            {
              "class": 1,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21610617637634, 7.809123801113218]),
            {
              "class": 1,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21827340126038, 7.803713432457359]),
            {
              "class": 1,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2112889289856, 7.808921843620432]),
            {
              "class": 1,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22622346878052, 7.805764916439025]),
            {
              "class": 1,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.23213505744934, 7.8027886669561255]),
            {
              "class": 1,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3636384010315, 7.871842810588304]),
            {
              "class": 1,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3594434261322, 7.872182898034178]),
            {
              "class": 1,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3559672832489, 7.878187521020034]),
            {
              "class": 1,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.35492658615112, 7.873447595774478]),
            {
              "class": 1,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34697651863098, 7.874382831956662]),
            {
              "class": 1,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34412264823914, 7.8784107000194155]),
            {
              "class": 1,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34362375736237, 7.8538915540931065]),
            {
              "class": 1,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.35104274749756, 7.834517760160273]),
            {
              "class": 1,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32559394836426, 7.837600069436722]),
            {
              "class": 1,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33228874206543, 7.848547397135737]),
            {
              "class": 1,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.27746438980103, 7.853594584624977]),
            {
              "class": 1,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.26733636856079, 7.846484254980042]),
            {
              "class": 1,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.26486873626709, 7.826886289381584]),
            {
              "class": 1,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33200979232788, 7.9202811991396]),
            {
              "class": 1,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33658564090729, 7.922103018265364]),
            {
              "class": 1,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33992767333984, 7.925959405736762]),
            {
              "class": 1,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34121513366699, 7.936433143321616]),
            {
              "class": 1,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3401529788971, 7.93350033648462]),
            {
              "class": 1,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33750295639038, 7.942596219914518]),
            {
              "class": 1,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34258842468262, 7.940471036722171]),
            {
              "class": 1,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34696578979492, 7.945199565881223]),
            {
              "class": 1,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34925103187561, 7.939865356020225]),
            {
              "class": 1,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36042511463165, 7.945746176625845]),
            {
              "class": 1,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3495192527771, 7.915245451726287]),
            {
              "class": 1,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33936977386475, 7.905148798122976]),
            {
              "class": 1,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3294187784195, 7.9010036710132505]),
            {
              "class": 1,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3295636177063, 7.8974489282886005]),
            {
              "class": 1,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33397316932678, 7.893750688141006]),
            {
              "class": 1,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3328788280487, 7.886795761470085]),
            {
              "class": 1,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33929467201233, 7.881173853428429]),
            {
              "class": 1,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.1581597328186, 7.718542651532404]),
            {
              "class": 1,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.16085267066956, 7.721007947109037]),
            {
              "class": 1,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.16996145248413, 7.714991672031389]),
            {
              "class": 1,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.1514220237732, 7.720817814337876]),
            {
              "class": 1,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.15839576721191, 7.729833292277955]),
            {
              "class": 1,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.15382528305054, 7.746162724186656]),
            {
              "class": 1,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.15363216400146, 7.736551014220225]),
            {
              "class": 1,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14858961105347, 7.703550551341224]),
            {
              "class": 1,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14116525650024, 7.708058498394849]),
            {
              "class": 1,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14580011367798, 7.691281037441306]),
            {
              "class": 1,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14667987823486, 7.687393299145317]),
            {
              "class": 1,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.17290115356445, 7.701541097217003]),
            {
              "class": 1,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.19048571586609, 7.713363780248439]),
            {
              "class": 1,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18999218940735, 7.706697613775565]),
            {
              "class": 1,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21523714065552, 7.697096873828237]),
            {
              "class": 1,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22585868835449, 7.695119285761291]),
            {
              "class": 1,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22201776504517, 7.699478473018722]),
            {
              "class": 1,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.11625289916992, 7.63526757038935]),
            {
              "class": 1,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.12597322463989, 7.625994871586274]),
            {
              "class": 1,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.10822772979736, 7.6275048889928305]),
            {
              "class": 1,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.10345339775085, 7.640902144923361]),
            {
              "class": 1,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.09655475616455, 7.650046920068949]),
            {
              "class": 1,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.09093284606934, 7.659988982235879]),
            {
              "class": 1,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.0929605960846, 7.665103471447636]),
            {
              "class": 1,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.08854031562805, 7.66284927587251]),
            {
              "class": 1,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.10145783424377, 7.677671456189752]),
            {
              "class": 1,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.1067042350769, 7.677139823072785]),
            {
              "class": 1,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14440536499023, 7.65214168399616]),
            {
              "class": 1,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.15562772750854, 7.661849770242321]),
            {
              "class": 1,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.16131401062012, 7.656841573736923]),
            {
              "class": 1,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.10711193084717, 7.663423458897024]),
            {
              "class": 1,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.09891510009766, 7.664848280094801]),
            {
              "class": 1,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.08479595184326, 7.5817766309974175]),
            {
              "class": 1,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.08265018463135, 7.6049603927917016]),
            {
              "class": 1,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.07073044776917, 7.605575955545309]),
            {
              "class": 1,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.05780220031738, 7.623594044263675]),
            {
              "class": 1,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.04724502563477, 7.60517555374321]),
            {
              "class": 1,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18822193145752, 7.606564958338222]),
            {
              "class": 1,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18065810203552, 7.621984599300079]),
            {
              "class": 1,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.15992999076843, 7.625142898655253]),
            {
              "class": 1,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14092922210693, 7.6401402341744085]),
            {
              "class": 1,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.16153931617737, 7.642125004109023]),
            {
              "class": 1,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.55999755859375, 7.789215805010691]),
            {
              "class": 1,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57481408119202, 7.775640037729494]),
            {
              "class": 1,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.56412816047668, 7.756154448758655]),
            {
              "class": 1,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61510622501373, 7.8869332995315]),
            {
              "class": 1,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61145842075348, 7.889558246568724]),
            {
              "class": 1,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60608327388763, 7.887576253686627]),
            {
              "class": 1,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60271978378296, 7.8944805014352815]),
            {
              "class": 1,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60246229171753, 7.901558126465553]),
            {
              "class": 1,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59405088424683, 7.906829071684636]),
            {
              "class": 1,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58293581008911, 7.902387029569569]),
            {
              "class": 1,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58913707733154, 7.917795822471796]),
            {
              "class": 1,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59203386306763, 7.924703025380342]),
            {
              "class": 1,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5971622467041, 7.928379735356066]),
            {
              "class": 1,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5692994594574, 7.914122478919596]),
            {
              "class": 1,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57745337486267, 7.986882021308074]),
            {
              "class": 1,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57707786560059, 7.980922101823391]),
            {
              "class": 1,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60666799545288, 7.953797015728736]),
            {
              "class": 1,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60093879699707, 7.9560283907792275]),
            {
              "class": 1,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60010194778442, 7.952160666308146]),
            {
              "class": 1,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60302019119263, 7.950269293259924]),
            {
              "class": 1,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5966204404831, 7.959102628560974]),
            {
              "class": 1,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62046527862549, 7.976832721760696]),
            {
              "class": 1,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6283187866211, 7.981741454601516]),
            {
              "class": 1,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62211751937866, 7.981337708237984]),
            {
              "class": 1,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62554001808167, 7.990877530886312]),
            {
              "class": 1,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61977863311768, 7.993544312176433]),
            {
              "class": 1,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63895106315613, 7.987265130037893]),
            {
              "class": 1,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63244938850403, 7.994776145634562]),
            {
              "class": 1,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63960552215576, 7.998825934870395]),
            {
              "class": 1,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.64711570739746, 7.995638586106448]),
            {
              "class": 1,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.64739465713501, 8.002331989732873]),
            {
              "class": 1,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6532096862793, 8.005561783280218]),
            {
              "class": 1,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67009687423706, 8.02058423631023]),
            {
              "class": 1,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6712555885315, 8.017333314004572]),
            {
              "class": 1,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67245721817017, 8.02351641844948]),
            {
              "class": 1,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7763123512268, 7.929229837032499]),
            {
              "class": 1,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77893018722534, 7.933799103440582]),
            {
              "class": 1,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78817844390869, 7.9307812680632805]),
            {
              "class": 1,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76500415802002, 7.929994927039267]),
            {
              "class": 1,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76596975326538, 7.9196023328816185]),
            {
              "class": 1,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75251579284668, 7.925808167091908]),
            {
              "class": 1,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75845956802368, 7.94227867720686]),
            {
              "class": 1,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75524091720581, 7.946465269378955]),
            {
              "class": 1,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76850175857544, 7.946422766119647]),
            {
              "class": 1,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8330249786377, 8.01486854513609]),
            {
              "class": 1,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85386037826538, 8.026257352191234]),
            {
              "class": 1,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85137128829956, 8.043276224379252]),
            {
              "class": 1,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85577011108398, 8.053240750649055]),
            {
              "class": 1,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84757328033447, 8.045209659081864]),
            {
              "class": 1,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85843086242676, 8.06420357088978]),
            {
              "class": 1,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84834575653076, 8.07040720573535]),
            {
              "class": 1,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86596250534058, 8.06023064515576]),
            {
              "class": 1,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.864417552948, 8.049522672491648]),
            {
              "class": 1,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87647676467896, 8.064394780234913]),
            {
              "class": 1,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8918833732605, 8.084619968853215]),
            {
              "class": 1,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87660551071167, 8.089123759441167]),
            {
              "class": 1,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88581085205078, 8.09379745119058]),
            {
              "class": 1,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86948156356812, 8.104504260060219]),
            {
              "class": 1,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86008310317993, 8.109496419926723]),
            {
              "class": 1,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86583375930786, 8.127191533946002]),
            {
              "class": 1,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86892366409302, 8.118439666222674]),
            {
              "class": 1,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85516929626465, 8.119140672364743]),
            {
              "class": 1,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8515214920044, 8.123729045984017]),
            {
              "class": 1,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8357286453247, 8.133245505509686]),
            {
              "class": 1,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.83772420883179, 8.116803980466763]),
            {
              "class": 1,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8444619178772, 8.117504989463432]),
            {
              "class": 1,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84047079086304, 8.106756050479119]),
            {
              "class": 1,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8639669418335, 8.091800527175232]),
            {
              "class": 1,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87819337844849, 8.116612795982642]),
            {
              "class": 1,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88776350021362, 8.119374340806877]),
            {
              "class": 1,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.89602470397949, 8.126957870054289]),
            {
              "class": 1,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.89091777801514, 8.111960612164852]),
            {
              "class": 1,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88203430175781, 8.108944098904935]),
            {
              "class": 1,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8851671218872, 8.105353993774465]),
            {
              "class": 1,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.9556233882904, 8.0524534110262]),
            {
              "class": 1,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.95603108406067, 8.048894672858161]),
            {
              "class": 1,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.95080614089966, 8.048873426566267]),
            {
              "class": 1,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.79543113708496, 8.137793692730082]),
            {
              "class": 1,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78877925872803, 8.152747502797592]),
            {
              "class": 1,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76989650726318, 8.156783236451663]),
            {
              "class": 1,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77852249145508, 8.171269060457046]),
            {
              "class": 1,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.80671787261963, 8.170716824603005]),
            {
              "class": 1,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.79684734344482, 8.167233473143106]),
            {
              "class": 1,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.82422733306885, 8.139323085306264]),
            {
              "class": 1,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84066390991211, 8.159204657088333]),
            {
              "class": 1,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84066390991211, 8.173860310795122]),
            {
              "class": 1,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8718204498291, 8.159884351472055]),
            {
              "class": 1,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88031768798828, 8.169697310249342]),
            {
              "class": 1,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.90576648712158, 8.183078228790754]),
            {
              "class": 1,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.91907024383545, 8.202193047025487]),
            {
              "class": 1,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.93520641326904, 8.199134737820504]),
            {
              "class": 1,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.03228092193604, 8.236614936689504]),
            {
              "class": 1,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.03681921958923, 8.240373749902348]),
            {
              "class": 1,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.01616621017456, 8.121222430595708]),
            {
              "class": 1,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.04481220245361, 8.045250917511877]),
            {
              "class": 1,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.089186668396, 7.930143694375335]),
            {
              "class": 1,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.02977573871613, 7.995796102105783]),
            {
              "class": 1,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.18139028549194, 7.91972985096411]),
            {
              "class": 1,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.17433071136475, 7.920176163941933]),
            {
              "class": 1,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60611009597778, 7.647388575402007]),
            {
              "class": 1,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6055736541748, 7.645027951455071]),
            {
              "class": 1,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61577677726746, 7.6620836973022]),
            {
              "class": 1,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62196731567383, 7.663061936342231]),
            {
              "class": 1,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63114047050476, 7.634809063935896]),
            {
              "class": 1,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6326425075531, 7.632161258209303]),
            {
              "class": 1,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62098026275635, 7.64914308474068]),
            {
              "class": 1,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59075713157654, 7.678256251850344]),
            {
              "class": 1,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53463459014893, 7.74688439169323]),
            {
              "class": 1,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54905414581299, 7.75879084970681]),
            {
              "class": 1,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54965496063232, 7.755357146830549]),
            {
              "class": 1,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45177578926086, 7.802799291266085]),
            {
              "class": 1,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4545545578003, 7.8066046349485365]),
            {
              "class": 1,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4500162601471, 7.8046275612694815]),
            {
              "class": 1,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45546650886536, 7.811239029060053]),
            {
              "class": 1,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44907212257385, 7.81776535924948]),
            {
              "class": 1,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42772173881531, 7.807784497042698]),
            {
              "class": 1,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4288911819458, 7.802948104239678]),
            {
              "class": 1,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41802287101746, 7.802374111049711]),
            {
              "class": 1,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41055560112, 7.806880999341427]),
            {
              "class": 1,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41357040405273, 7.821252930981814]),
            {
              "class": 1,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3940224647522, 7.8462304139546735]),
            {
              "class": 1,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.40118932723999, 7.8461028732211116]),
            {
              "class": 1,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.38729548454285, 7.842881216399624]),
            {
              "class": 1,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3839910030365, 7.847228241358442]),
            {
              "class": 1,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3859543800354, 7.864021962598147]),
            {
              "class": 1,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3888189792633, 7.884670290558209]),
            {
              "class": 1,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3685200214386, 7.90043043594844]),
            {
              "class": 1,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3783905506134, 7.89994159354093]),
            {
              "class": 1,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.38038611412048, 7.905822984447]),
            {
              "class": 1,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3755259513855, 7.909825839439457]),
            {
              "class": 1,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.37100911140442, 7.919292934290536]),
            {
              "class": 1,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36974310874939, 7.925488146807902]),
            {
              "class": 1,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46629190444946, 7.986999516254853]),
            {
              "class": 1,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48008918762207, 7.928167220039723]),
            {
              "class": 1,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49699783325195, 7.9166481632974826]),
            {
              "class": 1,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5033278465271, 7.919389813033837]),
            {
              "class": 1,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50309181213379, 7.911186062553216]),
            {
              "class": 1,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51053762435913, 7.913778975433202]),
            {
              "class": 1,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51455020904541, 7.909549543571225]),
            {
              "class": 1,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5193567276001, 7.911674891638678]),
            {
              "class": 1,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5111813545227, 7.907849257230843]),
            {
              "class": 1,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5228328704834, 7.899879071609664]),
            {
              "class": 1,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53208112716675, 7.893396540515076]),
            {
              "class": 1,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53735971450806, 7.901855691995367]),
            {
              "class": 1,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52889466285706, 7.901014920675984]),
            {
              "class": 1,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52621245384216, 7.9023904931880065]),
            {
              "class": 1,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5275160074234, 7.905844238173899]),
            {
              "class": 1,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52440464496613, 7.909143865995003]),
            {
              "class": 1,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52388429641724, 7.912652548070835]),
            {
              "class": 1,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53778886795044, 7.887551548249796]),
            {
              "class": 1,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53813219070435, 7.879623481285164]),
            {
              "class": 1,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53300380706787, 7.88589368085723]),
            {
              "class": 1,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54456949234009, 7.880771253733675]),
            {
              "class": 1,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54753065109253, 7.8731618881309124]),
            {
              "class": 1,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.55261611938477, 7.879262144855731]),
            {
              "class": 1,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5833649635315, 7.881939037737588]),
            {
              "class": 1,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58910489082336, 7.8890487594011]),
            {
              "class": 1,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58225989341736, 7.888230456852983]),
            {
              "class": 1,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5927312374115, 7.891312367104331]),
            {
              "class": 1,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59851408004761, 7.892098781902951]),
            {
              "class": 1,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59169054031372, 7.902736489065187]),
            {
              "class": 1,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5561888217926, 7.9817927295933275]),
            {
              "class": 1,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.585618019104, 8.018861313700587]),
            {
              "class": 1,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58733463287354, 8.014613578569099]),
            {
              "class": 1,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62257885932922, 8.01728958868177]),
            {
              "class": 1,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61188220977783, 8.016800885643901]),
            {
              "class": 1,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61247229576111, 8.024110121961284]),
            {
              "class": 1,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50521612167358, 8.037453388698554]),
            {
              "class": 1,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51087021827698, 8.0407997602094]),
            {
              "class": 1,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51339149475098, 8.03687972223954]),
            {
              "class": 1,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51592350006104, 8.047896101121879]),
            {
              "class": 1,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52223205566406, 8.053919394783051]),
            {
              "class": 1,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49348950386047, 8.03202477177495]),
            {
              "class": 1,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50509810447693, 8.02500251971942]),
            {
              "class": 1,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50206184387207, 8.033565189042918]),
            {
              "class": 1,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5206173658371, 8.007812274770764]),
            {
              "class": 1,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52251100540161, 8.00623457503433]),
            {
              "class": 1,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52918434143066, 8.023827971414885]),
            {
              "class": 1,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53050398826599, 8.025469965382102]),
            {
              "class": 1,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5473804473877, 8.016258132164984]),
            {
              "class": 1,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54658651351929, 8.023218962034994]),
            {
              "class": 1,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60980081558228, 8.185973671476114]),
            {
              "class": 1,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60776233673096, 8.191963036395164]),
            {
              "class": 1,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60576677322388, 8.196805435757529]),
            {
              "class": 1,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59345006942749, 8.196529335623977]),
            {
              "class": 1,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58072566986084, 8.201339822065247]),
            {
              "class": 1,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57554364204407, 8.208104138290004]),
            {
              "class": 1,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58080077171326, 8.209930590113654]),
            {
              "class": 1,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59380412101746, 8.210971239140381]),
            {
              "class": 1,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6152617931366, 8.19942837746682]),
            {
              "class": 1,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6246817111969, 8.190731188559338]),
            {
              "class": 1,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57830095291138, 8.14909160861959]),
            {
              "class": 1,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58254957199097, 8.152660081502487]),
            {
              "class": 1,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57139158248901, 8.161304999852979]),
            {
              "class": 1,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59003829956055, 8.159414603705397]),
            {
              "class": 1,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59349298477173, 8.154805398090648]),
            {
              "class": 1,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5940294265747, 8.172859586295978]),
            {
              "class": 1,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60405015945435, 8.152192783293527]),
            {
              "class": 1,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6162166595459, 8.146266545015939]),
            {
              "class": 1,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62048673629761, 8.136665427989529]),
            {
              "class": 1,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61398506164551, 8.130165426133484]),
            {
              "class": 1,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58533906936646, 8.132756942773655]),
            {
              "class": 1,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59160470962524, 8.141232359701972]),
            {
              "class": 1,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5693531036377, 8.146287786170069]),
            {
              "class": 1,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58882057666779, 8.121427695714324]),
            {
              "class": 1,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58060765266418, 8.054514283123634]),
            {
              "class": 1,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.56778132915497, 8.060611218370314]),
            {
              "class": 1,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53569674491882, 8.058152023841645]),
            {
              "class": 1,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60261249542236, 8.098193691552849]),
            {
              "class": 1,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6011962890625, 8.099733856737075]),
            {
              "class": 1,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63681602478027, 8.081589454281925]),
            {
              "class": 1,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72453498840332, 8.046911864092264]),
            {
              "class": 1,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75290203094482, 8.084218814370255]),
            {
              "class": 1,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.70887088775635, 8.119100666172974]),
            {
              "class": 1,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.66531181335449, 8.150028689243424]),
            {
              "class": 1,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63625812530518, 8.144845862659938]),
            {
              "class": 1,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.64080715179443, 8.15297869295644]),
            {
              "class": 1,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6170105934143, 8.151533076987905]),
            {
              "class": 1,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67599773406982, 8.196501194378815]),
            {
              "class": 1,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6578016281128, 8.206398203204156]),
            {
              "class": 1,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67007541656494, 8.208691895391727]),
            {
              "class": 1,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6755256652832, 8.180954322896165]),
            {
              "class": 1,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6491756439209, 8.190851718407451]),
            {
              "class": 1,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62267541885376, 8.22153685794328]),
            {
              "class": 1,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63462734222412, 7.538180168765504]),
            {
              "class": 1,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63655853271484, 7.5426685855359095]),
            {
              "class": 1,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.96754312515259, 7.640180307446748]),
            {
              "class": 1,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.98007440567017, 7.636883881415413]),
            {
              "class": 1,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.96250057220459, 7.6483680942656544]),
            {
              "class": 1,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.95795154571533, 7.616998449913196]),
            {
              "class": 1,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.99912881851196, 7.660256055656947]),
            {
              "class": 1,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.98876476287842, 7.633183347058246]),
            {
              "class": 1,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.98337888717651, 7.7361895592355525]),
            {
              "class": 1,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.97778916358948, 7.738485889201288]),
            {
              "class": 1,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.97744584083557, 7.740931041619969]),
            {
              "class": 1,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.97470730543137, 7.744050317657376]),
            {
              "class": 1,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.99124312400818, 7.735062651993678]),
            {
              "class": 1,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85755109786987, 7.9267858003556455]),
            {
              "class": 1,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84695100784302, 7.9322476941717275]),
            {
              "class": 1,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85059881210327, 7.923491627011042]),
            {
              "class": 1,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86442828178406, 7.922140830866444]),
            {
              "class": 1,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.82755327224731, 7.942713110144839]),
            {
              "class": 1,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.82909822463989, 7.943961032818875]),
            {
              "class": 1,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78659057617188, 7.9480191257472175]),
            {
              "class": 1,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78877925872803, 7.9646374996355895]),
            {
              "class": 1,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.80942153930664, 7.97284018249142]),
            {
              "class": 1,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.81168532371521, 7.973782098176986]),
            {
              "class": 1,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.81136345863342, 8.000120886755695]),
            {
              "class": 1,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.81433534622192, 7.990186932501023]),
            {
              "class": 1,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87568283081055, 7.936986944030122]),
            {
              "class": 1,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87287187576294, 7.938254896105004]),
            {
              "class": 1,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78710556030273, 8.104447967212817]),
            {
              "class": 1,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77714920043945, 8.125350898133085]),
            {
              "class": 1,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72603702545166, 8.14293414868494]),
            {
              "class": 1,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7024335861206, 8.151855408499255]),
            {
              "class": 1,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73427677154541, 8.202872688838472]),
            {
              "class": 1,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7564640045166, 8.185754379339786]),
            {
              "class": 1,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.79463720321655, 8.113957446519322]),
            {
              "class": 1,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77328681945801, 8.136792877952722]),
            {
              "class": 1,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.80530166625977, 8.226446324869096]),
            {
              "class": 1,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.81916332244873, 8.218843449308922]),
            {
              "class": 1,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.83341121673584, 8.230821097777566]),
            {
              "class": 1,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.83826065063477, 8.223260780229007]),
            {
              "class": 1,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7829213142395, 8.259294695873637]),
            {
              "class": 1,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7883071899414, 8.295205356845972]),
            {
              "class": 1,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.81652402877808, 8.282365973622525]),
            {
              "class": 1,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85049152374268, 8.31305833777058]),
            {
              "class": 1,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85421442985535, 8.295594453623037]),
            {
              "class": 1,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.85497617721558, 8.29766468107887]),
            {
              "class": 1,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.21173143386841, 7.6770560077285115]),
            {
              "class": 1,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.31509304046631, 7.701361598143718]),
            {
              "class": 1,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33228063583374, 7.711929736031621]),
            {
              "class": 1,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.27307891845703, 7.738978642748328]),
            {
              "class": 1,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.30483627319336, 7.751778311860482]),
            {
              "class": 1,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29745483398438, 7.794318109921648]),
            {
              "class": 1,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29865646362305, 7.781179575484188]),
            {
              "class": 1,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28915071487427, 7.779521284581327]),
            {
              "class": 1,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.25529050827026, 7.784346077570938]),
            {
              "class": 1,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.22947692871094, 7.779797666853858]),
            {
              "class": 1,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.19632482528687, 7.800780916658076]),
            {
              "class": 1,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.2572431564331, 7.874822266237047]),
            {
              "class": 1,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.2580156326294, 7.901390564796009]),
            {
              "class": 1,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28071784973145, 7.870613691257035]),
            {
              "class": 1,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.23149394989014, 7.844851180490554]),
            {
              "class": 1,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.22300744056702, 7.832114423278914]),
            {
              "class": 1,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28981590270996, 7.945677723531135]),
            {
              "class": 1,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28331422805786, 7.937208845978379]),
            {
              "class": 1,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28164052963257, 7.934435436588858]),
            {
              "class": 1,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.27739191055298, 7.939504067180834]),
            {
              "class": 1,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.27345442771912, 7.936975072729095]),
            {
              "class": 1,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.30822658538818, 8.003989386987893]),
            {
              "class": 1,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.10710382461548, 7.946082739886741]),
            {
              "class": 1,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.08878433704376, 7.945395521396458]),
            {
              "class": 1,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.63999438285828, 8.064595377745519]),
            {
              "class": 1,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.63614273071289, 8.06627376617331]),
            {
              "class": 1,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.63712978363037, 8.041172806924113]),
            {
              "class": 1,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.65165662765503, 8.05292205957297]),
            {
              "class": 1,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.92965149879456, 8.20802980058545]),
            {
              "class": 1,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.88678979873657, 8.218819723277585]),
            {
              "class": 1,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86875462532043, 8.276038223651302]),
            {
              "class": 1,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86711311340332, 8.272315303061431]),
            {
              "class": 1,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86443090438843, 8.258169227979]),
            {
              "class": 1,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86091184616089, 8.226824865833454]),
            {
              "class": 1,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.85595512390137, 8.228491955730089]),
            {
              "class": 1,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.96650505065918, 8.265178007619793]),
            {
              "class": 1,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.9888424873352, 8.28469230438039]),
            {
              "class": 1,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.99191093444824, 8.28896026432631]),
            {
              "class": 1,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.98800563812256, 8.2957124645533]),
            {
              "class": 1,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.07375049591064, 8.2971587837295]),
            {
              "class": 1,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.0895004272461, 8.284758473208692]),
            {
              "class": 1,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.09722518920898, 8.279662341852015]),
            {
              "class": 1,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.09907054901123, 8.289769604682624]),
            {
              "class": 1,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.09585189819336, 8.30480261581233]),
            {
              "class": 1,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.10155963897705, 8.326098395807811]),
            {
              "class": 1,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.09179639816284, 8.283460745141761]),
            {
              "class": 1,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.09153890609741, 8.290170572897289]),
            {
              "class": 1,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.04647779464722, 8.261461900366198]),
            {
              "class": 1,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.0332384109497, 8.261313255348043]),
            {
              "class": 1,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.04884886741638, 8.266376538060278]),
            {
              "class": 1,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.04567313194275, 8.274827871621797]),
            {
              "class": 1,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.03655362129211, 8.271791358059508]),
            {
              "class": 1,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.05757141113281, 8.287006775968448]),
            {
              "class": 1,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.38012313842773, 8.376920850026963]),
            {
              "class": 1,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.36870765686035, 8.378555459748338]),
            {
              "class": 1,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.38975763320923, 8.361253723005351]),
            {
              "class": 1,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.40125894546509, 8.353398703635438]),
            {
              "class": 1,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53830909729004, 8.487464365104833]),
            {
              "class": 1,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53024101257324, 8.486976243349439]),
            {
              "class": 1,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5378155708313, 8.492048434784408]),
            {
              "class": 1,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5353479385376, 8.48166930408304]),
            {
              "class": 1,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53337383270264, 8.481213009489727]),
            {
              "class": 1,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5501537322998, 8.463375888386269]),
            {
              "class": 1,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54764318466187, 8.449855962444175]),
            {
              "class": 1,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53431797027588, 8.444677089719304]),
            {
              "class": 1,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52506971359253, 8.443191334713312]),
            {
              "class": 1,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52264499664307, 8.44781838147076]),
            {
              "class": 1,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51895427703857, 8.438564232488947]),
            {
              "class": 1,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51195907592773, 8.431389991917648]),
            {
              "class": 1,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50745296478271, 8.423409023471786]),
            {
              "class": 1,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52743005752563, 8.409484386569698]),
            {
              "class": 1,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5189757347107, 8.40209733335131]),
            {
              "class": 1,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4891710281372, 8.378555470113893]),
            {
              "class": 1,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49123096466064, 8.389806493471196]),
            {
              "class": 1,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49404191970825, 8.365690693738472]),
            {
              "class": 1,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49361276626587, 8.347072105252469]),
            {
              "class": 1,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50670194625854, 8.357071480474142]),
            {
              "class": 1,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49146699905396, 8.334354907890486]),
            {
              "class": 1,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49517917633057, 8.33072437998605]),
            {
              "class": 1,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50605821609497, 8.34049063574509]),
            {
              "class": 1,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51927614212036, 8.337942940368402]),
            {
              "class": 1,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52307415008545, 8.359173227384865]),
            {
              "class": 1,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47578144073486, 8.393521382478982]),
            {
              "class": 1,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47453689575195, 8.402564335135388]),
            {
              "class": 1,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46213436126709, 8.380763243768921]),
            {
              "class": 1,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.41018533706665, 8.40018686565313]),
            {
              "class": 1,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50783920288086, 8.56978763101369]),
            {
              "class": 1,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58424997329712, 8.853843696860741]),
            {
              "class": 1,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58578419685364, 8.851416061420096]),
            {
              "class": 1,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57642865180969, 8.855062809051969]),
            {
              "class": 1,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5786817073822, 8.849295842691125]),
            {
              "class": 1,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58037686347961, 8.859483381968523]),
            {
              "class": 1,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5734031200409, 8.862419800301353]),
            {
              "class": 1,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5688648223877, 8.865515205051617]),
            {
              "class": 1,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57702946662903, 8.869511630823922]),
            {
              "class": 1,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58592367172241, 8.866437461012804]),
            {
              "class": 1,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58850932121277, 8.869172413349368]),
            {
              "class": 1,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59233951568604, 8.875871900430848]),
            {
              "class": 1,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60056853294373, 8.882857469494201]),
            {
              "class": 1,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61071801185608, 8.884352088383915]),
            {
              "class": 1,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60514974594116, 8.865197185217756]),
            {
              "class": 1,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60359406471252, 8.868866723456577]),
            {
              "class": 1,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60666251182556, 8.869426826484668]),
            {
              "class": 1,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59844422340393, 8.8751027577682]),
            {
              "class": 1,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57466912269592, 8.83954206325045]),
            {
              "class": 1,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57285594940186, 8.8405385939729]),
            {
              "class": 1,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57002890110016, 8.83829109533651]),
            {
              "class": 1,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5697660446167, 8.83288962156772]),
            {
              "class": 1,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57376790046692, 8.831686338418216]),
            {
              "class": 1,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57595658302307, 8.833313685178009]),
            {
              "class": 1,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5805538892746, 8.828405119042985]),
            {
              "class": 1,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57600486278534, 8.82513977321119]),
            {
              "class": 1,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58524239063263, 8.82803935933999]),
            {
              "class": 1,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59057462215424, 8.827827324563513]),
            {
              "class": 1,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5937932729721, 8.829136637361]),
            {
              "class": 1,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59849786758423, 8.830371733837298]),
            {
              "class": 1,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60334193706512, 8.831781753084414]),
            {
              "class": 1,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58639574050903, 8.838408327170505]),
            {
              "class": 1,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59209275245667, 8.84312593670727]),
            {
              "class": 1,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60046124458313, 8.842860904065514]),
            {
              "class": 1,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55464911460876, 8.869479213249521]),
            {
              "class": 1,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55617797374725, 8.871339603677736]),
            {
              "class": 1,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55641400814056, 8.868111740769843]),
            {
              "class": 1,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55383372306824, 8.86321953978172]),
            {
              "class": 1,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54788994789124, 8.86156582330653]),
            {
              "class": 1,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55180060863495, 8.853350134372697]),
            {
              "class": 1,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5583827495575, 8.839150427056824]),
            {
              "class": 1,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56613969802856, 8.82661934003188]),
            {
              "class": 1,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67686665058136, 8.809279111229822]),
            {
              "class": 1,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62471377849579, 8.721476281741143]),
            {
              "class": 1,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62398958206177, 8.724928428418426]),
            {
              "class": 1,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62019157409668, 8.712335777909939]),
            {
              "class": 1,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56521701812744, 8.722165901184855]),
            {
              "class": 1,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54210710525513, 8.690413900961143]),
            {
              "class": 1,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54370033740997, 8.692216858863427]),
            {
              "class": 1,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54167795181274, 8.692699413771823]),
            {
              "class": 1,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54463374614716, 8.693632705018382]),
            {
              "class": 1,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5445157289505, 8.699168771204574]),
            {
              "class": 1,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53966629505157, 8.700356575509451]),
            {
              "class": 1,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53735423088074, 8.70140650653428]),
            {
              "class": 1,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53833591938019, 8.70372376553279]),
            {
              "class": 1,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53914058208466, 8.70686291624174]),
            {
              "class": 1,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53975212574005, 8.707737843756274]),
            {
              "class": 1,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54233777523041, 8.70725530822859]),
            {
              "class": 1,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5441724061966, 8.706778074676956]),
            {
              "class": 1,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54423141479492, 8.713989538980323]),
            {
              "class": 1,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54605531692505, 8.71555907454555]),
            {
              "class": 1,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53224730491638, 8.732739311004975]),
            {
              "class": 1,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50771582126617, 8.704052529172634]),
            {
              "class": 1,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50519454479218, 8.701226212968383]),
            {
              "class": 1,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50730276107788, 8.695908206341356]),
            {
              "class": 1,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49829590320587, 8.685461024920508]),
            {
              "class": 1,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50208854675293, 8.677338750490733]),
            {
              "class": 1,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50168085098267, 8.660835405485598]),
            {
              "class": 1,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4992561340332, 8.652816809308447]),
            {
              "class": 1,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49724984169006, 8.646759084710059]),
            {
              "class": 1,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.502281665802, 8.6558915082443]),
            {
              "class": 1,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50820398330688, 8.663125163813298]),
            {
              "class": 1,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51284956932068, 8.665554028692405]),
            {
              "class": 1,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51590728759766, 8.671147232709064]),
            {
              "class": 1,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51603603363037, 8.676153327987754]),
            {
              "class": 1,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5214433670044, 8.685698663647942]),
            {
              "class": 1,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51492023468018, 8.683747192549063]),
            {
              "class": 1,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53909230232239, 8.681590501501512]),
            {
              "class": 1,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.44810104370117, 8.781177332329364]),
            {
              "class": 1,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45231747627258, 8.779194551268859]),
            {
              "class": 1,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.44670629501343, 8.778335696290258]),
            {
              "class": 1,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45734930038452, 8.784082564579087]),
            {
              "class": 1,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46264934539795, 8.786468230975244]),
            {
              "class": 1,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46616840362549, 8.777434426582401]),
            {
              "class": 1,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46109366416931, 8.778759822454093]),
            {
              "class": 1,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48094201087952, 8.821413831017885]),
            {
              "class": 1,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48594164848328, 8.823873469681029]),
            {
              "class": 1,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47612476348877, 8.821890917384513]),
            {
              "class": 1,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47876405715942, 8.825972631093649]),
            {
              "class": 1,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47246354818344, 8.81483435321102]),
            {
              "class": 1,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47618913650513, 8.819134409868575]),
            {
              "class": 1,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46517062187195, 8.803670465573584]),
            {
              "class": 1,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46349692344666, 8.808377916813035]),
            {
              "class": 1,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45570778846741, 8.80323576547812]),
            {
              "class": 1,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46228188276291, 8.804144616211795]),
            {
              "class": 1,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.39289045333862, 8.590336804347285]),
            {
              "class": 1,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.39868402481079, 8.592437276688212]),
            {
              "class": 1,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.40508913993835, 8.597932396757903]),
            {
              "class": 1,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.34210550785065, 8.518218241460403]),
            {
              "class": 1,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.36530661582947, 8.54959807916069]),
            {
              "class": 1,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.36140131950378, 8.551677557500975]),
            {
              "class": 1,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.35801100730896, 8.54606506188618]),
            {
              "class": 1,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.37260222434998, 8.54682896028755]),
            {
              "class": 1,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.37275242805481, 8.551115250701825]),
            {
              "class": 1,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.40016460418701, 8.56818566632702]),
            {
              "class": 1,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4597579240799, 8.733502217743238]),
            {
              "class": 1,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45639979839325, 8.732394052313118]),
            {
              "class": 1,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45327234268188, 8.548293094611804]),
            {
              "class": 1,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.27102160453796, 8.475298286358877]),
            {
              "class": 1,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.27392911911011, 8.436476005204335]),
            {
              "class": 1,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.2832202911377, 8.435457180749584]),
            {
              "class": 1,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.44846856594086, 8.071954214664602]),
            {
              "class": 1,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.46228194236755, 8.102597663508622]),
            {
              "class": 1,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.46419167518616, 8.09919869460686]),
            {
              "class": 1,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29024505615234, 7.985728261208513]),
            {
              "class": 1,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28681182861328, 7.9542698654695245]),
            {
              "class": 1,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29372119903564, 7.957978187334781]),
            {
              "class": 1,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.1473798751831, 8.038651888458007]),
            {
              "class": 1,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.14896774291992, 8.033637606043705]),
            {
              "class": 1,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.17059171199799, 8.037950034144483]),
            {
              "class": 1,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.16871416568756, 8.04383537301574]),
            {
              "class": 1,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.979323387146, 8.145169439946775]),
            {
              "class": 1,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.95194339752197, 8.174693635804173]),
            {
              "class": 1,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.00584506988525, 8.248054259580066]),
            {
              "class": 1,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.98552465438843, 8.230810479455203]),
            {
              "class": 1,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.01259350776672, 8.306642087676032]),
            {
              "class": 1,
              "system:index": "780"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.01117730140686, 8.302936988344923]),
            {
              "class": 1,
              "system:index": "781"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.08440160751343, 8.26163709943436]),
            {
              "class": 1,
              "system:index": "782"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4559063911438, 8.309909058107145]),
            {
              "class": 1,
              "system:index": "783"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.457022190094, 8.324941297711774]),
            {
              "class": 1,
              "system:index": "784"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47938108444214, 8.326937060161596]),
            {
              "class": 1,
              "system:index": "785"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49017429351807, 8.324622824039198]),
            {
              "class": 1,
              "system:index": "786"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50970077514648, 8.321204523645244]),
            {
              "class": 1,
              "system:index": "787"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51019430160522, 8.327913706163336]),
            {
              "class": 1,
              "system:index": "788"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53008556365967, 8.328295871326764]),
            {
              "class": 1,
              "system:index": "789"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53547143936157, 8.314962332922724]),
            {
              "class": 1,
              "system:index": "790"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52287578582764, 8.299972176630956]),
            {
              "class": 1,
              "system:index": "791"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53223133087158, 8.29026861170973]),
            {
              "class": 1,
              "system:index": "792"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51967859268188, 8.277910552198271]),
            {
              "class": 1,
              "system:index": "793"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51098823547363, 8.277358464884585]),
            {
              "class": 1,
              "system:index": "794"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.56967496871948, 8.331331947976981]),
            {
              "class": 1,
              "system:index": "795"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.56484699249268, 8.323667401467409]),
            {
              "class": 1,
              "system:index": "796"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53216695785522, 8.371923936884489]),
            {
              "class": 1,
              "system:index": "797"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5346131324768, 8.383536034739036]),
            {
              "class": 1,
              "system:index": "798"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5428957939148, 8.412978683264166]),
            {
              "class": 1,
              "system:index": "799"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53377628326416, 8.42450464824457]),
            {
              "class": 1,
              "system:index": "800"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52869081497192, 8.430002179120283]),
            {
              "class": 1,
              "system:index": "801"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5173397064209, 8.425841892676896]),
            {
              "class": 1,
              "system:index": "802"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52590131759644, 8.412278199195784]),
            {
              "class": 1,
              "system:index": "803"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52290260791779, 8.434347082509209]),
            {
              "class": 1,
              "system:index": "804"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53126573562622, 8.439978193771973]),
            {
              "class": 1,
              "system:index": "805"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52506446838379, 8.459441292901502]),
            {
              "class": 1,
              "system:index": "806"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53463459014893, 8.463749785048918]),
            {
              "class": 1,
              "system:index": "807"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5110365152359, 8.467351476659811]),
            {
              "class": 1,
              "system:index": "808"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51239371299744, 8.465664182296342]),
            {
              "class": 1,
              "system:index": "809"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52170634269714, 8.480563054046167]),
            {
              "class": 1,
              "system:index": "810"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71046948432922, 8.283497914681183]),
            {
              "class": 1,
              "system:index": "811"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.70846319198608, 8.278943235827468]),
            {
              "class": 1,
              "system:index": "812"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7152009010315, 8.267699642257618]),
            {
              "class": 1,
              "system:index": "813"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72149872779846, 8.262985518942399]),
            {
              "class": 1,
              "system:index": "814"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71847319602966, 8.262284766072415]),
            {
              "class": 1,
              "system:index": "815"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73652982711792, 8.268931250776244]),
            {
              "class": 1,
              "system:index": "816"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73941588401794, 8.255606316437316]),
            {
              "class": 1,
              "system:index": "817"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7600474357605, 8.260501025878613]),
            {
              "class": 1,
              "system:index": "818"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7809042930603, 8.295038321777266]),
            {
              "class": 1,
              "system:index": "819"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73325753211975, 8.336302852684879]),
            {
              "class": 1,
              "system:index": "820"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7365083694458, 8.341536247582667]),
            {
              "class": 1,
              "system:index": "821"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71948170661926, 8.354263826148317]),
            {
              "class": 1,
              "system:index": "822"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44004917144775, 8.415690041341934]),
            {
              "class": 1,
              "system:index": "823"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45541286468506, 8.416865992351934]),
            {
              "class": 1,
              "system:index": "824"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45560598373413, 8.423552300287831]),
            {
              "class": 1,
              "system:index": "825"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46194672584534, 8.421567646335973]),
            {
              "class": 1,
              "system:index": "826"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47369480133057, 8.424465025425844]),
            {
              "class": 1,
              "system:index": "827"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47030448913574, 8.443865231442654]),
            {
              "class": 1,
              "system:index": "828"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49383282661438, 8.449160851394637]),
            {
              "class": 1,
              "system:index": "829"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44060707092285, 8.425199451278862]),
            {
              "class": 1,
              "system:index": "830"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45082092285156, 8.412590942106185]),
            {
              "class": 1,
              "system:index": "831"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44914722442627, 8.395863869150968]),
            {
              "class": 1,
              "system:index": "832"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44532775878906, 8.382829837998138]),
            {
              "class": 1,
              "system:index": "833"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44249534606934, 8.376121599498164]),
            {
              "class": 1,
              "system:index": "834"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4355001449585, 8.33459588240708]),
            {
              "class": 1,
              "system:index": "835"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44588565826416, 8.321007777223194]),
            {
              "class": 1,
              "system:index": "836"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.43944835662842, 8.314086154907088]),
            {
              "class": 1,
              "system:index": "837"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42086601257324, 8.333916488353694]),
            {
              "class": 1,
              "system:index": "838"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41141390800476, 8.370812241863314]),
            {
              "class": 1,
              "system:index": "839"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.40519118309021, 8.363583674599347]),
            {
              "class": 1,
              "system:index": "840"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41216492652893, 8.373264192355704]),
            {
              "class": 1,
              "system:index": "841"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42579054832458, 8.393027834986208]),
            {
              "class": 1,
              "system:index": "842"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41483640670776, 8.399268776440424]),
            {
              "class": 1,
              "system:index": "843"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41083455085754, 8.405785570761452]),
            {
              "class": 1,
              "system:index": "844"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4003095626831, 8.407462513148163]),
            {
              "class": 1,
              "system:index": "845"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4080879688263, 8.417799959764942]),
            {
              "class": 1,
              "system:index": "846"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41099548339844, 8.448364910809888]),
            {
              "class": 1,
              "system:index": "847"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.40805578231812, 8.465235440092723]),
            {
              "class": 1,
              "system:index": "848"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.37325143814087, 8.443883606470783]),
            {
              "class": 1,
              "system:index": "849"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34821033477783, 8.449168613778953]),
            {
              "class": 1,
              "system:index": "850"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58345079421997, 8.35443081522194]),
            {
              "class": 1,
              "system:index": "851"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57621955871582, 8.33833816804445]),
            {
              "class": 1,
              "system:index": "852"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.56973934173584, 8.359823189743244]),
            {
              "class": 1,
              "system:index": "853"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5014181137085, 8.392197097033657]),
            {
              "class": 1,
              "system:index": "854"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48989534378052, 8.372836762720365]),
            {
              "class": 1,
              "system:index": "855"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4963755607605, 8.370713860427541]),
            {
              "class": 1,
              "system:index": "856"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4897665977478, 8.364981966432662]),
            {
              "class": 1,
              "system:index": "857"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4888653755188, 8.357169471441372]),
            {
              "class": 1,
              "system:index": "858"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49292087554932, 8.348571300148691]),
            {
              "class": 1,
              "system:index": "859"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49540996551514, 8.33545076279836]),
            {
              "class": 1,
              "system:index": "860"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.37876605987549, 8.410086131094495]),
            {
              "class": 1,
              "system:index": "861"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32321214675903, 8.364536169652325]),
            {
              "class": 1,
              "system:index": "862"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32065868377686, 8.358591887428993]),
            {
              "class": 1,
              "system:index": "863"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3486180305481, 8.36663785558343]),
            {
              "class": 1,
              "system:index": "864"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.35357475280762, 8.359971797434167]),
            {
              "class": 1,
              "system:index": "865"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.35505533218384, 8.349972517270853]),
            {
              "class": 1,
              "system:index": "866"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34170866012573, 8.37292167857129]),
            {
              "class": 1,
              "system:index": "867"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.31595945358276, 8.41845513067358]),
            {
              "class": 1,
              "system:index": "868"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.29061794281006, 8.433101118180081]),
            {
              "class": 1,
              "system:index": "869"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.29173374176025, 8.436709464702115]),
            {
              "class": 1,
              "system:index": "870"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.24330377578735, 8.354770494557165]),
            {
              "class": 1,
              "system:index": "871"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22768259048462, 8.353963755653126]),
            {
              "class": 1,
              "system:index": "872"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.23144841194153, 8.358785774626746]),
            {
              "class": 1,
              "system:index": "873"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.24897933006287, 8.355070554065703]),
            {
              "class": 1,
              "system:index": "874"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.256028175354, 8.34422190759007]),
            {
              "class": 1,
              "system:index": "875"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.26765823364258, 8.32784431013795]),
            {
              "class": 1,
              "system:index": "876"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.29186248779297, 8.326570423339248]),
            {
              "class": 1,
              "system:index": "877"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.28632640838623, 8.342382664086543]),
            {
              "class": 1,
              "system:index": "878"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.30924320220947, 8.352912911044116]),
            {
              "class": 1,
              "system:index": "879"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.28229236602783, 8.387134249431455]),
            {
              "class": 1,
              "system:index": "880"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18998146057129, 8.450089444940343]),
            {
              "class": 1,
              "system:index": "881"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18835067749023, 8.452827425764104]),
            {
              "class": 1,
              "system:index": "882"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18120527267456, 8.45138415147375]),
            {
              "class": 1,
              "system:index": "883"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.55764532089233, 9.566500713963757]),
            {
              "class": 1,
              "system:index": "884"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.5589542388916, 9.564749780003927]),
            {
              "class": 1,
              "system:index": "885"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.60470199584961, 9.55396066146768]),
            {
              "class": 1,
              "system:index": "886"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.61778312921524, 9.56203312414495]),
            {
              "class": 1,
              "system:index": "887"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.80640411376953, 8.940868773252129]),
            {
              "class": 1,
              "system:index": "888"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.80191946029663, 8.941737846981942]),
            {
              "class": 1,
              "system:index": "889"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.78935616090894, 8.93317295872703]),
            {
              "class": 1,
              "system:index": "890"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.78693144395947, 8.935557657668195]),
            {
              "class": 1,
              "system:index": "891"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.7886049747467, 8.971146107864547]),
            {
              "class": 1,
              "system:index": "892"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.84155178070068, 8.997926471025497]),
            {
              "class": 1,
              "system:index": "893"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.85993027687073, 9.002693760958852]),
            {
              "class": 1,
              "system:index": "894"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.85599279403687, 8.981691798699247]),
            {
              "class": 1,
              "system:index": "895"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.86459732055664, 8.976287144575512]),
            {
              "class": 1,
              "system:index": "896"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.8710560798645, 8.980038618931054]),
            {
              "class": 1,
              "system:index": "897"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88178491592407, 8.977283302567091]),
            {
              "class": 1,
              "system:index": "898"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88339424133301, 8.983938415530131]),
            {
              "class": 1,
              "system:index": "899"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88669872283936, 8.988558772404561]),
            {
              "class": 1,
              "system:index": "900"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88637685775757, 8.968402563550963]),
            {
              "class": 1,
              "system:index": "901"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89285707473755, 8.954222603982073]),
            {
              "class": 1,
              "system:index": "902"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88942384719849, 8.951891018059722]),
            {
              "class": 1,
              "system:index": "903"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89377975463867, 8.950013898376795]),
            {
              "class": 1,
              "system:index": "904"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88569021224976, 8.950119880426252]),
            {
              "class": 1,
              "system:index": "905"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88398432731628, 8.940708554116876]),
            {
              "class": 1,
              "system:index": "906"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88869428634644, 8.944640568013458]),
            {
              "class": 1,
              "system:index": "907"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88295435905457, 8.945965360974716]),
            {
              "class": 1,
              "system:index": "908"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89693403244019, 8.944047059202974]),
            {
              "class": 1,
              "system:index": "909"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89871501922607, 8.944025862441844]),
            {
              "class": 1,
              "system:index": "910"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89683747291565, 8.930279503062966]),
            {
              "class": 1,
              "system:index": "911"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88056182861328, 8.916956592378734]),
            {
              "class": 1,
              "system:index": "912"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88685965538025, 8.902626236578877]),
            {
              "class": 1,
              "system:index": "913"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.90275979042053, 8.906145281317318]),
            {
              "class": 1,
              "system:index": "914"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.90459442138672, 8.90201146022852]),
            {
              "class": 1,
              "system:index": "915"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.90431547164917, 8.899054159553627]),
            {
              "class": 1,
              "system:index": "916"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.90913271903992, 8.89879976698121]),
            {
              "class": 1,
              "system:index": "917"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.91952896118164, 8.881871664051678]),
            {
              "class": 1,
              "system:index": "918"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.9171793460846, 8.871027515435639]),
            {
              "class": 1,
              "system:index": "919"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89474534988403, 8.640300659429604]),
            {
              "class": 1,
              "system:index": "920"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.90111827850342, 8.641891717177225]),
            {
              "class": 1,
              "system:index": "921"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.95969772338867, 8.547328843142601]),
            {
              "class": 1,
              "system:index": "922"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.85744118690491, 8.691867487251281]),
            {
              "class": 1,
              "system:index": "923"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.86363172531128, 8.696396059241119]),
            {
              "class": 1,
              "system:index": "924"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.83191728591919, 9.003648701557767]),
            {
              "class": 1,
              "system:index": "925"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.3319320678711, 9.052434815640147]),
            {
              "class": 1,
              "system:index": "926"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.35652256011963, 9.06099564006107]),
            {
              "class": 1,
              "system:index": "927"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.36768054962158, 9.054638611709839]),
            {
              "class": 1,
              "system:index": "928"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.38471794128418, 9.057096676005017]),
            {
              "class": 1,
              "system:index": "929"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.33594465255737, 9.059806520104548]),
            {
              "class": 1,
              "system:index": "930"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.34982776641846, 9.051407037813755]),
            {
              "class": 1,
              "system:index": "931"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.91211533546448, 8.599292904045631]),
            {
              "class": 1,
              "system:index": "932"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.9105703830719, 8.598921615991722]),
            {
              "class": 1,
              "system:index": "933"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.9128395318985, 8.597112907554834]),
            {
              "class": 1,
              "system:index": "934"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.87137794494629, 8.569982292519768]),
            {
              "class": 1,
              "system:index": "935"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.86356735229492, 8.5674573316201]),
            {
              "class": 1,
              "system:index": "936"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.86691474914551, 8.568772859559068]),
            {
              "class": 1,
              "system:index": "937"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.86877083778381, 8.598023799778584]),
            {
              "class": 1,
              "system:index": "938"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89108681678772, 8.63591460881203]),
            {
              "class": 1,
              "system:index": "939"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89179491996765, 8.636116145508527]),
            {
              "class": 1,
              "system:index": "940"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89354372024536, 8.637261720474697]),
            {
              "class": 1,
              "system:index": "941"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.9211597442627, 8.630939800443398]),
            {
              "class": 1,
              "system:index": "942"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92407262325287, 8.571439986900817]),
            {
              "class": 1,
              "system:index": "943"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94368493556976, 8.59876983739149]),
            {
              "class": 1,
              "system:index": "944"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94603991508484, 8.57706537973739]),
            {
              "class": 1,
              "system:index": "945"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.95081961154938, 8.569718060921202]),
            {
              "class": 1,
              "system:index": "946"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94570732116699, 8.53746049467229]),
            {
              "class": 1,
              "system:index": "947"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.08836328983307, 8.458667582327712]),
            {
              "class": 1,
              "system:index": "948"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.07692098617554, 8.44878287801749]),
            {
              "class": 1,
              "system:index": "949"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.12509346008301, 8.399656188876857]),
            {
              "class": 1,
              "system:index": "950"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.12498617172241, 8.38891492518806]),
            {
              "class": 1,
              "system:index": "951"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.1207160949707, 8.398764632845637]),
            {
              "class": 1,
              "system:index": "952"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18549680709839, 8.366624773854523]),
            {
              "class": 1,
              "system:index": "953"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18096923828125, 8.372314185687987]),
            {
              "class": 1,
              "system:index": "954"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18011093139648, 8.357963121695974]),
            {
              "class": 1,
              "system:index": "955"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.19503474235535, 8.377344201501721]),
            {
              "class": 1,
              "system:index": "956"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18978834152222, 8.3748404484539]),
            {
              "class": 1,
              "system:index": "957"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.20922899246216, 8.361550937239935]),
            {
              "class": 1,
              "system:index": "958"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21804809570312, 8.364883967063271]),
            {
              "class": 1,
              "system:index": "959"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2211594581604, 8.352464571101658]),
            {
              "class": 1,
              "system:index": "960"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22600889205933, 8.362739791912118]),
            {
              "class": 1,
              "system:index": "961"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22974252700806, 8.338494932075864]),
            {
              "class": 1,
              "system:index": "962"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21661043167114, 8.342507539106848]),
            {
              "class": 1,
              "system:index": "963"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22332668304443, 8.326138391486028]),
            {
              "class": 1,
              "system:index": "964"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2412223815918, 8.326074696966984]),
            {
              "class": 1,
              "system:index": "965"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.24512767791748, 8.336711537950903]),
            {
              "class": 1,
              "system:index": "966"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.25062084197998, 8.341063854549658]),
            {
              "class": 1,
              "system:index": "967"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.25628566741943, 8.342019234632989]),
            {
              "class": 1,
              "system:index": "968"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53607749938965, 9.43417018738225]),
            {
              "class": 1,
              "system:index": "969"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5633716583252, 9.430698708417752]),
            {
              "class": 1,
              "system:index": "970"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49299049377441, 9.475909864932854]),
            {
              "class": 1,
              "system:index": "971"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52775192260742, 9.477095096179488]),
            {
              "class": 1,
              "system:index": "972"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49659538269043, 9.466935838452025]),
            {
              "class": 1,
              "system:index": "973"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52440452575684, 9.462618062939443]),
            {
              "class": 1,
              "system:index": "974"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54551887512207, 9.432646127749514]),
            {
              "class": 1,
              "system:index": "975"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55307197570801, 9.450087740761399]),
            {
              "class": 1,
              "system:index": "976"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49994277954102, 9.448817750208324]),
            {
              "class": 1,
              "system:index": "977"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48964309692383, 9.407836794687508]),
            {
              "class": 1,
              "system:index": "978"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46672630310059, 9.424602285449302]),
            {
              "class": 1,
              "system:index": "979"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47917175292969, 9.444076328072024]),
            {
              "class": 1,
              "system:index": "980"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50406265258789, 9.430021259908356]),
            {
              "class": 1,
              "system:index": "981"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54036903381348, 9.410715775190388]),
            {
              "class": 1,
              "system:index": "982"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56199836730957, 9.420368652455709]),
            {
              "class": 1,
              "system:index": "983"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56148338317871, 9.41664301248642]),
            {
              "class": 1,
              "system:index": "984"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52749443054199, 9.447293672678468]),
            {
              "class": 1,
              "system:index": "985"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49144554138184, 9.447717005257333]),
            {
              "class": 1,
              "system:index": "986"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4824333190918, 9.414272129767493]),
            {
              "class": 1,
              "system:index": "987"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47496604919434, 9.475994524443337]),
            {
              "class": 1,
              "system:index": "988"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47299194335938, 9.470745595317895]),
            {
              "class": 1,
              "system:index": "989"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49060869216919, 9.48790270165715]),
            {
              "class": 1,
              "system:index": "990"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48395681381226, 9.479288788359565]),
            {
              "class": 1,
              "system:index": "991"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48372077941895, 9.468370082934033]),
            {
              "class": 1,
              "system:index": "992"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4717903137207, 9.46172410036143]),
            {
              "class": 1,
              "system:index": "993"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47067451477051, 9.429000288828068]),
            {
              "class": 1,
              "system:index": "994"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50114440917969, 9.408890326050225]),
            {
              "class": 1,
              "system:index": "995"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.64791488647461, 9.535870344249217]),
            {
              "class": 1,
              "system:index": "996"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63898849487305, 9.507089937737017]),
            {
              "class": 1,
              "system:index": "997"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65546798706055, 9.491005714344247]),
            {
              "class": 1,
              "system:index": "998"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67744064331055, 9.535193186082402]),
            {
              "class": 1,
              "system:index": "999"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62645721435547, 9.527067183250468]),
            {
              "class": 1,
              "system:index": "1000"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57124662399292, 9.536885707006025]),
            {
              "class": 1,
              "system:index": "1001"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59223222732544, 9.538620117901349]),
            {
              "class": 1,
              "system:index": "1002"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58879899978638, 9.53786361127358]),
            {
              "class": 1,
              "system:index": "1003"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58812308311462, 9.535387759667314]),
            {
              "class": 1,
              "system:index": "1004"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5848400592804, 9.542000571064584]),
            {
              "class": 1,
              "system:index": "1005"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58317172527313, 9.543836264762]),
            {
              "class": 1,
              "system:index": "1006"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57416486740112, 9.542729119383512]),
            {
              "class": 1,
              "system:index": "1007"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58045196533203, 9.540877549077818]),
            {
              "class": 1,
              "system:index": "1008"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57841348648071, 9.530519150318748]),
            {
              "class": 1,
              "system:index": "1009"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57827401161194, 9.537777468851857]),
            {
              "class": 1,
              "system:index": "1010"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59912010007568, 9.525833436350899]),
            {
              "class": 1,
              "system:index": "1011"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60169506072998, 9.518511377104167]),
            {
              "class": 1,
              "system:index": "1012"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59594440460205, 9.517326289176165]),
            {
              "class": 1,
              "system:index": "1013"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59830474853516, 9.508437998758808]),
            {
              "class": 1,
              "system:index": "1014"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59469985961914, 9.505602162256718]),
            {
              "class": 1,
              "system:index": "1015"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59100914001465, 9.504374703348141]),
            {
              "class": 1,
              "system:index": "1016"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60414123535156, 9.49531676705007]),
            {
              "class": 1,
              "system:index": "1017"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61967658996582, 9.494258581292701]),
            {
              "class": 1,
              "system:index": "1018"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62478351593018, 9.49366599584089]),
            {
              "class": 1,
              "system:index": "1019"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62847423553467, 9.493496685523553]),
            {
              "class": 1,
              "system:index": "1020"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.629075050354, 9.490237445609441]),
            {
              "class": 1,
              "system:index": "1021"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61967658996582, 9.490449085505944]),
            {
              "class": 1,
              "system:index": "1022"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65718460083008, 9.524866357523708]),
            {
              "class": 1,
              "system:index": "1023"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75872230529785, 9.570596867398793]),
            {
              "class": 1,
              "system:index": "1024"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75065422058105, 9.575590357839914]),
            {
              "class": 1,
              "system:index": "1025"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74816513061523, 9.564587654502402]),
            {
              "class": 1,
              "system:index": "1026"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7255916595459, 9.540972958922943]),
            {
              "class": 1,
              "system:index": "1027"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72550582885742, 9.547151872583585]),
            {
              "class": 1,
              "system:index": "1028"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7149486541748, 9.539534017743188]),
            {
              "class": 1,
              "system:index": "1029"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.70413398742676, 9.522943433951538]),
            {
              "class": 1,
              "system:index": "1030"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68585205078125, 9.522858786048285]),
            {
              "class": 1,
              "system:index": "1031"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.70001411437988, 9.555337694285228]),
            {
              "class": 1,
              "system:index": "1032"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.70587205886841, 9.551444238886985]),
            {
              "class": 1,
              "system:index": "1033"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73711442947388, 9.581638510758435]),
            {
              "class": 1,
              "system:index": "1034"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75503158569336, 9.58737236849262]),
            {
              "class": 1,
              "system:index": "1035"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75719881057739, 9.588345633616601]),
            {
              "class": 1,
              "system:index": "1036"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78039455413818, 9.606773669765252]),
            {
              "class": 1,
              "system:index": "1037"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77360051870346, 9.603335632895083]),
            {
              "class": 1,
              "system:index": "1038"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77156472206116, 9.603425550011204]),
            {
              "class": 1,
              "system:index": "1039"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77106046676636, 9.601381649759743]),
            {
              "class": 1,
              "system:index": "1040"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.76785254478455, 9.59702326048721]),
            {
              "class": 1,
              "system:index": "1041"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77926802635193, 9.604237845321435]),
            {
              "class": 1,
              "system:index": "1042"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78167128562927, 9.601371071212888]),
            {
              "class": 1,
              "system:index": "1043"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78480410575867, 9.602926114054645]),
            {
              "class": 1,
              "system:index": "1044"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78658509254456, 9.604936022794542]),
            {
              "class": 1,
              "system:index": "1045"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7916169166565, 9.610457921168837]),
            {
              "class": 1,
              "system:index": "1046"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.79276490211487, 9.610235777571221]),
            {
              "class": 1,
              "system:index": "1047"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78948187828064, 9.608098960279952]),
            {
              "class": 1,
              "system:index": "1048"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82579898834229, 9.618932594611046]),
            {
              "class": 1,
              "system:index": "1049"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.84219264984131, 9.620794317138206]),
            {
              "class": 1,
              "system:index": "1050"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.83429622650146, 9.61711317405407]),
            {
              "class": 1,
              "system:index": "1051"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81192660331726, 9.60094792906785]),
            {
              "class": 1,
              "system:index": "1052"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81188368797302, 9.59830327868596]),
            {
              "class": 1,
              "system:index": "1053"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82182931900024, 9.598906260790002]),
            {
              "class": 1,
              "system:index": "1054"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8234601020813, 9.600302636278931]),
            {
              "class": 1,
              "system:index": "1055"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82852411270142, 9.603592558800983]),
            {
              "class": 1,
              "system:index": "1056"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82519817352295, 9.6052851109912]),
            {
              "class": 1,
              "system:index": "1057"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82294511795044, 9.608902912923181]),
            {
              "class": 1,
              "system:index": "1058"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8290605545044, 9.619651897711986]),
            {
              "class": 1,
              "system:index": "1059"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82567024230957, 9.622782963965383]),
            {
              "class": 1,
              "system:index": "1060"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85512089729309, 9.60666030341545]),
            {
              "class": 1,
              "system:index": "1061"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85688042640686, 9.604385943693613]),
            {
              "class": 1,
              "system:index": "1062"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85447716712952, 9.610955099168358]),
            {
              "class": 1,
              "system:index": "1063"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.87528038024902, 9.588348629609294]),
            {
              "class": 1,
              "system:index": "1064"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8727376461029, 9.58826399797099]),
            {
              "class": 1,
              "system:index": "1065"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.86961555480957, 9.591342460226164]),
            {
              "class": 1,
              "system:index": "1066"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72756576538086, 9.576097980350234]),
            {
              "class": 1,
              "system:index": "1067"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73460388183594, 9.57106217940475]),
            {
              "class": 1,
              "system:index": "1068"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73821145296097, 9.573807148767523]),
            {
              "class": 1,
              "system:index": "1069"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7388846874237, 9.587322469570667]),
            {
              "class": 1,
              "system:index": "1070"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74052619934082, 9.594315106874731]),
            {
              "class": 1,
              "system:index": "1071"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75333642959595, 9.594463209584765]),
            {
              "class": 1,
              "system:index": "1072"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75346517562866, 9.59913899043786]),
            {
              "class": 1,
              "system:index": "1073"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74925947189331, 9.601381649759743]),
            {
              "class": 1,
              "system:index": "1074"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77069568634033, 9.596007705418533]),
            {
              "class": 1,
              "system:index": "1075"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7679705619812, 9.598387907817933]),
            {
              "class": 1,
              "system:index": "1076"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77272343635559, 9.58994604782098]),
            {
              "class": 1,
              "system:index": "1077"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80880451202393, 9.611187820534152]),
            {
              "class": 1,
              "system:index": "1078"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80685186386108, 9.614879606242098]),
            {
              "class": 1,
              "system:index": "1079"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80571460723877, 9.601318178473667]),
            {
              "class": 1,
              "system:index": "1080"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81788110733032, 9.613462134546115]),
            {
              "class": 1,
              "system:index": "1081"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81924366950989, 9.618000138666629]),
            {
              "class": 1,
              "system:index": "1082"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82313823699951, 9.61596915134349]),
            {
              "class": 1,
              "system:index": "1083"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8254771232605, 9.607485416188485]),
            {
              "class": 1,
              "system:index": "1084"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66686201095581, 9.490793702768697]),
            {
              "class": 1,
              "system:index": "1085"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65288770198822, 9.482501824727994]),
            {
              "class": 1,
              "system:index": "1086"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65219569206238, 9.484835200011654]),
            {
              "class": 1,
              "system:index": "1087"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.64553308486938, 9.47468754958581]),
            {
              "class": 1,
              "system:index": "1088"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65491008758545, 9.457916909913184]),
            {
              "class": 1,
              "system:index": "1089"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66013503074646, 9.453831849864331]),
            {
              "class": 1,
              "system:index": "1090"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50901937484741, 9.484042332461675]),
            {
              "class": 1,
              "system:index": "1091"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59130954742432, 9.526682552283285]),
            {
              "class": 1,
              "system:index": "1092"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58760809898376, 9.522809931633644]),
            {
              "class": 1,
              "system:index": "1093"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57863879203796, 9.519212375841281]),
            {
              "class": 1,
              "system:index": "1094"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56398320198059, 9.532618369153841]),
            {
              "class": 1,
              "system:index": "1095"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60753154754639, 9.507244319803016]),
            {
              "class": 1,
              "system:index": "1096"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60628700256348, 9.513947616977843]),
            {
              "class": 1,
              "system:index": "1097"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61761665344238, 9.523823803967122]),
            {
              "class": 1,
              "system:index": "1098"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.1863603591919, 8.94472908089349]),
            {
              "class": 1,
              "system:index": "1099"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.18996524810791, 8.932561959914446]),
            {
              "class": 1,
              "system:index": "1100"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19361305236816, 8.965543665156218]),
            {
              "class": 1,
              "system:index": "1101"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.17052459716797, 8.871399774902128]),
            {
              "class": 1,
              "system:index": "1102"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.8983770608902, 9.076014619317757]),
            {
              "class": 1,
              "system:index": "1103"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92515087127686, 9.056647947672598]),
            {
              "class": 1,
              "system:index": "1104"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92471098899841, 9.050979534266395]),
            {
              "class": 1,
              "system:index": "1105"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92855191230774, 9.051805962719524]),
            {
              "class": 1,
              "system:index": "1106"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92579460144043, 9.054931540335838]),
            {
              "class": 1,
              "system:index": "1107"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93346035480499, 9.039327138012304]),
            {
              "class": 1,
              "system:index": "1108"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93659317493439, 9.040450268989886]),
            {
              "class": 1,
              "system:index": "1109"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93680775165558, 9.042463419522392]),
            {
              "class": 1,
              "system:index": "1110"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93287563323975, 9.043088553449994]),
            {
              "class": 1,
              "system:index": "1111"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.9277526140213, 9.041361485888388]),
            {
              "class": 1,
              "system:index": "1112"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92907226085663, 9.043851427280789]),
            {
              "class": 1,
              "system:index": "1113"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93797183036804, 9.062758526330528]),
            {
              "class": 1,
              "system:index": "1114"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94051456451416, 9.061990395147014]),
            {
              "class": 1,
              "system:index": "1115"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92701768875122, 9.018785497644703]),
            {
              "class": 1,
              "system:index": "1116"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92696404457092, 9.02146632513371]),
            {
              "class": 1,
              "system:index": "1117"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93017196655273, 9.025524615018487]),
            {
              "class": 1,
              "system:index": "1118"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92444276809692, 9.01369928801211]),
            {
              "class": 1,
              "system:index": "1119"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.9431163072586, 9.014172325499985]),
            {
              "class": 1,
              "system:index": "1120"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93203341960907, 8.953614528062806]),
            {
              "class": 1,
              "system:index": "1121"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.92311239242554, 8.959767470890304]),
            {
              "class": 1,
              "system:index": "1122"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94836807250977, 8.98848670396613]),
            {
              "class": 1,
              "system:index": "1123"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94757413864136, 8.992153276237703]),
            {
              "class": 1,
              "system:index": "1124"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.95014905929565, 8.993340135608662]),
            {
              "class": 1,
              "system:index": "1125"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94345426559448, 8.986176532434389]),
            {
              "class": 1,
              "system:index": "1126"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.95376205444336, 9.215673878862473]),
            {
              "class": 1,
              "system:index": "1127"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.85625839233398, 9.221350262713555]),
            {
              "class": 1,
              "system:index": "1128"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.46044731140137, 8.097445911120934]),
            {
              "class": 1,
              "system:index": "1129"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.20870316028595, 8.533115068571378]),
            {
              "class": 1,
              "system:index": "1130"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.21046268939972, 8.529316644360414]),
            {
              "class": 1,
              "system:index": "1131"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.21510291099548, 8.527693283945665]),
            {
              "class": 1,
              "system:index": "1132"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.24661350250244, 8.468670001854903]),
            {
              "class": 1,
              "system:index": "1133"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8719732761383, 8.26775679854189]),
            {
              "class": 1,
              "system:index": "1134"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.87801361083984, 8.249303447445815]),
            {
              "class": 1,
              "system:index": "1135"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.88775539398193, 8.237262649521755]),
            {
              "class": 1,
              "system:index": "1136"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.88219785690308, 8.226708068278489]),
            {
              "class": 1,
              "system:index": "1137"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.81237459182739, 8.2561743606673]),
            {
              "class": 1,
              "system:index": "1138"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.81681632995605, 8.264413564498893]),
            {
              "class": 1,
              "system:index": "1139"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.82087182998657, 8.244749613189972]),
            {
              "class": 1,
              "system:index": "1140"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8232536315918, 8.235087162031892]),
            {
              "class": 1,
              "system:index": "1141"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.84022665023804, 8.194544772127143]),
            {
              "class": 1,
              "system:index": "1142"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.83713674545288, 8.208519515578022]),
            {
              "class": 1,
              "system:index": "1143"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.83042049407959, 8.17188255700577]),
            {
              "class": 1,
              "system:index": "1144"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4736624956131, 8.795172516253622]),
            {
              "class": 1,
              "system:index": "1145"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47463881969452, 8.796391822279404]),
            {
              "class": 1,
              "system:index": "1146"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47469246387482, 8.792050014257779]),
            {
              "class": 1,
              "system:index": "1147"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48214364051819, 8.79388428856921]),
            {
              "class": 1,
              "system:index": "1148"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4872076511383, 8.795729156459112]),
            {
              "class": 1,
              "system:index": "1149"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48438596725464, 8.794812025007461]),
            {
              "class": 1,
              "system:index": "1150"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49160647392273, 8.790305854826599]),
            {
              "class": 1,
              "system:index": "1151"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48786211013794, 8.789462929848607]),
            {
              "class": 1,
              "system:index": "1152"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48489558696747, 8.784967297586942]),
            {
              "class": 1,
              "system:index": "1153"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45582580566406, 8.791758438024786]),
            {
              "class": 1,
              "system:index": "1154"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.44818687438965, 8.791138175093081]),
            {
              "class": 1,
              "system:index": "1155"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45736002922058, 8.79812066522732]),
            {
              "class": 1,
              "system:index": "1156"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74816513061523, 8.536297087018454]),
            {
              "class": 1,
              "system:index": "1157"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.76249885559082, 8.531501344897057]),
            {
              "class": 1,
              "system:index": "1158"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75146961212158, 8.550896143331006]),
            {
              "class": 1,
              "system:index": "1159"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80107975006104, 8.462317142971935]),
            {
              "class": 1,
              "system:index": "1160"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80700206756592, 8.468599413325258]),
            {
              "class": 1,
              "system:index": "1161"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81914710998535, 8.468174938828549]),
            {
              "class": 1,
              "system:index": "1162"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.83360958099365, 8.442196209375778]),
            {
              "class": 1,
              "system:index": "1163"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77533054351807, 8.422456299700528]),
            {
              "class": 1,
              "system:index": "1164"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80755996704102, 8.401399286112708]),
            {
              "class": 1,
              "system:index": "1165"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81687259674072, 8.41693743505156]),
            {
              "class": 1,
              "system:index": "1166"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82687187194824, 8.407852363485993]),
            {
              "class": 1,
              "system:index": "1167"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.83618450164795, 8.430904255414262]),
            {
              "class": 1,
              "system:index": "1168"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81944751739502, 8.419696877211692]),
            {
              "class": 1,
              "system:index": "1169"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.87064552307129, 8.426913786766297]),
            {
              "class": 1,
              "system:index": "1170"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.91789531707764, 8.374677334516221]),
            {
              "class": 1,
              "system:index": "1171"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.91489124298096, 8.362873906864381]),
            {
              "class": 1,
              "system:index": "1172"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.89858341217041, 8.37310639536079]),
            {
              "class": 1,
              "system:index": "1173"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.89479613304138, 8.387582673843784]),
            {
              "class": 1,
              "system:index": "1174"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.884281873703, 8.381617515053868]),
            {
              "class": 1,
              "system:index": "1175"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.89085865020752, 8.381606900810743]),
            {
              "class": 1,
              "system:index": "1176"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8815245628357, 8.387200566772322]),
            {
              "class": 1,
              "system:index": "1177"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.87308096885681, 8.391913194390103]),
            {
              "class": 1,
              "system:index": "1178"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.86257743835449, 8.372172320425008]),
            {
              "class": 1,
              "system:index": "1179"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82313823699951, 8.39548106539946]),
            {
              "class": 1,
              "system:index": "1180"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85519599914551, 8.319350989701778]),
            {
              "class": 1,
              "system:index": "1181"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75638341903687, 8.628037449867765]),
            {
              "class": 1,
              "system:index": "1182"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75724172592163, 8.630954478760337]),
            {
              "class": 1,
              "system:index": "1183"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75400161743164, 8.636746040218208]),
            {
              "class": 1,
              "system:index": "1184"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75481700897217, 8.63971603724663]),
            {
              "class": 1,
              "system:index": "1185"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74298310279846, 8.667155586032255]),
            {
              "class": 1,
              "system:index": "1186"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.75590062141418, 8.648328901497056]),
            {
              "class": 1,
              "system:index": "1187"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78207898139954, 9.585983166332879]),
            {
              "class": 1,
              "system:index": "1188"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78734683990479, 9.591378427315414]),
            {
              "class": 1,
              "system:index": "1189"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78009414672852, 9.598910491206498]),
            {
              "class": 1,
              "system:index": "1190"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.78095245361328, 9.604559429242723]),
            {
              "class": 1,
              "system:index": "1191"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68267095088959, 8.497039129060042]),
            {
              "class": 1,
              "system:index": "1192"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68378138542175, 8.494099851132354]),
            {
              "class": 1,
              "system:index": "1193"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68544435501099, 8.494731214175001]),
            {
              "class": 1,
              "system:index": "1194"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68533706665039, 8.491027910242584]),
            {
              "class": 1,
              "system:index": "1195"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68235445022583, 8.49001453574679]),
            {
              "class": 1,
              "system:index": "1196"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67959713935852, 8.486449131467323]),
            {
              "class": 1,
              "system:index": "1197"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67387330532074, 8.485520636010547]),
            {
              "class": 1,
              "system:index": "1198"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67214059829712, 8.484259728332216]),
            {
              "class": 1,
              "system:index": "1199"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67876029014587, 8.49120299302674]),
            {
              "class": 1,
              "system:index": "1200"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67850816249847, 8.49409984854173]),
            {
              "class": 1,
              "system:index": "1201"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67221570014954, 8.494492463566756]),
            {
              "class": 1,
              "system:index": "1202"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67585813999176, 8.506488171331938]),
            {
              "class": 1,
              "system:index": "1203"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67255902290344, 8.505209566664115]),
            {
              "class": 1,
              "system:index": "1204"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69608736038208, 8.487166019615584]),
            {
              "class": 1,
              "system:index": "1205"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69453167915344, 8.489946181679615]),
            {
              "class": 1,
              "system:index": "1206"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6952612400055, 8.494721222195608]),
            {
              "class": 1,
              "system:index": "1207"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69479990005493, 8.498222880800801]),
            {
              "class": 1,
              "system:index": "1208"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6682996749878, 8.52509969772234]),
            {
              "class": 1,
              "system:index": "1209"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66871809959412, 8.522945802107184]),
            {
              "class": 1,
              "system:index": "1210"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66749501228333, 8.529078537010651]),
            {
              "class": 1,
              "system:index": "1211"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67190456390381, 8.52928013043182]),
            {
              "class": 1,
              "system:index": "1212"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67008066177368, 8.53678145208984]),
            {
              "class": 1,
              "system:index": "1213"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.66932964324951, 8.539179297515522]),
            {
              "class": 1,
              "system:index": "1214"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67658233642578, 8.54818699778684]),
            {
              "class": 1,
              "system:index": "1215"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68823385238647, 8.55476492500359]),
            {
              "class": 1,
              "system:index": "1216"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68716096878052, 8.533025504643478]),
            {
              "class": 1,
              "system:index": "1217"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69768595695496, 8.537492319340219]),
            {
              "class": 1,
              "system:index": "1218"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73547291755676, 8.54238347451942]),
            {
              "class": 1,
              "system:index": "1219"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72109627723694, 8.540770779523477]),
            {
              "class": 1,
              "system:index": "1220"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.1533613204956, 9.080193161905406]),
            {
              "class": 1,
              "system:index": "1221"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.16241645812988, 9.06870866272811]),
            {
              "class": 1,
              "system:index": "1222"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.17104244232178, 9.078964210928529]),
            {
              "class": 1,
              "system:index": "1223"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.16705131530762, 9.093287583457046]),
            {
              "class": 1,
              "system:index": "1224"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.17404651641846, 9.074133121440424]),
            {
              "class": 1,
              "system:index": "1225"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.17052745819092, 9.065233575785014]),
            {
              "class": 1,
              "system:index": "1226"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.12568092346191, 9.115915650763126]),
            {
              "class": 1,
              "system:index": "1227"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.08019065856934, 9.146804462099785]),
            {
              "class": 1,
              "system:index": "1228"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.07710075378418, 9.21069213730241]),
            {
              "class": 1,
              "system:index": "1229"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.07474040985107, 9.205142670229385]),
            {
              "class": 1,
              "system:index": "1230"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.0961229801178, 9.208146699736211]),
            {
              "class": 1,
              "system:index": "1231"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.09245371818542, 9.194579907594067]),
            {
              "class": 1,
              "system:index": "1232"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.08130645751953, 9.195395412528677]),
            {
              "class": 1,
              "system:index": "1233"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.07815217971802, 9.201209802334938]),
            {
              "class": 1,
              "system:index": "1234"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.07345294952393, 9.202777235328071]),
            {
              "class": 1,
              "system:index": "1235"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.07983660697937, 9.200976804945649]),
            {
              "class": 1,
              "system:index": "1236"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.07936453819275, 9.212319363286603]),
            {
              "class": 1,
              "system:index": "1237"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.08013701438904, 9.138919912159906]),
            {
              "class": 1,
              "system:index": "1238"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.12854552268982, 9.149342923025515]),
            {
              "class": 1,
              "system:index": "1239"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.1261637210846, 9.151217761486805]),
            {
              "class": 1,
              "system:index": "1240"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.12926435470581, 9.144767004619933]),
            {
              "class": 1,
              "system:index": "1241"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.12372827529907, 9.135095946833838]),
            {
              "class": 1,
              "system:index": "1242"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.15040016174316, 9.13955670681373]),
            {
              "class": 1,
              "system:index": "1243"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.182608127594, 9.147225686045312]),
            {
              "class": 1,
              "system:index": "1244"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.19228553771973, 9.140286361166465]),
            {
              "class": 1,
              "system:index": "1245"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.19792890548706, 9.135223059924915]),
            {
              "class": 1,
              "system:index": "1246"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.2280662059784, 9.12973597023089]),
            {
              "class": 1,
              "system:index": "1247"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.25498485565186, 9.059639462755142]),
            {
              "class": 1,
              "system:index": "1248"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.21880722045898, 9.073878851770138]),
            {
              "class": 1,
              "system:index": "1249"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.93925929069519, 9.056711523330687]),
            {
              "class": 1,
              "system:index": "1250"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63020706176758, 8.187265002902624]),
            {
              "class": 1,
              "system:index": "1251"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60292363166809, 8.1802603280971]),
            {
              "class": 1,
              "system:index": "1252"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5875813961029, 8.203208781230575]),
            {
              "class": 1,
              "system:index": "1253"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48189163208008, 7.839749524480549]),
            {
              "class": 1,
              "system:index": "1254"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47927379608154, 7.829967414757924]),
            {
              "class": 1,
              "system:index": "1255"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.64193916320801, 8.836148278021618]),
            {
              "class": 1,
              "system:index": "1256"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.62185478210449, 8.873802889080237]),
            {
              "class": 1,
              "system:index": "1257"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.51242065429688, 8.810534158500777]),
            {
              "class": 1,
              "system:index": "1258"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8075065612793, 8.91891548462678]),
            {
              "class": 1,
              "system:index": "1259"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.86990547180176, 8.90899458210892]),
            {
              "class": 1,
              "system:index": "1260"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.79883766174316, 8.896444681253035]),
            {
              "class": 1,
              "system:index": "1261"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8924789428711, 8.945030761441247]),
            {
              "class": 1,
              "system:index": "1262"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.98637771606445, 8.970126792127019]),
            {
              "class": 1,
              "system:index": "1263"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.02070999145508, 9.015264894546652]),
            {
              "class": 1,
              "system:index": "1264"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.02238368988037, 9.074811173013408]),
            {
              "class": 1,
              "system:index": "1265"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.06980514526367, 9.09078739212036]),
            {
              "class": 1,
              "system:index": "1266"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.09598350524902, 9.111763042908589]),
            {
              "class": 1,
              "system:index": "1267"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.08594131469727, 9.1152376783506]),
            {
              "class": 1,
              "system:index": "1268"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.05109405517578, 9.136169522424053]),
            {
              "class": 1,
              "system:index": "1269"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.01710510253906, 9.140364217840089]),
            {
              "class": 1,
              "system:index": "1270"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.03693199157715, 9.222044973912906]),
            {
              "class": 1,
              "system:index": "1271"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.02650356292725, 9.220604708889885]),
            {
              "class": 1,
              "system:index": "1272"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.06628608703613, 9.209844896057282]),
            {
              "class": 1,
              "system:index": "1273"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.9714002609253, 9.21827485596849]),
            {
              "class": 1,
              "system:index": "1274"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.98925304412842, 9.227297655355262]),
            {
              "class": 1,
              "system:index": "1275"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.91458034515381, 9.212132442756667]),
            {
              "class": 1,
              "system:index": "1276"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.89835834503174, 9.216283878560978]),
            {
              "class": 1,
              "system:index": "1277"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.90852928161621, 9.227848335170199]),
            {
              "class": 1,
              "system:index": "1278"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8759994506836, 9.217385271705808]),
            {
              "class": 1,
              "system:index": "1279"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.85299682617188, 9.210819223313964]),
            {
              "class": 1,
              "system:index": "1280"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.83819103240967, 9.21416580516582]),
            {
              "class": 1,
              "system:index": "1281"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.82244110107422, 9.216453323883803]),
            {
              "class": 1,
              "system:index": "1282"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.89054775238037, 9.055443820826133]),
            {
              "class": 1,
              "system:index": "1283"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.83046627044678, 9.0569271341756]),
            {
              "class": 1,
              "system:index": "1284"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.85703086853027, 9.02251269014372]),
            {
              "class": 1,
              "system:index": "1285"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.77471923828125, 8.985848372466242]),
            {
              "class": 1,
              "system:index": "1286"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.81401634216309, 8.268583005314099]),
            {
              "class": 1,
              "system:index": "1287"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.84637451171875, 8.258645080192515]),
            {
              "class": 1,
              "system:index": "1288"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.79358863830566, 8.277331569685803]),
            {
              "class": 1,
              "system:index": "1289"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.77873992919922, 8.288797840334004]),
            {
              "class": 1,
              "system:index": "1290"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.83495903015137, 8.301792542925766]),
            {
              "class": 1,
              "system:index": "1291"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.73093223571777, 8.203005074607375]),
            {
              "class": 1,
              "system:index": "1292"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.76174545288086, 8.057114961625844]),
            {
              "class": 1,
              "system:index": "1293"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.05296897888184, 8.594053471757004]),
            {
              "class": 1,
              "system:index": "1294"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.0659294128418, 8.605213314318574]),
            {
              "class": 1,
              "system:index": "1295"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.08142185211182, 8.600842768751118]),
            {
              "class": 1,
              "system:index": "1296"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.05562973022461, 8.625665098129087]),
            {
              "class": 1,
              "system:index": "1297"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.09601306915283, 8.615948516568954]),
            {
              "class": 1,
              "system:index": "1298"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.99696445465088, 8.532647256381942]),
            {
              "class": 1,
              "system:index": "1299"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.96636581420898, 8.512742220967478]),
            {
              "class": 1,
              "system:index": "1300"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.93718338012695, 8.472037660216497]),
            {
              "class": 1,
              "system:index": "1301"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.92177677154541, 8.436295588569585]),
            {
              "class": 1,
              "system:index": "1302"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.90272235870361, 8.433833423721854]),
            {
              "class": 1,
              "system:index": "1303"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.95100212097168, 8.431668403738177]),
            {
              "class": 1,
              "system:index": "1304"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.95280456542969, 8.470764246700996]),
            {
              "class": 1,
              "system:index": "1305"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.98305988311768, 8.488846323298725]),
            {
              "class": 1,
              "system:index": "1306"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.99619197845459, 8.497717265531557]),
            {
              "class": 1,
              "system:index": "1307"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.02614688873291, 8.575806633875725]),
            {
              "class": 1,
              "system:index": "1308"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.92662620544434, 8.65523760966132]),
            {
              "class": 1,
              "system:index": "1309"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.8895902633667, 8.681329071949689]),
            {
              "class": 1,
              "system:index": "1310"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.15828323364258, 8.590791031233694]),
            {
              "class": 1,
              "system:index": "1311"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.22102546691895, 8.759724747482593]),
            {
              "class": 1,
              "system:index": "1312"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.18077087402344, 8.760573041830531]),
            {
              "class": 1,
              "system:index": "1313"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.21905136108398, 8.77423031428189]),
            {
              "class": 1,
              "system:index": "1314"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.22995185852051, 8.768716569068433]),
            {
              "class": 1,
              "system:index": "1315"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.25776100158691, 8.755907398970523]),
            {
              "class": 1,
              "system:index": "1316"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.28651428222656, 8.864898428004368]),
            {
              "class": 1,
              "system:index": "1317"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.29029083251953, 8.893052738979643]),
            {
              "class": 1,
              "system:index": "1318"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.25501441955566, 8.90297407405864]),
            {
              "class": 1,
              "system:index": "1319"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.25638771057129, 8.916286895668703]),
            {
              "class": 1,
              "system:index": "1320"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.30342292785645, 8.924342189054357]),
            {
              "class": 1,
              "system:index": "1321"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.2255744934082, 8.910351302628104]),
            {
              "class": 1,
              "system:index": "1322"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.35234642028809, 8.858707582037624]),
            {
              "class": 1,
              "system:index": "1323"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.38324546813965, 8.880671892572039]),
            {
              "class": 1,
              "system:index": "1324"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.39234352111816, 8.800101408813402]),
            {
              "class": 1,
              "system:index": "1325"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.39251518249512, 8.764984141236209]),
            {
              "class": 1,
              "system:index": "1326"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.39757919311523, 8.758876451199388]),
            {
              "class": 1,
              "system:index": "1327"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.38848114013672, 8.752259673792244]),
            {
              "class": 1,
              "system:index": "1328"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.37122917175293, 8.792976435124892]),
            {
              "class": 1,
              "system:index": "1329"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.36264610290527, 8.590875898926924]),
            {
              "class": 1,
              "system:index": "1330"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.55297565460205, 9.02467428521345]),
            {
              "class": 1,
              "system:index": "1331"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.54589462280273, 9.018825233375384]),
            {
              "class": 1,
              "system:index": "1332"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.54572296142578, 9.006872528447948]),
            {
              "class": 1,
              "system:index": "1333"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51770448684692, 8.586814779296311]),
            {
              "class": 1,
              "system:index": "1334"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53487062454224, 8.579144702771826]),
            {
              "class": 1,
              "system:index": "1335"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5439043045044, 8.57903861487319]),
            {
              "class": 1,
              "system:index": "1336"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5527663230896, 8.587695289919436]),
            {
              "class": 1,
              "system:index": "1337"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58574676513672, 8.458204627865722]),
            {
              "class": 1,
              "system:index": "1338"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.55828094482422, 8.411508374201064]),
            {
              "class": 1,
              "system:index": "1339"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57840824127197, 8.433833423721854]),
            {
              "class": 1,
              "system:index": "1340"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58690547943115, 8.437823820927271]),
            {
              "class": 1,
              "system:index": "1341"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57240009307861, 8.387431402442283]),
            {
              "class": 1,
              "system:index": "1342"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57351589202881, 8.400295459492948]),
            {
              "class": 1,
              "system:index": "1343"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.69432258605957, 8.322128083909275]),
            {
              "class": 1,
              "system:index": "1344"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7341480255127, 8.317669396905474]),
            {
              "class": 1,
              "system:index": "1345"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76212882995605, 8.318561138365249]),
            {
              "class": 1,
              "system:index": "1346"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77689170837402, 8.333805356889874]),
            {
              "class": 1,
              "system:index": "1347"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7735013961792, 8.26263229129224]),
            {
              "class": 1,
              "system:index": "1348"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77414512634277, 8.230014083728003]),
            {
              "class": 1,
              "system:index": "1349"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.82130908966064, 8.1894074591516]),
            {
              "class": 1,
              "system:index": "1350"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8353853225708, 8.18371540418505]),
            {
              "class": 1,
              "system:index": "1351"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53287506103516, 8.939349959257555]),
            {
              "class": 1,
              "system:index": "1352"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.40286302566528, 8.83955451265407]),
            {
              "class": 1,
              "system:index": "1353"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5479383468628, 8.815830269925518]),
            {
              "class": 1,
              "system:index": "1354"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62248229980469, 8.78864182476921]),
            {
              "class": 1,
              "system:index": "1355"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.99365711212158, 8.453742527513818]),
            {
              "class": 1,
              "system:index": "1356"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.99129676818848, 8.479253569765474]),
            {
              "class": 1,
              "system:index": "1357"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.034255027771, 8.494533915926397]),
            {
              "class": 1,
              "system:index": "1358"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.08961582183838, 8.507903719600035]),
            {
              "class": 1,
              "system:index": "1359"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.0787582397461, 8.518132365434063]),
            {
              "class": 1,
              "system:index": "1360"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.01110219955444, 8.522013317754002]),
            {
              "class": 1,
              "system:index": "1361"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.91874837875366, 8.521739913886574]),
            {
              "class": 1,
              "system:index": "1362"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88955521583557, 8.526977709847845]),
            {
              "class": 1,
              "system:index": "1363"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88589668273926, 8.524505515652967]),
            {
              "class": 1,
              "system:index": "1364"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8978271484375, 8.526001566410995]),
            {
              "class": 1,
              "system:index": "1365"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.23759341239929, 9.218631217524985]),
            {
              "class": 1,
              "system:index": "1366"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.24047946929932, 9.215030509129583]),
            {
              "class": 1,
              "system:index": "1367"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.24939513206482, 9.218747710418661]),
            {
              "class": 1,
              "system:index": "1368"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.26204442977905, 9.17861893299369]),
            {
              "class": 1,
              "system:index": "1369"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.27590608596802, 9.190777723425654]),
            {
              "class": 1,
              "system:index": "1370"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.25136923789978, 9.165442908927677]),
            {
              "class": 1,
              "system:index": "1371"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.2465090751648, 9.162000539106485]),
            {
              "class": 1,
              "system:index": "1372"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.24430966377258, 9.162773751233084]),
            {
              "class": 1,
              "system:index": "1373"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.24868702888489, 9.160115165496702]),
            {
              "class": 1,
              "system:index": "1374"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.19340133666992, 9.136889827170004]),
            {
              "class": 1,
              "system:index": "1375"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.20696258544922, 9.137228793605322]),
            {
              "class": 1,
              "system:index": "1376"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.0781307220459, 9.208743479401754]),
            {
              "class": 1,
              "system:index": "1377"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.09383773803711, 9.205100307550238]),
            {
              "class": 1,
              "system:index": "1378"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.10169124603271, 9.205820472405318]),
            {
              "class": 1,
              "system:index": "1379"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.10658359527588, 9.205185032903456]),
            {
              "class": 1,
              "system:index": "1380"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.04581546783447, 9.221494285039316]),
            {
              "class": 1,
              "system:index": "1381"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.05959129333496, 9.22369703537741]),
            {
              "class": 1,
              "system:index": "1382"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.03684616088867, 9.22153664575241]),
            {
              "class": 1,
              "system:index": "1383"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.01324272155762, 9.219206798982334]),
            {
              "class": 1,
              "system:index": "1384"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.98998260498047, 9.208955290563646]),
            {
              "class": 1,
              "system:index": "1385"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.97049903869629, 9.218063050394973]),
            {
              "class": 1,
              "system:index": "1386"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.95522117614746, 9.215606096456646]),
            {
              "class": 1,
              "system:index": "1387"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.91470909118652, 9.212852593281847]),
            {
              "class": 1,
              "system:index": "1388"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8878870010376, 9.211073395199943]),
            {
              "class": 1,
              "system:index": "1389"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.87548446655273, 9.217173465598618]),
            {
              "class": 1,
              "system:index": "1390"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.86402606964111, 9.214335251504897]),
            {
              "class": 1,
              "system:index": "1391"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8390064239502, 9.213530380670324]),
            {
              "class": 1,
              "system:index": "1392"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.82681846618652, 9.215394289282255]),
            {
              "class": 1,
              "system:index": "1393"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.79441738128662, 9.225687970966456]),
            {
              "class": 1,
              "system:index": "1394"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.88084888458252, 9.167946286258303]),
            {
              "class": 1,
              "system:index": "1395"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8931655883789, 9.158921974074627]),
            {
              "class": 1,
              "system:index": "1396"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.93020153045654, 9.171293273317062]),
            {
              "class": 1,
              "system:index": "1397"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.924880027771, 9.086380230404323]),
            {
              "class": 1,
              "system:index": "1398"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.95556449890137, 9.080659314622205]),
            {
              "class": 1,
              "system:index": "1399"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.96607875823975, 9.08438851453233]),
            {
              "class": 1,
              "system:index": "1400"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.97685050964355, 9.09112640231366]),
            {
              "class": 1,
              "system:index": "1401"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.95625114440918, 9.071039474185037]),
            {
              "class": 1,
              "system:index": "1402"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.02302742004395, 9.074387370237979]),
            {
              "class": 1,
              "system:index": "1403"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.04143810272217, 9.072692236900146]),
            {
              "class": 1,
              "system:index": "1404"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.00144100189209, 9.098754046784983]),
            {
              "class": 1,
              "system:index": "1405"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.98517608642578, 9.109474849892454]),
            {
              "class": 1,
              "system:index": "1406"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.92346382141113, 8.940537032623423]),
            {
              "class": 1,
              "system:index": "1407"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.85771751403809, 8.955544174357337]),
            {
              "class": 1,
              "system:index": "1408"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.97388935089111, 9.111000313531514]),
            {
              "class": 1,
              "system:index": "1409"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.9303731918335, 9.10451704809536]),
            {
              "class": 1,
              "system:index": "1410"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.91475200653076, 9.122441083138401]),
            {
              "class": 1,
              "system:index": "1411"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.01673221588135, 9.121866580941129]),
            {
              "class": 1,
              "system:index": "1412"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.04241704940796, 9.106696864316161]),
            {
              "class": 1,
              "system:index": "1413"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62941312789917, 7.482582872043324]),
            {
              "class": 1,
              "system:index": "1414"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60402870178223, 7.446796942089708]),
            {
              "class": 1,
              "system:index": "1415"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61952114105225, 7.439137266679032]),
            {
              "class": 1,
              "system:index": "1416"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62703132629395, 7.4400309023691875]),
            {
              "class": 1,
              "system:index": "1417"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6198000907898, 7.449371414056415]),
            {
              "class": 1,
              "system:index": "1418"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63196659088135, 7.411497493874178]),
            {
              "class": 1,
              "system:index": "1419"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78139781951904, 7.697983049661263]),
            {
              "class": 1,
              "system:index": "1420"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78826427459717, 7.687308239838209]),
            {
              "class": 1,
              "system:index": "1421"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76528310775757, 7.704253498787703]),
            {
              "class": 1,
              "system:index": "1422"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75150728225708, 7.710781490042284]),
            {
              "class": 1,
              "system:index": "1423"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.74228048324585, 7.708718910850035]),
            {
              "class": 1,
              "system:index": "1424"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.74803113937378, 7.75305151348585]),
            {
              "class": 1,
              "system:index": "1425"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73794603347778, 7.770400557063012]),
            {
              "class": 1,
              "system:index": "1426"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.88242053985596, 7.714909089309238]),
            {
              "class": 1,
              "system:index": "1427"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.96426010131836, 7.739701537244326]),
            {
              "class": 1,
              "system:index": "1428"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.93889713287354, 7.7074643474562885]),
            {
              "class": 1,
              "system:index": "1429"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.94878911972046, 7.709633251319915]),
            {
              "class": 1,
              "system:index": "1430"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8842658996582, 7.829801054155991]),
            {
              "class": 1,
              "system:index": "1431"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86042642593384, 7.873268154770793]),
            {
              "class": 1,
              "system:index": "1432"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87501764297485, 7.868209338462669]),
            {
              "class": 1,
              "system:index": "1433"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.97496747970581, 7.92249273305578]),
            {
              "class": 1,
              "system:index": "1434"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.97243547439575, 7.9127162978147805]),
            {
              "class": 1,
              "system:index": "1435"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.98282098770142, 7.897626127533188]),
            {
              "class": 1,
              "system:index": "1436"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.0028624534607, 7.897668635829936]),
            {
              "class": 1,
              "system:index": "1437"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.92409133911133, 7.952245671633621]),
            {
              "class": 1,
              "system:index": "1438"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.90917825698853, 7.949738007127072]),
            {
              "class": 1,
              "system:index": "1439"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.90786933898926, 7.969947646540059]),
            {
              "class": 1,
              "system:index": "1440"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.89975833892822, 8.00292696400095]),
            {
              "class": 1,
              "system:index": "1441"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87765693664551, 8.022496541783275]),
            {
              "class": 1,
              "system:index": "1442"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87130546569824, 8.040747883154628]),
            {
              "class": 1,
              "system:index": "1443"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.96902370452881, 7.984570158168746]),
            {
              "class": 1,
              "system:index": "1444"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.98769187927246, 7.988947562811716]),
            {
              "class": 1,
              "system:index": "1445"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.00146770477295, 7.966040042550673]),
            {
              "class": 1,
              "system:index": "1446"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.25582695007324, 8.170377007516583]),
            {
              "class": 1,
              "system:index": "1447"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.24290943145752, 8.207672479573034]),
            {
              "class": 1,
              "system:index": "1448"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.27513885498047, 8.189365002171856]),
            {
              "class": 1,
              "system:index": "1449"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.30921363830566, 8.21510566933896]),
            {
              "class": 1,
              "system:index": "1450"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.34122848510742, 8.148371892619503]),
            {
              "class": 1,
              "system:index": "1451"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32157325744629, 8.111453259568513]),
            {
              "class": 1,
              "system:index": "1452"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.34406089782715, 8.102828509797158]),
            {
              "class": 1,
              "system:index": "1453"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33972644805908, 8.11888824017737]),
            {
              "class": 1,
              "system:index": "1454"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29106044769287, 8.124113887048324]),
            {
              "class": 1,
              "system:index": "1455"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.44895672798157, 8.023196474607548]),
            {
              "class": 1,
              "system:index": "1456"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.42860412597656, 7.979602669276072]),
            {
              "class": 1,
              "system:index": "1457"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.40113830566406, 7.9847025741853]),
            {
              "class": 1,
              "system:index": "1458"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.52005672454834, 8.202320476065118]),
            {
              "class": 1,
              "system:index": "1459"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.53657913208008, 8.214256148241285]),
            {
              "class": 1,
              "system:index": "1460"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.4860463142395, 8.188246237345965]),
            {
              "class": 1,
              "system:index": "1461"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.69043064117432, 8.160733967825868]),
            {
              "class": 1,
              "system:index": "1462"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.65086269378662, 8.245049393847372]),
            {
              "class": 1,
              "system:index": "1463"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.661376953125, 8.258852475388677]),
            {
              "class": 1,
              "system:index": "1464"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.62910461425781, 8.280426786497852]),
            {
              "class": 1,
              "system:index": "1465"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.61288261413574, 8.292742300355728]),
            {
              "class": 1,
              "system:index": "1466"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.4440107345581, 8.273419511787331]),
            {
              "class": 1,
              "system:index": "1467"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.18966484069824, 8.932736424648027]),
            {
              "class": 1,
              "system:index": "1468"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.18623161315918, 8.944013276864352]),
            {
              "class": 1,
              "system:index": "1469"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19326972961426, 8.965718114075521]),
            {
              "class": 1,
              "system:index": "1470"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19262599945068, 8.960583861866725]),
            {
              "class": 1,
              "system:index": "1471"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19249725341797, 8.946763939702414]),
            {
              "class": 1,
              "system:index": "1472"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.16906547546387, 8.939005900598103]),
            {
              "class": 1,
              "system:index": "1473"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.17400074005127, 8.940362488824242]),
            {
              "class": 1,
              "system:index": "1474"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.17897891998291, 8.934172919542071]),
            {
              "class": 1,
              "system:index": "1475"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.17691898345947, 8.955623990877497]),
            {
              "class": 1,
              "system:index": "1476"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.18305587768555, 8.958718606264085]),
            {
              "class": 1,
              "system:index": "1477"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.1746015548706, 8.963975152825023]),
            {
              "class": 1,
              "system:index": "1478"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19344139099121, 8.91000715710385]),
            {
              "class": 1,
              "system:index": "1479"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.1876049041748, 8.963381696269193]),
            {
              "class": 1,
              "system:index": "1480"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19000816345215, 8.939811367057288]),
            {
              "class": 1,
              "system:index": "1481"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19301223754883, 8.900976382868581]),
            {
              "class": 1,
              "system:index": "1482"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.15940952301025, 8.886051797967127]),
            {
              "class": 1,
              "system:index": "1483"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.39789009094238, 8.56519758349061]),
            {
              "class": 1,
              "system:index": "1484"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4388313293457, 8.532732116319544]),
            {
              "class": 1,
              "system:index": "1485"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45668411254883, 8.527978770287417]),
            {
              "class": 1,
              "system:index": "1486"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45565414428711, 8.514100359257348]),
            {
              "class": 1,
              "system:index": "1487"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46385097503662, 8.470636884391437]),
            {
              "class": 1,
              "system:index": "1488"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.44732856750488, 8.451747416361117]),
            {
              "class": 1,
              "system:index": "1489"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46466636657715, 8.444743221022543]),
            {
              "class": 1,
              "system:index": "1490"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.34613418579102, 8.479805370623447]),
            {
              "class": 1,
              "system:index": "1491"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.34274387359619, 8.501961642206696]),
            {
              "class": 1,
              "system:index": "1492"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.34222888946533, 8.516986431158251]),
            {
              "class": 1,
              "system:index": "1493"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.34527587890625, 8.531543785356961]),
            {
              "class": 1,
              "system:index": "1494"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.34514713287354, 8.545548879427754]),
            {
              "class": 1,
              "system:index": "1495"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.3679780960083, 8.557855961726856]),
            {
              "class": 1,
              "system:index": "1496"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.34939575195312, 8.569229049636467]),
            {
              "class": 1,
              "system:index": "1497"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.3641586303711, 8.593119913190266]),
            {
              "class": 1,
              "system:index": "1498"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.3936414718628, 8.595665920086452]),
            {
              "class": 1,
              "system:index": "1499"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.3824405670166, 8.641533564034443]),
            {
              "class": 1,
              "system:index": "1500"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49367713928223, 8.661983380806971]),
            {
              "class": 1,
              "system:index": "1501"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53672122955322, 8.66758355173164]),
            {
              "class": 1,
              "system:index": "1502"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54105567932129, 8.678020011216216]),
            {
              "class": 1,
              "system:index": "1503"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52037048339844, 8.707461140901401]),
            {
              "class": 1,
              "system:index": "1504"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5413990020752, 8.722986798306]),
            {
              "class": 1,
              "system:index": "1505"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51693725585938, 8.733209624714776]),
            {
              "class": 1,
              "system:index": "1506"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5986909866333, 8.696558859705428]),
            {
              "class": 1,
              "system:index": "1507"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5847864151001, 8.717005678793479]),
            {
              "class": 1,
              "system:index": "1508"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59427070617676, 8.682729050399434]),
            {
              "class": 1,
              "system:index": "1509"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63954639434814, 8.672759393085862]),
            {
              "class": 1,
              "system:index": "1510"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67254829406738, 8.64654005335662]),
            {
              "class": 1,
              "system:index": "1511"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65782833099365, 8.65256472349592]),
            {
              "class": 1,
              "system:index": "1512"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63684272766113, 8.633769110585778]),
            {
              "class": 1,
              "system:index": "1513"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61791706085205, 8.615906066110671]),
            {
              "class": 1,
              "system:index": "1514"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62207984924316, 8.575509564354064]),
            {
              "class": 1,
              "system:index": "1515"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58500099182129, 8.575467128792098]),
            {
              "class": 1,
              "system:index": "1516"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.88463592529297, 8.383822597048916]),
            {
              "class": 1,
              "system:index": "1517"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.84348011016846, 8.372104362737236]),
            {
              "class": 1,
              "system:index": "1518"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.86463737487793, 8.356479501725081]),
            {
              "class": 1,
              "system:index": "1519"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8883695602417, 8.360895286815122]),
            {
              "class": 1,
              "system:index": "1520"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85811424255371, 8.388959827565666]),
            {
              "class": 1,
              "system:index": "1521"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8354549407959, 8.430776900668139]),
            {
              "class": 1,
              "system:index": "1522"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.84661293029785, 8.454888650527904]),
            {
              "class": 1,
              "system:index": "1523"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.92403221130371, 8.463845292949438]),
            {
              "class": 1,
              "system:index": "1524"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.92969703674316, 8.447587364162032]),
            {
              "class": 1,
              "system:index": "1525"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.94634819030762, 8.470212412142388]),
            {
              "class": 1,
              "system:index": "1526"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.89545059204102, 8.486639167060352]),
            {
              "class": 1,
              "system:index": "1527"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.92999744415283, 8.498141707385903]),
            {
              "class": 1,
              "system:index": "1528"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.93381690979004, 8.519702734960283]),
            {
              "class": 1,
              "system:index": "1529"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.97080993652344, 8.525050360891317]),
            {
              "class": 1,
              "system:index": "1530"
            }),
        ee.Feature(
            ee.Geometry.Point([-83.00183773040771, 8.520721336141658]),
            {
              "class": 1,
              "system:index": "1531"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.89433479309082, 8.332125640362786]),
            {
              "class": 1,
              "system:index": "1532"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8870177268982, 8.316159457189514]),
            {
              "class": 1,
              "system:index": "1533"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8722333908081, 8.326860261977624]),
            {
              "class": 1,
              "system:index": "1534"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.86161184310913, 8.323824161009943]),
            {
              "class": 1,
              "system:index": "1535"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.852942943573, 8.319896279377557]),
            {
              "class": 1,
              "system:index": "1536"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.85654783248901, 8.30872817085277]),
            {
              "class": 1,
              "system:index": "1537"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.86596775054932, 8.301466606516092]),
            {
              "class": 1,
              "system:index": "1538"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.8125810623169, 8.312039185018477]),
            {
              "class": 1,
              "system:index": "1539"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62229442596436, 8.47500894202418]),
            {
              "class": 1,
              "system:index": "1540"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62830257415771, 8.501325006316966]),
            {
              "class": 1,
              "system:index": "1541"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.64727115631104, 8.510153217000072]),
            {
              "class": 1,
              "system:index": "1542"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60457038879395, 8.488082309113649]),
            {
              "class": 1,
              "system:index": "1543"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57521629333496, 8.462996333003169]),
            {
              "class": 1,
              "system:index": "1544"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59315490722656, 8.456883766149566]),
            {
              "class": 1,
              "system:index": "1545"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60336875915527, 8.442493382328264]),
            {
              "class": 1,
              "system:index": "1546"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62753009796143, 8.447544935145954]),
            {
              "class": 1,
              "system:index": "1547"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62070655822754, 8.435871057780329]),
            {
              "class": 1,
              "system:index": "1548"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60628700256348, 8.424281752994442]),
            {
              "class": 1,
              "system:index": "1549"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57933616638184, 8.41931480177806]),
            {
              "class": 1,
              "system:index": "1550"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56268501281738, 8.424748728034992]),
            {
              "class": 1,
              "system:index": "1551"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5151777267456, 8.425385511272747]),
            {
              "class": 1,
              "system:index": "1552"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49015808105469, 8.425767580712241]),
            {
              "class": 1,
              "system:index": "1553"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.50002861022949, 8.412861915278107]),
            {
              "class": 1,
              "system:index": "1554"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54006862640381, 8.391209998054952]),
            {
              "class": 1,
              "system:index": "1555"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56298542022705, 8.375543446353216]),
            {
              "class": 1,
              "system:index": "1556"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58603096008301, 8.353931910662165]),
            {
              "class": 1,
              "system:index": "1557"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59972095489502, 8.350280334465122]),
            {
              "class": 1,
              "system:index": "1558"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60744571685791, 8.331215155500091]),
            {
              "class": 1,
              "system:index": "1559"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61645793914795, 8.316098228444226]),
            {
              "class": 1,
              "system:index": "1560"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.64250755310059, 8.331937016627561]),
            {
              "class": 1,
              "system:index": "1561"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65486717224121, 8.33758447240816]),
            {
              "class": 1,
              "system:index": "1562"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57461547851562, 8.311469614485453]),
            {
              "class": 1,
              "system:index": "1563"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55693435668945, 8.306543690088663]),
            {
              "class": 1,
              "system:index": "1564"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53470420837402, 8.323784154728315]),
            {
              "class": 1,
              "system:index": "1565"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51586437225342, 8.322382864491066]),
            {
              "class": 1,
              "system:index": "1566"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49080181121826, 8.334060129870585]),
            {
              "class": 1,
              "system:index": "1567"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46578216552734, 8.357625912275179]),
            {
              "class": 1,
              "system:index": "1568"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47702598571777, 8.371552408216312]),
            {
              "class": 1,
              "system:index": "1569"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.46582508087158, 8.470254880114561]),
            {
              "class": 1,
              "system:index": "1570"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51307487487793, 8.476155001728893]),
            {
              "class": 1,
              "system:index": "1571"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.53856658935547, 8.487463137132872]),
            {
              "class": 1,
              "system:index": "1572"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5972318649292, 8.555903851097272]),
            {
              "class": 1,
              "system:index": "1573"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56487369537354, 8.583275213099084]),
            {
              "class": 1,
              "system:index": "1574"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57607460021973, 8.621082637937429]),
            {
              "class": 1,
              "system:index": "1575"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61345386505127, 8.630332364159033]),
            {
              "class": 1,
              "system:index": "1576"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65872955322266, 8.648491717615777]),
            {
              "class": 1,
              "system:index": "1577"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62688636779785, 8.664316795495962]),
            {
              "class": 1,
              "system:index": "1578"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68353462219238, 8.671826049914532]),
            {
              "class": 1,
              "system:index": "1579"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.73095607757568, 8.682432085710229]),
            {
              "class": 1,
              "system:index": "1580"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74168491363525, 8.672250297098067]),
            {
              "class": 1,
              "system:index": "1581"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74013996124268, 8.738087638174006]),
            {
              "class": 1,
              "system:index": "1582"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.68722534179688, 8.727525598120852]),
            {
              "class": 1,
              "system:index": "1583"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65915870666504, 8.75717490302396]),
            {
              "class": 1,
              "system:index": "1584"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6486873626709, 8.764724706451616]),
            {
              "class": 1,
              "system:index": "1585"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61302471160889, 8.757683883354828]),
            {
              "class": 1,
              "system:index": "1586"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55972385406494, 8.724386620956032]),
            {
              "class": 1,
              "system:index": "1587"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54036903381348, 8.722562608588154]),
            {
              "class": 1,
              "system:index": "1588"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51710891723633, 8.723792757442379]),
            {
              "class": 1,
              "system:index": "1589"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.4968957901001, 8.704109889822835]),
            {
              "class": 1,
              "system:index": "1590"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.47608184814453, 8.69634674991926]),
            {
              "class": 1,
              "system:index": "1591"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.49809741973877, 8.685741107534373]),
            {
              "class": 1,
              "system:index": "1592"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54792213439941, 8.641106806552656]),
            {
              "class": 1,
              "system:index": "1593"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55017518997192, 8.651459146485232]),
            {
              "class": 1,
              "system:index": "1594"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55305051803589, 8.664887065011676]),
            {
              "class": 1,
              "system:index": "1595"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5666332244873, 8.654407814199192]),
            {
              "class": 1,
              "system:index": "1596"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5756025314331, 8.650101478767052]),
            {
              "class": 1,
              "system:index": "1597"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.58712530136108, 8.646198156817695]),
            {
              "class": 1,
              "system:index": "1598"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60733842849731, 8.640194599032831]),
            {
              "class": 1,
              "system:index": "1599"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61489152908325, 8.637839820583288]),
            {
              "class": 1,
              "system:index": "1600"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.77541637420654, 8.763664350056859]),
            {
              "class": 1,
              "system:index": "1601"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.76125431060791, 8.783004774694863]),
            {
              "class": 1,
              "system:index": "1602"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.79575824737549, 8.769559893252358]),
            {
              "class": 1,
              "system:index": "1603"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.82605648040771, 8.750770174349173]),
            {
              "class": 1,
              "system:index": "1604"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.56118297576904, 8.65371024846204]),
            {
              "class": 1,
              "system:index": "1605"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54785776138306, 8.642485720706746]),
            {
              "class": 1,
              "system:index": "1606"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5456690788269, 8.61757963326343]),
            {
              "class": 1,
              "system:index": "1607"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.55603313446045, 8.611936288174368]),
            {
              "class": 1,
              "system:index": "1608"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.89187526702881, 8.199389618559987]),
            {
              "class": 1,
              "system:index": "1609"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86127662658691, 8.21425616898106]),
            {
              "class": 1,
              "system:index": "1610"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86063289642334, 8.2263613773443]),
            {
              "class": 1,
              "system:index": "1611"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.85762882232666, 8.24148174846197]),
            {
              "class": 1,
              "system:index": "1612"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86565399169922, 8.259999169932614]),
            {
              "class": 1,
              "system:index": "1613"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.88882827758789, 8.274226415141964]),
            {
              "class": 1,
              "system:index": "1614"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86432361602783, 8.280766528685177]),
            {
              "class": 1,
              "system:index": "1615"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8564567565918, 8.070792087384108]),
            {
              "class": 1,
              "system:index": "1616"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8417797088623, 8.054985393112526]),
            {
              "class": 1,
              "system:index": "1617"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.80573081970215, 8.032294059917511]),
            {
              "class": 1,
              "system:index": "1618"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76603412628174, 8.018950623709946]),
            {
              "class": 1,
              "system:index": "1619"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.79349994659424, 8.027917121175244]),
            {
              "class": 1,
              "system:index": "1620"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75607776641846, 7.992602447239531]),
            {
              "class": 1,
              "system:index": "1621"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73625087738037, 7.9990196651093255]),
            {
              "class": 1,
              "system:index": "1622"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68509578704834, 8.009388995722942]),
            {
              "class": 1,
              "system:index": "1623"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68531036376953, 8.054305521443016]),
            {
              "class": 1,
              "system:index": "1624"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68041801452637, 8.073426476345572]),
            {
              "class": 1,
              "system:index": "1625"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.79982995986938, 7.928762291705062]),
            {
              "class": 1,
              "system:index": "1626"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77659130096436, 7.93220517906437]),
            {
              "class": 1,
              "system:index": "1627"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.66385269165039, 7.808585425776072]),
            {
              "class": 1,
              "system:index": "1628"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72723865509033, 7.811051428359896]),
            {
              "class": 1,
              "system:index": "1629"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77976703643799, 7.782181279918249]),
            {
              "class": 1,
              "system:index": "1630"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72702407836914, 7.762196359872213]),
            {
              "class": 1,
              "system:index": "1631"
            })]),
    input = ee.Image("users/images/input/Panama_2010_InputTOA3season"),
    NonCropClass = /* color: #98ff00 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-79.75181579589844, 9.178103348704242]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.94956970214844, 9.115735255064632]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89463806152344, 9.229616548508531]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.881591796875, 9.34007337804905]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.71199035644531, 9.085225149938543]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.50668334960938, 9.022162708703659]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.45930480957031, 9.037081703683176]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.7109603881836, 8.909173987756896]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.78769302368164, 8.867452397460392]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.6453857421875, 8.938511930245268]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.61894989013672, 8.954621356668463]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.51921463012695, 8.910700297237618]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.62032318115234, 8.980903624990441]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.91652488708496, 9.27749560062012]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.97978210449219, 9.308920839548383]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.90030288696289, 9.359991409533963]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33117294311523, 8.976824384709895]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44584274291992, 8.97606136935785]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.55167198181152, 8.949948321968238]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.93215942382812, 8.706086794376787]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.70831298828125, 8.893370116162915]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.375732421875, 8.617841024194746]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.14673614501953, 8.547111199679017]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.18793487548828, 8.518251774837594]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.15124225616455, 8.448436358050747]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.18330001831055, 8.43149857700808]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.20462894439697, 8.446865717887608]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.21973514556885, 8.431880640407295]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.26638412475586, 8.453063341897513]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28445148468018, 8.461383283222307]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29354953765869, 8.467453331109674]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29831314086914, 8.480314724558335]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32723808288574, 8.494958361303562]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.3892936706543, 8.48782761665551]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.45744323730469, 8.504678031878017]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.46482467651367, 8.4953828062111]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.486496925354, 8.507267072858964]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.50469303131104, 8.488039843111334]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.5052080154419, 8.502555854092536]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.72317504882812, 8.524142205623365]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.1392822265625, 8.689796827616423]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.53915405273438, 8.689796827616423]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.881103515625, 8.742736624669917]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.056884765625, 8.855378280589834]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.93487644195557, 8.877444445600968]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.00422763824463, 8.866589565527667]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.03920364379883, 8.880539723658416]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.13996887207031, 8.761659957555729]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.0184326171875, 8.74581240276282]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.02727317810059, 8.770328246256037]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.0580005645752, 8.77397579411679]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.9525146484375, 8.765662725847296]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.88985824584961, 8.783391391495874]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.91886901855469, 8.737413870505963]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.84874534606934, 8.775163360105706]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8085765838623, 8.814605354186419]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.77982330322266, 8.83852296554996]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.74480438232422, 8.824189547715177]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.68661117553711, 8.850396380602625]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.63888931274414, 8.855484869802918]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.61674499511719, 8.876855755142726]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.65047645568848, 8.923918233264427]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.68841361999512, 8.938926059732834]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.70815467834473, 8.991406188656292]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.74583435058594, 8.994119009956284]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.77999496459961, 9.045913034811992]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.83921813964844, 9.060746286087504]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.87131881713867, 9.111852735505853]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.91749572753906, 9.128717108951003]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.88359260559082, 9.171764251143587]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.41638946533203, 9.056084473055636]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.3553638458252, 9.089563422776513]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.39192771911621, 9.084986738118896]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.3978500366211, 9.149600847661636]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.42261219024658, 9.154303810167244]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.43969249725342, 9.170107003033555]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.3956184387207, 9.192433638935196]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.37304496765137, 9.207218435288924]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.36248779296875, 9.200911320943845]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.41999435424805, 9.197098613884584]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.35416221618652, 9.160240330194943]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.35399055480957, 9.209722753322538]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.25065040588379, 9.130576518379566]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.25086498260498, 9.127652867702423]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.26361083984375, 9.118585161008337]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.21850681304932, 9.134008599448746]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.16799545288086, 9.138499914865063]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.16069984436035, 9.161887735765267]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.18357372283936, 9.173708168426726]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.0885591506958, 9.19662766972727]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.96358966827393, 9.071736268799187]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.99815797805786, 9.079851668651347]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.82038116455078, 9.11264513293339]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.77986907958984, 9.122475697034343]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.75720977783203, 9.179080907671532]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.65730285644531, 9.250248281832448]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.67790222167969, 9.167218286742647]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.75240325927734, 9.00279567108141]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.76750946044922, 8.94141459419055]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.74176025390625, 8.8701858515395]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8656997680664, 8.868489764147396]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.83136749267578, 8.864758344310685]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.76665115356445, 8.812484923792894]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.78098487854004, 8.840134380043542]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.76330375671387, 8.851753317938075]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.80870819091797, 8.8570114028354]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.88895988464355, 8.902465296776114]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.91427993774414, 8.930616718021247]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.11031723022461, 9.090590346436308]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.12250518798828, 9.046685794432452]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.2886734008789, 9.083471054337185]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.09356689453125, 7.97507645503904]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.91091918945312, 7.764221159433865]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.596435546875, 7.662156228371328]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.37945556640625, 7.93427414567043]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.41104125976562, 8.191260254936935]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.57858276367188, 8.43857170489582]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.63900756835938, 8.002275734557017]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.58132934570312, 7.893467786226641]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.78457641601562, 7.9165918859801945]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.991943359375, 8.242909561981365]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.22265625, 8.32444735239918]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.34762573242188, 8.41140228138905]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.2611083984375, 8.154557987403754]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.343505859375, 8.071625667868567]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.9421615600586, 8.073886106744622]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.96138763427734, 8.230218694183826]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.06232452392578, 8.263856159930784]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.1454086303711, 8.271670514571225]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.8817367553711, 8.312778260101409]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.10111999511719, 8.481580355073913]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.86972045898438, 8.551864473145084]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.14815521240234, 8.555938518259003]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.12515258789062, 8.724972716425178]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.36719512939453, 8.653363065436999]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.10009002685547, 8.751101733932552]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.03691864013672, 8.820996307467166]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.92671203613281, 8.86577617366079]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.7777099609375, 8.818282201339377]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.68295288085938, 8.670333412766155]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.69943237304688, 8.766710402053251]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.96550750732422, 8.964815234449139]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.07537078857422, 8.927509153417187]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-77.9421615600586, 9.105526279673933]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.189697265625, 9.04043306155375]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.24771881103516, 8.99262273025075]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.32324981689453, 9.009577472677096]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.18695068359375, 9.149593089608882]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.05545806884766, 9.186876128225883]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.37268829345703, 9.090271116886273]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.48255157470703, 9.02788770098704]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.55945587158203, 9.11264513293339]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.64631652832031, 9.12552650669989]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.51276397705078, 9.163828893653692]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.36719512939453, 9.208905171586315]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.24531555175781, 9.273289875471466]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.42761993408203, 9.314625410848391]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.49868774414062, 9.344776938675649]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.37783813476562, 9.260413877049405]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.75274658203125, 9.340711716237472]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.69609832763672, 9.194332265653532]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.75652313232422, 9.137729484342227]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.7221908569336, 9.212633027782976]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.10053253173828, 9.061793074976132]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.21314239501953, 9.184503687946924]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.13211822509766, 9.361376104151155]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.00920867919922, 9.316996973738581]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8986587524414, 9.368828532906287]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.8986587524414, 9.422007124194918]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-78.78089904785156, 9.487706933303171]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.03427124023438, 9.556102634342063]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.14241790771484, 9.539512856798172]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.20764923095703, 9.428103510320193]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.30927276611328, 9.360359851482105]),
            {
              "class": 2,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.3377685546875, 9.305138998321146]),
            {
              "class": 2,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.45106506347656, 9.236693697980778]),
            {
              "class": 2,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.49398040771484, 9.071625035443803]),
            {
              "class": 2,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.6505355834961, 9.0919661670871]),
            {
              "class": 2,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.58015441894531, 9.121608465859689]),
            {
              "class": 2,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.6208381652832, 9.163131234045204]),
            {
              "class": 2,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.53655242919922, 9.139065566504952]),
            {
              "class": 2,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.53723907470703, 9.240232053952296]),
            {
              "class": 2,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.4809341430664, 9.309693067621303]),
            {
              "class": 2,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.58084106445312, 9.418092391760153]),
            {
              "class": 2,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.51578140258789, 9.441461551982044]),
            {
              "class": 2,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.64624404907227, 9.465675748764486]),
            {
              "class": 2,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.54753875732422, 9.51223671305473]),
            {
              "class": 2,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.67765808105469, 9.431470583011903]),
            {
              "class": 2,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.73241806030273, 9.386084237904294]),
            {
              "class": 2,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.80451583862305, 9.351024297062008]),
            {
              "class": 2,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.74357604980469, 9.360001333901316]),
            {
              "class": 2,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.75542068481445, 9.300037116300036]),
            {
              "class": 2,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.82013702392578, 9.226338203760388]),
            {
              "class": 2,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.85807418823242, 9.22261049226782]),
            {
              "class": 2,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.78065490722656, 9.184483912028234]),
            {
              "class": 2,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.80314254760742, 9.307490856581547]),
            {
              "class": 2,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.86734390258789, 9.36305008613852]),
            {
              "class": 2,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89583969116211, 9.296649000034364]),
            {
              "class": 2,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.95437622070312, 9.29004207899383]),
            {
              "class": 2,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.99832153320312, 9.283096207114895]),
            {
              "class": 2,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.89343643188477, 9.149742788965138]),
            {
              "class": 2,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.82254028320312, 9.113642320534588]),
            {
              "class": 2,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.04158020019531, 9.050265606244805]),
            {
              "class": 2,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.9833869934082, 9.062451367173557]),
            {
              "class": 2,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.0053596496582, 9.098726506943986]),
            {
              "class": 2,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.1394271850586, 9.146522707988613]),
            {
              "class": 2,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.0790023803711, 9.164317527636413]),
            {
              "class": 2,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.09230613708496, 9.05354164046344]),
            {
              "class": 2,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2152156829834, 9.136682917629173]),
            {
              "class": 2,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.27589797973633, 9.170577982434379]),
            {
              "class": 2,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.30181884765625, 9.160409802329628]),
            {
              "class": 2,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.30731201171875, 9.107276335969585]),
            {
              "class": 2,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36636352539062, 9.078460623708262]),
            {
              "class": 2,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.39752006530762, 9.099309871086712]),
            {
              "class": 2,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42352676391602, 9.052524502391222]),
            {
              "class": 2,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6118392944336, 8.890877651990328]),
            {
              "class": 2,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71380615234375, 8.95023240352153]),
            {
              "class": 2,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71895599365234, 8.815907342115866]),
            {
              "class": 2,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72101593017578, 8.644198759700236]),
            {
              "class": 2,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36979675292969, 8.503651637085701]),
            {
              "class": 2,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36190032958984, 8.325687242486785]),
            {
              "class": 2,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41168212890625, 8.337576718159628]),
            {
              "class": 2,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.27229309082031, 8.309381088814828]),
            {
              "class": 2,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.28173446655273, 8.323968894766372]),
            {
              "class": 2,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.17762184143066, 8.345784483387531]),
            {
              "class": 2,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.16903877258301, 8.338566067803288]),
            {
              "class": 2,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14749526977539, 8.354871005084995]),
            {
              "class": 2,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.13290405273438, 8.369986432026202]),
            {
              "class": 2,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.16303062438965, 8.379327132961153]),
            {
              "class": 2,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.12938499450684, 8.381365074275191]),
            {
              "class": 2,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.24946212768555, 8.30688838737641]),
            {
              "class": 2,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32902717590332, 8.31342795746401]),
            {
              "class": 2,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3679084777832, 8.311134873871822]),
            {
              "class": 2,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3858470916748, 8.310455439121561]),
            {
              "class": 2,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3924560546875, 8.337207292312238]),
            {
              "class": 2,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42970657348633, 8.319542781472437]),
            {
              "class": 2,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42670249938965, 8.29024171739326]),
            {
              "class": 2,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4525375366211, 8.266204721236788]),
            {
              "class": 2,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47279357910156, 8.26204268959273]),
            {
              "class": 2,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49802780151367, 8.249216560968652]),
            {
              "class": 2,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45880317687988, 8.225686753154204]),
            {
              "class": 2,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51244735717773, 8.263656543809915]),
            {
              "class": 2,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48815727233887, 8.212774454325341]),
            {
              "class": 2,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54085731506348, 8.241061943074838]),
            {
              "class": 2,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4982852935791, 8.195699048147112]),
            {
              "class": 2,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50609588623047, 8.158062606957792]),
            {
              "class": 2,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.49914360046387, 8.126455452812053]),
            {
              "class": 2,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50678253173828, 8.095015759701708]),
            {
              "class": 2,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52626609802246, 8.150840762125151]),
            {
              "class": 2,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5462646484375, 8.170381923385664]),
            {
              "class": 2,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57682037353516, 8.110905857833911]),
            {
              "class": 2,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61638832092285, 8.119997770615415]),
            {
              "class": 2,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57415962219238, 8.109631274183581]),
            {
              "class": 2,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52824020385742, 8.082354216707628]),
            {
              "class": 2,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50643920898438, 8.093316246839478]),
            {
              "class": 2,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4612922668457, 8.045047094394693]),
            {
              "class": 2,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46472549438477, 8.020740378364163]),
            {
              "class": 2,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47794342041016, 8.044367206046994]),
            {
              "class": 2,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42567253112793, 8.012921125641727]),
            {
              "class": 2,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.43210983276367, 7.96727749463794]),
            {
              "class": 2,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.65346717834473, 7.971952588850422]),
            {
              "class": 2,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86967468261719, 7.574126749834905]),
            {
              "class": 2,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.84074974060059, 7.524351010986444]),
            {
              "class": 2,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.79809188842773, 7.5303073838976395]),
            {
              "class": 2,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7326889038086, 7.506991972229132]),
            {
              "class": 2,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7125186920166, 7.452612857704676]),
            {
              "class": 2,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.2462272644043, 8.991146913968292]),
            {
              "class": 2,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.25365161895752, 8.979447631000195]),
            {
              "class": 2,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.27060317993164, 8.97749771379161]),
            {
              "class": 2,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.24584102630615, 8.956683814332825]),
            {
              "class": 2,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.23129272460938, 8.930866120264907]),
            {
              "class": 2,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.1156358718872, 8.9270056864585]),
            {
              "class": 2,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.10982084274292, 8.921070267674795]),
            {
              "class": 2,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.2601318359375, 8.785371913557162]),
            {
              "class": 2,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.23369598388672, 8.762638473075807]),
            {
              "class": 2,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.17945098876953, 8.710719588189848]),
            {
              "class": 2,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.15747833251953, 8.820317617149849]),
            {
              "class": 2,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.96264266967773, 8.914770424683956]),
            {
              "class": 2,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.99628829956055, 8.938172776764315]),
            {
              "class": 2,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.92916870117188, 8.920875530811427]),
            {
              "class": 2,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.91629409790039, 8.89967680781524]),
            {
              "class": 2,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.85243606567383, 8.938681506867333]),
            {
              "class": 2,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.82685852050781, 8.942581747384098]),
            {
              "class": 2,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80213928222656, 8.878646461047262]),
            {
              "class": 2,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.85089111328125, 8.839126501398825]),
            {
              "class": 2,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.86359405517578, 8.876102385670384]),
            {
              "class": 2,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.9253921508789, 8.74565259581052]),
            {
              "class": 2,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.85260772705078, 8.731400423059222]),
            {
              "class": 2,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.84385299682617, 8.74633125710716]),
            {
              "class": 2,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.88985824584961, 8.666071010829999]),
            {
              "class": 2,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.90393447875977, 8.669634726865773]),
            {
              "class": 2,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.95405960083008, 8.672180217628082]),
            {
              "class": 2,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.98375701904297, 8.656397897041899]),
            {
              "class": 2,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.01654434204102, 8.64383944861165]),
            {
              "class": 2,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.06787109375, 8.602936739261775]),
            {
              "class": 2,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.13310241699219, 8.62415239024919]),
            {
              "class": 2,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.07817077636719, 8.566263431373436]),
            {
              "class": 2,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.0833420753479, 8.571305954964732]),
            {
              "class": 2,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.05939531326294, 8.580429591669585]),
            {
              "class": 2,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.05870866775513, 8.574637168642427]),
            {
              "class": 2,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.10580825805664, 8.564685876813753]),
            {
              "class": 2,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.23273038864136, 8.607968913390133]),
            {
              "class": 2,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.2687578201294, 8.606483793014197]),
            {
              "class": 2,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.27249145507812, 8.603343805039138]),
            {
              "class": 2,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.28382110595703, 8.601985964337194]),
            {
              "class": 2,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.29871273040771, 8.59608778730229]),
            {
              "class": 2,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.30152368545532, 8.590613857431125]),
            {
              "class": 2,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.30532169342041, 8.579877936139527]),
            {
              "class": 2,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.30896949768066, 8.575422227486735]),
            {
              "class": 2,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.29731798171997, 8.567974712094813]),
            {
              "class": 2,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.29618072509766, 8.571878840924393]),
            {
              "class": 2,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.29542970657349, 8.560060241015867]),
            {
              "class": 2,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.29886293411255, 8.553333872156031]),
            {
              "class": 2,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.30577230453491, 8.554691886797182]),
            {
              "class": 2,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.43398189544678, 8.428059989423357]),
            {
              "class": 2,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.45226383209229, 8.440073686832914]),
            {
              "class": 2,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.42239475250244, 8.409677885621488]),
            {
              "class": 2,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.43797302246094, 8.415791199450023]),
            {
              "class": 2,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.40518569946289, 8.467920253905806]),
            {
              "class": 2,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.38394260406494, 8.485747791180694]),
            {
              "class": 2,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7579927444458, 8.43294192564568]),
            {
              "class": 2,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.80112266540527, 8.441177400011448]),
            {
              "class": 2,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.81606793403625, 8.307548534503923]),
            {
              "class": 2,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.99235343933105, 8.284466135882004]),
            {
              "class": 2,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.9193115234375, 8.309860891280131]),
            {
              "class": 2,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6223373413086, 8.516704216131947]),
            {
              "class": 2,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.60894775390625, 8.540471056099953]),
            {
              "class": 2,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59092330932617, 8.473241036259646]),
            {
              "class": 2,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65151977539062, 8.537924679700986]),
            {
              "class": 2,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69456386566162, 8.61819735589961]),
            {
              "class": 2,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.7030611038208, 8.624095188322048]),
            {
              "class": 2,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.67636775970459, 8.682516932788275]),
            {
              "class": 2,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65963077545166, 8.695116510791095]),
            {
              "class": 2,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63761520385742, 8.73329446027667]),
            {
              "class": 2,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6746940612793, 8.732149178563073]),
            {
              "class": 2,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.69293308258057, 8.73944498709024]),
            {
              "class": 2,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.72610664367676, 8.747928305793275]),
            {
              "class": 2,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.74880886077881, 8.764936777367527]),
            {
              "class": 2,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5498104095459, 8.60907215225653]),
            {
              "class": 2,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.51882553100586, 8.767538881793977]),
            {
              "class": 2,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.57822036743164, 8.785182634123544]),
            {
              "class": 2,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.5428581237793, 8.828440201019884]),
            {
              "class": 2,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.54354476928711, 8.803673742595748]),
            {
              "class": 2,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.52861022949219, 8.805370128310967]),
            {
              "class": 2,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.61341094970703, 8.79841489745148]),
            {
              "class": 2,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.62285232543945, 8.790950601886124]),
            {
              "class": 2,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63727188110352, 8.7850129866541]),
            {
              "class": 2,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.6175308227539, 8.814869744497907]),
            {
              "class": 2,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.65031814575195, 8.863381827080543]),
            {
              "class": 2,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.63984680175781, 8.879664169071736]),
            {
              "class": 2,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.59349822998047, 8.927828526776702]),
            {
              "class": 2,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.48912811279297, 8.908834889814521]),
            {
              "class": 2,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.44552612304688, 8.952077893235243]),
            {
              "class": 2,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.36639022827148, 8.879664169071736]),
            {
              "class": 2,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.29034423828125, 8.923139581082149]),
            {
              "class": 2,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.37411499023438, 8.823410725318583]),
            {
              "class": 2,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19146728515625, 8.681573028679106]),
            {
              "class": 2,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.35969543457031, 8.314856193091279]),
            {
              "class": 2,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.41874694824219, 8.34203235865302]),
            {
              "class": 2,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19902038574219, 8.251664336147746]),
            {
              "class": 2,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.22511291503906, 8.362413242853314]),
            {
              "class": 2,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.25502490997314, 8.213364191648436]),
            {
              "class": 2,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.28974342346191, 8.222411297335086]),
            {
              "class": 2,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.30613708496094, 8.214398464565733]),
            {
              "class": 2,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.17842102050781, 8.209301426069391]),
            {
              "class": 2,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.19575881958008, 8.289487224277616]),
            {
              "class": 2,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.32982635498047, 8.27589755732995]),
            {
              "class": 2,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.35797882080078, 8.266214633548463]),
            {
              "class": 2,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.26356506347656, 8.294073630919067]),
            {
              "class": 2,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.29257583618164, 8.330932804929969]),
            {
              "class": 2,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.32467651367188, 8.321930653725346]),
            {
              "class": 2,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.27094650268555, 8.349785695522684]),
            {
              "class": 2,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.23026275634766, 8.347917431658542]),
            {
              "class": 2,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.6397476196289, 7.96592741843239]),
            {
              "class": 2,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.69167518615723, 8.023970067333801]),
            {
              "class": 2,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.68429374694824, 8.018105688453742]),
            {
              "class": 2,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.65571212768555, 8.010881337373034]),
            {
              "class": 2,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.62747383117676, 8.009861418655708]),
            {
              "class": 2,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.67631149291992, 8.039098074196506]),
            {
              "class": 2,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.70875549316406, 8.036888400486204]),
            {
              "class": 2,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.69450759887695, 8.054905388741936]),
            {
              "class": 2,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.70746803283691, 8.067142885894047]),
            {
              "class": 2,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.67854309082031, 8.077000600331518]),
            {
              "class": 2,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.70523643493652, 8.080144820702305]),
            {
              "class": 2,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.73519134521484, 8.074876113245546]),
            {
              "class": 2,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.71622276306152, 8.113030196427877]),
            {
              "class": 2,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.72626495361328, 8.129514360124794]),
            {
              "class": 2,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.7258358001709, 8.15135058517164]),
            {
              "class": 2,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.76334381103516, 8.161970886529904]),
            {
              "class": 2,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.78265571594238, 8.167748211920246]),
            {
              "class": 2,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.77227020263672, 8.20351478947942]),
            {
              "class": 2,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.75579071044922, 8.20198564290227]),
            {
              "class": 2,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.87655448913574, 8.281573418283008]),
            {
              "class": 2,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.91187381744385, 8.27482097540608]),
            {
              "class": 2,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.92071437835693, 8.25082550996524]),
            {
              "class": 2,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.95054054260254, 8.239358136808598]),
            {
              "class": 2,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.96968078613281, 8.228017850793638]),
            {
              "class": 2,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.99873447418213, 8.216210017085736]),
            {
              "class": 2,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.01396942138672, 8.224535001157063]),
            {
              "class": 2,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-82.02804565429688, 8.234955855012355]),
            {
              "class": 2,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.93929672241211, 8.275048187570533]),
            {
              "class": 2,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.7738151550293, 8.27507578796919]),
            {
              "class": 2,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.79969310760498, 8.287136665993065]),
            {
              "class": 2,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80080890655518, 8.314739394405157]),
            {
              "class": 2,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80123805999756, 8.365608253760518]),
            {
              "class": 2,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.7846941947937, 8.437227032069888]),
            {
              "class": 2,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.78821325302124, 8.429203732367665]),
            {
              "class": 2,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8103575706482, 8.414154290109943]),
            {
              "class": 2,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8217945098877, 8.416234501745025]),
            {
              "class": 2,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8247127532959, 8.414948432928576]),
            {
              "class": 2,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8172025680542, 8.435889827021658]),
            {
              "class": 2,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8192195892334, 8.441408421157199]),
            {
              "class": 2,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80694580078125, 8.446608562675623]),
            {
              "class": 2,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.81143045425415, 8.46053186173275]),
            {
              "class": 2,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80177450180054, 8.460446965091931]),
            {
              "class": 2,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.79104566574097, 8.461444499439796]),
            {
              "class": 2,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.78720474243164, 8.473499603788525]),
            {
              "class": 2,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80685997009277, 8.476937786150582]),
            {
              "class": 2,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8103575706482, 8.487782715408388]),
            {
              "class": 2,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.79756879806519, 8.488865069233114]),
            {
              "class": 2,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80679559707642, 8.499688439576975]),
            {
              "class": 2,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.8085765838623, 8.511148145724851]),
            {
              "class": 2,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.81430578231812, 8.501407417347458]),
            {
              "class": 2,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.79598093032837, 8.51025684754215]),
            {
              "class": 2,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.786367893219, 8.535827791877907]),
            {
              "class": 2,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.76883697509766, 8.555314674637653]),
            {
              "class": 2,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.81046485900879, 8.558115559962037]),
            {
              "class": 2,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.76042556762695, 8.584935114549037]),
            {
              "class": 2,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.80402755737305, 8.581540338862563]),
            {
              "class": 2,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.73235893249512, 8.595883059206132]),
            {
              "class": 2,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.72523498535156, 8.576363247504402]),
            {
              "class": 2,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.67571067810059, 8.59469492546303]),
            {
              "class": 2,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.64875984191895, 8.604199891098244]),
            {
              "class": 2,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.6624927520752, 8.644253907624133]),
            {
              "class": 2,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.70772552490234, 8.64943006991627]),
            {
              "class": 2,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.58473014831543, 8.686594520706125]),
            {
              "class": 2,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.57940864562988, 8.715865297465132]),
            {
              "class": 2,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.62541389465332, 8.713489783562352]),
            {
              "class": 2,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.55614852905273, 8.702799784257667]),
            {
              "class": 2,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.51700973510742, 8.682776424697181]),
            {
              "class": 2,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.49048805236816, 8.680485548440057]),
            {
              "class": 2,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.44233703613281, 8.688545976989241]),
            {
              "class": 2,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.40302658081055, 8.672424946763751]),
            {
              "class": 2,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.4083480834961, 8.64289621394081]),
            {
              "class": 2,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.44379615783691, 8.609885783291805]),
            {
              "class": 2,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.50293350219727, 8.587141702462592]),
            {
              "class": 2,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.64219379425049, 8.482437046078374]),
            {
              "class": 2,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.63365364074707, 8.47721616507611]),
            {
              "class": 2,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.66807174682617, 8.488167199653745]),
            {
              "class": 2,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.67734146118164, 8.479083805452428]),
            {
              "class": 2,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.66116237640381, 8.496528825840238]),
            {
              "class": 2,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.66871547698975, 8.50709732094017]),
            {
              "class": 2,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.69094562530518, 8.509813674197611]),
            {
              "class": 2,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.6573429107666, 8.525262566726497]),
            {
              "class": 2,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.63545608520508, 8.505017599957325]),
            {
              "class": 2,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.62537097930908, 8.51384572553319]),
            {
              "class": 2,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.62116527557373, 8.503489634490428]),
            {
              "class": 2,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.60271167755127, 8.49551016031661]),
            {
              "class": 2,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.6020679473877, 8.477683076020924]),
            {
              "class": 2,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.57267093658447, 8.47602766193041]),
            {
              "class": 2,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.5470290184021, 8.474666891370662]),
            {
              "class": 2,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.54516220092773, 8.483134926070742]),
            {
              "class": 2,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.54110670089722, 8.492685117161024]),
            {
              "class": 2,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.5483433008194, 8.498705063587607]),
            {
              "class": 2,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.53576374053955, 8.50607868350211]),
            {
              "class": 2,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.52087211608887, 8.527045091090448]),
            {
              "class": 2,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.5319013595581, 8.520339361016566]),
            {
              "class": 2,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.48070335388184, 8.537188345214153]),
            {
              "class": 2,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.49241924285889, 8.523395151333814]),
            {
              "class": 2,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.47671222686768, 8.49907547781174]),
            {
              "class": 2,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.4257287979126, 8.496486381497425]),
            {
              "class": 2,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.39139652252197, 8.51401549518401]),
            {
              "class": 2,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.40985012054443, 8.517623082458877]),
            {
              "class": 2,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.36693477630615, 8.479296036739157]),
            {
              "class": 2,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.36294364929199, 8.456544176258573]),
            {
              "class": 2,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.37942314147949, 8.445804491641944]),
            {
              "class": 2,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.38714790344238, 8.44669593929551]),
            {
              "class": 2,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.35697841644287, 8.443172586554518]),
            {
              "class": 2,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33955478668213, 8.454336834673555]),
            {
              "class": 2,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29942893981934, 8.449285370798231]),
            {
              "class": 2,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.29796981811523, 8.458411916955553]),
            {
              "class": 2,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32097244262695, 8.468745523224968]),
            {
              "class": 2,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32972717285156, 8.47513380541139]),
            {
              "class": 2,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32803201675415, 8.471929065815232]),
            {
              "class": 2,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32899761199951, 8.469488352185472]),
            {
              "class": 2,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32912635803223, 8.46751454636203]),
            {
              "class": 2,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32633686065674, 8.463566904349095]),
            {
              "class": 2,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33062839508057, 8.461147361819101]),
            {
              "class": 2,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.34200096130371, 8.46749332258849]),
            {
              "class": 2,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33854627609253, 8.47776549212734]),
            {
              "class": 2,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.35223627090454, 8.459449428160742]),
            {
              "class": 2,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.34152889251709, 8.447839606328031]),
            {
              "class": 2,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.34526252746582, 8.436951101248495]),
            {
              "class": 2,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.3329029083252, 8.439604274058457]),
            {
              "class": 2,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33755922317505, 8.427908951465561]),
            {
              "class": 2,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.3266372680664, 8.431835732638547]),
            {
              "class": 2,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33500576019287, 8.42376986868479]),
            {
              "class": 2,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33408308029175, 8.414769864104674]),
            {
              "class": 2,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.32457733154297, 8.41368730228896]),
            {
              "class": 2,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.3062310218811, 8.412689644603509]),
            {
              "class": 2,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.30144596099854, 8.420352438758501]),
            {
              "class": 2,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.2913179397583, 8.423302892462742]),
            {
              "class": 2,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28870010375977, 8.43088994769932]),
            {
              "class": 2,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.27119064331055, 8.439136078475533]),
            {
              "class": 2,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.2643027305603, 8.440696137469171]),
            {
              "class": 2,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8784294128418, 7.913807669486246]),
            {
              "class": 2,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.90967178344727, 7.887065171012971]),
            {
              "class": 2,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8949089050293, 7.908956924423954]),
            {
              "class": 2,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.91040134429932, 7.910019601354105]),
            {
              "class": 2,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.92615127563477, 7.902325758543729]),
            {
              "class": 2,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.91477870941162, 7.921581349299325]),
            {
              "class": 2,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.93902587890625, 7.949676743150652]),
            {
              "class": 2,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.91469287872314, 7.979597709580424]),
            {
              "class": 2,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.90344905853271, 7.996512287363063]),
            {
              "class": 2,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87246417999268, 8.022690229634405]),
            {
              "class": 2,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.8848237991333, 8.051883469343307]),
            {
              "class": 2,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73307514190674, 8.108819098412154]),
            {
              "class": 2,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71796894073486, 8.103508278997655]),
            {
              "class": 2,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76122760772705, 8.119440526787553]),
            {
              "class": 2,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.81002235412598, 8.111113350707836]),
            {
              "class": 2,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.82937717437744, 8.11982289297294]),
            {
              "class": 2,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.97292900085449, 8.102323583288072]),
            {
              "class": 2,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.96151351928711, 8.114474670555502]),
            {
              "class": 2,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.95335960388184, 8.112945183269218]),
            {
              "class": 2,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.00391387939453, 8.148376808759286]),
            {
              "class": 2,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.04391098022461, 8.174205082220443]),
            {
              "class": 2,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.14562034606934, 8.15237010485725]),
            {
              "class": 2,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.22097969055176, 8.116938832271742]),
            {
              "class": 2,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.19840621948242, 8.092296535681118]),
            {
              "class": 2,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.13798141479492, 8.030939177661518]),
            {
              "class": 2,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.1160945892334, 8.022695168056114]),
            {
              "class": 2,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.10665321350098, 7.974757619737879]),
            {
              "class": 2,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.07275009155273, 7.956567077595842]),
            {
              "class": 2,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.04682922363281, 7.925964345326509]),
            {
              "class": 2,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.06760025024414, 7.927919629543708]),
            {
              "class": 2,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.11128807067871, 7.907261596210153]),
            {
              "class": 2,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.11369132995605, 7.895444395782339]),
            {
              "class": 2,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.04339599609375, 7.8730843079659225]),
            {
              "class": 2,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.01876258850098, 7.849107512010663]),
            {
              "class": 2,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.94546318054199, 7.8275952375987865]),
            {
              "class": 2,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.01567268371582, 7.822493349431609]),
            {
              "class": 2,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.74092864990234, 7.774867759997621]),
            {
              "class": 2,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71934223175049, 7.761260872230388]),
            {
              "class": 2,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.70294857025146, 7.727922137331139]),
            {
              "class": 2,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67771434783936, 7.705127812900106]),
            {
              "class": 2,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.65896034240723, 7.67417135635241]),
            {
              "class": 2,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.69595336914062, 7.660646291990292]),
            {
              "class": 2,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67715644836426, 7.621514759156397]),
            {
              "class": 2,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.58205604553223, 7.603904401466573]),
            {
              "class": 2,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60488700866699, 7.587569510652168]),
            {
              "class": 2,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7773208618164, 7.302235407784487]),
            {
              "class": 2,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.69835662841797, 7.296786762924936]),
            {
              "class": 2,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6396484375, 7.281462093702955]),
            {
              "class": 2,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.56411743164062, 7.429238022794741]),
            {
              "class": 2,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.37254333496094, 7.375785595108802]),
            {
              "class": 2,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.30078887939453, 7.422769602554384]),
            {
              "class": 2,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.07247924804688, 7.641621167026135]),
            {
              "class": 2,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.17410278320312, 7.7487938930552644]),
            {
              "class": 2,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.17822265625, 7.7328047638861666]),
            {
              "class": 2,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.37769317626953, 7.996716995977495]),
            {
              "class": 2,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45562744140625, 8.34572929253813]),
            {
              "class": 2,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76616287231445, 8.268083286484122]),
            {
              "class": 2,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7659912109375, 8.310040703012248]),
            {
              "class": 2,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86641311645508, 8.266214633548463]),
            {
              "class": 2,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.11824035644531, 8.231731794141526]),
            {
              "class": 2,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.1255145072937, 8.237019671139137]),
            {
              "class": 2,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.11188888549805, 8.209471328406767]),
            {
              "class": 2,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.11188888549805, 8.278955273298012]),
            {
              "class": 2,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.23651504516602, 8.236145092897038]),
            {
              "class": 2,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.23248100280762, 8.221779140683054]),
            {
              "class": 2,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.21591567993164, 8.185844292708156]),
            {
              "class": 2,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.23660087585449, 8.154494223769515]),
            {
              "class": 2,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.27196311950684, 8.174035206311745]),
            {
              "class": 2,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.55460357666016, 7.781770964963727]),
            {
              "class": 2,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.4797592163086, 7.7458824370099215]),
            {
              "class": 2,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.38603210449219, 7.760840612200826]),
            {
              "class": 2,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.33427619934082, 7.795707413507815]),
            {
              "class": 2,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.28938674926758, 7.834907835050634]),
            {
              "class": 2,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.20561599731445, 7.810078494256341]),
            {
              "class": 2,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.2010102935791, 7.843410693851598]),
            {
              "class": 2,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.68746948242188, 8.636092134306189]),
            {
              "class": 2,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.77896499633789, 8.626867990496546]),
            {
              "class": 2,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.69158935546875, 8.610235140326594]),
            {
              "class": 2,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.62927627563477, 8.69593738183514]),
            {
              "class": 2,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.58721923828125, 8.711378677074377]),
            {
              "class": 2,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.49280548095703, 8.703593068856263]),
            {
              "class": 2,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.44062042236328, 8.678818299101897]),
            {
              "class": 2,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.3644027709961, 8.625869479922342]),
            {
              "class": 2,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.42311096191406, 8.567820900831729]),
            {
              "class": 2,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.2936782836914, 8.51349841455909]),
            {
              "class": 2,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.24252319335938, 8.642841065818269]),
            {
              "class": 2,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.17008209228516, 8.612970564508787]),
            {
              "class": 2,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.11446380615234, 8.686963609545895]),
            {
              "class": 2,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.9967041015625, 8.66524238897877]),
            {
              "class": 2,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-81.05026245117188, 8.54167916981792]),
            {
              "class": 2,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.91499328613281, 8.548619346348385]),
            {
              "class": 2,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.87722778320312, 8.56712210831511]),
            {
              "class": 2,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.86761474609375, 8.662187741611898]),
            {
              "class": 2,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.76152801513672, 8.698841870099335]),
            {
              "class": 2,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46592712402344, 8.938003282706664]),
            {
              "class": 2,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41597366333008, 8.911378737767897]),
            {
              "class": 2,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36911010742188, 9.07060794857213]),
            {
              "class": 2,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.31143188476562, 9.111289171818616]),
            {
              "class": 2,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.14217376708984, 9.15162681080099]),
            {
              "class": 2,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.00244140625, 9.095695249279034]),
            {
              "class": 2,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.97566223144531, 9.050943702871605]),
            {
              "class": 2,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.05462646484375, 9.035347157208694]),
            {
              "class": 2,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.97274398803711, 9.082189846492593]),
            {
              "class": 2,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.8922348022461, 9.139763273321433]),
            {
              "class": 2,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.84691619873047, 9.09772927773458]),
            {
              "class": 2,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.77104187011719, 9.16213418497917]),
            {
              "class": 2,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.79850769042969, 9.210599656551397]),
            {
              "class": 2,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.71027374267578, 9.087898033125951]),
            {
              "class": 2,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.75696563720703, 9.07365920053864]),
            {
              "class": 2,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.63680267333984, 9.09366120926296]),
            {
              "class": 2,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.67697143554688, 9.028904908651601]),
            {
              "class": 2,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.51011657714844, 8.991944524028472]),
            {
              "class": 2,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.48471069335938, 9.060097882173059]),
            {
              "class": 2,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.62478637695312, 8.973293355423495]),
            {
              "class": 2,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.44076538085938, 9.041111176706861]),
            {
              "class": 2,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.4582748413086, 9.171285515737928]),
            {
              "class": 2,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.49089050292969, 9.24042126055727]),
            {
              "class": 2,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.33845520019531, 9.311915033544823]),
            {
              "class": 2,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.44385528564453, 9.351552203921068]),
            {
              "class": 2,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.58187103271484, 9.247537406816726]),
            {
              "class": 2,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.6786880493164, 9.430135615096093]),
            {
              "class": 2,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.56710815429688, 9.479241167844584]),
            {
              "class": 2,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.50187683105469, 9.49109318096499]),
            {
              "class": 2,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.76005554199219, 9.350197161423907]),
            {
              "class": 2,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.88433837890625, 9.346470767350956]),
            {
              "class": 2,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.96879577636719, 9.319368520524211]),
            {
              "class": 2,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.96845245361328, 9.217038625296802]),
            {
              "class": 2,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.83558654785156, 9.146542486021458]),
            {
              "class": 2,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.91918563842773, 9.245145601524742]),
            {
              "class": 2,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.8599624633789, 9.22227160745191]),
            {
              "class": 2,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.81773376464844, 9.23176025923869]),
            {
              "class": 2,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.77069854736328, 9.368131280421482]),
            {
              "class": 2,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-79.80829238891602, 9.411995828904534]),
            {
              "class": 2,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22388458251953, 8.685406672779242]),
            {
              "class": 2,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.27203559875488, 8.708144822096347]),
            {
              "class": 2,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.22354125976562, 8.737413911929112]),
            {
              "class": 2,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.29890060424805, 8.709247756908052]),
            {
              "class": 2,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2126407623291, 8.740298277681099]),
            {
              "class": 2,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.17702102661133, 8.771939999288078]),
            {
              "class": 2,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.19392967224121, 8.717816601161584]),
            {
              "class": 2,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.13758182525635, 8.685908324800122]),
            {
              "class": 2,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.0961685180664, 8.662187741611898]),
            {
              "class": 2,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.19264221191406, 8.555938518259003]),
            {
              "class": 2,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.07591247558594, 8.624851160502093]),
            {
              "class": 2,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.18028259277344, 8.52062868151177]),
            {
              "class": 2,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.29804229736328, 8.574271181644704]),
            {
              "class": 2,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41030883789062, 8.605842027767611]),
            {
              "class": 2,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42816162109375, 8.729723583064377]),
            {
              "class": 2,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52085876464844, 8.683230364210653]),
            {
              "class": 2,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.42404174804688, 8.799282900305158]),
            {
              "class": 2,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.19538879394531, 8.917219625536433]),
            {
              "class": 2,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.20852088928223, 8.91391267261292]),
            {
              "class": 2,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.16663551330566, 8.964700770182128]),
            {
              "class": 2,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.20637512207031, 8.980893814203954]),
            {
              "class": 2,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50094604492188, 9.007243428025234]),
            {
              "class": 2,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60874938964844, 9.000461582647521]),
            {
              "class": 2,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68496704101562, 8.938740958027658]),
            {
              "class": 2,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.12123107910156, 8.556540416767861]),
            {
              "class": 2,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.119149684906, 8.538310522715141]),
            {
              "class": 2,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.12816190719604, 8.541396760627515]),
            {
              "class": 2,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.09393692016602, 8.523140503073476]),
            {
              "class": 2,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.11655330657959, 8.524371301427044]),
            {
              "class": 2,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.07462501525879, 8.533453621894106]),
            {
              "class": 2,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.06802678108215, 8.549767832919942]),
            {
              "class": 2,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.06122469902039, 8.550096730613296]),
            {
              "class": 2,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.06138563156128, 8.539498832614411]),
            {
              "class": 2,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21289825439453, 8.518251940626387]),
            {
              "class": 2,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.21873474121094, 8.598713356799331]),
            {
              "class": 2,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44060707092285, 8.48715346527624]),
            {
              "class": 2,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48498153686523, 8.533840536649276]),
            {
              "class": 2,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54523468017578, 8.572883523501186]),
            {
              "class": 2,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59879302978516, 8.572713780051814]),
            {
              "class": 2,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.68187713623047, 8.614468380497422]),
            {
              "class": 2,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.57750701904297, 8.64493275263171]),
            {
              "class": 2,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48892974853516, 8.693891218266236]),
            {
              "class": 2,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45682907104492, 8.658509395862959]),
            {
              "class": 2,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.40593147277832, 8.704072419239294]),
            {
              "class": 2,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.36224365234375, 8.687442981207537]),
            {
              "class": 2,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44558525085449, 8.595543592802402]),
            {
              "class": 2,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46627044677734, 8.542922631890269]),
            {
              "class": 2,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46661376953125, 8.519495478963767]),
            {
              "class": 2,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.45966148376465, 8.51058259811952]),
            {
              "class": 2,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.48154830932617, 8.488341934004701]),
            {
              "class": 2,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46343803405762, 8.49054908045334]),
            {
              "class": 2,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4788875579834, 8.523569869618083]),
            {
              "class": 2,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54137229919434, 8.477306011486728]),
            {
              "class": 2,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52180290222168, 8.46609998136749]),
            {
              "class": 2,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54523468017578, 8.495218002267624]),
            {
              "class": 2,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.54712295532227, 8.42415937094811]),
            {
              "class": 2,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.59673309326172, 8.409046051625674]),
            {
              "class": 2,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.56034088134766, 8.38713918332591]),
            {
              "class": 2,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.52326202392578, 8.369137266281951]),
            {
              "class": 2,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.51871299743652, 8.336188207594912]),
            {
              "class": 2,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46592712402344, 8.344765421037136]),
            {
              "class": 2,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.47296524047852, 8.285315526795545]),
            {
              "class": 2,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4074764251709, 8.356229719118225]),
            {
              "class": 2,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3085994720459, 8.451667492311644]),
            {
              "class": 2,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.30147552490234, 8.496491334719309]),
            {
              "class": 2,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32155990600586, 8.520938497285346]),
            {
              "class": 2,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32422065734863, 8.547930423700784]),
            {
              "class": 2,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.30276298522949, 8.596646857502918]),
            {
              "class": 2,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.34233093261719, 8.575429666143584]),
            {
              "class": 2,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32628059387207, 8.58340746924713]),
            {
              "class": 2,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.33288955688477, 8.593761389195302]),
            {
              "class": 2,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.30696868896484, 8.647054135398403]),
            {
              "class": 2,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32662391662598, 8.672085549213039]),
            {
              "class": 2,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3276538848877, 8.708568986751676]),
            {
              "class": 2,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.35469055175781, 8.71679848951355]),
            {
              "class": 2,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3459358215332, 8.745218573368605]),
            {
              "class": 2,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.32310485839844, 8.776266096550374]),
            {
              "class": 2,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.2946949005127, 8.80849848171955]),
            {
              "class": 2,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.3444766998291, 8.851922934753114]),
            {
              "class": 2,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.39983749389648, 8.874057257598372]),
            {
              "class": 2,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.41211128234863, 8.902295661924073]),
            {
              "class": 2,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.44060707092285, 8.879315023240475]),
            {
              "class": 2,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.46232223510742, 8.87337883073706]),
            {
              "class": 2,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4763126373291, 8.847428062736967]),
            {
              "class": 2,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.4939079284668, 8.905857107804758]),
            {
              "class": 2,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.50257682800293, 8.895427061241787]),
            {
              "class": 2,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.53321838378906, 8.862184606529748]),
            {
              "class": 2,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.5598258972168, 8.853110250268832]),
            {
              "class": 2,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.61999320983887, 8.81579278989162]),
            {
              "class": 2,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.67046165466309, 8.795436221549023]),
            {
              "class": 2,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.64866065979004, 8.71993753045736]),
            {
              "class": 2,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.62213897705078, 8.677600721409059]),
            {
              "class": 2,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63029289245605, 8.631101044365213]),
            {
              "class": 2,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.65048456192017, 8.611533188874661]),
            {
              "class": 2,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.66211462020874, 8.614651893314955]),
            {
              "class": 2,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.6441330909729, 8.619425370709667]),
            {
              "class": 2,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.63855409622192, 8.604362192730095]),
            {
              "class": 2,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.60647487640381, 8.622225782726497]),
            {
              "class": 2,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72730302810669, 8.449134320413728]),
            {
              "class": 2,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72172403335571, 8.447966955447196]),
            {
              "class": 2,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.70279836654663, 8.45072617603798]),
            {
              "class": 2,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.71560859680176, 8.435040805541083]),
            {
              "class": 2,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73575735092163, 8.421689697541183]),
            {
              "class": 2,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75586318969727, 8.418059984382406]),
            {
              "class": 2,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.74062824249268, 8.402840290470792]),
            {
              "class": 2,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.74275255203247, 8.383989967334534]),
            {
              "class": 2,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.73522090911865, 8.370361123748898]),
            {
              "class": 2,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.72073698043823, 8.36339791669803]),
            {
              "class": 2,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.75193643569946, 8.359661510399128]),
            {
              "class": 2,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7680082321167, 8.349959424616562]),
            {
              "class": 2,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.78809261322021, 8.337412168408282]),
            {
              "class": 2,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.77300786972046, 8.321573601752146]),
            {
              "class": 2,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.80345630645752, 8.307624092379934]),
            {
              "class": 2,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.81298351287842, 8.299322093475736]),
            {
              "class": 2,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.80553770065308, 8.255133830427255]),
            {
              "class": 2,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7650899887085, 8.335553222053367]),
            {
              "class": 2,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.7908821105957, 8.334565979597624]),
            {
              "class": 2,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.80662131309509, 8.316805805529127]),
            {
              "class": 2,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-80.79837083816528, 8.30575438835099]),
            {
              "class": 2,
              "system:index": "756"
            })]),
    panama = /* color: #0b4a8b */ee.Geometry.Polygon(
        [[[-82.738037109375, 9.786114693437106],
          [-83.067626953125, 9.580348552981992],
          [-83.111572265625, 7.984347389550114],
          [-82.529296875, 7.984347389550114],
          [-82.100830078125, 8.104007872426935],
          [-81.749267578125, 7.886417255243569],
          [-81.40869140625, 7.527143818847037],
          [-80.958251953125, 7.080360346789022],
          [-80.09033203125, 7.200272710947484],
          [-79.892578125, 7.429107864064015],
          [-80.233154296875, 8.125760516800703],
          [-79.639892578125, 8.549697632331217],
          [-79.51904296875, 8.832062080112761],
          [-79.0576171875, 8.875483755299815],
          [-78.563232421875, 8.517103519869258],
          [-78.486328125, 7.962587156038866],
          [-78.123779296875, 7.080360346789022],
          [-77.94322063082097, 7.156689551825588],
          [-77.838134765625, 7.258854756501894],
          [-77.79203587959057, 7.382804749136646],
          [-77.63741004509882, 7.437278785002429],
          [-77.55004424016357, 7.487659205969335],
          [-77.4708921164974, 7.5734243431763435],
          [-77.3822021484375, 7.706818645385934],
          [-77.3307575348532, 7.764653783317823],
          [-77.32441605011581, 7.845774988824847],
          [-77.29609743097836, 7.8724762785215425],
          [-77.22709891150635, 7.904103170146744],
          [-77.1549874500314, 7.904783137172882],
          [-77.14278104865889, 7.980086538572556],
          [-77.18551099029162, 8.0309091489701],
          [-77.22015380859375, 8.152949663821095],
          [-77.395906125539, 8.510121670175415],
          [-77.27783203125, 8.918900292395039],
          [-78.11279296875, 9.450326524920236],
          [-78.62069186142548, 9.645783384525565],
          [-79.25537109375, 9.71032079845572],
          [-79.68668886421062, 9.69704556725104],
          [-80.123291015625, 9.547847687685096],
          [-80.738525390625, 9.114210473732474],
          [-81.32080078125, 8.897192667629188],
          [-81.80419921875, 9.276887506226982],
          [-82.320556640625, 9.580348552981992]]]),
    input2 = ee.Image("users/images/input/Panama_2010_InputTOA3seasonV2");
/***** End of imports. If edited, may not auto-convert in the playground. *****/
var zones=ee.FeatureCollection("ft:1emWmrrMBzdiKOitmcYSBmoCozs4Fpqq_f6A86pnR");
var zones2=ee.FeatureCollection("ft:13cK2cS_HzpvNGVZlIfH9zInVbJOMQgjXQKwgLHpL");
var countries = ee.FeatureCollection("ft:1tdSwUL7MVpOauSgRzqVTOwdfy17KDbw-1d9omPw");

print(input2);

//add layer to map
//Map.addLayer(image, {palette: '00FF00'}, 'cropland');
//print(input1)
//print(input2)

//create bounds for training samples inside area of interest
function buffer1(geometry) {
  return geometry.buffer(45).bounds();
} 

//buffer function of 1km********************************************************
function buffer2(geometry) {
  return geometry.buffer(1000);
}
function clean_output_noise_in(image00,studyarea,px,nc){
  image00=image00.unmask().focal_max({kernel: ee.Kernel.circle({
    radius: ee.Number(px),units:'meters'}),iterations: 1})
  function invert_image(in_img,studyarea){
    in_img=in_img.clip(studyarea).subtract(1).abs()
    return in_img.updateMask(in_img.eq(1))
  }
  function make_binary_gt(in_img,studyarea,thresh){
    in_img=ee.Image(in_img.unmask()).clip(studyarea)
    var image01=in_img.updateMask(in_img.gt(ee.Number(thresh)
                .subtract(1))).multiply(0).add(1)
    image01=ee.Image(image01.unmask()).clip(studyarea)
    var image02=in_img.multiply(0)
    var out_img=in_img.multiply(image02).add(image01)
    return out_img.updateMask(out_img.eq(1))
  }
  image00=ee.Image(invert_image(image00,studyarea)).byte()
  var temp_img=image00.connectedPixelCount(ee.Number(nc), true)
  temp_img=make_binary_gt(temp_img,studyarea,ee.Number(nc))
  return ee.Image(invert_image(temp_img.unmask(),studyarea))
  
}
function clean_output_noise(image){
  image=image.clip(studyArea)
  function make_binary_gt(in_img,thresh){
    in_img=in_img.unmask()
    var image1=in_img.updateMask(in_img.gt(ee.Number(thresh).subtract(1))).multiply(0).add(1)
    image1=image1.unmask()
    var image2=in_img.multiply(0)
    var out_img=in_img.multiply(image2).add(image1)
    return out_img.updateMask(out_img.eq(1))
  }
  var kernel = ee.Kernel.square({radius: 45,units:'meters'});
  var temp_img=image
  //.unmask().focal_mode({kernel: kernel, iterations: 1})
  //classified2=classified2.updateMask(classified2.eq(1))
              //.focal_max({kernel: kernel, iterations: 2});
  temp_img=temp_img.connectedPixelCount(400, true)
  return make_binary_gt(temp_img,100)
}

var region = countries.filterMetadata('Country','equals','Panama').geometry()
var studyArea = panama
studyArea=buffer2(studyArea);

//visual parameters for FCC display 
var vizParams = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  max: 255,
  gamma: [1.5,1.6, 1.7]
};


//add all max val to map
//prev=clean_output_noise(prev)
//Map.addLayer(input.clip(studyArea),vizParams,'FCC');

//var input=ee.ImageCollection([input1,input2]).mosaic()


//add layer to map
//Map.addLayer(input1.select([0]), {min:0,max:0.5}, 'inp1');
//Map.addLayer(input2.select([0]), {min:0,max:0.5}, 'inp2');

//prev2=clean_output_noise(clean_output_noise_in(clean_output_noise(prev2),studyArea,16,50).byte()).reproject('EPSG:3857',null,30)
//Map.addLayer(prev2.clip(studyArea),{palette:'00ff00'},'clean');

//throw('stop')


//var studyArea = zones.filterMetadata('name','equals','CenAM1');
var studyArea = region
studyArea=buffer1(studyArea);

input2=input2.clip(studyArea)
//print(CropSamples);
var CropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer1);
print('Crop:',CropSamplesArea);

//print(NonCropSamples);
var NonCropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer1);
print('Non-crop:',NonCropSamplesArea);

//print(NonCropSamples);
//var NonCropSamplesArea2 = NonCropClass2.filterBounds(studyArea).map(buffer);
//print('Non-crop:',NonCropSamplesArea2);

//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                    .merge(NonCropSamplesArea)
//                    .merge(NonCropSamplesArea2);
                    
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);


print(input);

var training = input2.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});


//build classifier
var classifier = ee.Classifier.randomForest(400,5).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input2.classify(classifier);
//studyArea = zones.filterMetadata('name','equals','CenAM1');
classified = classified.updateMask(classified.eq(1)).clip(studyArea);


Export.table.toDrive({
  collection: training,
  description: 'RandomForestTrainingTable_Panama_v1',
  folder: 'data',
  fileNamePrefix: 'RFtable_Panama_2010_v1',
  fileFormat: 'CSV'
});


var classified2=classified//clean_output_noise(classified)
//Map.addLayer(prev2, {palette: '00FF00'}, 'prev2');
Map.addLayer(classified2, {palette: '00ff00'}, 'cropland_final');
//Map.addLayer(prev3, {palette: '0000ff'}, 'prev3');
//Map.addLayer(prev.clip(studyArea), {palette: 'ffff00'}, 'cropland0');


Export.image.toAsset({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  description: 'Panama_v8_asset',
  assetId: 'Panama_2010_v8',
  region: studyArea, 
});

Export.image.toDrive({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  folder: 'data',
  description: 'Panama_v8_drive',
  fileNamePrefix: 'Panama_2010_v8',
  region: studyArea, 
});
