/**** Start of imports. If edited, may not auto-convert in the playground. ****/
var Cropclass = /* color: #ff0000 */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-72.59053230285645, 19.173018010101966]),
            {
              "class": 1,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61324524879456, 19.1629853222217]),
            {
              "class": 1,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61198997497559, 19.17938186318414]),
            {
              "class": 1,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63490676879883, 19.187528857626354]),
            {
              "class": 1,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64058768749237, 19.19818824650973]),
            {
              "class": 1,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61471509933472, 19.19901401635951]),
            {
              "class": 1,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56944477558136, 19.201050773168197]),
            {
              "class": 1,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62932777404785, 19.20106575786107]),
            {
              "class": 1,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54354000091553, 19.23386988055143]),
            {
              "class": 1,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55130767822266, 19.237010141760614]),
            {
              "class": 1,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55924701690674, 19.227731002955434]),
            {
              "class": 1,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56143569946289, 19.244445230445518]),
            {
              "class": 1,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56697177886963, 19.251130444946448]),
            {
              "class": 1,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57559776306152, 19.260165180757895]),
            {
              "class": 1,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58730292320251, 19.260155052408976]),
            {
              "class": 1,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60457634925842, 19.261643912987363]),
            {
              "class": 1,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61569142341614, 19.25897003126645]),
            {
              "class": 1,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62301921844482, 19.274972157691646]),
            {
              "class": 1,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59890079498291, 19.280602914054466]),
            {
              "class": 1,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66076326370239, 19.25065438564863]),
            {
              "class": 1,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66624569892883, 19.25694433426953]),
            {
              "class": 1,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72382736206055, 19.26812586949761]),
            {
              "class": 1,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7433967590332, 19.26630284513478]),
            {
              "class": 1,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75296688079834, 19.260185437453877]),
            {
              "class": 1,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6974880695343, 19.277909087136827]),
            {
              "class": 1,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68170595169067, 19.301868412678473]),
            {
              "class": 1,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68694162368774, 19.31033333739197]),
            {
              "class": 1,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72059798240662, 19.204429545353346]),
            {
              "class": 1,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72053360939026, 19.2084214207716]),
            {
              "class": 1,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7070689201355, 19.195128302472376]),
            {
              "class": 1,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7139139175415, 19.193405792390372]),
            {
              "class": 1,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.521653175354, 19.18386073339274]),
            {
              "class": 1,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52785444259644, 19.17824692650554]),
            {
              "class": 1,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52562284469604, 19.16316774017882]),
            {
              "class": 1,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52169609069824, 19.149850699003732]),
            {
              "class": 1,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5131344795227, 19.144904674782776]),
            {
              "class": 1,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55435466766357, 19.137627263113842]),
            {
              "class": 1,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4579668045044, 19.079396430535365]),
            {
              "class": 1,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42599487304688, 19.0492997698019]),
            {
              "class": 1,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.41221904754639, 19.080937621854822]),
            {
              "class": 1,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37290859222412, 19.12325393962783]),
            {
              "class": 1,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42942810058594, 19.150033131488374]),
            {
              "class": 1,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47268676757812, 19.202281592603022]),
            {
              "class": 1,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4696397781372, 19.23453845732452]),
            {
              "class": 1,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47105598449707, 19.281494095161637]),
            {
              "class": 1,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20154762268066, 19.319607799648]),
            {
              "class": 1,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.17077732086182, 19.331635466770223]),
            {
              "class": 1,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12960004806519, 19.345383179802663]),
            {
              "class": 1,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1541690826416, 19.376215148095312]),
            {
              "class": 1,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.17103481292725, 19.383988013344688]),
            {
              "class": 1,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1757984161377, 19.37224760515761]),
            {
              "class": 1,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19674110412598, 19.329286698998803]),
            {
              "class": 1,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12112426757812, 19.285058771096764]),
            {
              "class": 1,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.09011256694794, 19.25369810265901]),
            {
              "class": 1,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13560819625854, 19.214581282042733]),
            {
              "class": 1,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.55412673950195, 18.93137544655444]),
            {
              "class": 1,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.54794692993164, 18.97099045082013]),
            {
              "class": 1,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.50786399841309, 18.903688072314996]),
            {
              "class": 1,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.45816802978516, 18.86754956367561]),
            {
              "class": 1,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.41525268554688, 18.869904894964893]),
            {
              "class": 1,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.37431144714355, 18.8479746687124]),
            {
              "class": 1,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.34512901306152, 18.822873226740434]),
            {
              "class": 1,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.32864952087402, 18.837577115516776]),
            {
              "class": 1,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28908157348633, 18.821004684649775]),
            {
              "class": 1,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.31277084350586, 18.81702380833008]),
            {
              "class": 1,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.23234748840332, 18.784767112056524]),
            {
              "class": 1,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.23432159423828, 18.85390423488726]),
            {
              "class": 1,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.34109497070312, 18.88298044259002]),
            {
              "class": 1,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.46076440811157, 18.823827800009607]),
            {
              "class": 1,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.14102363586426, 18.776641025215238]),
            {
              "class": 1,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.16411209106445, 18.728851713580486]),
            {
              "class": 1,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.1148452758789, 18.716739689060848]),
            {
              "class": 1,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.06781005859375, 18.68108953823139]),
            {
              "class": 1,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.03875637054443, 18.65258841256554]),
            {
              "class": 1,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.02596759796143, 18.630589263888258]),
            {
              "class": 1,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.97391128540039, 18.597849585004976]),
            {
              "class": 1,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.97803115844727, 18.551393178836488]),
            {
              "class": 1,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.00592613220215, 18.516155984198274]),
            {
              "class": 1,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0529613494873, 18.500528853515267]),
            {
              "class": 1,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0775089263916, 18.465444007871348]),
            {
              "class": 1,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.10806465148926, 18.44557840771041]),
            {
              "class": 1,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.14025115966797, 18.443380023841723]),
            {
              "class": 1,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.21260643005371, 18.42432618558753]),
            {
              "class": 1,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.17793083190918, 18.4428914902728]),
            {
              "class": 1,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.24942779541016, 18.423267577102184]),
            {
              "class": 1,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28616333007812, 18.40730622895931]),
            {
              "class": 1,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.26298904418945, 18.462187509652114]),
            {
              "class": 1,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.25380516052246, 18.375460548328444]),
            {
              "class": 1,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.29354476928711, 18.331306683882172]),
            {
              "class": 1,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.31877899169922, 18.370410309203773]),
            {
              "class": 1,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.22127532958984, 18.341653712537617]),
            {
              "class": 1,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.16857528686523, 18.341083419999062]),
            {
              "class": 1,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.14831924438477, 18.311588584892746]),
            {
              "class": 1,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.14960670471191, 18.29146077109147]),
            {
              "class": 1,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.15887641906738, 18.24867121885699]),
            {
              "class": 1,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.36581420898438, 18.237829524945578]),
            {
              "class": 1,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19356536865234, 18.598663069487518]),
            {
              "class": 1,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20867156982422, 18.60240504804511]),
            {
              "class": 1,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19965934753418, 18.535769268528856]),
            {
              "class": 1,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5151139497757, 18.480708019263215]),
            {
              "class": 1,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53776788711548, 18.484371179818854]),
            {
              "class": 1,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63894081115723, 18.47606790352395]),
            {
              "class": 1,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62791156768799, 18.493203144960116]),
            {
              "class": 1,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64898300170898, 18.514161976634362]),
            {
              "class": 1,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62138843536377, 18.526613969736985]),
            {
              "class": 1,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63241767883301, 18.535118241255848]),
            {
              "class": 1,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63216018676758, 18.540285701942206]),
            {
              "class": 1,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6152515411377, 18.486691141011622]),
            {
              "class": 1,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63919830322266, 18.46389717892288]),
            {
              "class": 1,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64679431915283, 18.448631671966172]),
            {
              "class": 1,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60400772094727, 18.541058773172058]),
            {
              "class": 1,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57353782653809, 18.534385832609143]),
            {
              "class": 1,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59199142456055, 18.556600831289714]),
            {
              "class": 1,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57671356201172, 18.516725696376476]),
            {
              "class": 1,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19236636161804, 18.882564233583125]),
            {
              "class": 1,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.18493127822876, 18.87985377402438]),
            {
              "class": 1,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1879460811615, 18.867935352963265]),
            {
              "class": 1,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.18082213401794, 18.86988459052622]),
            {
              "class": 1,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.16869854927063, 18.871021635304476]),
            {
              "class": 1,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.15770149230957, 18.874341355835178]),
            {
              "class": 1,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.15968632698059, 18.88103135734747]),
            {
              "class": 1,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1650185585022, 18.883021048291425]),
            {
              "class": 1,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1797707080841, 18.889324964036067]),
            {
              "class": 1,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.18769931793213, 18.895344423751148]),
            {
              "class": 1,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1979775428772, 18.902023435991396]),
            {
              "class": 1,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20723116397858, 18.91445198233094]),
            {
              "class": 1,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8639566898346, 18.775269709416484]),
            {
              "class": 1,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.87280797958374, 18.77713875930075]),
            {
              "class": 1,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.87454605102539, 18.783553302734095]),
            {
              "class": 1,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97666311264038, 18.779881349322448]),
            {
              "class": 1,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97125577926636, 18.78674778631225]),
            {
              "class": 1,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.98169493675232, 18.788342466095465]),
            {
              "class": 1,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.99241304397583, 18.776976234046707]),
            {
              "class": 1,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.99521327018738, 18.771551863790616]),
            {
              "class": 1,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.00506234169006, 18.777646649709393]),
            {
              "class": 1,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.00109267234802, 18.777159074946468]),
            {
              "class": 1,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.01085591316223, 18.771734710574695]),
            {
              "class": 1,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.96014070510864, 18.780927584864646]),
            {
              "class": 1,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.9482102394104, 18.770972847666044]),
            {
              "class": 1,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64409065246582, 19.004824194557667]),
            {
              "class": 1,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63402700424194, 19.012645049836394]),
            {
              "class": 1,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6286518573761, 19.015870665111148]),
            {
              "class": 1,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63340473175049, 19.026399124664625]),
            {
              "class": 1,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62730002403259, 19.023193999502787]),
            {
              "class": 1,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61913537979126, 19.019998955616703]),
            {
              "class": 1,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61294484138489, 19.01784860578794]),
            {
              "class": 1,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6189637184143, 19.009926558184805]),
            {
              "class": 1,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65272736549377, 19.001770816622265]),
            {
              "class": 1,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64992713928223, 18.991463984332412]),
            {
              "class": 1,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66134798526764, 18.953959383999457]),
            {
              "class": 1,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65198707580566, 18.943756145593156]),
            {
              "class": 1,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71381735801697, 18.97307038445085]),
            {
              "class": 1,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70615696907043, 18.978620129090334]),
            {
              "class": 1,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71213293075562, 18.97703740540163]),
            {
              "class": 1,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72406339645386, 18.976773616658452]),
            {
              "class": 1,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72083401679993, 18.97120351838535]),
            {
              "class": 1,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72072672843933, 18.95815516424747]),
            {
              "class": 1,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71493315696716, 18.9528685653212]),
            {
              "class": 1,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.3622522354126, 19.52027657924074]),
            {
              "class": 1,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.37062072753906, 19.486296091491717]),
            {
              "class": 1,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.39503955841064, 19.51036634104723]),
            {
              "class": 1,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.45730972290039, 19.498877794629955]),
            {
              "class": 1,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.45713806152344, 19.517242897379262]),
            {
              "class": 1,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.48606300354004, 19.52306751626075]),
            {
              "class": 1,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.53567314147949, 19.537466367299448]),
            {
              "class": 1,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.4719009399414, 19.58000827504733]),
            {
              "class": 1,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.52983665466309, 19.480186937661344]),
            {
              "class": 1,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.6224479675293, 19.52970085427819]),
            {
              "class": 1,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.58330917358398, 19.539488575028958]),
            {
              "class": 1,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.27294540405273, 19.47719296356969]),
            {
              "class": 1,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.29088401794434, 19.457933105144498]),
            {
              "class": 1,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.22239112854004, 19.494589606959394]),
            {
              "class": 1,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18651390075684, 19.454614999341057]),
            {
              "class": 1,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.19054794311523, 19.509314606646335]),
            {
              "class": 1,
              "system:index": "173"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.30770683288574, 19.52533258913115]),
            {
              "class": 1,
              "system:index": "174"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.41216278076172, 19.541753417615002]),
            {
              "class": 1,
              "system:index": "175"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.41611099243164, 19.563833967088687]),
            {
              "class": 1,
              "system:index": "176"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.40958786010742, 19.596019240312508]),
            {
              "class": 1,
              "system:index": "177"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.4785099029541, 19.666351563033633]),
            {
              "class": 1,
              "system:index": "178"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.4547348022461, 19.653095872140927]),
            {
              "class": 1,
              "system:index": "179"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.43962860107422, 19.683242897827906]),
            {
              "class": 1,
              "system:index": "180"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.48623466491699, 19.707404916006134]),
            {
              "class": 1,
              "system:index": "181"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.52932167053223, 19.692536413365165]),
            {
              "class": 1,
              "system:index": "182"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.59232139587402, 19.70199100161765]),
            {
              "class": 1,
              "system:index": "183"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.56880378723145, 19.72283760637474]),
            {
              "class": 1,
              "system:index": "184"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.61008834838867, 19.739238256385057]),
            {
              "class": 1,
              "system:index": "185"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.62476539611816, 19.70982899738849]),
            {
              "class": 1,
              "system:index": "186"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.66064262390137, 19.664088473861852]),
            {
              "class": 1,
              "system:index": "187"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.65296077728271, 19.631067988433202]),
            {
              "class": 1,
              "system:index": "188"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.63386344909668, 19.625651495467384]),
            {
              "class": 1,
              "system:index": "189"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.69900894165039, 19.58631581505655]),
            {
              "class": 1,
              "system:index": "190"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.50614738464355, 19.767188190939084]),
            {
              "class": 1,
              "system:index": "191"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.53876304626465, 19.753294615818263]),
            {
              "class": 1,
              "system:index": "192"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.60390853881836, 19.766461231553482]),
            {
              "class": 1,
              "system:index": "193"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.58408164978027, 19.76403800966327]),
            {
              "class": 1,
              "system:index": "194"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.62588119506836, 19.782049744952165]),
            {
              "class": 1,
              "system:index": "195"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.6403865814209, 19.809023153413822]),
            {
              "class": 1,
              "system:index": "196"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.65128707885742, 19.792952720854217]),
            {
              "class": 1,
              "system:index": "197"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.54923439025879, 19.869091185022157]),
            {
              "class": 1,
              "system:index": "198"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.54485702514648, 19.841683927283466]),
            {
              "class": 1,
              "system:index": "199"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.41233444213867, 19.725827012881712]),
            {
              "class": 1,
              "system:index": "200"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.43928527832031, 19.708374552967705]),
            {
              "class": 1,
              "system:index": "201"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.32495880126953, 19.660208818110092]),
            {
              "class": 1,
              "system:index": "202"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.25938415527344, 19.642264189621358]),
            {
              "class": 1,
              "system:index": "203"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.19535446166992, 19.629814935402305]),
            {
              "class": 1,
              "system:index": "204"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.202392578125, 19.57572224153912]),
            {
              "class": 1,
              "system:index": "205"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.16497039794922, 19.59512978401518]),
            {
              "class": 1,
              "system:index": "206"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.12935066223145, 19.636524718298524]),
            {
              "class": 1,
              "system:index": "207"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.1086654663086, 19.612756273800603]),
            {
              "class": 1,
              "system:index": "208"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.09381675720215, 19.633452804292585]),
            {
              "class": 1,
              "system:index": "209"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0873794555664, 19.565613220419067]),
            {
              "class": 1,
              "system:index": "210"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0387134552002, 19.564966221479995]),
            {
              "class": 1,
              "system:index": "211"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0390567779541, 19.536657477115956]),
            {
              "class": 1,
              "system:index": "212"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.96455574035645, 19.531076024414915]),
            {
              "class": 1,
              "system:index": "213"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.93571662902832, 19.558657845759246]),
            {
              "class": 1,
              "system:index": "214"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.92206954956055, 19.509314606646335]),
            {
              "class": 1,
              "system:index": "215"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.92061042785645, 19.464973738927142]),
            {
              "class": 1,
              "system:index": "216"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.98197937011719, 19.48771208762424]),
            {
              "class": 1,
              "system:index": "217"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0211181640625, 19.35933217911175]),
            {
              "class": 1,
              "system:index": "218"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.9031867980957, 19.302597466496902]),
            {
              "class": 1,
              "system:index": "219"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.99365234375, 19.20503745141682]),
            {
              "class": 1,
              "system:index": "220"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.61273574829102, 19.459875379481304]),
            {
              "class": 1,
              "system:index": "221"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.61264991760254, 19.472256831422754]),
            {
              "class": 1,
              "system:index": "222"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.57265281677246, 19.443527177909466]),
            {
              "class": 1,
              "system:index": "223"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.54389953613281, 19.40443049681278]),
            {
              "class": 1,
              "system:index": "224"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.46278953552246, 19.38386656517791]),
            {
              "class": 1,
              "system:index": "225"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.43583869934082, 19.253135956181822]),
            {
              "class": 1,
              "system:index": "226"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.42871475219727, 19.35463540688098]),
            {
              "class": 1,
              "system:index": "227"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.39644241333008, 19.358360444230627]),
            {
              "class": 1,
              "system:index": "228"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.40382385253906, 19.324913041429543]),
            {
              "class": 1,
              "system:index": "229"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.3659725189209, 19.32467005702027]),
            {
              "class": 1,
              "system:index": "230"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.31816482543945, 19.321106244169787]),
            {
              "class": 1,
              "system:index": "231"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.31301498413086, 19.26626233325198]),
            {
              "class": 1,
              "system:index": "232"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.79795837402344, 19.558172575866372]),
            {
              "class": 1,
              "system:index": "233"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.81872940063477, 19.51060904801448]),
            {
              "class": 1,
              "system:index": "234"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.86490631103516, 19.481643445588652]),
            {
              "class": 1,
              "system:index": "235"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.77993392944336, 19.444093727298153]),
            {
              "class": 1,
              "system:index": "236"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.73186874389648, 19.373178771870265]),
            {
              "class": 1,
              "system:index": "237"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8237075805664, 19.353825604895217]),
            {
              "class": 1,
              "system:index": "238"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.90035438537598, 19.3454034259489]),
            {
              "class": 1,
              "system:index": "239"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.94666004180908, 19.405037660019467]),
            {
              "class": 1,
              "system:index": "240"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.08875274658203, 19.436161855911585]),
            {
              "class": 1,
              "system:index": "241"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.10008239746094, 19.687041182394736]),
            {
              "class": 1,
              "system:index": "242"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.11021041870117, 19.72926072161381]),
            {
              "class": 1,
              "system:index": "243"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.09254002571106, 19.730583689696157]),
            {
              "class": 1,
              "system:index": "244"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.67307472229004, 19.49806871131406]),
            {
              "class": 1,
              "system:index": "245"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.62286376953125, 19.38864345811583]),
            {
              "class": 1,
              "system:index": "246"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.63385009765625, 19.342973870468345]),
            {
              "class": 1,
              "system:index": "247"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.57612895965576, 19.29870914192231]),
            {
              "class": 1,
              "system:index": "248"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.63505172729492, 19.24957058592488]),
            {
              "class": 1,
              "system:index": "249"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.48733711242676, 19.237901559805035]),
            {
              "class": 1,
              "system:index": "250"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.44261932373047, 19.196080741483424]),
            {
              "class": 1,
              "system:index": "251"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.38193702697754, 19.2071853681804]),
            {
              "class": 1,
              "system:index": "252"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.33936500549316, 19.237982597569076]),
            {
              "class": 1,
              "system:index": "253"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.40820121765137, 19.133978300864314]),
            {
              "class": 1,
              "system:index": "254"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.18838882446289, 19.130572530019965]),
            {
              "class": 1,
              "system:index": "255"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.17568588256836, 19.193486852092565]),
            {
              "class": 1,
              "system:index": "256"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.2989387512207, 19.220153326147226]),
            {
              "class": 1,
              "system:index": "257"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.19740104675293, 19.229149245882606]),
            {
              "class": 1,
              "system:index": "258"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.21671295166016, 19.26180596502361]),
            {
              "class": 1,
              "system:index": "259"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.15916347503662, 19.254999641613253]),
            {
              "class": 1,
              "system:index": "260"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.14521598815918, 19.222665749696095]),
            {
              "class": 1,
              "system:index": "261"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.15148162841797, 19.194297446918753]),
            {
              "class": 1,
              "system:index": "262"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.11697769165039, 19.194054268890074]),
            {
              "class": 1,
              "system:index": "263"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.07895469665527, 19.19826930385633]),
            {
              "class": 1,
              "system:index": "264"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.1268482208252, 19.146870939868826]),
            {
              "class": 1,
              "system:index": "265"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.17765998840332, 19.085236658688448]),
            {
              "class": 1,
              "system:index": "266"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.22443771362305, 19.108757713864012]),
            {
              "class": 1,
              "system:index": "267"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.27241706848145, 19.126842319471784]),
            {
              "class": 1,
              "system:index": "268"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.31679153442383, 19.183678338342553]),
            {
              "class": 1,
              "system:index": "269"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.33567428588867, 19.104864804598762]),
            {
              "class": 1,
              "system:index": "270"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.3648567199707, 19.091238900776972]),
            {
              "class": 1,
              "system:index": "271"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.40571212768555, 19.01156983083902]),
            {
              "class": 1,
              "system:index": "272"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.35824775695801, 18.95581122263302]),
            {
              "class": 1,
              "system:index": "273"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.45463562011719, 18.881518630784125]),
            {
              "class": 1,
              "system:index": "274"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.42571067810059, 18.914487505639496]),
            {
              "class": 1,
              "system:index": "275"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.3740406036377, 18.88923360463289]),
            {
              "class": 1,
              "system:index": "276"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.37687301635742, 18.927478380893426]),
            {
              "class": 1,
              "system:index": "277"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.31636238098145, 18.875752470945933]),
            {
              "class": 1,
              "system:index": "278"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.29172897338867, 18.92731600118485]),
            {
              "class": 1,
              "system:index": "279"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.26632308959961, 18.962224006318102]),
            {
              "class": 1,
              "system:index": "280"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.13852119445801, 18.89077655675402]),
            {
              "class": 1,
              "system:index": "281"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.11354446411133, 18.93113188261391]),
            {
              "class": 1,
              "system:index": "282"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.1034164428711, 18.960681713774356]),
            {
              "class": 1,
              "system:index": "283"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.07148742675781, 18.96295456096549]),
            {
              "class": 1,
              "system:index": "284"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.0173282623291, 19.02049596647759]),
            {
              "class": 1,
              "system:index": "285"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.00827312469482, 19.057128672185858]),
            {
              "class": 1,
              "system:index": "286"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.01101970672607, 19.067674795836062]),
            {
              "class": 1,
              "system:index": "287"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.87004280090332, 18.941036529726667]),
            {
              "class": 1,
              "system:index": "288"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.94565963745117, 18.892238287753116]),
            {
              "class": 1,
              "system:index": "289"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97329711914062, 18.889477229597247]),
            {
              "class": 1,
              "system:index": "290"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.92694854736328, 18.821410891218967]),
            {
              "class": 1,
              "system:index": "291"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.9759578704834, 18.761362921287137]),
            {
              "class": 1,
              "system:index": "292"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.99458312988281, 18.719991324475327]),
            {
              "class": 1,
              "system:index": "293"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.02659797668457, 18.747140038263492]),
            {
              "class": 1,
              "system:index": "294"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.03294944763184, 18.715560955782284]),
            {
              "class": 1,
              "system:index": "295"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.0792121887207, 18.706577925450826]),
            {
              "class": 1,
              "system:index": "296"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.0436782836914, 18.687228240544066]),
            {
              "class": 1,
              "system:index": "297"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.98441219329834, 18.686374527048045]),
            {
              "class": 1,
              "system:index": "298"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.84283447265625, 18.768514546536878]),
            {
              "class": 1,
              "system:index": "299"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.84952926635742, 18.70202525738593]),
            {
              "class": 1,
              "system:index": "300"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89493370056152, 18.655028068640167]),
            {
              "class": 1,
              "system:index": "301"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.85107421875, 18.623960496134618]),
            {
              "class": 1,
              "system:index": "302"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.82386589050293, 18.65966331856008]),
            {
              "class": 1,
              "system:index": "303"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.77837562561035, 18.66657529812902]),
            {
              "class": 1,
              "system:index": "304"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.78691577911377, 18.631239926544293]),
            {
              "class": 1,
              "system:index": "305"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.80648517608643, 18.637217773103217]),
            {
              "class": 1,
              "system:index": "306"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.80360984802246, 18.609888758380304]),
            {
              "class": 1,
              "system:index": "307"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.80009078979492, 18.591666975937823]),
            {
              "class": 1,
              "system:index": "308"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.76910591125488, 18.542035279198743]),
            {
              "class": 1,
              "system:index": "309"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75082397460938, 18.552695106843483]),
            {
              "class": 1,
              "system:index": "310"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.65786933898926, 18.516481534246697]),
            {
              "class": 1,
              "system:index": "311"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.58701610565186, 18.511842387575662]),
            {
              "class": 1,
              "system:index": "312"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.57658767700195, 18.53084581323618]),
            {
              "class": 1,
              "system:index": "313"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.59959030151367, 18.525271151349617]),
            {
              "class": 1,
              "system:index": "314"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.58894729614258, 18.57596539447271]),
            {
              "class": 1,
              "system:index": "315"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.60757255554199, 18.654784104610805]),
            {
              "class": 1,
              "system:index": "316"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.6247386932373, 18.665843454800985]),
            {
              "class": 1,
              "system:index": "317"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.59684371948242, 18.678975496549533]),
            {
              "class": 1,
              "system:index": "318"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.57032203674316, 18.685195582290177]),
            {
              "class": 1,
              "system:index": "319"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.53298568725586, 18.67129154604106]),
            {
              "class": 1,
              "system:index": "320"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.55023765563965, 18.64461862503533]),
            {
              "class": 1,
              "system:index": "321"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.52968120574951, 18.60134754070344]),
            {
              "class": 1,
              "system:index": "322"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.51903820037842, 18.57393140504093]),
            {
              "class": 1,
              "system:index": "323"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.50114250183105, 18.562703346807037]),
            {
              "class": 1,
              "system:index": "324"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.85819816589355, 19.275174706240232]),
            {
              "class": 1,
              "system:index": "325"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.85665321350098, 19.318514331461238]),
            {
              "class": 1,
              "system:index": "326"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8320198059082, 19.325075030834952]),
            {
              "class": 1,
              "system:index": "327"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.91888046264648, 19.27549878339711]),
            {
              "class": 1,
              "system:index": "328"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.76266860961914, 19.26820689233202]),
            {
              "class": 1,
              "system:index": "329"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.80661392211914, 19.216019900608572]),
            {
              "class": 1,
              "system:index": "330"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.73159790039062, 19.148087174586315]),
            {
              "class": 1,
              "system:index": "331"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.82378005981445, 19.133329588022935]),
            {
              "class": 1,
              "system:index": "332"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8569107055664, 19.156843799897302]),
            {
              "class": 1,
              "system:index": "333"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.90446090698242, 19.13803269838618]),
            {
              "class": 1,
              "system:index": "334"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.98848915100098, 19.151168262416018]),
            {
              "class": 1,
              "system:index": "335"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.03732681274414, 19.160735484156255]),
            {
              "class": 1,
              "system:index": "336"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.29326057434082, 19.28570688565736]),
            {
              "class": 1,
              "system:index": "337"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.31506156921387, 19.29056766308718]),
            {
              "class": 1,
              "system:index": "338"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.24686908721924, 19.256903820074363]),
            {
              "class": 1,
              "system:index": "339"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.22588348388672, 18.546022620870723]),
            {
              "class": 1,
              "system:index": "340"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.18828964233398, 18.60085945817623]),
            {
              "class": 1,
              "system:index": "341"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.0849494934082, 18.57189739134533]),
            {
              "class": 1,
              "system:index": "342"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.0439224243164, 18.607204421870936]),
            {
              "class": 1,
              "system:index": "343"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.95380020101602, 18.62802725546566]),
            {
              "class": 1,
              "system:index": "344"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.91380310058594, 18.52600359905007]),
            {
              "class": 1,
              "system:index": "345"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.83569717407227, 18.482702416384967]),
            {
              "class": 1,
              "system:index": "346"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.82282257080078, 18.59988328892385]),
            {
              "class": 1,
              "system:index": "347"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.73407363891602, 18.52258548293869]),
            {
              "class": 1,
              "system:index": "348"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.67691040039062, 18.46365294149847]),
            {
              "class": 1,
              "system:index": "349"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.67021560668945, 18.508423988494403]),
            {
              "class": 1,
              "system:index": "350"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.56893539428711, 18.58133500997299]),
            {
              "class": 1,
              "system:index": "351"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.63502502441406, 18.60785517400399]),
            {
              "class": 1,
              "system:index": "352"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.34965133666992, 18.558879129277344]),
            {
              "class": 1,
              "system:index": "353"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.3288803100586, 18.582311285526607]),
            {
              "class": 1,
              "system:index": "354"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.51375961303711, 18.772334040309826]),
            {
              "class": 1,
              "system:index": "355"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.50517654418945, 18.7372239479693]),
            {
              "class": 1,
              "system:index": "356"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.5240592956543, 18.700968370498494]),
            {
              "class": 1,
              "system:index": "357"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.20212173461914, 18.339413266739687]),
            {
              "class": 1,
              "system:index": "358"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.16358375549316, 18.350574472252266]),
            {
              "class": 1,
              "system:index": "359"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.18826007843018, 18.362264450741247]),
            {
              "class": 1,
              "system:index": "360"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.65753936767578, 18.443787134087998]),
            {
              "class": 1,
              "system:index": "361"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.60277938842773, 18.445741249840804]),
            {
              "class": 1,
              "system:index": "362"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.65444946289062, 18.43051484325589]),
            {
              "class": 1,
              "system:index": "363"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.62037467956543, 18.425303356867854]),
            {
              "class": 1,
              "system:index": "364"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.84885597229004, 18.42391902924885]),
            {
              "class": 1,
              "system:index": "365"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.81006050109863, 18.414635603256183]),
            {
              "class": 1,
              "system:index": "366"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.86181640625, 18.353222097674145]),
            {
              "class": 1,
              "system:index": "367"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.86713790893555, 18.397370356748134]),
            {
              "class": 1,
              "system:index": "368"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.73761940002441, 18.411622453824254]),
            {
              "class": 1,
              "system:index": "369"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.77512741088867, 18.42823483739566]),
            {
              "class": 1,
              "system:index": "370"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.79066276550293, 18.432550537224685]),
            {
              "class": 1,
              "system:index": "371"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.81135869026184, 18.46387682581745]),
            {
              "class": 1,
              "system:index": "372"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.80087661743164, 18.37252816941728]),
            {
              "class": 1,
              "system:index": "373"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.83254814147949, 18.37391291011496]),
            {
              "class": 1,
              "system:index": "374"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.3817195892334, 19.7186361837963]),
            {
              "class": 1,
              "system:index": "375"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.40583801269531, 19.720817705457673]),
            {
              "class": 1,
              "system:index": "376"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.938232421875, 19.819722415546984]),
            {
              "class": 1,
              "system:index": "377"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.9535961151123, 19.806519825917984]),
            {
              "class": 1,
              "system:index": "378"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97307968139648, 19.793073860837573]),
            {
              "class": 1,
              "system:index": "379"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.82447719573975, 18.21854920407997]),
            {
              "class": 1,
              "system:index": "380"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.8133192062378, 18.225397427404022]),
            {
              "class": 1,
              "system:index": "381"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.8414716720581, 18.23092064927811]),
            {
              "class": 1,
              "system:index": "382"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.84408950805664, 18.23299945489377]),
            {
              "class": 1,
              "system:index": "383"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.85859489440918, 18.193273667770004]),
            {
              "class": 1,
              "system:index": "384"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.86674880981445, 18.238807750644074]),
            {
              "class": 1,
              "system:index": "385"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.79739761352539, 18.233916567119845]),
            {
              "class": 1,
              "system:index": "386"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.76692771911621, 18.2257642889057]),
            {
              "class": 1,
              "system:index": "387"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.36017608642578, 18.28665256678193]),
            {
              "class": 1,
              "system:index": "388"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.37974548339844, 18.295046463756524]),
            {
              "class": 1,
              "system:index": "389"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.39330673217773, 18.297898666306782]),
            {
              "class": 1,
              "system:index": "390"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.35099220275879, 18.31101819322442]),
            {
              "class": 1,
              "system:index": "391"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.3036994934082, 18.29052358918988]),
            {
              "class": 1,
              "system:index": "392"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2922625541687, 18.294740867841732]),
            {
              "class": 1,
              "system:index": "393"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.28327178955078, 18.2679481991001]),
            {
              "class": 1,
              "system:index": "394"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.28099727630615, 18.260042043202475]),
            {
              "class": 1,
              "system:index": "395"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23207378387451, 18.325847765727083]),
            {
              "class": 1,
              "system:index": "396"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20962905883789, 18.305558635050424]),
            {
              "class": 1,
              "system:index": "397"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2270097732544, 18.302665814319333]),
            {
              "class": 1,
              "system:index": "398"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19735527038574, 18.30091380080883]),
            {
              "class": 1,
              "system:index": "399"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.59974026679993, 18.228322107322914]),
            {
              "class": 1,
              "system:index": "400"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.59294891357422, 18.223440819665747]),
            {
              "class": 1,
              "system:index": "401"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.58076095581055, 18.235873057038543]),
            {
              "class": 1,
              "system:index": "402"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.91115009784698, 18.11643088428641]),
            {
              "class": 1,
              "system:index": "403"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.91090869903564, 18.12615342635273]),
            {
              "class": 1,
              "system:index": "404"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.84565591812134, 18.03066869155544]),
            {
              "class": 1,
              "system:index": "405"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.83537769317627, 18.02942404884562]),
            {
              "class": 1,
              "system:index": "406"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.8800311088562, 18.032607052019713]),
            {
              "class": 1,
              "system:index": "407"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.87048244476318, 18.02699595003307]),
            {
              "class": 1,
              "system:index": "408"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.88747692108154, 18.042461754470427]),
            {
              "class": 1,
              "system:index": "409"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.19994354248047, 18.567829291171822]),
            {
              "class": 1,
              "system:index": "410"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.21127319335938, 18.595734507162010]),
            {
              "class": 1,
              "system:index": "411"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.14132118225098, 18.58328755548769]),
            {
              "class": 1,
              "system:index": "412"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.09348678588867, 18.887487615349173]),
            {
              "class": 1,
              "system:index": "413"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.0791745185852, 18.871285591024932]),
            {
              "class": 1,
              "system:index": "414"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06559181213379, 18.854960163049142]),
            {
              "class": 1,
              "system:index": "415"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06769466400146, 18.871732284374207]),
            {
              "class": 1,
              "system:index": "416"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07458257675171, 18.884320425539034]),
            {
              "class": 1,
              "system:index": "417"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.10415124893188, 18.848279274819237]),
            {
              "class": 1,
              "system:index": "418"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1278190612793, 18.83603367383566]),
            {
              "class": 1,
              "system:index": "419"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.10621118545532, 18.79319751284625]),
            {
              "class": 1,
              "system:index": "420"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.9441306591034, 19.112011872386525]),
            {
              "class": 1,
              "system:index": "421"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98785066604614, 19.14897907434852]),
            {
              "class": 1,
              "system:index": "422"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98019027709961, 19.155972212190278]),
            {
              "class": 1,
              "system:index": "423"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.00602531433105, 19.159539611788727]),
            {
              "class": 1,
              "system:index": "424"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.97192907333374, 19.186515571807817]),
            {
              "class": 1,
              "system:index": "425"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.9918417930603, 19.201025229881584]),
            {
              "class": 1,
              "system:index": "426"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.06234931945801, 18.46275740130157]),
            {
              "class": 1,
              "system:index": "427"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.86468124389648, 18.458116799979834]),
            {
              "class": 1,
              "system:index": "428"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.94055557250977, 18.45030076681354]),
            {
              "class": 1,
              "system:index": "429"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.9723129272461, 18.455755744135708]),
            {
              "class": 1,
              "system:index": "430"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.99583053588867, 18.49328454344319]),
            {
              "class": 1,
              "system:index": "431"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.03951835632324, 18.459093779106]),
            {
              "class": 1,
              "system:index": "432"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.03239440917969, 18.369840111627486]),
            {
              "class": 1,
              "system:index": "433"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.13882446289062, 18.393949677950552]),
            {
              "class": 1,
              "system:index": "434"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.16423034667969, 18.375297639696726]),
            {
              "class": 1,
              "system:index": "435"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.1784782409668, 18.401768272537144]),
            {
              "class": 1,
              "system:index": "436"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.16131210327148, 18.27809526321298]),
            {
              "class": 1,
              "system:index": "437"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.17822074890137, 18.279888257021245]),
            {
              "class": 1,
              "system:index": "438"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.09290504455566, 18.276465252759646]),
            {
              "class": 1,
              "system:index": "439"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.11204528808594, 18.119505244106016]),
            {
              "class": 1,
              "system:index": "440"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.13092803955078, 18.10310803483161]),
            {
              "class": 1,
              "system:index": "441"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.14646339416504, 18.096907695219805]),
            {
              "class": 1,
              "system:index": "442"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.17161178588867, 18.111021307542703]),
            {
              "class": 1,
              "system:index": "443"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.1729850769043, 18.168116793951466]),
            {
              "class": 1,
              "system:index": "444"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.15470314025879, 18.15245817322754]),
            {
              "class": 1,
              "system:index": "445"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.06149101257324, 18.097641957410563]),
            {
              "class": 1,
              "system:index": "446"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.0067310333252, 18.073572873577177]),
            {
              "class": 1,
              "system:index": "447"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.97025299072266, 18.07259372232433]),
            {
              "class": 1,
              "system:index": "448"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.99110984802246, 18.032688666728816]),
            {
              "class": 1,
              "system:index": "449"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.03514099121094, 18.031137980784216]),
            {
              "class": 1,
              "system:index": "450"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.95789337158203, 17.976283888327405]),
            {
              "class": 1,
              "system:index": "451"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.9001293182373, 17.980120964571938]),
            {
              "class": 1,
              "system:index": "452"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.87884330749512, 18.00003976447006]),
            {
              "class": 1,
              "system:index": "453"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.8038272857666, 17.991550059155923]),
            {
              "class": 1,
              "system:index": "454"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.83798789978027, 18.02713878030202]),
            {
              "class": 1,
              "system:index": "455"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.82047843933105, 18.04631779211484]),
            {
              "class": 1,
              "system:index": "456"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.78348541259766, 18.007223042049322]),
            {
              "class": 1,
              "system:index": "457"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.72821044921875, 18.02093575901826]),
            {
              "class": 1,
              "system:index": "458"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.7338752746582, 17.999305094585168]),
            {
              "class": 1,
              "system:index": "459"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.5994644165039, 17.991468425390746]),
            {
              "class": 1,
              "system:index": "460"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.5467643737793, 18.014977388121583]),
            {
              "class": 1,
              "system:index": "461"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.50616645812988, 17.991713326572974]),
            {
              "class": 1,
              "system:index": "462"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.56109809875488, 17.994897011004795]),
            {
              "class": 1,
              "system:index": "463"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.52590751647949, 18.01105944538502]),
            {
              "class": 1,
              "system:index": "464"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.46359443664551, 18.021751958513192]),
            {
              "class": 1,
              "system:index": "465"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.47741317749023, 18.010569696417736]),
            {
              "class": 1,
              "system:index": "466"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.45106315612793, 17.988611219813738]),
            {
              "class": 1,
              "system:index": "467"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.3695240020752, 17.973589721140314]),
            {
              "class": 1,
              "system:index": "468"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.33974075317383, 17.99326435949917]),
            {
              "class": 1,
              "system:index": "469"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.2926197052002, 17.998570421639577]),
            {
              "class": 1,
              "system:index": "470"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.19434356689453, 17.976283888327405]),
            {
              "class": 1,
              "system:index": "471"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.13391876220703, 17.9535862859398]),
            {
              "class": 1,
              "system:index": "472"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.07950210571289, 17.97007907798806]),
            {
              "class": 1,
              "system:index": "473"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.04001998901367, 17.983957957423037]),
            {
              "class": 1,
              "system:index": "474"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.01118087768555, 17.99359089100915]),
            {
              "class": 1,
              "system:index": "475"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.90234756469727, 17.993427625329723]),
            {
              "class": 1,
              "system:index": "476"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.86629867553711, 18.010896195880484]),
            {
              "class": 1,
              "system:index": "477"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.86664199829102, 18.05774259237435]),
            {
              "class": 1,
              "system:index": "478"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.8165168762207, 18.136716583015705]),
            {
              "class": 1,
              "system:index": "479"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.78596115112305, 18.17570093361045]),
            {
              "class": 1,
              "system:index": "480"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.7560920715332, 18.205708059238493]),
            {
              "class": 1,
              "system:index": "481"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.6930923461914, 18.213535155446717]),
            {
              "class": 1,
              "system:index": "482"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.63455581665039, 18.273857204179226]),
            {
              "class": 1,
              "system:index": "483"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.65567016601562, 18.354851385452655]),
            {
              "class": 1,
              "system:index": "484"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.70493698120117, 18.364626789278347]),
            {
              "class": 1,
              "system:index": "485"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.89599609375, 18.423430440370172]),
            {
              "class": 1,
              "system:index": "486"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.95281600952148, 18.409423635812352]),
            {
              "class": 1,
              "system:index": "487"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.24670028686523, 18.43141055157181]),
            {
              "class": 1,
              "system:index": "488"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.26008987426758, 18.404700154006118]),
            {
              "class": 1,
              "system:index": "489"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.36926651000977, 18.47032863931402]),
            {
              "class": 1,
              "system:index": "490"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.44479751586914, 18.42489620284244]),
            {
              "class": 1,
              "system:index": "491"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.49784088134766, 18.415287088088913]),
            {
              "class": 1,
              "system:index": "492"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.5526008605957, 18.464467064894613]),
            {
              "class": 1,
              "system:index": "493"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.6818618774414, 18.457953969584864]),
            {
              "class": 1,
              "system:index": "494"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.62778854370117, 18.48530730829006]),
            {
              "class": 1,
              "system:index": "495"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.71585083007812, 18.43141055157181]),
            {
              "class": 1,
              "system:index": "496"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.68581008911133, 18.409749388401245]),
            {
              "class": 1,
              "system:index": "497"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.80047988891602, 18.452906150735696]),
            {
              "class": 1,
              "system:index": "498"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.91892623901367, 18.33774309734216]),
            {
              "class": 1,
              "system:index": "499"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.8876838684082, 18.38254692487064]),
            {
              "class": 1,
              "system:index": "500"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.97128295898438, 18.364463870417264]),
            {
              "class": 1,
              "system:index": "501"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.03376770019531, 18.319247948079784]),
            {
              "class": 1,
              "system:index": "502"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.03994750976562, 18.3419795931433]),
            {
              "class": 1,
              "system:index": "503"
            }),
        ee.Feature(
            ee.Geometry.Point([-67.23461151123047, 18.37326126881833]),
            {
              "class": 1,
              "system:index": "504"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.34849548339844, 18.11175551060337]),
            {
              "class": 1,
              "system:index": "505"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.2314224243164, 18.232938313906754]),
            {
              "class": 1,
              "system:index": "506"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.34180068969727, 18.342549882724626]),
            {
              "class": 1,
              "system:index": "507"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.92097282409668, 18.18255084099314]),
            {
              "class": 1,
              "system:index": "508"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.85690021514893, 18.208765560559062]),
            {
              "class": 1,
              "system:index": "509"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.87981700897217, 18.208847093192944]),
            {
              "class": 1,
              "system:index": "510"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.87852954864502, 18.226334960815347]),
            {
              "class": 1,
              "system:index": "511"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.89260578155518, 18.23860395407741]),
            {
              "class": 1,
              "system:index": "512"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.97822189331055, 18.265543787725044]),
            {
              "class": 1,
              "system:index": "513"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.82125091552734, 18.300180394543297]),
            {
              "class": 1,
              "system:index": "514"
            }),
        ee.Feature(
            ee.Geometry.Point([-66.80022239685059, 18.290319853323393]),
            {
              "class": 1,
              "system:index": "515"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.69694137573242, 17.70948544995622]),
            {
              "class": 1,
              "system:index": "516"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.7153091430664, 17.716149032671378]),
            {
              "class": 1,
              "system:index": "517"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.6548843383789, 17.755062678342156]),
            {
              "class": 1,
              "system:index": "518"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.80491638183594, 17.71157040121573]),
            {
              "class": 1,
              "system:index": "519"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.80045318603516, 17.737732434786246]),
            {
              "class": 1,
              "system:index": "520"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.5111312866211, 18.096744525426494]),
            {
              "class": 1,
              "system:index": "521"
            }),
        ee.Feature(
            ee.Geometry.Point([-65.4261589050293, 18.14470989920909]),
            {
              "class": 1,
              "system:index": "522"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.29714965820312, 19.782372806820053]),
            {
              "class": 1,
              "system:index": "523"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.3177490234375, 19.73374463014124]),
            {
              "class": 1,
              "system:index": "524"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.41679763793945, 19.831470587125658]),
            {
              "class": 1,
              "system:index": "525"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.45954132080078, 19.84971688349328]),
            {
              "class": 1,
              "system:index": "526"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.17012023925781, 19.71435385099788]),
            {
              "class": 1,
              "system:index": "527"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.9771728515625, 19.626257828383604]),
            {
              "class": 1,
              "system:index": "528"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.85821151733398, 19.56706895853795]),
            {
              "class": 1,
              "system:index": "529"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.18529891967773, 19.467239624995084]),
            {
              "class": 1,
              "system:index": "530"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.08058547973633, 19.57175958082328]),
            {
              "class": 1,
              "system:index": "531"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.18195152282715, 19.614615836680283]),
            {
              "class": 1,
              "system:index": "532"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.22109031677246, 19.6079859924227]),
            {
              "class": 1,
              "system:index": "533"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.05844116210938, 19.626096139829674]),
            {
              "class": 1,
              "system:index": "534"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.06376266479492, 19.602407009286537]),
            {
              "class": 1,
              "system:index": "535"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.0120496749878, 19.659481372207193]),
            {
              "class": 1,
              "system:index": "536"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.98342514038086, 19.586477543603273]),
            {
              "class": 1,
              "system:index": "537"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.02239227294922, 19.581463883128308]),
            {
              "class": 1,
              "system:index": "538"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.90137100219727, 19.569818650227024]),
            {
              "class": 1,
              "system:index": "539"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89398956298828, 19.61671792534097]),
            {
              "class": 1,
              "system:index": "540"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.94977951049805, 19.62577276223367]),
            {
              "class": 1,
              "system:index": "541"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.00900268554688, 19.48908761486637]),
            {
              "class": 1,
              "system:index": "542"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.94668960571289, 19.463193377655312]),
            {
              "class": 1,
              "system:index": "543"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88574981689453, 19.50850557552955]),
            {
              "class": 1,
              "system:index": "544"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97020721435547, 19.40345903096802]),
            {
              "class": 1,
              "system:index": "545"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.01998901367188, 19.41786851229719]),
            {
              "class": 1,
              "system:index": "546"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88798141479492, 19.39074848509055]),
            {
              "class": 1,
              "system:index": "547"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8704719543457, 19.40653531957229]),
            {
              "class": 1,
              "system:index": "548"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.9008560180664, 19.441584707849152]),
            {
              "class": 1,
              "system:index": "549"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88240242004395, 19.472580516826326]),
            {
              "class": 1,
              "system:index": "550"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88489151000977, 19.49062495501272]),
            {
              "class": 1,
              "system:index": "551"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.059739112854, 18.500773038403683]),
            {
              "class": 1,
              "system:index": "552"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.0839433670044, 18.525271151349617]),
            {
              "class": 1,
              "system:index": "553"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.09954309463501, 18.547507678415883]),
            {
              "class": 1,
              "system:index": "554"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.12136554718018, 18.53247341745597]),
            {
              "class": 1,
              "system:index": "555"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.1311502456665, 18.542218373457306]),
            {
              "class": 1,
              "system:index": "556"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.89674663543701, 18.088422664636212]),
            {
              "class": 1,
              "system:index": "557"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.9189338684082, 18.08964649245852]),
            {
              "class": 1,
              "system:index": "558"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.89425754547119, 18.101965883487484]),
            {
              "class": 1,
              "system:index": "559"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.85400295257568, 18.099803933780798]),
            {
              "class": 1,
              "system:index": "560"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.91995310783386, 18.15073523146526]),
            {
              "class": 1,
              "system:index": "561"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.96776080131531, 18.194985997298485]),
            {
              "class": 1,
              "system:index": "562"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23370456695557, 18.29724673843435]),
            {
              "class": 1,
              "system:index": "563"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21477890014648, 18.314644222543983]),
            {
              "class": 1,
              "system:index": "564"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2831859588623, 18.311099677863517]),
            {
              "class": 1,
              "system:index": "565"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13079357147217, 18.296594808109063]),
            {
              "class": 1,
              "system:index": "566"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.32749080657959, 18.65852484785414]),
            {
              "class": 1,
              "system:index": "567"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.31955146789551, 18.6461231543884]),
            {
              "class": 1,
              "system:index": "568"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28470420837402, 18.642056828168197]),
            {
              "class": 1,
              "system:index": "569"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.39379501342773, 18.69592774225206]),
            {
              "class": 1,
              "system:index": "570"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.37001991271973, 18.688203907842645]),
            {
              "class": 1,
              "system:index": "571"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.44919872283936, 18.67080366440892]),
            {
              "class": 1,
              "system:index": "572"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.46546363830566, 18.664867658784697]),
            {
              "class": 1,
              "system:index": "573"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.51009559631348, 18.654702783189748]),
            {
              "class": 1,
              "system:index": "574"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.51249885559082, 18.729786498187874]),
            {
              "class": 1,
              "system:index": "575"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.51563167572021, 18.75266678664034]),
            {
              "class": 1,
              "system:index": "576"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.54365539550781, 18.755023727222422]),
            {
              "class": 1,
              "system:index": "577"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.5623664855957, 18.755186273635307]),
            {
              "class": 1,
              "system:index": "578"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.5819787979126, 18.771155695078118]),
            {
              "class": 1,
              "system:index": "579"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.64690971374512, 18.809630502263055]),
            {
              "class": 1,
              "system:index": "580"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.62888526916504, 18.835708736937562]),
            {
              "class": 1,
              "system:index": "581"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.56652927398682, 18.847690369180604]),
            {
              "class": 1,
              "system:index": "582"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.61901473999023, 18.890005082470704]),
            {
              "class": 1,
              "system:index": "583"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.60549640655518, 18.90291665754117]),
            {
              "class": 1,
              "system:index": "584"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.62137508392334, 18.917288748494087]),
            {
              "class": 1,
              "system:index": "585"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.596999168396, 18.930928912392183]),
            {
              "class": 1,
              "system:index": "586"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.62523746490479, 18.933973439822676]),
            {
              "class": 1,
              "system:index": "587"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.83043718338013, 19.047940829429955]),
            {
              "class": 1,
              "system:index": "588"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.82050228118896, 19.053518498854736]),
            {
              "class": 1,
              "system:index": "589"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.81024551391602, 19.05913654357348]),
            {
              "class": 1,
              "system:index": "590"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.79917335510254, 19.070290941888878]),
            {
              "class": 1,
              "system:index": "591"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.78059101104736, 19.07554338950592]),
            {
              "class": 1,
              "system:index": "592"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.79024696350098, 19.048752138453413]),
            {
              "class": 1,
              "system:index": "593"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.78788661956787, 19.034675364412458]),
            {
              "class": 1,
              "system:index": "594"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.82595252990723, 18.949306865840487]),
            {
              "class": 1,
              "system:index": "595"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19309329986572, 19.389291161622516]),
            {
              "class": 1,
              "system:index": "596"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20038890838623, 19.40082794850489]),
            {
              "class": 1,
              "system:index": "597"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20794200897217, 19.36212588463893]),
            {
              "class": 1,
              "system:index": "598"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.23480701446533, 19.332850333398213]),
            {
              "class": 1,
              "system:index": "599"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.26394653320312, 19.368968236542962]),
            {
              "class": 1,
              "system:index": "600"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.24371194839478, 19.41786851229719]),
            {
              "class": 1,
              "system:index": "601"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.32587337493896, 19.346699174082985]),
            {
              "class": 1,
              "system:index": "602"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.28707790374756, 19.347185076980765]),
            {
              "class": 1,
              "system:index": "603"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.26583480834961, 19.326775909894856]),
            {
              "class": 1,
              "system:index": "604"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.29548931121826, 19.247990453874]),
            {
              "class": 1,
              "system:index": "605"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68571853637695, 19.697627414904087]),
            {
              "class": 1,
              "system:index": "606"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67269372940063, 19.692334386154428]),
            {
              "class": 1,
              "system:index": "607"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.76865243911743, 19.66857420880341]),
            {
              "class": 1,
              "system:index": "608"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85749793052673, 19.626399305734825]),
            {
              "class": 1,
              "system:index": "609"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8737199306488, 19.7686622928509]),
            {
              "class": 1,
              "system:index": "610"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.86987900733948, 19.772993650419178]),
            {
              "class": 1,
              "system:index": "611"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.93140888214111, 19.727543876471714]),
            {
              "class": 1,
              "system:index": "612"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.92479991912842, 19.734007197460283]),
            {
              "class": 1,
              "system:index": "613"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.15104961395264, 19.753234030718655]),
            {
              "class": 1,
              "system:index": "614"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14538478851318, 19.76386636338272]),
            {
              "class": 1,
              "system:index": "615"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19305038452148, 19.68930394740021]),
            {
              "class": 1,
              "system:index": "616"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.22231864929199, 19.698193071745962]),
            {
              "class": 1,
              "system:index": "617"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19702005386353, 19.725160460869795]),
            {
              "class": 1,
              "system:index": "618"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1823000907898, 19.698900139986755]),
            {
              "class": 1,
              "system:index": "619"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15949058532715, 19.71805039976124]),
            {
              "class": 1,
              "system:index": "620"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13552236557007, 19.72814982392258]),
            {
              "class": 1,
              "system:index": "621"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11796998977661, 19.70578884134168]),
            {
              "class": 1,
              "system:index": "622"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11764812469482, 19.6866573173019]),
            {
              "class": 1,
              "system:index": "623"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12955713272095, 19.673605356749363]),
            {
              "class": 1,
              "system:index": "624"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14208841323853, 19.667745771709903]),
            {
              "class": 1,
              "system:index": "625"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07054853439331, 19.638747777309646]),
            {
              "class": 1,
              "system:index": "626"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.0691967010498, 19.665502908337714]),
            {
              "class": 1,
              "system:index": "627"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.04414486885071, 19.647336579728364]),
            {
              "class": 1,
              "system:index": "628"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.00042486190796, 19.626722682069826]),
            {
              "class": 1,
              "system:index": "629"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98177814483643, 19.65331815647664]),
            {
              "class": 1,
              "system:index": "630"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.950364112854, 19.67176668243874]),
            {
              "class": 1,
              "system:index": "631"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.84736728668213, 19.623226140922373]),
            {
              "class": 1,
              "system:index": "632"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.76904678344727, 19.557242471157156]),
            {
              "class": 1,
              "system:index": "633"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.72565937042236, 19.597272556751648]),
            {
              "class": 1,
              "system:index": "634"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.38775730133057, 19.79198359766913]),
            {
              "class": 1,
              "system:index": "635"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37674951553345, 19.781585342369244]),
            {
              "class": 1,
              "system:index": "636"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.38269329071045, 19.761473393052952]),
            {
              "class": 1,
              "system:index": "637"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39389419555664, 19.76252347728141]),
            {
              "class": 1,
              "system:index": "638"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40361452102661, 19.748912234266317]),
            {
              "class": 1,
              "system:index": "639"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40387201309204, 19.729119335063913]),
            {
              "class": 1,
              "system:index": "640"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40329265594482, 19.738410185113707]),
            {
              "class": 1,
              "system:index": "641"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40543842315674, 19.716091037564333]),
            {
              "class": 1,
              "system:index": "642"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.38840103149414, 19.700253661904856]),
            {
              "class": 1,
              "system:index": "643"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42599487304688, 19.70374852376061]),
            {
              "class": 1,
              "system:index": "644"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43949174880981, 19.705506026596815]),
            {
              "class": 1,
              "system:index": "645"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72114247083664, 20.023438238207614]),
            {
              "class": 1,
              "system:index": "646"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74836421012878, 20.020048698731784]),
            {
              "class": 1,
              "system:index": "647"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75037050247192, 20.02585497302939]),
            {
              "class": 1,
              "system:index": "648"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78873682022095, 20.046094613114928]),
            {
              "class": 1,
              "system:index": "649"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.87124156951904, 20.083643925342844]),
            {
              "class": 1,
              "system:index": "650"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85916090011597, 20.082656431072106]),
            {
              "class": 1,
              "system:index": "651"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.89587497711182, 20.07679179608241]),
            {
              "class": 1,
              "system:index": "652"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.87305474281311, 20.0364488548724]),
            {
              "class": 1,
              "system:index": "653"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85592079162598, 20.03357617918]),
            {
              "class": 1,
              "system:index": "654"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73810744285583, 20.011671560643325]),
            {
              "class": 1,
              "system:index": "655"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65809178352356, 20.01483698175067]),
            {
              "class": 1,
              "system:index": "656"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8502506017685, 20.057327092620973]),
            {
              "class": 1,
              "system:index": "657"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40068018436432, 19.802699147331754]),
            {
              "class": 1,
              "system:index": "658"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40546524524689, 19.803920563144615]),
            {
              "class": 1,
              "system:index": "659"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39486515522003, 19.804203203484477]),
            {
              "class": 1,
              "system:index": "660"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.27217292785645, 18.86811809494757]),
            {
              "class": 1,
              "system:index": "661"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.27028465270996, 18.92276930528053]),
            {
              "class": 1,
              "system:index": "662"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.26152992248535, 18.94598863296667]),
            {
              "class": 1,
              "system:index": "663"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.30204200744629, 18.95686650778248]),
            {
              "class": 1,
              "system:index": "664"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.40958786010742, 18.95954527856256]),
            {
              "class": 1,
              "system:index": "665"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.39538288116455, 18.952361205366458]),
            {
              "class": 1,
              "system:index": "666"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.16123676300049, 18.818039346959313]),
            {
              "class": 1,
              "system:index": "667"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.1304235458374, 18.842491664267307]),
            {
              "class": 1,
              "system:index": "668"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.11428737640381, 18.82214206056991]),
            {
              "class": 1,
              "system:index": "669"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.00395202636719, 18.74080030996209]),
            {
              "class": 1,
              "system:index": "670"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.94942808151245, 18.80501967708448]),
            {
              "class": 1,
              "system:index": "671"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.84954261779785, 18.779850876345197]),
            {
              "class": 1,
              "system:index": "672"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.89202880859375, 18.56546974861181]),
            {
              "class": 1,
              "system:index": "673"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.85932731628418, 18.530642361618977]),
            {
              "class": 1,
              "system:index": "674"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.87655258178711, 18.974561833073587]),
            {
              "class": 1,
              "system:index": "675"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.79449844360352, 18.960600540087484]),
            {
              "class": 1,
              "system:index": "676"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.72523307800293, 18.927234811271397]),
            {
              "class": 1,
              "system:index": "677"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.00792694091797, 19.663401458328526]),
            {
              "class": 1,
              "system:index": "678"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.01204681396484, 19.659541992825133]),
            {
              "class": 1,
              "system:index": "679"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.01875233650208, 19.660309852002303]),
            {
              "class": 1,
              "system:index": "680"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.04207682609558, 19.645204578713876]),
            {
              "class": 1,
              "system:index": "681"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26184630393982, 19.8093057846884]),
            {
              "class": 1,
              "system:index": "682"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.27003240585327, 19.80480381253957]),
            {
              "class": 1,
              "system:index": "683"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26319813728333, 19.79875724143873]),
            {
              "class": 1,
              "system:index": "684"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2643461227417, 19.81849102769813]),
            {
              "class": 1,
              "system:index": "685"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2862114906311, 19.803713629720313]),
            {
              "class": 1,
              "system:index": "686"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.34543466567993, 19.758666403192247]),
            {
              "class": 1,
              "system:index": "687"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.39932560920715, 19.68536429127199]),
            {
              "class": 1,
              "system:index": "688"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.38627934455872, 19.680232491286514]),
            {
              "class": 1,
              "system:index": "689"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.3111560344696, 19.765401076507963]),
            {
              "class": 1,
              "system:index": "690"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.29869449138641, 19.778496021166347]),
            {
              "class": 1,
              "system:index": "691"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.29439222812653, 19.788162570134986]),
            {
              "class": 1,
              "system:index": "692"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2768988609314, 19.799534526385393]),
            {
              "class": 1,
              "system:index": "693"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22266459465027, 19.815685042710168]),
            {
              "class": 1,
              "system:index": "694"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21064829826355, 19.807266790665288]),
            {
              "class": 1,
              "system:index": "695"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1953489780426, 19.828543718397615]),
            {
              "class": 1,
              "system:index": "696"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19417953491211, 19.839393047450358]),
            {
              "class": 1,
              "system:index": "697"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.17654132843018, 19.909002852988678]),
            {
              "class": 1,
              "system:index": "698"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20067048072815, 19.89666520881759]),
            {
              "class": 1,
              "system:index": "699"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.24003994464874, 19.875538669813505]),
            {
              "class": 1,
              "system:index": "700"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26061248779297, 19.867214403086923]),
            {
              "class": 1,
              "system:index": "701"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26405107975006, 19.859056197681124]),
            {
              "class": 1,
              "system:index": "702"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.24226617944078, 18.914965554329356]),
            {
              "class": 1,
              "system:index": "703"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23828578126268, 18.91137259745968]),
            {
              "class": 1,
              "system:index": "704"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.25087070465088, 18.91770589326395]),
            {
              "class": 1,
              "system:index": "705"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26177120470675, 18.910550469357283]),
            {
              "class": 1,
              "system:index": "706"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2503342628479, 18.93074726101985]),
            {
              "class": 1,
              "system:index": "707"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.24544191622408, 18.935659076493465]),
            {
              "class": 1,
              "system:index": "708"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23588252067566, 18.93384253347004]),
            {
              "class": 1,
              "system:index": "709"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2336938381195, 18.93013834821293]),
            {
              "class": 1,
              "system:index": "710"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19784879946383, 18.89335692375723]),
            {
              "class": 1,
              "system:index": "711"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20604563021334, 18.89626002669152]),
            {
              "class": 1,
              "system:index": "712"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19527387880953, 18.91063268829651]),
            {
              "class": 1,
              "system:index": "713"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.18192720413208, 18.915585693998715]),
            {
              "class": 1,
              "system:index": "714"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21061611175537, 18.92790667052391]),
            {
              "class": 1,
              "system:index": "715"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1930422782898, 18.929652237949615]),
            {
              "class": 1,
              "system:index": "716"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13620090484619, 18.85695424844114]),
            {
              "class": 1,
              "system:index": "717"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.0980920791626, 18.876040807443957]),
            {
              "class": 1,
              "system:index": "718"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1206226348877, 18.863086550021283]),
            {
              "class": 1,
              "system:index": "719"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.0975341796875, 18.88464935755504]),
            {
              "class": 1,
              "system:index": "720"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.10864925384521, 18.894719169623414]),
            {
              "class": 1,
              "system:index": "721"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.12684535980225, 18.897277130252842]),
            {
              "class": 1,
              "system:index": "722"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13476324146905, 18.879012208888575]),
            {
              "class": 1,
              "system:index": "723"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14994454514817, 18.88760030030115]),
            {
              "class": 1,
              "system:index": "724"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.10503363609314, 18.841568682671536]),
            {
              "class": 1,
              "system:index": "725"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1100332736969, 18.839405880892862]),
            {
              "class": 1,
              "system:index": "726"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.88115501403809, 20.039099733560814]),
            {
              "class": 1,
              "system:index": "727"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8771424293518, 20.03778941888728]),
            {
              "class": 1,
              "system:index": "728"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.86008358001709, 20.033273789209776]),
            {
              "class": 1,
              "system:index": "729"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.86607027053833, 20.035874323935722]),
            {
              "class": 1,
              "system:index": "730"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83828258514404, 20.042083178502782]),
            {
              "class": 1,
              "system:index": "731"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.82920598983765, 20.041438114127857]),
            {
              "class": 1,
              "system:index": "732"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83202767372131, 20.045258066111927]),
            {
              "class": 1,
              "system:index": "733"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80980825424194, 20.039190447249084]),
            {
              "class": 1,
              "system:index": "734"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80658960342407, 20.036438775400388]),
            {
              "class": 1,
              "system:index": "735"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7959144115448, 20.025915453924828]),
            {
              "class": 1,
              "system:index": "736"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78816819190979, 20.027165387220816]),
            {
              "class": 1,
              "system:index": "737"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78765320777893, 20.02288130030682]),
            {
              "class": 1,
              "system:index": "738"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.76087403297424, 20.014867224320295]),
            {
              "class": 1,
              "system:index": "739"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75873363018036, 20.01531582175354]),
            {
              "class": 1,
              "system:index": "740"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74722695350647, 20.0148924264572]),
            {
              "class": 1,
              "system:index": "741"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7462774515152, 20.016439829927783]),
            {
              "class": 1,
              "system:index": "742"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65583872795105, 20.012467962396432]),
            {
              "class": 1,
              "system:index": "743"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6574695110321, 20.009060544342063]),
            {
              "class": 1,
              "system:index": "744"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6426449418068, 19.993738852817597]),
            {
              "class": 1,
              "system:index": "745"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64136552810669, 19.9939631818082]),
            {
              "class": 1,
              "system:index": "746"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6582419872284, 20.01327444107571]),
            {
              "class": 1,
              "system:index": "747"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65633761882782, 20.01034085504709]),
            {
              "class": 1,
              "system:index": "748"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.77422070503235, 20.029902101626515]),
            {
              "class": 1,
              "system:index": "749"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.76741325855255, 20.03210454251646]),
            {
              "class": 1,
              "system:index": "750"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75425970554352, 20.017316853148323]),
            {
              "class": 1,
              "system:index": "751"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75589048862457, 20.02401533467504]),
            {
              "class": 1,
              "system:index": "752"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75372326374054, 20.026429540596602]),
            {
              "class": 1,
              "system:index": "753"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73850440979004, 20.03514859764429]),
            {
              "class": 1,
              "system:index": "754"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75343894958496, 20.03698306596358]),
            {
              "class": 1,
              "system:index": "755"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73914813995361, 20.031237681593435]),
            {
              "class": 1,
              "system:index": "756"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71178960800171, 20.023516360560805]),
            {
              "class": 1,
              "system:index": "757"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74740397930145, 20.043282588032067]),
            {
              "class": 1,
              "system:index": "758"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.77272939682007, 20.03230613739464]),
            {
              "class": 1,
              "system:index": "759"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.76498317718506, 20.032457333383537]),
            {
              "class": 1,
              "system:index": "760"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78364062309265, 20.032880681378526]),
            {
              "class": 1,
              "system:index": "761"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78152704238892, 20.034493425196505]),
            {
              "class": 1,
              "system:index": "762"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78954148292542, 20.035067961182758]),
            {
              "class": 1,
              "system:index": "763"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80086040496826, 20.036942748208755]),
            {
              "class": 1,
              "system:index": "764"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.81774759292603, 20.046114770819045]),
            {
              "class": 1,
              "system:index": "765"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.82408833503723, 20.04005726429493]),
            {
              "class": 1,
              "system:index": "766"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8250002861023, 20.041407876670284]),
            {
              "class": 1,
              "system:index": "767"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83151268959045, 20.04100471001298]),
            {
              "class": 1,
              "system:index": "768"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85727262496948, 20.03530987044319]),
            {
              "class": 1,
              "system:index": "769"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.86717534065247, 20.03691250988583]),
            {
              "class": 1,
              "system:index": "770"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.87903070449829, 20.03692258932745]),
            {
              "class": 1,
              "system:index": "771"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.88665890693665, 20.0388880680845]),
            {
              "class": 1,
              "system:index": "772"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.86346316337585, 20.045217750481132]),
            {
              "class": 1,
              "system:index": "773"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.86940693855286, 20.050488931402977]),
            {
              "class": 1,
              "system:index": "774"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83209204673767, 20.084963933475898]),
            {
              "class": 1,
              "system:index": "775"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8961353302002, 18.825780088563032]),
            {
              "class": 1,
              "system:index": "776"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.87510681152344, 18.836990710890923]),
            {
              "class": 1,
              "system:index": "777"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.86549377441406, 18.84084926650856]),
            {
              "class": 1,
              "system:index": "778"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8430061340332, 18.82385826502467]),
            {
              "class": 1,
              "system:index": "779"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8781967163086, 18.73056886828635]),
            {
              "class": 1,
              "system:index": "780"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.91171360015869, 18.605397046448637]),
            {
              "class": 1,
              "system:index": "781"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.91870880126953, 18.596611555850057]),
            {
              "class": 1,
              "system:index": "782"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89634990692139, 18.59814574464932]),
            {
              "class": 1,
              "system:index": "783"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.63014602661133, 18.62481960714837]),
            {
              "class": 1,
              "system:index": "784"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.67306137084961, 18.65377266666491]),
            {
              "class": 1,
              "system:index": "785"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.66550827026367, 18.701014101317725]),
            {
              "class": 1,
              "system:index": "786"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.69812393188477, 18.709811972940223]),
            {
              "class": 1,
              "system:index": "787"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.74138259887695, 18.725691696896785]),
            {
              "class": 1,
              "system:index": "788"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.73880767822266, 18.75397733094103]),
            {
              "class": 1,
              "system:index": "789"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.72696304321289, 18.721789858454564]),
            {
              "class": 1,
              "system:index": "790"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75563049316406, 18.725854271544]),
            {
              "class": 1,
              "system:index": "791"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.76987838745117, 18.776442946955978]),
            {
              "class": 1,
              "system:index": "792"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.77983474731445, 18.767503788360365]),
            {
              "class": 1,
              "system:index": "793"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75987911224365, 18.79124992460857]),
            {
              "class": 1,
              "system:index": "794"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75983619689941, 18.80683253862283]),
            {
              "class": 1,
              "system:index": "795"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75399971008301, 18.82462496608556]),
            {
              "class": 1,
              "system:index": "796"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.77043628692627, 18.85084048263411]),
            {
              "class": 1,
              "system:index": "797"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.79202270507812, 18.84582717997316]),
            {
              "class": 1,
              "system:index": "798"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.79803085327148, 18.849888601241002]),
            {
              "class": 1,
              "system:index": "799"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.7637414932251, 18.864323619821196]),
            {
              "class": 1,
              "system:index": "800"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75279808044434, 18.87646563791164]),
            {
              "class": 1,
              "system:index": "801"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.81489658355713, 18.95867519011957]),
            {
              "class": 1,
              "system:index": "802"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.80931758880615, 18.97097269517739]),
            {
              "class": 1,
              "system:index": "803"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.19156455993652, 18.659383784049652]),
            {
              "class": 1,
              "system:index": "804"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.18675804138184, 18.67515897472084]),
            {
              "class": 1,
              "system:index": "805"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.20066261291504, 18.69296528688479]),
            {
              "class": 1,
              "system:index": "806"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.22791385650635, 18.69387740345062]),
            {
              "class": 1,
              "system:index": "807"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.2558946609497, 18.69441476230305]),
            {
              "class": 1,
              "system:index": "808"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.24263381958008, 18.76356736083478]),
            {
              "class": 1,
              "system:index": "809"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.24349212646484, 18.724995672420565]),
            {
              "class": 1,
              "system:index": "810"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.25434970855713, 18.74618757024071]),
            {
              "class": 1,
              "system:index": "811"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.2619457244873, 18.758164147002535]),
            {
              "class": 1,
              "system:index": "812"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.26913404464722, 18.774356762434234]),
            {
              "class": 1,
              "system:index": "813"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.26276111602783, 18.775596032798763]),
            {
              "class": 1,
              "system:index": "814"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.24857759475708, 18.771167123034793]),
            {
              "class": 1,
              "system:index": "815"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.2022933959961, 18.836990710890923]),
            {
              "class": 1,
              "system:index": "816"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.18645763397217, 18.83597528678311]),
            {
              "class": 1,
              "system:index": "817"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.1974868774414, 18.811205923198077]),
            {
              "class": 1,
              "system:index": "818"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.12938022613525, 18.82180821106985]),
            {
              "class": 1,
              "system:index": "819"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.08642196655273, 18.84426096814227]),
            {
              "class": 1,
              "system:index": "820"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.07376194000244, 18.846129251562687]),
            {
              "class": 1,
              "system:index": "821"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.08509159088135, 18.829313952422854]),
            {
              "class": 1,
              "system:index": "822"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.09576416015625, 18.7090803163895]),
            {
              "class": 1,
              "system:index": "823"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.09893989562988, 18.718103859344346]),
            {
              "class": 1,
              "system:index": "824"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.10825252532959, 18.703226950083717]),
            {
              "class": 1,
              "system:index": "825"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.08846855163574, 18.71911999393071]),
            {
              "class": 1,
              "system:index": "826"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.07370567321777, 18.712006923606513]),
            {
              "class": 1,
              "system:index": "827"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.07323360443115, 18.70501550015879]),
            {
              "class": 1,
              "system:index": "828"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.0794563293457, 18.704893554163238]),
            {
              "class": 1,
              "system:index": "829"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.07464981079102, 18.686925884172943]),
            {
              "class": 1,
              "system:index": "830"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.07941341400146, 18.679242294129313]),
            {
              "class": 1,
              "system:index": "831"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.08014297485352, 18.672981333550624]),
            {
              "class": 1,
              "system:index": "832"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.09645080566406, 18.6657532447277]),
            {
              "class": 1,
              "system:index": "833"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.10263061523438, 18.65703186409031]),
            {
              "class": 1,
              "system:index": "834"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.1085958480835, 18.649358355629158]),
            {
              "class": 1,
              "system:index": "835"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.10323143005371, 18.638745241823408]),
            {
              "class": 1,
              "system:index": "836"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.03156280517578, 18.51104883673178]),
            {
              "class": 1,
              "system:index": "837"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.99345397949219, 18.47123431610906]),
            {
              "class": 1,
              "system:index": "838"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.04838562011719, 18.464721477663783]),
            {
              "class": 1,
              "system:index": "839"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.9666748046875, 18.576545077017467]),
            {
              "class": 1,
              "system:index": "840"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.02435302734375, 18.56905990171128]),
            {
              "class": 1,
              "system:index": "841"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.00186538696289, 18.645360725639005]),
            {
              "class": 1,
              "system:index": "842"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.96306991577148, 18.69284841365496]),
            {
              "class": 1,
              "system:index": "843"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.92255783081055, 18.72016406585754]),
            {
              "class": 1,
              "system:index": "844"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.92805099487305, 18.78375645134723]),
            {
              "class": 1,
              "system:index": "845"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.92221450805664, 18.761327365574466]),
            {
              "class": 1,
              "system:index": "846"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.8868522644043, 18.779530909751536]),
            {
              "class": 1,
              "system:index": "847"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.90264511108398, 18.805613810328712]),
            {
              "class": 1,
              "system:index": "848"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.8634204864502, 18.820562933891622]),
            {
              "class": 1,
              "system:index": "849"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.86796951293945, 18.836404304217602]),
            {
              "class": 1,
              "system:index": "850"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.7769889831543, 18.435736349902612]),
            {
              "class": 1,
              "system:index": "851"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.80016326904297, 18.45983668659458]),
            {
              "class": 1,
              "system:index": "852"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.84737014770508, 18.452997745544906]),
            {
              "class": 1,
              "system:index": "853"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.73235702514648, 18.499073911336755]),
            {
              "class": 1,
              "system:index": "854"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.60635757446289, 18.51014337037662]),
            {
              "class": 1,
              "system:index": "855"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.58558654785156, 18.547090643012076]),
            {
              "class": 1,
              "system:index": "856"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.47177505493164, 18.5588079329256]),
            {
              "class": 1,
              "system:index": "857"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.46181869506836, 18.66341411889296]),
            {
              "class": 1,
              "system:index": "858"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.52516174316406, 18.65137873675753]),
            {
              "class": 1,
              "system:index": "859"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.61305236816406, 18.703254896324008]),
            {
              "class": 1,
              "system:index": "860"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.57477188110352, 18.77104395501652]),
            {
              "class": 1,
              "system:index": "861"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.6092758178711, 18.761454350228156]),
            {
              "class": 1,
              "system:index": "862"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.54524612426758, 18.76665555948619]),
            {
              "class": 1,
              "system:index": "863"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.51795196533203, 18.73235712919445]),
            {
              "class": 1,
              "system:index": "864"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.45495223999023, 18.42971073749736]),
            {
              "class": 1,
              "system:index": "865"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.51022720336914, 18.428733591260997]),
            {
              "class": 1,
              "system:index": "866"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.57528686523438, 18.407886482466278]),
            {
              "class": 1,
              "system:index": "867"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.68824005126953, 18.438667652536854]),
            {
              "class": 1,
              "system:index": "868"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.6477279663086, 18.473676566777126]),
            {
              "class": 1,
              "system:index": "869"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.75038146972656, 18.375633638581053]),
            {
              "class": 1,
              "system:index": "870"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.35179710388184, 18.577150182132563]),
            {
              "class": 1,
              "system:index": "871"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.35394287109375, 18.574668729013666]),
            {
              "class": 1,
              "system:index": "872"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.37952041625977, 18.537930864731546]),
            {
              "class": 1,
              "system:index": "873"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.52423095703125, 18.527839790950743]),
            {
              "class": 1,
              "system:index": "874"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.51848030090332, 18.554937857977585]),
            {
              "class": 1,
              "system:index": "875"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.5009708404541, 18.5131903982022]),
            {
              "class": 1,
              "system:index": "876"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.7114839553833, 19.24691929801267]),
            {
              "class": 1,
              "system:index": "877"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.72148323059082, 19.25267256371835]),
            {
              "class": 1,
              "system:index": "878"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.69963932037354, 19.251781225900544]),
            {
              "class": 1,
              "system:index": "879"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.6904125213623, 19.25182174136096]),
            {
              "class": 1,
              "system:index": "880"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.7915210723877, 19.22287342814963]),
            {
              "class": 1,
              "system:index": "881"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.76937675476074, 19.242323124353007]),
            {
              "class": 1,
              "system:index": "882"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.84877014160156, 19.25066957905182]),
            {
              "class": 1,
              "system:index": "883"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.81418037414551, 19.29053222044075]),
            {
              "class": 1,
              "system:index": "884"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.84834098815918, 19.310378900992568]),
            {
              "class": 1,
              "system:index": "885"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.88044166564941, 19.30608574153603]),
            {
              "class": 1,
              "system:index": "886"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.87889671325684, 19.331357058561867]),
            {
              "class": 1,
              "system:index": "887"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.96446990966797, 19.26460640147422]),
            {
              "class": 1,
              "system:index": "888"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.97940444946289, 19.239405816780028]),
            {
              "class": 1,
              "system:index": "889"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75592803955078, 19.735423538727606]),
            {
              "class": 1,
              "system:index": "890"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7682876586914, 19.744350491540853]),
            {
              "class": 1,
              "system:index": "891"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7390193939209, 19.751378600903095]),
            {
              "class": 1,
              "system:index": "892"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78721332550049, 19.745723824594883]),
            {
              "class": 1,
              "system:index": "893"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75781631469727, 19.755457993672003]),
            {
              "class": 1,
              "system:index": "894"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.79347896575928, 19.76147591730217]),
            {
              "class": 1,
              "system:index": "895"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74423360824585, 19.71531902711443]),
            {
              "class": 1,
              "system:index": "896"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74352550506592, 19.70746804359138]),
            {
              "class": 1,
              "system:index": "897"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74516701698303, 19.691087493820636]),
            {
              "class": 1,
              "system:index": "898"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.88999557495117, 18.184589451972258]),
            {
              "class": 1,
              "system:index": "899"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.90432929992676, 18.16950316667231]),
            {
              "class": 1,
              "system:index": "900"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85431146621704, 18.149093833278066]),
            {
              "class": 1,
              "system:index": "901"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8891372680664, 18.20790946559896]),
            {
              "class": 1,
              "system:index": "902"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.89995193481445, 18.21263831851694]),
            {
              "class": 1,
              "system:index": "903"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85531997680664, 18.171786580094793]),
            {
              "class": 1,
              "system:index": "904"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83326148986816, 18.15539427152853]),
            {
              "class": 1,
              "system:index": "905"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.81060218811035, 18.15490492523775]),
            {
              "class": 1,
              "system:index": "906"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8133487701416, 18.180186022410798]),
            {
              "class": 1,
              "system:index": "907"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97977447509766, 18.176190221627056]),
            {
              "class": 1,
              "system:index": "908"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.96762943267822, 18.17296905030668]),
            {
              "class": 1,
              "system:index": "909"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.02987813949585, 18.184059415409685]),
            {
              "class": 1,
              "system:index": "910"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.16083693504333, 18.29701245125605]),
            {
              "class": 1,
              "system:index": "911"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.1643238067627, 18.278971387502967]),
            {
              "class": 1,
              "system:index": "912"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.15520429611206, 18.274407342689276]),
            {
              "class": 1,
              "system:index": "913"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.17636156082153, 18.28975957845586]),
            {
              "class": 1,
              "system:index": "914"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.17344331741333, 18.299334936245753]),
            {
              "class": 1,
              "system:index": "915"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.19985771179199, 18.30447892592177]),
            {
              "class": 1,
              "system:index": "916"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.20150995254517, 18.30564012225866]),
            {
              "class": 1,
              "system:index": "917"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.19981479644775, 18.301219385836454]),
            {
              "class": 1,
              "system:index": "918"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.19697165489197, 18.308634750565016]),
            {
              "class": 1,
              "system:index": "919"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.1986346244812, 18.30819676394385]),
            {
              "class": 1,
              "system:index": "920"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.20314073562622, 18.30942923509692]),
            {
              "class": 1,
              "system:index": "921"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.20770049095154, 18.309836661647946]),
            {
              "class": 1,
              "system:index": "922"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.20642375946045, 18.31273954807304]),
            {
              "class": 1,
              "system:index": "923"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.20276522636414, 18.314797003010707]),
            {
              "class": 1,
              "system:index": "924"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.21103715896606, 18.307870819692837]),
            {
              "class": 1,
              "system:index": "925"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.21044707298279, 18.302227812602954]),
            {
              "class": 1,
              "system:index": "926"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.18733716011047, 18.31631461499074]),
            {
              "class": 1,
              "system:index": "927"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.32028889656067, 18.297216179255138]),
            {
              "class": 1,
              "system:index": "928"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.32439804077148, 18.300435049848485]),
            {
              "class": 1,
              "system:index": "929"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.31776762008667, 18.295229821046714]),
            {
              "class": 1,
              "system:index": "930"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.34067368507385, 18.295056650277726]),
            {
              "class": 1,
              "system:index": "931"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.34914946556091, 18.29657443524688]),
            {
              "class": 1,
              "system:index": "932"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.35821533203125, 18.298866367219606]),
            {
              "class": 1,
              "system:index": "933"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.36288237571716, 18.300536911865727]),
            {
              "class": 1,
              "system:index": "934"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.36598300933838, 18.302176882098937]),
            {
              "class": 1,
              "system:index": "935"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.36272144317627, 18.30401037080942]),
            {
              "class": 1,
              "system:index": "936"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.36986684799194, 18.30248246489842]),
            {
              "class": 1,
              "system:index": "937"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.37140107154846, 18.30465208727295]),
            {
              "class": 1,
              "system:index": "938"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.45971012115479, 18.412762570624047]),
            {
              "class": 1,
              "system:index": "939"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.45452809333801, 18.412650595201363]),
            {
              "class": 1,
              "system:index": "940"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.34206306934357, 18.647490434704256]),
            {
              "class": 1,
              "system:index": "941"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.34903681278229, 18.644359397347838]),
            {
              "class": 1,
              "system:index": "942"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.36413764953613, 18.557816266366892]),
            {
              "class": 1,
              "system:index": "943"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.36244249343872, 18.55608210740815]),
            {
              "class": 1,
              "system:index": "944"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.36037182807922, 18.553463036286015]),
            {
              "class": 1,
              "system:index": "945"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.35463726520538, 18.565505345401522]),
            {
              "class": 1,
              "system:index": "946"
            }),
        ee.Feature(
            ee.Geometry.Point([-74.35474991798401, 18.56889209170601]),
            {
              "class": 1,
              "system:index": "947"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.46185874938965, 17.857946809630107]),
            {
              "class": 1,
              "system:index": "948"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.4107894897461, 17.806062706568735]),
            {
              "class": 1,
              "system:index": "949"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.39602661132812, 17.790208488272096]),
            {
              "class": 1,
              "system:index": "950"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.3382625579834, 17.822487498206257]),
            {
              "class": 1,
              "system:index": "951"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28264427185059, 17.87216123111977]),
            {
              "class": 1,
              "system:index": "952"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28684997558594, 17.895767728562458]),
            {
              "class": 1,
              "system:index": "953"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.33319854736328, 17.841116772820776]),
            {
              "class": 1,
              "system:index": "954"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.37310981750488, 18.01016157123865]),
            {
              "class": 1,
              "system:index": "955"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.32667541503906, 18.064678715924888]),
            {
              "class": 1,
              "system:index": "956"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.31036758422852, 18.008855564314203]),
            {
              "class": 1,
              "system:index": "957"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28742933273315, 18.037789510938815]),
            {
              "class": 1,
              "system:index": "958"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.21496677398682, 18.101048077906928]),
            {
              "class": 1,
              "system:index": "959"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.19002223014832, 18.18450790799055]),
            {
              "class": 1,
              "system:index": "960"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18492603302002, 18.190134353286673]),
            {
              "class": 1,
              "system:index": "961"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.17123603820801, 18.189461635686442]),
            {
              "class": 1,
              "system:index": "962"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.17231965065002, 18.186261095196038]),
            {
              "class": 1,
              "system:index": "963"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.1654531955719, 18.19054205966009]),
            {
              "class": 1,
              "system:index": "964"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.14698886871338, 18.2677444367159]),
            {
              "class": 1,
              "system:index": "965"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2027359008789, 18.269578289562237]),
            {
              "class": 1,
              "system:index": "966"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.19385242462158, 18.312525652839653]),
            {
              "class": 1,
              "system:index": "967"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.23118877410889, 18.362916133567005]),
            {
              "class": 1,
              "system:index": "968"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.24852657318115, 18.394560518431295]),
            {
              "class": 1,
              "system:index": "969"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2859058380127, 18.39810335051096]),
            {
              "class": 1,
              "system:index": "970"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.24346256256104, 18.44688114043115]),
            {
              "class": 1,
              "system:index": "971"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.76791763305664, 18.391485932696916]),
            {
              "class": 1,
              "system:index": "972"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.7784104347229, 18.38993843832819]),
            {
              "class": 1,
              "system:index": "973"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.75549364089966, 18.406939752052544]),
            {
              "class": 1,
              "system:index": "974"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.74654579162598, 18.441344458140208]),
            {
              "class": 1,
              "system:index": "975"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.7837963104248, 18.487749358494213]),
            {
              "class": 1,
              "system:index": "976"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.74731826782227, 18.478876409630818]),
            {
              "class": 1,
              "system:index": "977"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.79692840576172, 18.518272048439087]),
            {
              "class": 1,
              "system:index": "978"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.77723026275635, 18.590019598155024]),
            {
              "class": 1,
              "system:index": "979"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.91228485107422, 18.64681442016211]),
            {
              "class": 1,
              "system:index": "980"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.93902111053467, 18.662224849717205]),
            {
              "class": 1,
              "system:index": "981"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.96421241760254, 18.68336616900989]),
            {
              "class": 1,
              "system:index": "982"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.97253799438477, 18.701171618489386]),
            {
              "class": 1,
              "system:index": "983"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.70837831497192, 17.713348722849037]),
            {
              "class": 1,
              "system:index": "984"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.7039794921875, 17.712142736538695]),
            {
              "class": 1,
              "system:index": "985"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.68870162963867, 17.71406413462556]),
            {
              "class": 1,
              "system:index": "986"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.66921806335449, 17.71933765339294]),
            {
              "class": 1,
              "system:index": "987"
            }),
        ee.Feature(
            ee.Geometry.Point([-64.65093612670898, 17.727513344868772]),
            {
              "class": 1,
              "system:index": "988"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.47602081298828, 19.45773550572028]),
            {
              "class": 1,
              "system:index": "989"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.45297527313232, 19.49985340896362]),
            {
              "class": 1,
              "system:index": "990"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.4226770401001, 19.507943972032894]),
            {
              "class": 1,
              "system:index": "991"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.36452674865723, 19.51170594544243]),
            {
              "class": 1,
              "system:index": "992"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.32427215576172, 19.531808770920126]),
            {
              "class": 1,
              "system:index": "993"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.3001537322998, 19.51490153152216]),
            {
              "class": 1,
              "system:index": "994"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.26384735107422, 19.514618380875593]),
            {
              "class": 1,
              "system:index": "995"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.22968673706055, 19.494634781937982]),
            {
              "class": 1,
              "system:index": "996"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2622594833374, 19.464937998335305]),
            {
              "class": 1,
              "system:index": "997"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.02995872497559, 19.48512754829679]),
            {
              "class": 1,
              "system:index": "998"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.00674152374268, 19.51219135375673]),
            {
              "class": 1,
              "system:index": "999"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.99730014801025, 19.492045633206622]),
            {
              "class": 1,
              "system:index": "1000"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.95708847045898, 19.514861080225717]),
            {
              "class": 1,
              "system:index": "1001"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.95674514770508, 19.52820905116469]),
            {
              "class": 1,
              "system:index": "1002"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.96009254455566, 19.547500988400298]),
            {
              "class": 1,
              "system:index": "1003"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.96614360809326, 19.57342215930893]),
            {
              "class": 1,
              "system:index": "1004"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.94138145446777, 19.578638240630347]),
            {
              "class": 1,
              "system:index": "1005"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8858060836792, 19.57556522090915]),
            {
              "class": 1,
              "system:index": "1006"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.89112758636475, 19.545681092922223]),
            {
              "class": 1,
              "system:index": "1007"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.88619232177734, 19.526914751976335]),
            {
              "class": 1,
              "system:index": "1008"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.90915203094482, 19.522141929555005]),
            {
              "class": 1,
              "system:index": "1009"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.84254741668701, 19.510735121973266]),
            {
              "class": 1,
              "system:index": "1010"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.81074714660645, 19.51182729796624]),
            {
              "class": 1,
              "system:index": "1011"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.80842971801758, 19.533224368585394]),
            {
              "class": 1,
              "system:index": "1012"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.77435493469238, 19.512393608539742]),
            {
              "class": 1,
              "system:index": "1013"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.75135231018066, 19.51109918145726]),
            {
              "class": 1,
              "system:index": "1014"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.76251029968262, 19.537107087059724]),
            {
              "class": 1,
              "system:index": "1015"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.69766521453857, 19.520888029095303]),
            {
              "class": 1,
              "system:index": "1016"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.79405307769775, 19.55065542527615]),
            {
              "class": 1,
              "system:index": "1017"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.81907272338867, 19.482052749013384]),
            {
              "class": 1,
              "system:index": "1018"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.77250957489014, 19.467446656585057]),
            {
              "class": 1,
              "system:index": "1019"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.80727100372314, 19.450613625475714]),
            {
              "class": 1,
              "system:index": "1020"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.78444004058838, 19.4271415805946]),
            {
              "class": 1,
              "system:index": "1021"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.75942039489746, 19.420180252992186]),
            {
              "class": 1,
              "system:index": "1022"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.73980808258057, 19.392574845129957]),
            {
              "class": 1,
              "system:index": "1023"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.71242809295654, 19.364478904657638]),
            {
              "class": 1,
              "system:index": "1024"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.73101043701172, 19.333745955604492]),
            {
              "class": 1,
              "system:index": "1025"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.72568893432617, 19.30442481343178]),
            {
              "class": 1,
              "system:index": "1026"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.71736335754395, 19.31831656275221]),
            {
              "class": 1,
              "system:index": "1027"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.69161415100098, 19.299159410556967]),
            {
              "class": 1,
              "system:index": "1028"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.67487716674805, 19.309204032374932]),
            {
              "class": 1,
              "system:index": "1029"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.6617021560669, 19.320827481849296]),
            {
              "class": 1,
              "system:index": "1030"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.58986186981201, 19.295838069281515]),
            {
              "class": 1,
              "system:index": "1031"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.54784774780273, 19.306368919343754]),
            {
              "class": 1,
              "system:index": "1032"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.53038120269775, 19.321961432667152]),
            {
              "class": 1,
              "system:index": "1033"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.51222801208496, 19.28785847389845]),
            {
              "class": 1,
              "system:index": "1034"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.49162864685059, 19.307462468764154]),
            {
              "class": 1,
              "system:index": "1035"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.46935558319092, 19.283321677717858]),
            {
              "class": 1,
              "system:index": "1036"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.44712543487549, 19.284293858909685]),
            {
              "class": 1,
              "system:index": "1037"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.43935775756836, 19.26100043109819]),
            {
              "class": 1,
              "system:index": "1038"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.41665554046631, 19.253991499782508]),
            {
              "class": 1,
              "system:index": "1039"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.38034915924072, 19.24349780004017]),
            {
              "class": 1,
              "system:index": "1040"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.3822374343872, 19.21647039632669]),
            {
              "class": 1,
              "system:index": "1041"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.39219379425049, 19.18343987471756]),
            {
              "class": 1,
              "system:index": "1042"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.4088020324707, 19.157456592657418]),
            {
              "class": 1,
              "system:index": "1043"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.41983127593994, 19.13605076769137]),
            {
              "class": 1,
              "system:index": "1044"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.36417007446289, 19.135239886418105]),
            {
              "class": 1,
              "system:index": "1045"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.24617958068848, 18.915994364928466]),
            {
              "class": 1,
              "system:index": "1046"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.25858211517334, 18.917943043015427]),
            {
              "class": 1,
              "system:index": "1047"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.27283000946045, 18.917252888790618]),
            {
              "class": 1,
              "system:index": "1048"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.2900390625, 18.924966215143225]),
            {
              "class": 1,
              "system:index": "1049"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.29630470275879, 18.904058216129414]),
            {
              "class": 1,
              "system:index": "1050"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.26785182952881, 18.898089802522044]),
            {
              "class": 1,
              "system:index": "1051"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.24377632141113, 18.90353038774834]),
            {
              "class": 1,
              "system:index": "1052"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3206377029419, 18.943963837150985]),
            {
              "class": 1,
              "system:index": "1053"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.32085227966309, 18.956952419844427]),
            {
              "class": 1,
              "system:index": "1054"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.34445571899414, 18.96527269922104]),
            {
              "class": 1,
              "system:index": "1055"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3519229888916, 18.976433397522257]),
            {
              "class": 1,
              "system:index": "1056"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36299514770508, 18.982885969335573]),
            {
              "class": 1,
              "system:index": "1057"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37406730651855, 18.98747160742104]),
            {
              "class": 1,
              "system:index": "1058"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40067481994629, 18.988242631512627]),
            {
              "class": 1,
              "system:index": "1059"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39737033843994, 19.00577232087999]),
            {
              "class": 1,
              "system:index": "1060"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40779876708984, 19.008693756232955]),
            {
              "class": 1,
              "system:index": "1061"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.41419315338135, 19.02772240540898]),
            {
              "class": 1,
              "system:index": "1062"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4103307723999, 19.033118192968196]),
            {
              "class": 1,
              "system:index": "1063"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4277114868164, 19.03478152070475]),
            {
              "class": 1,
              "system:index": "1064"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4215316772461, 19.049669590282246]),
            {
              "class": 1,
              "system:index": "1065"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.41277694702148, 19.063501722144]),
            {
              "class": 1,
              "system:index": "1066"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.41294860839844, 19.0764809723929]),
            {
              "class": 1,
              "system:index": "1067"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40891456604004, 19.081104584707113]),
            {
              "class": 1,
              "system:index": "1068"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42517948150635, 19.084430261130848]),
            {
              "class": 1,
              "system:index": "1069"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.44633674621582, 19.06845018118349]),
            {
              "class": 1,
              "system:index": "1070"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45697975158691, 19.07781939975481]),
            {
              "class": 1,
              "system:index": "1071"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.48255729675293, 19.068652983730804]),
            {
              "class": 1,
              "system:index": "1072"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.46676445007324, 19.08763420330185]),
            {
              "class": 1,
              "system:index": "1073"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.48169898986816, 19.111641517876674]),
            {
              "class": 1,
              "system:index": "1074"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49873638153076, 19.127576881594212]),
            {
              "class": 1,
              "system:index": "1075"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49380111694336, 19.143064744292055]),
            {
              "class": 1,
              "system:index": "1076"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.51272678375244, 19.136415682762042]),
            {
              "class": 1,
              "system:index": "1077"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52371311187744, 19.14647025745472]),
            {
              "class": 1,
              "system:index": "1078"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54538536071777, 19.14034839175306]),
            {
              "class": 1,
              "system:index": "1079"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53259658813477, 19.16588844759285]),
            {
              "class": 1,
              "system:index": "1080"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53221035003662, 19.172212040941954]),
            {
              "class": 1,
              "system:index": "1081"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54714488983154, 19.179467659994135]),
            {
              "class": 1,
              "system:index": "1082"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5447416305542, 19.195031708605406]),
            {
              "class": 1,
              "system:index": "1083"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55993366241455, 19.177684185488772]),
            {
              "class": 1,
              "system:index": "1084"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53584742546082, 19.192758495791164]),
            {
              "class": 1,
              "system:index": "1085"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52546191215515, 19.20488665717067]),
            {
              "class": 1,
              "system:index": "1086"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53166317939758, 19.20624430717849]),
            {
              "class": 1,
              "system:index": "1087"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52286553382874, 19.212059785918445]),
            {
              "class": 1,
              "system:index": "1088"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.51762986183167, 19.218067546753662]),
            {
              "class": 1,
              "system:index": "1089"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52299427986145, 19.223862345774936]),
            {
              "class": 1,
              "system:index": "1090"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53362655639648, 19.222545363940327]),
            {
              "class": 1,
              "system:index": "1091"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5227689743042, 19.228704695907606]),
            {
              "class": 1,
              "system:index": "1092"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57027626037598, 19.23798732608973]),
            {
              "class": 1,
              "system:index": "1093"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59130477905273, 19.243740904924397]),
            {
              "class": 1,
              "system:index": "1094"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59109020233154, 19.254194074255068]),
            {
              "class": 1,
              "system:index": "1095"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56143569946289, 19.264727602036828]),
            {
              "class": 1,
              "system:index": "1096"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59169101715088, 19.270642286318754]),
            {
              "class": 1,
              "system:index": "1097"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61057376861572, 19.281660854830665]),
            {
              "class": 1,
              "system:index": "1098"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6254653930664, 19.27181709545868]),
            {
              "class": 1,
              "system:index": "1099"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62181758880615, 19.297458244179154]),
            {
              "class": 1,
              "system:index": "1100"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59542465209961, 19.295838069281515]),
            {
              "class": 1,
              "system:index": "1101"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63786792755127, 19.25237089499597]),
            {
              "class": 1,
              "system:index": "1102"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61619567871094, 19.256868033845816]),
            {
              "class": 1,
              "system:index": "1103"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63679504394531, 19.23523201975281]),
            {
              "class": 1,
              "system:index": "1104"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64233112335205, 19.218131879238328]),
            {
              "class": 1,
              "system:index": "1105"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66151428222656, 19.216024629761396]),
            {
              "class": 1,
              "system:index": "1106"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64220237731934, 19.210918490157628]),
            {
              "class": 1,
              "system:index": "1107"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68271446228027, 19.19478853166164]),
            {
              "class": 1,
              "system:index": "1108"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70048141479492, 19.18100791789096]),
            {
              "class": 1,
              "system:index": "1109"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67374515533447, 19.171482407938132]),
            {
              "class": 1,
              "system:index": "1110"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71550178527832, 19.184007326143078]),
            {
              "class": 1,
              "system:index": "1111"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71498680114746, 19.203704784618775]),
            {
              "class": 1,
              "system:index": "1112"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70554542541504, 19.247306401854747]),
            {
              "class": 1,
              "system:index": "1113"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69988059997559, 19.24074258618738]),
            {
              "class": 1,
              "system:index": "1114"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68640518188477, 19.256300833939058]),
            {
              "class": 1,
              "system:index": "1115"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6815128326416, 19.276354210298525]),
            {
              "class": 1,
              "system:index": "1116"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6884651184082, 19.28907366581585]),
            {
              "class": 1,
              "system:index": "1117"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7109956741333, 19.27550351083624]),
            {
              "class": 1,
              "system:index": "1118"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73502826690674, 19.271938626957976]),
            {
              "class": 1,
              "system:index": "1119"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6820707321167, 19.298430341417873]),
            {
              "class": 1,
              "system:index": "1120"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65958309173584, 19.305356367064725]),
            {
              "class": 1,
              "system:index": "1121"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68322944641113, 19.310054556699857]),
            {
              "class": 1,
              "system:index": "1122"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67305850982666, 19.322163923056607]),
            {
              "class": 1,
              "system:index": "1123"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66790866851807, 19.334272392116212]),
            {
              "class": 1,
              "system:index": "1124"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64812469482422, 19.337349986990397]),
            {
              "class": 1,
              "system:index": "1125"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61881351470947, 19.324958264806323]),
            {
              "class": 1,
              "system:index": "1126"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63979911804199, 19.322973882105234]),
            {
              "class": 1,
              "system:index": "1127"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59023189544678, 19.334798826930818]),
            {
              "class": 1,
              "system:index": "1128"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57847309112549, 19.35431621172965]),
            {
              "class": 1,
              "system:index": "1129"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56152153015137, 19.353141995240936]),
            {
              "class": 1,
              "system:index": "1130"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55551338195801, 19.403949488336597]),
            {
              "class": 1,
              "system:index": "1131"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52465724945068, 19.419370776939566]),
            {
              "class": 1,
              "system:index": "1132"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54924774169922, 19.434183550357027]),
            {
              "class": 1,
              "system:index": "1133"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56276607513428, 19.454336465517912]),
            {
              "class": 1,
              "system:index": "1134"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57426738739014, 19.464452447093098]),
            {
              "class": 1,
              "system:index": "1135"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55860328674316, 19.469550662599357]),
            {
              "class": 1,
              "system:index": "1136"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59722709655762, 19.488768663947507]),
            {
              "class": 1,
              "system:index": "1137"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.607741355896, 19.496010231836213]),
            {
              "class": 1,
              "system:index": "1138"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61808395385742, 19.498235229524397]),
            {
              "class": 1,
              "system:index": "1139"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61774063110352, 19.5074989818964]),
            {
              "class": 1,
              "system:index": "1140"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6280403137207, 19.503130116743282]),
            {
              "class": 1,
              "system:index": "1141"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63070106506348, 19.515791410574742]),
            {
              "class": 1,
              "system:index": "1142"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63649463653564, 19.516721754086113]),
            {
              "class": 1,
              "system:index": "1143"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65074253082275, 19.517207148575178]),
            {
              "class": 1,
              "system:index": "1144"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64748096466064, 19.496900234582576]),
            {
              "class": 1,
              "system:index": "1145"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63138771057129, 19.486058049631406]),
            {
              "class": 1,
              "system:index": "1146"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62958526611328, 19.456683429460057]),
            {
              "class": 1,
              "system:index": "1147"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62301921844482, 19.470117121090386]),
            {
              "class": 1,
              "system:index": "1148"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65134334564209, 19.46890327904245]),
            {
              "class": 1,
              "system:index": "1149"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64061450958252, 19.458059220119605]),
            {
              "class": 1,
              "system:index": "1150"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.630615234375, 19.451301548005137]),
            {
              "class": 1,
              "system:index": "1151"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65872478485107, 19.427020164645608]),
            {
              "class": 1,
              "system:index": "1152"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67850875854492, 19.43062213254396]),
            {
              "class": 1,
              "system:index": "1153"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66713619232178, 19.431998144138795]),
            {
              "class": 1,
              "system:index": "1154"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67301559448242, 19.411680553377526]),
            {
              "class": 1,
              "system:index": "1155"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66812324523926, 19.41471621140074]),
            {
              "class": 1,
              "system:index": "1156"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66228675842285, 19.421556353028446]),
            {
              "class": 1,
              "system:index": "1157"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66679286956787, 19.424146627366785]),
            {
              "class": 1,
              "system:index": "1158"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64155864715576, 19.43875662005344]),
            {
              "class": 1,
              "system:index": "1159"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65198707580566, 19.444988737726952]),
            {
              "class": 1,
              "system:index": "1160"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62928485870361, 19.531808751171184]),
            {
              "class": 1,
              "system:index": "1161"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63108730316162, 19.54394204276586]),
            {
              "class": 1,
              "system:index": "1162"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6135778427124, 19.53492304965653]),
            {
              "class": 1,
              "system:index": "1163"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63276100158691, 19.56327253624212]),
            {
              "class": 1,
              "system:index": "1164"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63327598571777, 19.57370518707049]),
            {
              "class": 1,
              "system:index": "1165"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62576580047607, 19.569055057904386]),
            {
              "class": 1,
              "system:index": "1166"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65576362609863, 19.585511868568837]),
            {
              "class": 1,
              "system:index": "1167"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64233112335205, 19.587654769329017]),
            {
              "class": 1,
              "system:index": "1168"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65743732452393, 19.588018655304822]),
            {
              "class": 1,
              "system:index": "1169"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67211437225342, 19.584137162500543]),
            {
              "class": 1,
              "system:index": "1170"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68580436706543, 19.58183248188296]),
            {
              "class": 1,
              "system:index": "1171"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69391536712646, 19.585390571446617]),
            {
              "class": 1,
              "system:index": "1172"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68928050994873, 19.571562100732745]),
            {
              "class": 1,
              "system:index": "1173"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69829273223877, 19.59792412425366]),
            {
              "class": 1,
              "system:index": "1174"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70537376403809, 19.609890734677915]),
            {
              "class": 1,
              "system:index": "1175"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68434524536133, 19.61393330727837]),
            {
              "class": 1,
              "system:index": "1176"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7195143699646, 19.658069232897958]),
            {
              "class": 1,
              "system:index": "1177"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71814107894897, 19.66586896620972]),
            {
              "class": 1,
              "system:index": "1178"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69882917404175, 19.657846955145754]),
            {
              "class": 1,
              "system:index": "1179"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69211292266846, 19.65691742666264]),
            {
              "class": 1,
              "system:index": "1180"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6862120628357, 19.670839582744403]),
            {
              "class": 1,
              "system:index": "1181"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6858901977539, 19.678982170206243]),
            {
              "class": 1,
              "system:index": "1182"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70357131958008, 19.677689082217462]),
            {
              "class": 1,
              "system:index": "1183"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73020029067993, 19.668010795484594]),
            {
              "class": 1,
              "system:index": "1184"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75955438613892, 19.6411550368359]),
            {
              "class": 1,
              "system:index": "1185"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8097653388977, 19.66605082075038]),
            {
              "class": 1,
              "system:index": "1186"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.96885251998901, 19.86792306666859]),
            {
              "class": 1,
              "system:index": "1187"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.9497766494751, 19.870586867671538]),
            {
              "class": 1,
              "system:index": "1188"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.94692277908325, 19.88180662900203]),
            {
              "class": 1,
              "system:index": "1189"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.94958353042603, 19.873250623915595]),
            {
              "class": 1,
              "system:index": "1190"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.92192459106445, 19.887254787693134]),
            {
              "class": 1,
              "system:index": "1191"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.91276216506958, 19.888324219064124]),
            {
              "class": 1,
              "system:index": "1192"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.92610883712769, 19.888586531316435]),
            {
              "class": 1,
              "system:index": "1193"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.9077410697937, 19.871817851498896]),
            {
              "class": 1,
              "system:index": "1194"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.89257049560547, 19.848003682017133]),
            {
              "class": 1,
              "system:index": "1195"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.91083097457886, 19.848447707708992]),
            {
              "class": 1,
              "system:index": "1196"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85223007202148, 19.853816283672526]),
            {
              "class": 1,
              "system:index": "1197"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.844398021698, 19.856480321610576]),
            {
              "class": 1,
              "system:index": "1198"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.84416198730469, 19.83129126671483]),
            {
              "class": 1,
              "system:index": "1199"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.84154415130615, 19.827314744682585]),
            {
              "class": 1,
              "system:index": "1200"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83987045288086, 19.813769600691728]),
            {
              "class": 1,
              "system:index": "1201"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83019304275513, 19.817504219111406]),
            {
              "class": 1,
              "system:index": "1202"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.84122228622437, 19.804079370958767]),
            {
              "class": 1,
              "system:index": "1203"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.84111499786377, 19.797396806201076]),
            {
              "class": 1,
              "system:index": "1204"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.84441947937012, 19.77835702475481]),
            {
              "class": 1,
              "system:index": "1205"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80210494995117, 19.77837721660876]),
            {
              "class": 1,
              "system:index": "1206"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80395030975342, 19.800001222815624]),
            {
              "class": 1,
              "system:index": "1207"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8133487701416, 19.785000006624895]),
            {
              "class": 1,
              "system:index": "1208"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7365517616272, 19.775811662338864]),
            {
              "class": 1,
              "system:index": "1209"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74172306060791, 19.772843384563714]),
            {
              "class": 1,
              "system:index": "1210"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73443818092346, 19.76668453665724]),
            {
              "class": 1,
              "system:index": "1211"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73956656455994, 19.76208039002807]),
            {
              "class": 1,
              "system:index": "1212"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74909377098083, 19.756335117137912]),
            {
              "class": 1,
              "system:index": "1213"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74181962013245, 19.755890834340356]),
            {
              "class": 1,
              "system:index": "1214"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72854804992676, 19.757879999961116]),
            {
              "class": 1,
              "system:index": "1215"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72322654724121, 19.756910663467778]),
            {
              "class": 1,
              "system:index": "1216"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71688580513, 19.752447600708678]),
            {
              "class": 1,
              "system:index": "1217"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72418141365051, 19.74552051852051]),
            {
              "class": 1,
              "system:index": "1218"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72479295730591, 19.742682953450323]),
            {
              "class": 1,
              "system:index": "1219"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72709965705872, 19.739138450790175]),
            {
              "class": 1,
              "system:index": "1220"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7308976650238, 19.734876864794686]),
            {
              "class": 1,
              "system:index": "1221"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72731423377991, 19.735492883071558]),
            {
              "class": 1,
              "system:index": "1222"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72060871124268, 19.72721178295881]),
            {
              "class": 1,
              "system:index": "1223"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72325873374939, 19.721768240672866]),
            {
              "class": 1,
              "system:index": "1224"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71451473236084, 19.71843536817324]),
            {
              "class": 1,
              "system:index": "1225"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.91520833969116, 19.716537788382617]),
            {
              "class": 1,
              "system:index": "1226"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.9458498954773, 19.71621459321412]),
            {
              "class": 1,
              "system:index": "1227"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83354043960571, 19.73390856711135]),
            {
              "class": 1,
              "system:index": "1228"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.79588222503662, 19.734615477415275]),
            {
              "class": 1,
              "system:index": "1229"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78972387313843, 19.742068141365863]),
            {
              "class": 1,
              "system:index": "1230"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.77607679367065, 19.749500261927775]),
            {
              "class": 1,
              "system:index": "1231"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.77032613754272, 19.746127576190656]),
            {
              "class": 1,
              "system:index": "1232"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.79098987579346, 19.762222925691205]),
            {
              "class": 1,
              "system:index": "1233"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.79517412185669, 19.774015726603317]),
            {
              "class": 1,
              "system:index": "1234"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.79277086257935, 19.775812840544532]),
            {
              "class": 1,
              "system:index": "1235"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8062891960144, 19.78790749585248]),
            {
              "class": 1,
              "system:index": "1236"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80530214309692, 19.804584094853045]),
            {
              "class": 1,
              "system:index": "1237"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.79948711395264, 19.813163988486107]),
            {
              "class": 1,
              "system:index": "1238"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80272722244263, 19.787806542597252]),
            {
              "class": 1,
              "system:index": "1239"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74659395217896, 19.70455893090261]),
            {
              "class": 1,
              "system:index": "1240"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70048141479492, 19.72922268256899]),
            {
              "class": 1,
              "system:index": "1241"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69503384828568, 19.733828239447018]),
            {
              "class": 1,
              "system:index": "1242"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6930034160614, 19.73391912813566]),
            {
              "class": 1,
              "system:index": "1243"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70165085792542, 19.766048445366714]),
            {
              "class": 1,
              "system:index": "1244"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69787430763245, 19.730069820899256]),
            {
              "class": 1,
              "system:index": "1245"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70033121109009, 19.73576554614044]),
            {
              "class": 1,
              "system:index": "1246"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69993424415588, 19.72507074577859]),
            {
              "class": 1,
              "system:index": "1247"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69524574279785, 19.72453548200118]),
            {
              "class": 1,
              "system:index": "1248"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6974880695343, 19.716142715537714]),
            {
              "class": 1,
              "system:index": "1249"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69331455230713, 19.715183225601038]),
            {
              "class": 1,
              "system:index": "1250"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70707964897156, 19.702881044239735]),
            {
              "class": 1,
              "system:index": "1251"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80208349227905, 19.716860982897735]),
            {
              "class": 1,
              "system:index": "1252"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7868914604187, 19.716436789962646]),
            {
              "class": 1,
              "system:index": "1253"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.76826620101929, 19.72591016402443]),
            {
              "class": 1,
              "system:index": "1254"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78573274612427, 19.72162802609932]),
            {
              "class": 1,
              "system:index": "1255"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78302907943726, 19.74996475797221]),
            {
              "class": 1,
              "system:index": "1256"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7867841720581, 19.75650794987212]),
            {
              "class": 1,
              "system:index": "1257"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.79030323028564, 19.77139069229357]),
            {
              "class": 1,
              "system:index": "1258"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8095293045044, 19.767897310358954]),
            {
              "class": 1,
              "system:index": "1259"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75543451309204, 19.75913322920915]),
            {
              "class": 1,
              "system:index": "1260"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75399684906006, 19.769391598706328]),
            {
              "class": 1,
              "system:index": "1261"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74893283843994, 19.773692647790643]),
            {
              "class": 1,
              "system:index": "1262"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73638010025024, 19.78699891425159]),
            {
              "class": 1,
              "system:index": "1263"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74584293365479, 19.797598710344175]),
            {
              "class": 1,
              "system:index": "1264"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73597240447998, 19.80837949311566]),
            {
              "class": 1,
              "system:index": "1265"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7314019203186, 19.776115722921006]),
            {
              "class": 1,
              "system:index": "1266"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.72408485412598, 19.771915702614216]),
            {
              "class": 1,
              "system:index": "1267"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67672777175903, 19.703771082527123]),
            {
              "class": 1,
              "system:index": "1268"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67683506011963, 19.693185256356962]),
            {
              "class": 1,
              "system:index": "1269"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68322944641113, 19.679042793315066]),
            {
              "class": 1,
              "system:index": "1270"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6844310760498, 19.682538118223338]),
            {
              "class": 1,
              "system:index": "1271"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68516063690186, 19.65338113764023]),
            {
              "class": 1,
              "system:index": "1272"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66911029815674, 19.641215674245593]),
            {
              "class": 1,
              "system:index": "1273"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66936779022217, 19.63491028726579]),
            {
              "class": 1,
              "system:index": "1274"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66001224517822, 19.64649018274148]),
            {
              "class": 1,
              "system:index": "1275"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65305995941162, 19.634950707201593]),
            {
              "class": 1,
              "system:index": "1276"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64808177947998, 19.632485072501385]),
            {
              "class": 1,
              "system:index": "1277"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66908884048462, 19.62369336203171]),
            {
              "class": 1,
              "system:index": "1278"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6817274093628, 19.62704841635717]),
            {
              "class": 1,
              "system:index": "1279"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67269372940063, 19.628746127995473]),
            {
              "class": 1,
              "system:index": "1280"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69082546234131, 19.618215984268424]),
            {
              "class": 1,
              "system:index": "1281"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66621351242065, 19.603763704385354]),
            {
              "class": 1,
              "system:index": "1282"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66258716583252, 19.61197033317442]),
            {
              "class": 1,
              "system:index": "1283"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65005588531494, 19.59422246680242]),
            {
              "class": 1,
              "system:index": "1284"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64012098312378, 19.608048991362693]),
            {
              "class": 1,
              "system:index": "1285"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6432752609253, 19.612051184576792]),
            {
              "class": 1,
              "system:index": "1286"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63999223709106, 19.622399828400766]),
            {
              "class": 1,
              "system:index": "1287"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65035629272461, 19.621712634424416]),
            {
              "class": 1,
              "system:index": "1288"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.637460231781, 19.597941999583774]),
            {
              "class": 1,
              "system:index": "1289"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64782428741455, 19.591149744453915]),
            {
              "class": 1,
              "system:index": "1290"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6579737663269, 19.578150671566924]),
            {
              "class": 1,
              "system:index": "1291"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65342473983765, 19.576149165899633]),
            {
              "class": 1,
              "system:index": "1292"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6634669303894, 19.584579582146812]),
            {
              "class": 1,
              "system:index": "1293"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67224311828613, 19.578656098358508]),
            {
              "class": 1,
              "system:index": "1294"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68524646759033, 19.568668571085187]),
            {
              "class": 1,
              "system:index": "1295"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69415140151978, 19.559772276678878]),
            {
              "class": 1,
              "system:index": "1296"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69367933273315, 19.56816311296636]),
            {
              "class": 1,
              "system:index": "1297"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69818544387817, 19.55212914921272]),
            {
              "class": 1,
              "system:index": "1298"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70704746246338, 19.54863098782519]),
            {
              "class": 1,
              "system:index": "1299"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69211292266846, 19.542888176954538]),
            {
              "class": 1,
              "system:index": "1300"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69086837768555, 19.535972267336977]),
            {
              "class": 1,
              "system:index": "1301"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67788648605347, 19.526629252428105]),
            {
              "class": 1,
              "system:index": "1302"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66123533248901, 19.52341367425401]),
            {
              "class": 1,
              "system:index": "1303"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66112804412842, 19.516213782926354]),
            {
              "class": 1,
              "system:index": "1304"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6519227027893, 19.525375386789637]),
            {
              "class": 1,
              "system:index": "1305"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65492677688599, 19.534010683490727]),
            {
              "class": 1,
              "system:index": "1306"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66091346740723, 19.535082479679133]),
            {
              "class": 1,
              "system:index": "1307"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66769409179688, 19.526265227922618]),
            {
              "class": 1,
              "system:index": "1308"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64443397521973, 19.507011207778177]),
            {
              "class": 1,
              "system:index": "1309"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63563632965088, 19.508568603465296]),
            {
              "class": 1,
              "system:index": "1310"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61276245117188, 19.498495831167293]),
            {
              "class": 1,
              "system:index": "1311"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60413646697998, 19.493317615821525]),
            {
              "class": 1,
              "system:index": "1312"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60703325271606, 19.48601524156845]),
            {
              "class": 1,
              "system:index": "1313"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59769916534424, 19.4857522690386]),
            {
              "class": 1,
              "system:index": "1314"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59338617324829, 19.478510242336277]),
            {
              "class": 1,
              "system:index": "1315"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59621858596802, 19.481605338065197]),
            {
              "class": 1,
              "system:index": "1316"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58224964141846, 19.473918063246316]),
            {
              "class": 1,
              "system:index": "1317"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57540464401245, 19.479926306545035]),
            {
              "class": 1,
              "system:index": "1318"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56634950637817, 19.472117569846276]),
            {
              "class": 1,
              "system:index": "1319"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56634950637817, 19.46643273468009]),
            {
              "class": 1,
              "system:index": "1320"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5530457496643, 19.440716987042876]),
            {
              "class": 1,
              "system:index": "1321"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55486965179443, 19.437600876112807]),
            {
              "class": 1,
              "system:index": "1322"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55871057510376, 19.443428359574497]),
            {
              "class": 1,
              "system:index": "1323"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.50058174133301, 19.40267206269388]),
            {
              "class": 1,
              "system:index": "1324"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.50287771224976, 19.40520192178526]),
            {
              "class": 1,
              "system:index": "1325"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.50710487365723, 19.382229358354152]),
            {
              "class": 1,
              "system:index": "1326"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.50991582870483, 19.376075804177848]),
            {
              "class": 1,
              "system:index": "1327"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.51062393188477, 19.363970437113377]),
            {
              "class": 1,
              "system:index": "1328"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5236701965332, 19.36125773992058]),
            {
              "class": 1,
              "system:index": "1329"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52225399017334, 19.37324185237117]),
            {
              "class": 1,
              "system:index": "1330"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53156661987305, 19.367816721429577]),
            {
              "class": 1,
              "system:index": "1331"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.31613159179688, 18.918448128803153]),
            {
              "class": 1,
              "system:index": "1332"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.32716083526611, 18.920173496686832]),
            {
              "class": 1,
              "system:index": "1333"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.30428695678711, 18.914104182574743]),
            {
              "class": 1,
              "system:index": "1334"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.30576753616333, 18.931174835362615]),
            {
              "class": 1,
              "system:index": "1335"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.31218338012695, 18.951632962766173]),
            {
              "class": 1,
              "system:index": "1336"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.33986377716064, 18.94053149240483]),
            {
              "class": 1,
              "system:index": "1337"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3487901687622, 18.940775042637185]),
            {
              "class": 1,
              "system:index": "1338"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.35346794128418, 18.948568462465452]),
            {
              "class": 1,
              "system:index": "1339"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36295223236084, 18.94481386552314]),
            {
              "class": 1,
              "system:index": "1340"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36042022705078, 18.938156859021614]),
            {
              "class": 1,
              "system:index": "1341"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.33670949935913, 18.97572081561368]),
            {
              "class": 1,
              "system:index": "1342"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.34769582748413, 18.989335913459573]),
            {
              "class": 1,
              "system:index": "1343"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.28646367788315, 18.9999273917182]),
            {
              "class": 1,
              "system:index": "1344"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.26452589035034, 19.00169202069232]),
            {
              "class": 1,
              "system:index": "1345"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.09400177001953, 19.061227872166974]),
            {
              "class": 1,
              "system:index": "1346"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06323146820068, 18.986089493416692]),
            {
              "class": 1,
              "system:index": "1347"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.03173160552979, 18.973285807495763]),
            {
              "class": 1,
              "system:index": "1348"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.03849077224731, 18.975923731350715]),
            {
              "class": 1,
              "system:index": "1349"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.00087547302246, 18.921147814212073]),
            {
              "class": 1,
              "system:index": "1350"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07147121429443, 18.902269421308]),
            {
              "class": 1,
              "system:index": "1351"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07295179367065, 18.896361867430105]),
            {
              "class": 1,
              "system:index": "1352"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07848787307739, 18.896240060001432]),
            {
              "class": 1,
              "system:index": "1353"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.0726728439331, 18.886373363944312]),
            {
              "class": 1,
              "system:index": "1354"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.08659887313843, 18.87157222996936]),
            {
              "class": 1,
              "system:index": "1355"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06569910049438, 18.86696310515097]),
            {
              "class": 1,
              "system:index": "1356"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.09646940231323, 18.87979524360288]),
            {
              "class": 1,
              "system:index": "1357"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.08681344985962, 18.855957545821276]),
            {
              "class": 1,
              "system:index": "1358"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.10415124893188, 18.84005709577245]),
            {
              "class": 1,
              "system:index": "1359"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14230298995972, 18.84952038034057]),
            {
              "class": 1,
              "system:index": "1360"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13142395019531, 18.852566388476653]),
            {
              "class": 1,
              "system:index": "1361"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15513467788696, 18.846819540218704]),
            {
              "class": 1,
              "system:index": "1362"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.16161489486694, 18.84452480732157]),
            {
              "class": 1,
              "system:index": "1363"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15352535247803, 18.804818934475165]),
            {
              "class": 1,
              "system:index": "1364"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.162344455719, 18.80398612779592]),
            {
              "class": 1,
              "system:index": "1365"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20004558563232, 18.812090583500588]),
            {
              "class": 1,
              "system:index": "1366"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1727728843689, 18.784992954536275]),
            {
              "class": 1,
              "system:index": "1367"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.16577768325806, 18.776907509941932]),
            {
              "class": 1,
              "system:index": "1368"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1597695350647, 18.771950412385277]),
            {
              "class": 1,
              "system:index": "1369"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20667600631714, 18.601065209281977]),
            {
              "class": 1,
              "system:index": "1370"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19174146652222, 18.57964923714848]),
            {
              "class": 1,
              "system:index": "1371"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.17539072036743, 18.573242226711933]),
            {
              "class": 1,
              "system:index": "1372"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.16925382614136, 18.573913448619912]),
            {
              "class": 1,
              "system:index": "1373"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19839334487915, 18.550907337191497]),
            {
              "class": 1,
              "system:index": "1374"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.18828678131104, 18.539942237224512]),
            {
              "class": 1,
              "system:index": "1375"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.17487573623657, 18.532658906132756]),
            {
              "class": 1,
              "system:index": "1376"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1853256225586, 18.532007867011206]),
            {
              "class": 1,
              "system:index": "1377"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19704151153564, 18.529261268419525]),
            {
              "class": 1,
              "system:index": "1378"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19382286071777, 18.522770982343694]),
            {
              "class": 1,
              "system:index": "1379"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.18588352203369, 18.525354918856184]),
            {
              "class": 1,
              "system:index": "1380"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15680837631226, 18.532150282030948]),
            {
              "class": 1,
              "system:index": "1381"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14298963546753, 18.531153374400873]),
            {
              "class": 1,
              "system:index": "1382"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13844060897827, 18.54761177817682]),
            {
              "class": 1,
              "system:index": "1383"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12708950042725, 18.528427107518034]),
            {
              "class": 1,
              "system:index": "1384"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12464332580566, 18.521916443567317]),
            {
              "class": 1,
              "system:index": "1385"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1064043045044, 18.51050183770353]),
            {
              "class": 1,
              "system:index": "1386"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1037220954895, 18.51200755124097]),
            {
              "class": 1,
              "system:index": "1387"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.10243463516235, 18.515588654532813]),
            {
              "class": 1,
              "system:index": "1388"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.09573984146118, 18.523096519801992]),
            {
              "class": 1,
              "system:index": "1389"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.09370136260986, 18.52486661888534]),
            {
              "class": 1,
              "system:index": "1390"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07388520240784, 18.541517703091266]),
            {
              "class": 1,
              "system:index": "1391"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06807017326355, 18.54064291405237]),
            {
              "class": 1,
              "system:index": "1392"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.0621907711029, 18.539788464620166]),
            {
              "class": 1,
              "system:index": "1393"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07409977912903, 18.54472183399017]),
            {
              "class": 1,
              "system:index": "1394"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07814455032349, 18.54238231576274]),
            {
              "class": 1,
              "system:index": "1395"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07774758338928, 18.543877576759996]),
            {
              "class": 1,
              "system:index": "1396"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.08303689956665, 18.544884581892124]),
            {
              "class": 1,
              "system:index": "1397"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.0822536945343, 18.538242307165923]),
            {
              "class": 1,
              "system:index": "1398"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07751154899597, 18.5369097523448]),
            {
              "class": 1,
              "system:index": "1399"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07190036773682, 18.534743057053674]),
            {
              "class": 1,
              "system:index": "1400"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06368207931519, 18.536706307946236]),
            {
              "class": 1,
              "system:index": "1401"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.08803653717041, 18.60696515544635]),
            {
              "class": 1,
              "system:index": "1402"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.08898067474365, 18.624371942224688]),
            {
              "class": 1,
              "system:index": "1403"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.10657596588135, 18.586302452837742]),
            {
              "class": 1,
              "system:index": "1404"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12575912475586, 18.576173559209842]),
            {
              "class": 1,
              "system:index": "1405"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13721752166748, 18.61650909870784]),
            {
              "class": 1,
              "system:index": "1406"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1552848815918, 18.577319175785096]),
            {
              "class": 1,
              "system:index": "1407"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14406251907349, 18.575976756142406]),
            {
              "class": 1,
              "system:index": "1408"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1517014503479, 18.57090190759665]),
            {
              "class": 1,
              "system:index": "1409"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14107990264893, 18.56920347765954]),
            {
              "class": 1,
              "system:index": "1410"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13741064071655, 18.56798303851885]),
            {
              "class": 1,
              "system:index": "1411"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14126229286194, 18.56269436800573]),
            {
              "class": 1,
              "system:index": "1412"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13256120681763, 18.561992589789917]),
            {
              "class": 1,
              "system:index": "1413"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13040471076965, 18.561463711546057]),
            {
              "class": 1,
              "system:index": "1414"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1397602558136, 18.555462862817947]),
            {
              "class": 1,
              "system:index": "1415"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14992046356201, 18.555930733184155]),
            {
              "class": 1,
              "system:index": "1416"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14739918708801, 18.561117905654122]),
            {
              "class": 1,
              "system:index": "1417"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15514540672302, 18.554283010112872]),
            {
              "class": 1,
              "system:index": "1418"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15068221092224, 18.547335953404396]),
            {
              "class": 1,
              "system:index": "1419"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14552164077759, 18.552503044479934]),
            {
              "class": 1,
              "system:index": "1420"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14617609977722, 18.544518398894652]),
            {
              "class": 1,
              "system:index": "1421"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13182091712952, 18.545108360004082]),
            {
              "class": 1,
              "system:index": "1422"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12890267372131, 18.531060629270733]),
            {
              "class": 1,
              "system:index": "1423"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1332585811615, 18.527795205672913]),
            {
              "class": 1,
              "system:index": "1424"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13893413543701, 18.529076968166688]),
            {
              "class": 1,
              "system:index": "1425"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13634848594666, 18.521538846064367]),
            {
              "class": 1,
              "system:index": "1426"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12767958641052, 18.516879489726588]),
            {
              "class": 1,
              "system:index": "1427"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12246537208557, 18.514529416876204]),
            {
              "class": 1,
              "system:index": "1428"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1257483959198, 18.512840600002725]),
            {
              "class": 1,
              "system:index": "1429"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11261630058289, 18.513562927332035]),
            {
              "class": 1,
              "system:index": "1430"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1017587184906, 18.51129419884905]),
            {
              "class": 1,
              "system:index": "1431"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.10933327674866, 18.527968142443214]),
            {
              "class": 1,
              "system:index": "1432"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12138175964355, 18.539056075991287]),
            {
              "class": 1,
              "system:index": "1433"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11619973182678, 18.53713354090343]),
            {
              "class": 1,
              "system:index": "1434"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11146831512451, 18.53740819009754]),
            {
              "class": 1,
              "system:index": "1435"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12963223457336, 18.543969122926427]),
            {
              "class": 1,
              "system:index": "1436"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12597370147705, 18.553255717926557]),
            {
              "class": 1,
              "system:index": "1437"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13058710098267, 18.557029206394933]),
            {
              "class": 1,
              "system:index": "1438"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13316202163696, 18.55602227288841]),
            {
              "class": 1,
              "system:index": "1439"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.118581533432, 18.558331091415763]),
            {
              "class": 1,
              "system:index": "1440"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11552381515503, 18.566976169653767]),
            {
              "class": 1,
              "system:index": "1441"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11803436279297, 18.568328830495325]),
            {
              "class": 1,
              "system:index": "1442"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.10922598838806, 18.56778980152077]),
            {
              "class": 1,
              "system:index": "1443"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.17742919921875, 18.578252967968435]),
            {
              "class": 1,
              "system:index": "1444"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1706485748291, 18.568164277461598]),
            {
              "class": 1,
              "system:index": "1445"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19107627868652, 18.54700863440582]),
            {
              "class": 1,
              "system:index": "1446"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19802856445312, 18.542126190608595]),
            {
              "class": 1,
              "system:index": "1447"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.21253395080566, 18.546520396306956]),
            {
              "class": 1,
              "system:index": "1448"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.0633602142334, 18.58541232162372]),
            {
              "class": 1,
              "system:index": "1449"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06902503967285, 18.59924203927911]),
            {
              "class": 1,
              "system:index": "1450"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.07941055297852, 18.61437209057385]),
            {
              "class": 1,
              "system:index": "1451"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.08378791809082, 18.57507997643054]),
            {
              "class": 1,
              "system:index": "1452"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.99443817138672, 18.49544635853206]),
            {
              "class": 1,
              "system:index": "1453"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98235750198364, 18.497295755536335]),
            {
              "class": 1,
              "system:index": "1454"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.9750189781189, 18.503095162059623]),
            {
              "class": 1,
              "system:index": "1455"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.97656393051147, 18.512943528654183]),
            {
              "class": 1,
              "system:index": "1456"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.96753025054932, 18.50822289471816]),
            {
              "class": 1,
              "system:index": "1457"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.96665048599243, 18.51436783228561]),
            {
              "class": 1,
              "system:index": "1458"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.96703672409058, 18.518009926216667]),
            {
              "class": 1,
              "system:index": "1459"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98188543319702, 18.514835815176664]),
            {
              "class": 1,
              "system:index": "1460"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.97377443313599, 18.514388179394444]),
            {
              "class": 1,
              "system:index": "1461"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.96939706802368, 18.504560244206676]),
            {
              "class": 1,
              "system:index": "1462"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.97265863418579, 18.50293237438048]),
            {
              "class": 1,
              "system:index": "1463"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98742151260376, 18.496298644803865]),
            {
              "class": 1,
              "system:index": "1464"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.99716329574585, 18.49530152826651]),
            {
              "class": 1,
              "system:index": "1465"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.00242042541504, 18.500307401684516]),
            {
              "class": 1,
              "system:index": "1466"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.03003644943237, 18.500388796791274]),
            {
              "class": 1,
              "system:index": "1467"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.02248334884644, 18.499391704067484]),
            {
              "class": 1,
              "system:index": "1468"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.003493309021, 18.51656530605835]),
            {
              "class": 1,
              "system:index": "1469"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.99617624282837, 18.519617306138038]),
            {
              "class": 1,
              "system:index": "1470"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98664903640747, 18.520736359189875]),
            {
              "class": 1,
              "system:index": "1471"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98205709457397, 18.52476488954924]),
            {
              "class": 1,
              "system:index": "1472"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20240592956543, 18.598916647058967]),
            {
              "class": 1,
              "system:index": "1473"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.31355667114258, 18.643001622334115]),
            {
              "class": 1,
              "system:index": "1474"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39949464797974, 18.752465981654392]),
            {
              "class": 1,
              "system:index": "1475"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40112543106079, 18.737774980624415]),
            {
              "class": 1,
              "system:index": "1476"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40996599197388, 18.734930102426183]),
            {
              "class": 1,
              "system:index": "1477"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39704847335815, 18.749722945749678]),
            {
              "class": 1,
              "system:index": "1478"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4164891242981, 18.744947925061005]),
            {
              "class": 1,
              "system:index": "1479"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42655277252197, 18.72891505937194]),
            {
              "class": 1,
              "system:index": "1480"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42163896560669, 18.72139595447623]),
            {
              "class": 1,
              "system:index": "1481"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.41578102111816, 18.715644629603542]),
            {
              "class": 1,
              "system:index": "1482"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40436553955078, 18.716152705048625]),
            {
              "class": 1,
              "system:index": "1483"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.41539478302002, 18.719160480416633]),
            {
              "class": 1,
              "system:index": "1484"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39949464797974, 18.716884331007947]),
            {
              "class": 1,
              "system:index": "1485"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43910551071167, 18.720420478521348]),
            {
              "class": 1,
              "system:index": "1486"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.44110107421875, 18.72712676203785]),
            {
              "class": 1,
              "system:index": "1487"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43165969848633, 18.71672174773496]),
            {
              "class": 1,
              "system:index": "1488"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43082284927368, 18.72946373771479]),
            {
              "class": 1,
              "system:index": "1489"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.44408369064331, 18.73377181686423]),
            {
              "class": 1,
              "system:index": "1490"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42481470108032, 18.733751495994007]),
            {
              "class": 1,
              "system:index": "1491"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43687391281128, 18.749601032008115]),
            {
              "class": 1,
              "system:index": "1492"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.44371891021729, 18.741270051100816]),
            {
              "class": 1,
              "system:index": "1493"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45352506637573, 18.744907286007443]),
            {
              "class": 1,
              "system:index": "1494"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45167970657349, 18.7549854716474]),
            {
              "class": 1,
              "system:index": "1495"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45198011398315, 18.76187324017669]),
            {
              "class": 1,
              "system:index": "1496"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4437403678894, 18.76806995971225]),
            {
              "class": 1,
              "system:index": "1497"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.46339559555054, 18.759272581858713]),
            {
              "class": 1,
              "system:index": "1498"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.432861328125, 18.76258435070468]),
            {
              "class": 1,
              "system:index": "1499"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43910551071167, 18.763518948553333]),
            {
              "class": 1,
              "system:index": "1500"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47869491577148, 18.766343027973903]),
            {
              "class": 1,
              "system:index": "1501"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.46019840240479, 18.774916562048222]),
            {
              "class": 1,
              "system:index": "1502"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47989654541016, 18.773941395315504]),
            {
              "class": 1,
              "system:index": "1503"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.48423099517822, 18.772417686001187]),
            {
              "class": 1,
              "system:index": "1504"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45380401611328, 18.781864461694234]),
            {
              "class": 1,
              "system:index": "1505"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47406005859375, 18.78474917796047]),
            {
              "class": 1,
              "system:index": "1506"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4867844581604, 18.784383512435316]),
            {
              "class": 1,
              "system:index": "1507"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45481252670288, 18.796896947986795]),
            {
              "class": 1,
              "system:index": "1508"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47028350830078, 18.803011129372965]),
            {
              "class": 1,
              "system:index": "1509"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49697685241699, 18.791757613771818]),
            {
              "class": 1,
              "system:index": "1510"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.50716924667358, 18.785521135906908]),
            {
              "class": 1,
              "system:index": "1511"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.50365018844604, 18.798359496634966]),
            {
              "class": 1,
              "system:index": "1512"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.51332759857178, 18.78739007207353]),
            {
              "class": 1,
              "system:index": "1513"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52298355102539, 18.783570919537592]),
            {
              "class": 1,
              "system:index": "1514"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.51549482345581, 18.77747634787731]),
            {
              "class": 1,
              "system:index": "1515"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52693176269531, 18.775749512497942]),
            {
              "class": 1,
              "system:index": "1516"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53178119659424, 18.79350459873348]),
            {
              "class": 1,
              "system:index": "1517"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53304719924927, 18.804493937237105]),
            {
              "class": 1,
              "system:index": "1518"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.51388549804688, 18.811948403432158]),
            {
              "class": 1,
              "system:index": "1519"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5371241569519, 18.80983599968637]),
            {
              "class": 1,
              "system:index": "1520"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54422664642334, 18.806809528860512]),
            {
              "class": 1,
              "system:index": "1521"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55806684494019, 18.81399984706083]),
            {
              "class": 1,
              "system:index": "1522"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56512641906738, 18.812638991210044]),
            {
              "class": 1,
              "system:index": "1523"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57079124450684, 18.826145505462907]),
            {
              "class": 1,
              "system:index": "1524"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56381750106812, 18.828968534470512]),
            {
              "class": 1,
              "system:index": "1525"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55293846130371, 18.83032925813111]),
            {
              "class": 1,
              "system:index": "1526"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54208087921143, 18.831101006951485]),
            {
              "class": 1,
              "system:index": "1527"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57212162017822, 18.83363962937563]),
            {
              "class": 1,
              "system:index": "1528"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54826068878174, 18.81621375319778]),
            {
              "class": 1,
              "system:index": "1529"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54544973373413, 18.793463971382092]),
            {
              "class": 1,
              "system:index": "1530"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53575086593628, 18.778674964384127]),
            {
              "class": 1,
              "system:index": "1531"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49841451644897, 18.78269737780096]),
            {
              "class": 1,
              "system:index": "1532"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69272446632385, 19.078221436792404]),
            {
              "class": 1,
              "system:index": "1533"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.69327163696289, 19.079478734443285]),
            {
              "class": 1,
              "system:index": "1534"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68373370170593, 19.084680195088115]),
            {
              "class": 1,
              "system:index": "1535"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6875102519989, 19.088086911181268]),
            {
              "class": 1,
              "system:index": "1536"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67729640007019, 19.089161634452452]),
            {
              "class": 1,
              "system:index": "1537"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67563343048096, 19.085856331184733]),
            {
              "class": 1,
              "system:index": "1538"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67286539077759, 19.082196087087638]),
            {
              "class": 1,
              "system:index": "1539"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65772700309753, 19.086535647365757]),
            {
              "class": 1,
              "system:index": "1540"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6552164554596, 19.088168022614934]),
            {
              "class": 1,
              "system:index": "1541"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65177249908447, 19.09070273489311]),
            {
              "class": 1,
              "system:index": "1542"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6479423046112, 19.084771447325558]),
            {
              "class": 1,
              "system:index": "1543"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64155864715576, 19.090570930811168]),
            {
              "class": 1,
              "system:index": "1544"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63135552406311, 19.09493054861731]),
            {
              "class": 1,
              "system:index": "1545"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62027263641357, 19.092355346398275]),
            {
              "class": 1,
              "system:index": "1546"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62240767478943, 19.096664225181705]),
            {
              "class": 1,
              "system:index": "1547"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61718273162842, 19.098854106461133]),
            {
              "class": 1,
              "system:index": "1548"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61173248291016, 19.09957392221978]),
            {
              "class": 1,
              "system:index": "1549"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61406064033508, 19.101479898119056]),
            {
              "class": 1,
              "system:index": "1550"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62640953063965, 19.09783013780345]),
            {
              "class": 1,
              "system:index": "1551"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6301109790802, 19.092527703703322]),
            {
              "class": 1,
              "system:index": "1552"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63388752937317, 19.08891830149257]),
            {
              "class": 1,
              "system:index": "1553"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60962963104248, 19.067534021544713]),
            {
              "class": 1,
              "system:index": "1554"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6070761680603, 19.068679859010686]),
            {
              "class": 1,
              "system:index": "1555"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61181831359863, 19.068324954447604]),
            {
              "class": 1,
              "system:index": "1556"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58452415466309, 19.386624112039556]),
            {
              "class": 1,
              "system:index": "1557"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59405136108398, 19.389862643973146]),
            {
              "class": 1,
              "system:index": "1558"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60722637176514, 19.3921295779943]),
            {
              "class": 1,
              "system:index": "1559"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58950233459473, 19.379822985316032]),
            {
              "class": 1,
              "system:index": "1560"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57667064666748, 19.37686764530762]),
            {
              "class": 1,
              "system:index": "1561"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56971836090088, 19.373224001639606]),
            {
              "class": 1,
              "system:index": "1562"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57761478424072, 19.3497002973011]),
            {
              "class": 1,
              "system:index": "1563"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55409717559814, 19.34451733835484]),
            {
              "class": 1,
              "system:index": "1564"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58055448532104, 19.306913341590086]),
            {
              "class": 1,
              "system:index": "1565"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57699251174927, 19.31171273813244]),
            {
              "class": 1,
              "system:index": "1566"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57012605667114, 19.306184307007793]),
            {
              "class": 1,
              "system:index": "1567"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58456707000732, 19.31373775770577]),
            {
              "class": 1,
              "system:index": "1568"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57094144821167, 19.30278210265795]),
            {
              "class": 1,
              "system:index": "1569"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57319450378418, 19.297233117564797]),
            {
              "class": 1,
              "system:index": "1570"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56684303283691, 19.28672193296962]),
            {
              "class": 1,
              "system:index": "1571"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55890369415283, 19.287289027590155]),
            {
              "class": 1,
              "system:index": "1572"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55300283432007, 19.28218510529959]),
            {
              "class": 1,
              "system:index": "1573"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55263805389404, 19.27167295471107]),
            {
              "class": 1,
              "system:index": "1574"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54111528396606, 19.267014175195495]),
            {
              "class": 1,
              "system:index": "1575"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5296139717102, 19.26045114810137]),
            {
              "class": 1,
              "system:index": "1576"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52678155899048, 19.24736482246566]),
            {
              "class": 1,
              "system:index": "1577"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.53450632095337, 19.246534230965654]),
            {
              "class": 1,
              "system:index": "1578"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54577159881592, 19.253300390556205]),
            {
              "class": 1,
              "system:index": "1579"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55521297454834, 19.252490086750388]),
            {
              "class": 1,
              "system:index": "1580"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49918699264526, 19.248742379587163]),
            {
              "class": 1,
              "system:index": "1581"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49184846878052, 19.248742379587163]),
            {
              "class": 1,
              "system:index": "1582"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49105453491211, 19.25700747942093]),
            {
              "class": 1,
              "system:index": "1583"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4912691116333, 19.23808626886907]),
            {
              "class": 1,
              "system:index": "1584"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47841596603394, 19.235533561699476]),
            {
              "class": 1,
              "system:index": "1585"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4661636352539, 19.231420783343612]),
            {
              "class": 1,
              "system:index": "1586"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47521877288818, 19.226031469605875]),
            {
              "class": 1,
              "system:index": "1587"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.46236562728882, 19.213996048154463]),
            {
              "class": 1,
              "system:index": "1588"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.46116399765015, 19.219790990726104]),
            {
              "class": 1,
              "system:index": "1589"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45341777801514, 19.2106324563255]),
            {
              "class": 1,
              "system:index": "1590"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4473237991333, 19.201838162249157]),
            {
              "class": 1,
              "system:index": "1591"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42839813232422, 19.188321591105684]),
            {
              "class": 1,
              "system:index": "1592"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43314027786255, 19.181998616096763]),
            {
              "class": 1,
              "system:index": "1593"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42820501327515, 19.183782043886307]),
            {
              "class": 1,
              "system:index": "1594"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42743253707886, 19.171398982083694]),
            {
              "class": 1,
              "system:index": "1595"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42144618183374, 19.165784750579228]),
            {
              "class": 1,
              "system:index": "1596"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43704557418823, 19.15854879835995]),
            {
              "class": 1,
              "system:index": "1597"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43951320648193, 19.164751062562235]),
            {
              "class": 1,
              "system:index": "1598"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.44058609008789, 19.157028599969387]),
            {
              "class": 1,
              "system:index": "1599"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4148154258728, 19.151576039825535]),
            {
              "class": 1,
              "system:index": "1600"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.4038290977478, 19.14873820487725]),
            {
              "class": 1,
              "system:index": "1601"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3963189125061, 19.130108634016338]),
            {
              "class": 1,
              "system:index": "1602"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.34992742538452, 19.110625409735935]),
            {
              "class": 1,
              "system:index": "1603"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3540472984314, 19.111841911350105]),
            {
              "class": 1,
              "system:index": "1604"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.38994598388672, 19.050458251342892]),
            {
              "class": 1,
              "system:index": "1605"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.38346576690674, 19.057658371046397]),
            {
              "class": 1,
              "system:index": "1606"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.38520383834839, 19.061978292848064]),
            {
              "class": 1,
              "system:index": "1607"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.38870143890381, 19.044921045343592]),
            {
              "class": 1,
              "system:index": "1608"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3850965499878, 19.035590536787534]),
            {
              "class": 1,
              "system:index": "1609"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39028930664062, 19.030864231319253]),
            {
              "class": 1,
              "system:index": "1610"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.400803565979, 19.02540751397622]),
            {
              "class": 1,
              "system:index": "1611"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.39091157913208, 19.010091234870572]),
            {
              "class": 1,
              "system:index": "1612"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36644983291626, 19.00463383557997]),
            {
              "class": 1,
              "system:index": "1613"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36529111862183, 19.020741777103442]),
            {
              "class": 1,
              "system:index": "1614"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36428260803223, 19.023865806718373]),
            {
              "class": 1,
              "system:index": "1615"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.35981941223145, 19.01786112633105]),
            {
              "class": 1,
              "system:index": "1616"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37338066101074, 19.016339635706117]),
            {
              "class": 1,
              "system:index": "1617"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.35074281692505, 18.99438804855749]),
            {
              "class": 1,
              "system:index": "1618"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37565517425537, 18.994246023314773]),
            {
              "class": 1,
              "system:index": "1619"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.34625816345215, 19.001732617342807]),
            {
              "class": 1,
              "system:index": "1620"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.34278202056885, 18.97856163326005]),
            {
              "class": 1,
              "system:index": "1621"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.32874870300293, 18.957579170283907]),
            {
              "class": 1,
              "system:index": "1622"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.34570026397705, 18.949887644941775]),
            {
              "class": 1,
              "system:index": "1623"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3240065574646, 18.946478095490082]),
            {
              "class": 1,
              "system:index": "1624"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.31061697006226, 18.955407720161787]),
            {
              "class": 1,
              "system:index": "1625"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.31126070022583, 18.940795358293993]),
            {
              "class": 1,
              "system:index": "1626"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.27808713912964, 18.927358974736354]),
            {
              "class": 1,
              "system:index": "1627"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.22137451171875, 18.88807876037992]),
            {
              "class": 1,
              "system:index": "1628"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20770597457886, 18.88682001707031]),
            {
              "class": 1,
              "system:index": "1629"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.2422742843628, 18.91051122702143]),
            {
              "class": 1,
              "system:index": "1630"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1298360824585, 18.888322387024438]),
            {
              "class": 1,
              "system:index": "1631"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.13747501373291, 18.88580489460662]),
            {
              "class": 1,
              "system:index": "1632"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.92126750946045, 18.89342054218377]),
            {
              "class": 1,
              "system:index": "1633"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.9016981124878, 18.90121617022603]),
            {
              "class": 1,
              "system:index": "1634"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.88925266265869, 18.907306251956154]),
            {
              "class": 1,
              "system:index": "1635"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.88878059387207, 18.911366183272392]),
            {
              "class": 1,
              "system:index": "1636"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.88830852508545, 18.920703651244818]),
            {
              "class": 1,
              "system:index": "1637"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.88427448272705, 18.932841579802936]),
            {
              "class": 1,
              "system:index": "1638"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.8879222869873, 18.92760492278345]),
            {
              "class": 1,
              "system:index": "1639"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.88401699066162, 18.94303026364984]),
            {
              "class": 1,
              "system:index": "1640"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.8791675567627, 18.943070854772373]),
            {
              "class": 1,
              "system:index": "1641"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.88401699066162, 18.95423303884535]),
            {
              "class": 1,
              "system:index": "1642"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.8754768371582, 18.969452995389698]),
            {
              "class": 1,
              "system:index": "1643"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.87840580940247, 18.97354843260102]),
            {
              "class": 1,
              "system:index": "1644"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.8689215183258, 18.976095040391396]),
            {
              "class": 1,
              "system:index": "1645"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86541318893433, 18.98136061193854]),
            {
              "class": 1,
              "system:index": "1646"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86128258705139, 18.978732919772867]),
            {
              "class": 1,
              "system:index": "1647"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86267733573914, 18.992002848513433]),
            {
              "class": 1,
              "system:index": "1648"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86959760263562, 18.99479264547354]),
            {
              "class": 1,
              "system:index": "1649"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86996238306165, 18.99857654990018]),
            {
              "class": 1,
              "system:index": "1650"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.8746829032898, 19.00018950177292]),
            {
              "class": 1,
              "system:index": "1651"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.96416139602661, 19.08600960530999]),
            {
              "class": 1,
              "system:index": "1652"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98098421096802, 19.088889072997745]),
            {
              "class": 1,
              "system:index": "1653"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.99203491210938, 19.08148752330461]),
            {
              "class": 1,
              "system:index": "1654"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.98467493057251, 19.09604696933846]),
            {
              "class": 1,
              "system:index": "1655"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.00475931167603, 19.09438425614539]),
            {
              "class": 1,
              "system:index": "1656"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.01035976409912, 19.09330956677977]),
            {
              "class": 1,
              "system:index": "1657"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.01366424560547, 19.0751401775249]),
            {
              "class": 1,
              "system:index": "1658"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.02186107635498, 19.079114901748135]),
            {
              "class": 1,
              "system:index": "1659"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.93731784820557, 19.032527581628433]),
            {
              "class": 1,
              "system:index": "1660"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.90210580825806, 19.046685669510648]),
            {
              "class": 1,
              "system:index": "1661"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.87663555145264, 19.040478977320745]),
            {
              "class": 1,
              "system:index": "1662"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86564922332764, 19.037700088944288]),
            {
              "class": 1,
              "system:index": "1663"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.85745239257812, 19.022283513343798]),
            {
              "class": 1,
              "system:index": "1664"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.84494256973267, 19.035022575858797]),
            {
              "class": 1,
              "system:index": "1665"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.83775424957275, 18.966629956934806]),
            {
              "class": 1,
              "system:index": "1666"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.83232545852661, 18.96669083500227]),
            {
              "class": 1,
              "system:index": "1667"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.83114528656006, 18.965452976594108]),
            {
              "class": 1,
              "system:index": "1668"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.82462215423584, 18.964154230023876]),
            {
              "class": 1,
              "system:index": "1669"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.83923482894897, 18.963525146017137]),
            {
              "class": 1,
              "system:index": "1670"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.84747457504272, 18.96100878625694]),
            {
              "class": 1,
              "system:index": "1671"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.85320377349854, 18.95705153079796]),
            {
              "class": 1,
              "system:index": "1672"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.8601131439209, 18.955975952830908]),
            {
              "class": 1,
              "system:index": "1673"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86142206192017, 18.94866995670545]),
            {
              "class": 1,
              "system:index": "1674"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.78147077560425, 18.94976586660845]),
            {
              "class": 1,
              "system:index": "1675"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.78591251373291, 18.95043559183976]),
            {
              "class": 1,
              "system:index": "1676"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.77350997924805, 18.952688284254616]),
            {
              "class": 1,
              "system:index": "1677"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.7652702331543, 18.9646006653898]),
            {
              "class": 1,
              "system:index": "1678"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.78166389465332, 18.95916206881809]),
            {
              "class": 1,
              "system:index": "1679"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.74102306365967, 18.957274753182766]),
            {
              "class": 1,
              "system:index": "1680"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.73072338104248, 18.957842979491897]),
            {
              "class": 1,
              "system:index": "1681"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.72405004501343, 18.954555357619725]),
            {
              "class": 1,
              "system:index": "1682"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.7072057723999, 18.96890271313452]),
            {
              "class": 1,
              "system:index": "1683"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.662917137146, 18.9433120123886]),
            {
              "class": 1,
              "system:index": "1684"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.6472315788269, 18.937365316346945]),
            {
              "class": 1,
              "system:index": "1685"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.64356231689453, 18.941505700493202]),
            {
              "class": 1,
              "system:index": "1686"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.64109468460083, 18.913231329861073]),
            {
              "class": 1,
              "system:index": "1687"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.61150455474854, 18.896909989849505]),
            {
              "class": 1,
              "system:index": "1688"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.58272981643677, 18.89112405804712]),
            {
              "class": 1,
              "system:index": "1689"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.57815933227539, 18.896889688684027]),
            {
              "class": 1,
              "system:index": "1690"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.56496286392212, 18.891773716496093]),
            {
              "class": 1,
              "system:index": "1691"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.56537055969238, 18.898818288409533]),
            {
              "class": 1,
              "system:index": "1692"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.55356884002686, 18.911404393339478]),
            {
              "class": 1,
              "system:index": "1693"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.54421329498291, 18.898594978000038]),
            {
              "class": 1,
              "system:index": "1694"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.5243649482727, 18.90157919249235]),
            {
              "class": 1,
              "system:index": "1695"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.53841972351074, 18.89374297826718]),
            {
              "class": 1,
              "system:index": "1696"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.41947984695435, 18.932717410502132]),
            {
              "class": 1,
              "system:index": "1697"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.39079093933105, 18.928333240459224]),
            {
              "class": 1,
              "system:index": "1698"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.38647794723511, 18.941079489838064]),
            {
              "class": 1,
              "system:index": "1699"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.37757301330566, 18.93318423664515]),
            {
              "class": 1,
              "system:index": "1700"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.37158632278442, 18.937750945315674]),
            {
              "class": 1,
              "system:index": "1701"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.373131275177, 18.94296698865035]),
            {
              "class": 1,
              "system:index": "1702"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.36484861373901, 18.93470648674316]),
            {
              "class": 1,
              "system:index": "1703"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.36253118515015, 18.925430694218985]),
            {
              "class": 1,
              "system:index": "1704"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.35628700256348, 18.93673613195826]),
            {
              "class": 1,
              "system:index": "1705"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.3636040687561, 18.908988746631966]),
            {
              "class": 1,
              "system:index": "1706"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.36300325393677, 18.92064036778763]),
            {
              "class": 1,
              "system:index": "1707"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.36519193649292, 18.89081952978142]),
            {
              "class": 1,
              "system:index": "1708"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.35697364807129, 18.88036372342204]),
            {
              "class": 1,
              "system:index": "1709"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.34873390197754, 18.89189552717463]),
            {
              "class": 1,
              "system:index": "1710"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.3322114944458, 18.90151829068773]),
            {
              "class": 1,
              "system:index": "1711"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.3183069229126, 18.91061271464865]),
            {
              "class": 1,
              "system:index": "1712"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.31277084350586, 18.918630825568727]),
            {
              "class": 1,
              "system:index": "1713"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.29624843597412, 18.92392865748761]),
            {
              "class": 1,
              "system:index": "1714"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2956690788269, 18.90494905780024]),
            {
              "class": 1,
              "system:index": "1715"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.30955219268799, 18.912114871025057]),
            {
              "class": 1,
              "system:index": "1716"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.30852222442627, 18.903528038536606]),
            {
              "class": 1,
              "system:index": "1717"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28472566604614, 18.913231329861073]),
            {
              "class": 1,
              "system:index": "1718"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28341674804688, 18.9044821528021]),
            {
              "class": 1,
              "system:index": "1719"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28062725067139, 18.911343495111694]),
            {
              "class": 1,
              "system:index": "1720"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2712287902832, 18.88446491362007]),
            {
              "class": 1,
              "system:index": "1721"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.25646591186523, 18.87770398700152]),
            {
              "class": 1,
              "system:index": "1722"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28099203109741, 18.872607732866157]),
            {
              "class": 1,
              "system:index": "1723"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2873649597168, 18.87415083812592]),
            {
              "class": 1,
              "system:index": "1724"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28835201263428, 18.867308276374718]),
            {
              "class": 1,
              "system:index": "1725"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2804126739502, 18.859714127190166]),
            {
              "class": 1,
              "system:index": "1726"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.26996278762817, 18.85323649293143]),
            {
              "class": 1,
              "system:index": "1727"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28719329833984, 18.84365157222323]),
            {
              "class": 1,
              "system:index": "1728"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.27998352050781, 18.834533205423934]),
            {
              "class": 1,
              "system:index": "1729"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2689757347107, 18.83394425157214]),
            {
              "class": 1,
              "system:index": "1730"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.26172304153442, 18.83721393479523]),
            {
              "class": 1,
              "system:index": "1731"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.29302978515625, 18.83240077650866]),
            {
              "class": 1,
              "system:index": "1732"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.30590438842773, 18.827282836678208]),
            {
              "class": 1,
              "system:index": "1733"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2642765045166, 18.81911818143819]),
            {
              "class": 1,
              "system:index": "1734"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.30084037780762, 18.813959214739988]),
            {
              "class": 1,
              "system:index": "1735"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28785848617554, 18.801772050807465]),
            {
              "class": 1,
              "system:index": "1736"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.26245260238647, 18.80341735956601]),
            {
              "class": 1,
              "system:index": "1737"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.28260135650635, 18.79102629252176]),
            {
              "class": 1,
              "system:index": "1738"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.2803053855896, 18.781762866438612]),
            {
              "class": 1,
              "system:index": "1739"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.25543594360352, 18.77930472268268]),
            {
              "class": 1,
              "system:index": "1740"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.24876260757446, 18.771340903273494]),
            {
              "class": 1,
              "system:index": "1741"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.23593091964722, 18.777598221631365]),
            {
              "class": 1,
              "system:index": "1742"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.22756242752075, 18.78842608400196]),
            {
              "class": 1,
              "system:index": "1743"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.21588945388794, 18.787004077986882]),
            {
              "class": 1,
              "system:index": "1744"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.20629787445068, 18.793829597354073]),
            {
              "class": 1,
              "system:index": "1745"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.20398044586182, 18.807093877728434]),
            {
              "class": 1,
              "system:index": "1746"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18715763092041, 18.807561053841397]),
            {
              "class": 1,
              "system:index": "1747"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18303775787354, 18.814324806098544]),
            {
              "class": 1,
              "system:index": "1748"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18732929229736, 18.82212412053968]),
            {
              "class": 1,
              "system:index": "1749"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.15237474441528, 18.810425028095853]),
            {
              "class": 1,
              "system:index": "1750"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18529081344604, 18.83258355719065]),
            {
              "class": 1,
              "system:index": "1751"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18245840072632, 18.841113101133278]),
            {
              "class": 1,
              "system:index": "1752"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.18941068649292, 18.84235187981984]),
            {
              "class": 1,
              "system:index": "1753"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.21185541152954, 18.851713501856292]),
            {
              "class": 1,
              "system:index": "1754"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.22185468673706, 18.861622849446807]),
            {
              "class": 1,
              "system:index": "1755"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.19732856750488, 18.858840981044754]),
            {
              "class": 1,
              "system:index": "1756"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.19561195373535, 18.86830320626732]),
            {
              "class": 1,
              "system:index": "1757"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.09810829162598, 18.825536202487527]),
            {
              "class": 1,
              "system:index": "1758"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.08495473861694, 18.836970233893148]),
            {
              "class": 1,
              "system:index": "1759"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.08038425445557, 18.799842325647973]),
            {
              "class": 1,
              "system:index": "1760"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.05695247650146, 18.78734942340865]),
            {
              "class": 1,
              "system:index": "1761"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0624885559082, 18.791391943624905]),
            {
              "class": 1,
              "system:index": "1762"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.05566501617432, 18.753156793456387]),
            {
              "class": 1,
              "system:index": "1763"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.01283550262451, 18.72804121478439]),
            {
              "class": 1,
              "system:index": "1764"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.00440263748169, 18.733914043042724]),
            {
              "class": 1,
              "system:index": "1765"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.01807117462158, 18.71241321420277]),
            {
              "class": 1,
              "system:index": "1766"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0097885131836, 18.714404899264856]),
            {
              "class": 1,
              "system:index": "1767"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.00137710571289, 18.713530999523183]),
            {
              "class": 1,
              "system:index": "1768"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8842396736145, 18.54519090592218]),
            {
              "class": 1,
              "system:index": "1769"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.88788747787476, 18.555972589561094]),
            {
              "class": 1,
              "system:index": "1770"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8734679222107, 18.547204894761954]),
            {
              "class": 1,
              "system:index": "1771"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.85840463638306, 18.550052919244035]),
            {
              "class": 1,
              "system:index": "1772"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.85610866546631, 18.544641632116694]),
            {
              "class": 1,
              "system:index": "1773"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.78847408294678, 18.49630098973785]),
            {
              "class": 1,
              "system:index": "1774"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.87138652801514, 18.517666377001312]),
            {
              "class": 1,
              "system:index": "1775"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8409595489502, 18.44989844265291]),
            {
              "class": 1,
              "system:index": "1776"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.83241939544678, 18.43145603663521]),
            {
              "class": 1,
              "system:index": "1777"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.77572822570801, 18.382022265540957]),
            {
              "class": 1,
              "system:index": "1778"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.84465026855469, 18.383651281407996]),
            {
              "class": 1,
              "system:index": "1779"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.86962699890137, 18.35990685301591]),
            {
              "class": 1,
              "system:index": "1780"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.88129997253418, 18.420340783378347]),
            {
              "class": 1,
              "system:index": "1781"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8909559249878, 18.435079535327446]),
            {
              "class": 1,
              "system:index": "1782"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.89928150177002, 18.452992338908224]),
            {
              "class": 1,
              "system:index": "1783"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8592414855957, 18.451689652542186]),
            {
              "class": 1,
              "system:index": "1784"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.87082862854004, 18.44806650412392]),
            {
              "class": 1,
              "system:index": "1785"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.89546203613281, 18.50228356696817]),
            {
              "class": 1,
              "system:index": "1786"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.9072208404541, 18.508428717772073]),
            {
              "class": 1,
              "system:index": "1787"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8912992477417, 18.488323895034096]),
            {
              "class": 1,
              "system:index": "1788"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.91099739074707, 18.517300135689872]),
            {
              "class": 1,
              "system:index": "1789"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.89983940124512, 18.541429691951215]),
            {
              "class": 1,
              "system:index": "1790"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.90494632720947, 18.566369479030207]),
            {
              "class": 1,
              "system:index": "1791"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.90752124786377, 18.574871770631812]),
            {
              "class": 1,
              "system:index": "1792"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.92395782470703, 18.575888762771694]),
            {
              "class": 1,
              "system:index": "1793"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.94176769256592, 18.597325544822816]),
            {
              "class": 1,
              "system:index": "1794"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.95477104187012, 18.589434519394402]),
            {
              "class": 1,
              "system:index": "1795"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.9363603591919, 18.61452996621504]),
            {
              "class": 1,
              "system:index": "1796"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.92623233795166, 18.623029853829337]),
            {
              "class": 1,
              "system:index": "1797"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.97064971923828, 18.5813397372322]),
            {
              "class": 1,
              "system:index": "1798"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.98172187805176, 18.578329519155577]),
            {
              "class": 1,
              "system:index": "1799"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.99579811096191, 18.58744136751458]),
            {
              "class": 1,
              "system:index": "1800"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.9878158569336, 18.577760012458334]),
            {
              "class": 1,
              "system:index": "1801"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.00759983062744, 18.60131159391791]),
            {
              "class": 1,
              "system:index": "1802"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.00146293640137, 18.612211741325403]),
            {
              "class": 1,
              "system:index": "1803"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.02025985717773, 18.599399928956775]),
            {
              "class": 1,
              "system:index": "1804"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.04055881500244, 18.65003146129757]),
            {
              "class": 1,
              "system:index": "1805"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0535192489624, 18.655032793851472]),
            {
              "class": 1,
              "system:index": "1806"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0599136352539, 18.66714923229692]),
            {
              "class": 1,
              "system:index": "1807"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.07154369354248, 18.672759907231725]),
            {
              "class": 1,
              "system:index": "1808"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.04794025421143, 18.690403862942347]),
            {
              "class": 1,
              "system:index": "1809"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.07429027557373, 18.69207059326061]),
            {
              "class": 1,
              "system:index": "1810"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.34614562988281, 18.241421062203283]),
            {
              "class": 1,
              "system:index": "1811"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.31550407409668, 18.245456124371223]),
            {
              "class": 1,
              "system:index": "1812"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.35854816436768, 18.24036133337713]),
            {
              "class": 1,
              "system:index": "1813"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.37352561950684, 18.246352792131926]),
            {
              "class": 1,
              "system:index": "1814"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.39682865142822, 18.263388600371076]),
            {
              "class": 1,
              "system:index": "1815"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.36215305328369, 18.266934120695574]),
            {
              "class": 1,
              "system:index": "1816"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.40099143981934, 18.27516596905384]),
            {
              "class": 1,
              "system:index": "1817"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.28825283050537, 18.25478939403215]),
            {
              "class": 1,
              "system:index": "1818"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.3022512793541, 18.26169288086753]),
            {
              "class": 1,
              "system:index": "1819"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.26550233364105, 18.30408735761289]),
            {
              "class": 1,
              "system:index": "1820"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.26158630847931, 18.300914392681392]),
            {
              "class": 1,
              "system:index": "1821"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.27036786079407, 18.310606268489906]),
            {
              "class": 1,
              "system:index": "1822"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.19405364990234, 18.33762564305853]),
            {
              "class": 1,
              "system:index": "1823"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.16555786132812, 18.334774095100038]),
            {
              "class": 1,
              "system:index": "1824"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.18577098846436, 18.30552264618086]),
            {
              "class": 1,
              "system:index": "1825"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.14749050140381, 18.356892726896017]),
            {
              "class": 1,
              "system:index": "1826"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.1971435546875, 19.06707585070348]),
            {
              "class": 1,
              "system:index": "1827"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.12650489807129, 19.057989966742507]),
            {
              "class": 1,
              "system:index": "1828"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.09800910949707, 19.04014124566516]),
            {
              "class": 1,
              "system:index": "1829"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.12255668640137, 19.023264326228762]),
            {
              "class": 1,
              "system:index": "1830"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.09114265441895, 19.017827645762708]),
            {
              "class": 1,
              "system:index": "1831"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.08135795593262, 19.05912572946384]),
            {
              "class": 1,
              "system:index": "1832"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.15877723693848, 18.967428464559855]),
            {
              "class": 1,
              "system:index": "1833"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.13611793518066, 18.944780390089246]),
            {
              "class": 1,
              "system:index": "1834"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.1118278503418, 18.946160468248333]),
            {
              "class": 1,
              "system:index": "1835"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.1191234588623, 18.9379610128923]),
            {
              "class": 1,
              "system:index": "1836"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.04745483398438, 18.92464618816018]),
            {
              "class": 1,
              "system:index": "1837"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.02084732055664, 18.985934284261877]),
            {
              "class": 1,
              "system:index": "1838"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.99183654785156, 18.96117822794157]),
            {
              "class": 1,
              "system:index": "1839"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.9569034576416, 18.92456499694951]),
            {
              "class": 1,
              "system:index": "1840"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.93081092834473, 18.998189199779357]),
            {
              "class": 1,
              "system:index": "1841"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.92377281188965, 18.999325371408617]),
            {
              "class": 1,
              "system:index": "1842"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.95716094970703, 19.024075755821386]),
            {
              "class": 1,
              "system:index": "1843"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.98351097106934, 19.031378443836903]),
            {
              "class": 1,
              "system:index": "1844"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.84858512878418, 19.0078464113329]),
            {
              "class": 1,
              "system:index": "1845"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8320198059082, 19.00151653764359]),
            {
              "class": 1,
              "system:index": "1846"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.81416702270508, 19.012390787481063]),
            {
              "class": 1,
              "system:index": "1847"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.82000350952148, 19.021316879041333]),
            {
              "class": 1,
              "system:index": "1848"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.94055271148682, 18.95818797309232]),
            {
              "class": 1,
              "system:index": "1849"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.9283218383789, 18.962165494824504]),
            {
              "class": 1,
              "system:index": "1850"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.96293306350708, 18.97793259372205]),
            {
              "class": 1,
              "system:index": "1851"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.96838331222534, 18.966528483531054]),
            {
              "class": 1,
              "system:index": "1852"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.98035669326782, 18.993799647570395]),
            {
              "class": 1,
              "system:index": "1853"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97848987579346, 18.989031574176543]),
            {
              "class": 1,
              "system:index": "1854"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97868299484253, 18.97330610928523]),
            {
              "class": 1,
              "system:index": "1855"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97501373291016, 18.95579329691773]),
            {
              "class": 1,
              "system:index": "1856"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8316764831543, 19.01191708065898]),
            {
              "class": 1,
              "system:index": "1857"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.81472492218018, 19.015771599064074]),
            {
              "class": 1,
              "system:index": "1858"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.81047630310059, 19.047760651339644]),
            {
              "class": 1,
              "system:index": "1859"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.84141826629639, 19.021370635023274]),
            {
              "class": 1,
              "system:index": "1860"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8119568824768, 19.019220302940283]),
            {
              "class": 1,
              "system:index": "1861"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.80300903320312, 18.99237938466984]),
            {
              "class": 1,
              "system:index": "1862"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.79288101196289, 18.983573484259953]),
            {
              "class": 1,
              "system:index": "1863"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.76101636886597, 18.94968468760988]),
            {
              "class": 1,
              "system:index": "1864"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.73880767822266, 18.93407729171809]),
            {
              "class": 1,
              "system:index": "1865"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.73282098770142, 18.911952476391612]),
            {
              "class": 1,
              "system:index": "1866"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.71535444259644, 18.923421209595052]),
            {
              "class": 1,
              "system:index": "1867"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8296594619751, 19.007354771398994]),
            {
              "class": 1,
              "system:index": "1868"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8131799697876, 19.005528865617805]),
            {
              "class": 1,
              "system:index": "1869"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.81764316558838, 19.025491013466247]),
            {
              "class": 1,
              "system:index": "1870"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.83708381652832, 18.99120495402205]),
            {
              "class": 1,
              "system:index": "1871"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.85682487487793, 18.99420780249426]),
            {
              "class": 1,
              "system:index": "1872"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.82845783233643, 18.97874661238216]),
            {
              "class": 1,
              "system:index": "1873"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8539924621582, 18.958860032766673]),
            {
              "class": 1,
              "system:index": "1874"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.79240894317627, 18.963405745826634]),
            {
              "class": 1,
              "system:index": "1875"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.87729549407959, 18.948631725431902]),
            {
              "class": 1,
              "system:index": "1876"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.87922668457031, 18.87734087331529]),
            {
              "class": 1,
              "system:index": "1877"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89081382751465, 18.860691146400953]),
            {
              "class": 1,
              "system:index": "1878"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.87695217132568, 18.855614681289453]),
            {
              "class": 1,
              "system:index": "1879"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88626480102539, 18.83896279769505]),
            {
              "class": 1,
              "system:index": "1880"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.87510681152344, 18.817637852908607]),
            {
              "class": 1,
              "system:index": "1881"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89197254180908, 18.789606669187556]),
            {
              "class": 1,
              "system:index": "1882"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.9036455154419, 18.7802619039685]),
            {
              "class": 1,
              "system:index": "1883"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89021301269531, 18.76640632001688]),
            {
              "class": 1,
              "system:index": "1884"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88042831420898, 18.770469659135138]),
            {
              "class": 1,
              "system:index": "1885"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88197326660156, 18.742227428391143]),
            {
              "class": 1,
              "system:index": "1886"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8996114730835, 18.71227331189425]),
            {
              "class": 1,
              "system:index": "1887"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.88171577453613, 18.715972139973484]),
            {
              "class": 1,
              "system:index": "1888"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.8701286315918, 18.720687012325477]),
            {
              "class": 1,
              "system:index": "1889"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.85665321350098, 18.702233228003198]),
            {
              "class": 1,
              "system:index": "1890"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89313125610352, 18.697273938459208]),
            {
              "class": 1,
              "system:index": "1891"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.91381645202637, 18.678898911273826]),
            {
              "class": 1,
              "system:index": "1892"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.92475986480713, 18.6430374808861]),
            {
              "class": 1,
              "system:index": "1893"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.94428634643555, 18.641248276835373]),
            {
              "class": 1,
              "system:index": "1894"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.90068435668945, 18.62925199022153]),
            {
              "class": 1,
              "system:index": "1895"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.78785991668701, 18.652918427338456]),
            {
              "class": 1,
              "system:index": "1896"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75850582122803, 18.645517937138916]),
            {
              "class": 1,
              "system:index": "1897"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.72443103790283, 18.67548386361681]),
            {
              "class": 1,
              "system:index": "1898"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.7131872177124, 18.703534001206435]),
            {
              "class": 1,
              "system:index": "1899"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.69391822814941, 18.727677787933818]),
            {
              "class": 1,
              "system:index": "1900"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.7221565246582, 18.710850664172344]),
            {
              "class": 1,
              "system:index": "1901"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.73026752471924, 18.729994434668832]),
            {
              "class": 1,
              "system:index": "1902"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.6873950958252, 18.71946766138965]),
            {
              "class": 1,
              "system:index": "1903"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.69820976257324, 18.732961321823023]),
            {
              "class": 1,
              "system:index": "1904"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.66259002685547, 18.71954895172562]),
            {
              "class": 1,
              "system:index": "1905"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.63993072509766, 18.77311077704719]),
            {
              "class": 1,
              "system:index": "1906"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.63340759277344, 18.7751423780518]),
            {
              "class": 1,
              "system:index": "1907"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.65435028076172, 18.779896228703866]),
            {
              "class": 1,
              "system:index": "1908"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.58199501037598, 18.744543875598538]),
            {
              "class": 1,
              "system:index": "1909"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.56757545471191, 18.7358875156542]),
            {
              "class": 1,
              "system:index": "1910"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.58379745483398, 18.722881821848954]),
            {
              "class": 1,
              "system:index": "1911"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.59881782531738, 18.709631242316778]),
            {
              "class": 1,
              "system:index": "1912"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.56371307373047, 18.69731458896407]),
            {
              "class": 1,
              "system:index": "1913"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.521484375, 18.68324893184731]),
            {
              "class": 1,
              "system:index": "1914"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.52264308929443, 18.671702837742412]),
            {
              "class": 1,
              "system:index": "1915"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.50170040130615, 18.673776313986817]),
            {
              "class": 1,
              "system:index": "1916"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.54186916351318, 18.652918427338456]),
            {
              "class": 1,
              "system:index": "1917"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.52633380889893, 18.629007989163426]),
            {
              "class": 1,
              "system:index": "1918"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.56839084625244, 18.60883602403361]),
            {
              "class": 1,
              "system:index": "1919"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.56233978271484, 18.596959474411104]),
            {
              "class": 1,
              "system:index": "1920"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.61079120635986, 18.600660856486943]),
            {
              "class": 1,
              "system:index": "1921"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.56371307373047, 18.578654990425235]),
            {
              "class": 1,
              "system:index": "1922"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.52517509460449, 18.582397408524784]),
            {
              "class": 1,
              "system:index": "1923"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.54886436462402, 18.600579509168128]),
            {
              "class": 1,
              "system:index": "1924"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.48144435882568, 18.587115992471993]),
            {
              "class": 1,
              "system:index": "1925"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.4544506072998, 18.589434559117382]),
            {
              "class": 1,
              "system:index": "1926"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.43140506744385, 18.589393882781508]),
            {
              "class": 1,
              "system:index": "1927"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.40544128417969, 18.604118041884735]),
            {
              "class": 1,
              "system:index": "1928"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.37634468078613, 18.614001251038605]),
            {
              "class": 1,
              "system:index": "1929"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.36686038970947, 18.58089231547187]),
            {
              "class": 1,
              "system:index": "1930"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.30866718292236, 18.532071286214336]),
            {
              "class": 1,
              "system:index": "1931"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.39621448516846, 18.524136550605323]),
            {
              "class": 1,
              "system:index": "1932"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.3722677230835, 18.520392855189545]),
            {
              "class": 1,
              "system:index": "1933"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.36411380767822, 18.483602622153455]),
            {
              "class": 1,
              "system:index": "1934"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.34441566467285, 18.453277300233413]),
            {
              "class": 1,
              "system:index": "1935"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.33767795562744, 18.478759071471796]),
            {
              "class": 1,
              "system:index": "1936"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.3162202835083, 18.493859101167004]),
            {
              "class": 1,
              "system:index": "1937"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.2803430557251, 18.489382142179963]),
            {
              "class": 1,
              "system:index": "1938"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.26390647888184, 18.486166799459316]),
            {
              "class": 1,
              "system:index": "1939"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.25283432006836, 18.476479706153828]),
            {
              "class": 1,
              "system:index": "1940"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.22734260559082, 18.522793712762525]),
            {
              "class": 1,
              "system:index": "1941"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.19343948364258, 18.498498735199906]),
            {
              "class": 1,
              "system:index": "1942"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.14880752563477, 18.47212440602462]),
            {
              "class": 1,
              "system:index": "1943"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.09748077392578, 18.407840354928997]),
            {
              "class": 1,
              "system:index": "1944"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.10932540893555, 18.41077213300198]),
            {
              "class": 1,
              "system:index": "1945"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.06898498535156, 18.427954605794486]),
            {
              "class": 1,
              "system:index": "1946"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.05782699584961, 18.432758876419577]),
            {
              "class": 1,
              "system:index": "1947"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.94624710083008, 18.48681801298367]),
            {
              "class": 1,
              "system:index": "1948"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.91976833343506, 18.47069975113521]),
            {
              "class": 1,
              "system:index": "1949"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.9047908782959, 18.46593724747598]),
            {
              "class": 1,
              "system:index": "1950"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.92457485198975, 18.50419635941401]),
            {
              "class": 1,
              "system:index": "1951"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.92624855041504, 18.516201046791076]),
            {
              "class": 1,
              "system:index": "1952"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.94697666168213, 18.520392855189545]),
            {
              "class": 1,
              "system:index": "1953"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.93341541290283, 18.488120432608415]),
            {
              "class": 1,
              "system:index": "1954"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.93105506896973, 18.448351473622917]),
            {
              "class": 1,
              "system:index": "1955"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.89487743377686, 18.49267882333556]),
            {
              "class": 1,
              "system:index": "1956"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.88273239135742, 18.524706236201375]),
            {
              "class": 1,
              "system:index": "1957"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.87178897857666, 18.51717809481828]),
            {
              "class": 1,
              "system:index": "1958"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.8200330734253, 18.516404915589863]),
            {
              "class": 1,
              "system:index": "1959"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.79385471343994, 18.517259481902208]),
            {
              "class": 1,
              "system:index": "1960"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.78488540649414, 18.49605683821755]),
            {
              "class": 1,
              "system:index": "1961"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.78698892891407, 18.473019897326942]),
            {
              "class": 1,
              "system:index": "1962"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.77029486000538, 18.47733447169898]),
            {
              "class": 1,
              "system:index": "1963"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.79462718963623, 18.435405239333633]),
            {
              "class": 1,
              "system:index": "1964"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.81132125854492, 18.435486665238745]),
            {
              "class": 1,
              "system:index": "1965"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.83749961853027, 18.434468838652343]),
            {
              "class": 1,
              "system:index": "1966"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.83385181427002, 18.412441595424973]),
            {
              "class": 1,
              "system:index": "1967"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.83479595184326, 18.407840354928997]),
            {
              "class": 1,
              "system:index": "1968"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.72913837432861, 18.480305766394096]),
            {
              "class": 1,
              "system:index": "1969"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.6923599243164, 18.500167344779385]),
            {
              "class": 1,
              "system:index": "1970"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.69931221008301, 18.472694264667073]),
            {
              "class": 1,
              "system:index": "1971"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.66189002990723, 18.440534996015096]),
            {
              "class": 1,
              "system:index": "1972"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.67274761199951, 18.420747948186822]),
            {
              "class": 1,
              "system:index": "1973"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.64884376525879, 18.42164370737328]),
            {
              "class": 1,
              "system:index": "1974"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.61172199249268, 18.477008847231826]),
            {
              "class": 1,
              "system:index": "1975"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.62064838409424, 18.489382142179963]),
            {
              "class": 1,
              "system:index": "1976"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.64124774932861, 18.49190553345063]),
            {
              "class": 1,
              "system:index": "1977"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.65609645843506, 18.49377770295695]),
            {
              "class": 1,
              "system:index": "1978"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.64931583404541, 18.513556330386283]),
            {
              "class": 1,
              "system:index": "1979"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.63635540008545, 18.561365579660347]),
            {
              "class": 1,
              "system:index": "1980"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.63348007202148, 18.574871810358186]),
            {
              "class": 1,
              "system:index": "1981"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.60652923583984, 18.576376956570062]),
            {
              "class": 1,
              "system:index": "1982"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.59966278076172, 18.583210966802923]),
            {
              "class": 1,
              "system:index": "1983"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.56957912445068, 18.57483113054642]),
            {
              "class": 1,
              "system:index": "1984"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.60442638397217, 18.60810397164727]),
            {
              "class": 1,
              "system:index": "1985"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.63523960113525, 18.617092217738207]),
            {
              "class": 1,
              "system:index": "1986"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.61901760101318, 18.613838608832538]),
            {
              "class": 1,
              "system:index": "1987"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.67012977600098, 18.60598898148952]),
            {
              "class": 1,
              "system:index": "1988"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.6391019821167, 18.64206155374052]),
            {
              "class": 1,
              "system:index": "1989"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.59052181243896, 18.64486732916809]),
            {
              "class": 1,
              "system:index": "1990"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.6237382888794, 18.652186525100966]),
            {
              "class": 1,
              "system:index": "1991"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.63738536834717, 18.670320506158436]),
            {
              "class": 1,
              "system:index": "1992"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.62953186035156, 18.686094679272394]),
            {
              "class": 1,
              "system:index": "1993"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.63060474395752, 18.667108574554685]),
            {
              "class": 1,
              "system:index": "1994"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.60142230987549, 18.70166413658313]),
            {
              "class": 1,
              "system:index": "1995"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.61524105072021, 18.72454823227116]),
            {
              "class": 1,
              "system:index": "1996"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.62815856933594, 18.713126894784278]),
            {
              "class": 1,
              "system:index": "1997"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.64948749542236, 18.74698220674634]),
            {
              "class": 1,
              "system:index": "1998"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.59803199768066, 18.779774336772626]),
            {
              "class": 1,
              "system:index": "1999"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.57142448425293, 18.775589326986584]),
            {
              "class": 1,
              "system:index": "2000"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.54970932006836, 18.773354570460658]),
            {
              "class": 1,
              "system:index": "2001"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.53700637817383, 18.761570818881143]),
            {
              "class": 1,
              "system:index": "2002"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.53292942047119, 18.74889220821365]),
            {
              "class": 1,
              "system:index": "2003"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.53061199188232, 18.7456004900863]),
            {
              "class": 1,
              "system:index": "2004"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.52142810821533, 18.73084792809183]),
            {
              "class": 1,
              "system:index": "2005"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.49958419799805, 18.65865155233427]),
            {
              "class": 1,
              "system:index": "2006"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.49194526672363, 18.652755782669534]),
            {
              "class": 1,
              "system:index": "2007"
            }),
        ee.Feature(
            ee.Geometry.Point([-68.48718166351318, 18.580526209746573]),
            {
              "class": 1,
              "system:index": "2008"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.31154251098633, 18.881294028360497]),
            {
              "class": 1,
              "system:index": "2009"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.35617446899414, 18.86391370984404]),
            {
              "class": 1,
              "system:index": "2010"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.30622100830078, 18.85985262807273]),
            {
              "class": 1,
              "system:index": "2011"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.35291290283203, 18.9421921181875]),
            {
              "class": 1,
              "system:index": "2012"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.38501358032227, 18.905493524238814]),
            {
              "class": 1,
              "system:index": "2013"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.46899890899658, 19.004025192590984]),
            {
              "class": 1,
              "system:index": "2010"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.43709135055542, 19.00339625916304]),
            {
              "class": 1,
              "system:index": "2015"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.45833444595337, 19.015609315259955]),
            {
              "class": 1,
              "system:index": "2016"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.82412338256836, 19.14745752085687]),
            {
              "class": 1,
              "system:index": "2017"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.75271224975586, 19.138051703140142]),
            {
              "class": 1,
              "system:index": "2018"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.7001838684082, 19.153457503821095]),
            {
              "class": 1,
              "system:index": "2019"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.78635787963867, 19.164321782438403]),
            {
              "class": 1,
              "system:index": "2020"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.77605819702148, 19.222036381072293]),
            {
              "class": 1,
              "system:index": "2021"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.79116439819336, 19.28102698521444]),
            {
              "class": 1,
              "system:index": "2022"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.69881057739258, 19.230302825518574]),
            {
              "class": 1,
              "system:index": "2023"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.86515045166016, 19.133672950020088]),
            {
              "class": 1,
              "system:index": "2024"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.0594711303711, 19.17648243911006]),
            {
              "class": 1,
              "system:index": "2025"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.25121688842773, 19.17875232896097]),
            {
              "class": 1,
              "system:index": "2026"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.3154182434082, 19.138051703140142]),
            {
              "class": 1,
              "system:index": "2027"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.15474319458008, 19.336108915398558]),
            {
              "class": 1,
              "system:index": "2028"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.95591640472412, 19.58276244469753]),
            {
              "class": 1,
              "system:index": "2029"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.92514610290527, 19.58458192163032]),
            {
              "class": 1,
              "system:index": "2030"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.93634700775146, 19.58737174633483]),
            {
              "class": 1,
              "system:index": "2031"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.91111278533936, 19.617935354031463]),
            {
              "class": 1,
              "system:index": "2032"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.94398593902588, 19.595983508964213]),
            {
              "class": 1,
              "system:index": "2033"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97913360595703, 19.632244887801097]),
            {
              "class": 1,
              "system:index": "2034"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.00024795532227, 19.639358757898336]),
            {
              "class": 1,
              "system:index": "2035"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97638702392578, 19.65301973810643]),
            {
              "class": 1,
              "system:index": "2036"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.02668380737305, 19.6176928085795]),
            {
              "class": 1,
              "system:index": "2037"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.03977298736572, 19.630749318205844]),
            {
              "class": 1,
              "system:index": "2038"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.02204895019531, 19.63317455917947]),
            {
              "class": 1,
              "system:index": "2039"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.03668308258057, 19.58276244469753]),
            {
              "class": 1,
              "system:index": "2040"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.01277923583984, 19.567680211410035]),
            {
              "class": 1,
              "system:index": "2041"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.0462532043457, 19.560805803055512]),
            {
              "class": 1,
              "system:index": "2042"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.04286289215088, 19.54127283634601]),
            {
              "class": 1,
              "system:index": "2043"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.02307891845703, 19.545600227949667]),
            {
              "class": 1,
              "system:index": "2044"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.982008934021, 19.518946506359228]),
            {
              "class": 1,
              "system:index": "2045"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.95359897613525, 19.509642958355073]),
            {
              "class": 1,
              "system:index": "2046"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97677326202393, 19.489011442822463]),
            {
              "class": 1,
              "system:index": "2047"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.9537706375122, 19.491034256723204]),
            {
              "class": 1,
              "system:index": "2048"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.96737480163574, 19.47343492939015]),
            {
              "class": 1,
              "system:index": "2049"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.96870517730713, 19.495362993544067]),
            {
              "class": 1,
              "system:index": "2050"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.93068218231201, 19.479827549901685]),
            {
              "class": 1,
              "system:index": "2051"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.93304252624512, 19.450087584861652]),
            {
              "class": 1,
              "system:index": "2052"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.89343166351318, 19.45870666673764]),
            {
              "class": 1,
              "system:index": "2053"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.95385646820068, 19.436571295142375]),
            {
              "class": 1,
              "system:index": "2054"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97325420379639, 19.452717869668753]),
            {
              "class": 1,
              "system:index": "2055"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.99020576477051, 19.396299034915543]),
            {
              "class": 1,
              "system:index": "2056"
            }),
        ee.Feature(
            ee.Geometry.Point([-69.97475624084473, 19.38140184361948]),
            {
              "class": 1,
              "system:index": "2057"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.06783962249756, 19.417913729647836]),
            {
              "class": 1,
              "system:index": "2058"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.16191005706787, 19.456764378403545]),
            {
              "class": 1,
              "system:index": "2059"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.26288986206055, 19.54147501399537]),
            {
              "class": 1,
              "system:index": "2060"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.30215740203857, 19.529746040431483]),
            {
              "class": 1,
              "system:index": "2061"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.2934455871582, 19.51854201540557]),
            {
              "class": 1,
              "system:index": "2062"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.29417514801025, 19.53856310216608]),
            {
              "class": 1,
              "system:index": "2063"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.34790515899658, 19.567194968671085]),
            {
              "class": 1,
              "system:index": "2064"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.34816265106201, 19.58183248188296]),
            {
              "class": 1,
              "system:index": "2065"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.32468795776367, 19.582519846220098]),
            {
              "class": 1,
              "system:index": "2066"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.31189918518066, 19.56808457924333]),
            {
              "class": 1,
              "system:index": "2067"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.37133693695068, 19.577991274237945]),
            {
              "class": 1,
              "system:index": "2068"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.38472652435303, 19.604150106980235]),
            {
              "class": 1,
              "system:index": "2069"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.37966251373291, 19.620603329848297]),
            {
              "class": 1,
              "system:index": "2070"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.40236473083496, 19.618945956142042]),
            {
              "class": 1,
              "system:index": "2071"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.40202140808105, 19.626545480445383]),
            {
              "class": 1,
              "system:index": "2072"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.38047790527344, 19.64845273506332]),
            {
              "class": 1,
              "system:index": "2073"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.4058837890625, 19.657990752941963]),
            {
              "class": 1,
              "system:index": "2074"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.39785861968994, 19.677509588878014]),
            {
              "class": 1,
              "system:index": "2075"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.42137622833252, 19.661021783940615]),
            {
              "class": 1,
              "system:index": "2076"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.38197994232178, 19.684136561917757]),
            {
              "class": 1,
              "system:index": "2077"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.35743236541748, 19.664739770393876]),
            {
              "class": 1,
              "system:index": "2078"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.4177713394165, 19.69270273049674]),
            {
              "class": 1,
              "system:index": "2079"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.39206504821777, 19.696864429988157]),
            {
              "class": 1,
              "system:index": "2080"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.37004947662354, 19.69488460585957]),
            {
              "class": 1,
              "system:index": "2081"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.42189121246338, 19.687369132199006]),
            {
              "class": 1,
              "system:index": "2082"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.47077178955078, 19.659930619380305]),
            {
              "class": 1,
              "system:index": "2083"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.52699089050293, 19.663567805707583]),
            {
              "class": 1,
              "system:index": "2084"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.54553031921387, 19.674519279582974]),
            {
              "class": 1,
              "system:index": "2085"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.50973892211914, 19.676337717560735]),
            {
              "class": 1,
              "system:index": "2086"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.6267261505127, 19.741666549048777]),
            {
              "class": 1,
              "system:index": "2087"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.62063217163086, 19.75289540849809]),
            {
              "class": 1,
              "system:index": "2088"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.58531284332275, 19.732497074444424]),
            {
              "class": 1,
              "system:index": "2089"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.51184177398682, 19.711328524260335]),
            {
              "class": 1,
              "system:index": "2090"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.45557975769043, 19.767839067615547]),
            {
              "class": 1,
              "system:index": "2091"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.38442611694336, 19.661951288635915]),
            {
              "class": 1,
              "system:index": "2092"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.38120746612549, 19.616803472124584]),
            {
              "class": 1,
              "system:index": "2093"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.34790515899658, 19.591495746486434]),
            {
              "class": 1,
              "system:index": "2094"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.3309965133667, 19.558015518395102]),
            {
              "class": 1,
              "system:index": "2095"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.99845886230469, 19.85280340222156]),
            {
              "class": 1,
              "system:index": "2096"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.08016967773438, 19.856194009841936]),
            {
              "class": 1,
              "system:index": "2097"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.04497909545898, 19.851834643879975]),
            {
              "class": 1,
              "system:index": "2098"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.90250015258789, 19.854256528644914]),
            {
              "class": 1,
              "system:index": "2099"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.84327697753906, 19.83568780105269]),
            {
              "class": 1,
              "system:index": "2100"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.82199096679688, 19.843922896085875]),
            {
              "class": 1,
              "system:index": "2101"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.9028434753418, 19.784652992924492]),
            {
              "class": 1,
              "system:index": "2102"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.92533111572266, 19.812756463865398]),
            {
              "class": 1,
              "system:index": "2103"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.85529327392578, 19.78788352931887]),
            {
              "class": 1,
              "system:index": "2104"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.96927642822266, 19.83972466570548]),
            {
              "class": 1,
              "system:index": "2105"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21321249008179, 19.72488002768938]),
            {
              "class": 1,
              "system:index": "2106"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20731163024902, 19.72580916166407]),
            {
              "class": 1,
              "system:index": "2107"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20422172546387, 19.72485982906473]),
            {
              "class": 1,
              "system:index": "2108"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20767641067505, 19.72948524745847]),
            {
              "class": 1,
              "system:index": "2109"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19430828094482, 19.729121682302583]),
            {
              "class": 1,
              "system:index": "2110"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20383548736572, 19.73510020423912]),
            {
              "class": 1,
              "system:index": "2111"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21791172027588, 19.72651610780832]),
            {
              "class": 1,
              "system:index": "2112"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.17263603210449, 19.734534677962603]),
            {
              "class": 1,
              "system:index": "2113"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.16246509552002, 19.72185020546049]),
            {
              "class": 1,
              "system:index": "2114"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1543755531311, 19.724698239975492]),
            {
              "class": 1,
              "system:index": "2115"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14362525939941, 19.72174921039698]),
            {
              "class": 1,
              "system:index": "2116"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.17898750305176, 19.733524804631198]),
            {
              "class": 1,
              "system:index": "2117"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.12939882278442, 19.73532237472847]),
            {
              "class": 1,
              "system:index": "2118"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14918279647827, 19.712275589733995]),
            {
              "class": 1,
              "system:index": "2119"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14480543136597, 19.7120735874457]),
            {
              "class": 1,
              "system:index": "2120"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13248872756958, 19.740048473735737]),
            {
              "class": 1,
              "system:index": "2121"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1445050239563, 19.745380314934895]),
            {
              "class": 1,
              "system:index": "2122"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1266736984253, 19.75059080585799]),
            {
              "class": 1,
              "system:index": "2123"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13611507415771, 19.75608385237279]),
            {
              "class": 1,
              "system:index": "2124"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14459085464478, 19.76735208369555]),
            {
              "class": 1,
              "system:index": "2125"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13673734664917, 19.774459949041784]),
            {
              "class": 1,
              "system:index": "2126"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.12120199203491, 19.766100097312584]),
            {
              "class": 1,
              "system:index": "2127"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1173825263977, 19.768684832589987]),
            {
              "class": 1,
              "system:index": "2128"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14903259277344, 19.78086079512962]),
            {
              "class": 1,
              "system:index": "2129"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21522951126099, 19.825619151429816]),
            {
              "class": 1,
              "system:index": "2130"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2172679901123, 19.84410832233238]),
            {
              "class": 1,
              "system:index": "2131"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19246292114258, 19.840333961195512]),
            {
              "class": 1,
              "system:index": "2132"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21181774139404, 19.858195786763737]),
            {
              "class": 1,
              "system:index": "2133"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20956468582153, 19.863907110116287]),
            {
              "class": 1,
              "system:index": "2134"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20319175720215, 19.866490255957466]),
            {
              "class": 1,
              "system:index": "2135"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22158098220825, 19.85757015227428]),
            {
              "class": 1,
              "system:index": "2136"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22449922561646, 19.85601614625442]),
            {
              "class": 1,
              "system:index": "2137"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22368383407593, 19.85991122351245]),
            {
              "class": 1,
              "system:index": "2138"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23020696640015, 19.883441106136285]),
            {
              "class": 1,
              "system:index": "2139"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22437047958374, 19.88886903080089]),
            {
              "class": 1,
              "system:index": "2140"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.25308084487915, 19.869658588317105]),
            {
              "class": 1,
              "system:index": "2141"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1224250793457, 19.888828675170025]),
            {
              "class": 1,
              "system:index": "2142"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.11094522476196, 19.88596339909614]),
            {
              "class": 1,
              "system:index": "2143"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.09682607650757, 19.88935329756917]),
            {
              "class": 1,
              "system:index": "2144"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.09116125106812, 19.884409671382805]),
            {
              "class": 1,
              "system:index": "2145"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13135147094727, 19.87730672206929]),
            {
              "class": 1,
              "system:index": "2146"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14967632293701, 19.87040525615126]),
            {
              "class": 1,
              "system:index": "2147"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.10038805007935, 19.867277299842296]),
            {
              "class": 1,
              "system:index": "2148"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.11094522476196, 19.863543851857795]),
            {
              "class": 1,
              "system:index": "2149"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.08704137802124, 19.860920295287134]),
            {
              "class": 1,
              "system:index": "2150"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.05155038833618, 19.87319009435149]),
            {
              "class": 1,
              "system:index": "2151"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.04064989089966, 19.8783156831353]),
            {
              "class": 1,
              "system:index": "2152"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.02987813949585, 19.88418770903686]),
            {
              "class": 1,
              "system:index": "2153"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.05747270584106, 19.894680134281025]),
            {
              "class": 1,
              "system:index": "2154"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.01481485366821, 19.892662414185637]),
            {
              "class": 1,
              "system:index": "2155"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.02178859710693, 19.892279044460707]),
            {
              "class": 1,
              "system:index": "2156"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.99264907836914, 19.88796102661926]),
            {
              "class": 1,
              "system:index": "2157"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.98511743545532, 19.886387140372992]),
            {
              "class": 1,
              "system:index": "2158"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97303676605225, 19.89381251779113]),
            {
              "class": 1,
              "system:index": "2159"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.98443078994751, 19.89627411497537]),
            {
              "class": 1,
              "system:index": "2160"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.96846628189087, 19.89619340747784]),
            {
              "class": 1,
              "system:index": "2161"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97155618667603, 19.86955768698873]),
            {
              "class": 1,
              "system:index": "2162"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97438859939575, 19.86176791061695]),
            {
              "class": 1,
              "system:index": "2163"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.97842264175415, 19.861061564823327]),
            {
              "class": 1,
              "system:index": "2164"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.95119285583496, 19.866792965606248]),
            {
              "class": 1,
              "system:index": "2165"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.94351100921631, 19.870263994938835]),
            {
              "class": 1,
              "system:index": "2166"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.98282146453857, 19.87306901544706]),
            {
              "class": 1,
              "system:index": "2167"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.94861793518066, 19.85460340030064]),
            {
              "class": 1,
              "system:index": "2168"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.93696641921997, 19.861525735270643]),
            {
              "class": 1,
              "system:index": "2169"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.96664237976074, 19.846308309623467]),
            {
              "class": 1,
              "system:index": "2170"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.92213916778564, 19.843300979899986]),
            {
              "class": 1,
              "system:index": "2171"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.91911363601685, 19.84854863232068]),
            {
              "class": 1,
              "system:index": "2172"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.91023015975952, 19.84834680274307]),
            {
              "class": 1,
              "system:index": "2173"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.25285291671753, 19.656553696659454]),
            {
              "class": 1,
              "system:index": "2174"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.2574234008789, 19.643782209318275]),
            {
              "class": 1,
              "system:index": "2175"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.24139451980591, 19.649157674391038]),
            {
              "class": 1,
              "system:index": "2176"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.26175785064697, 19.63537510604517]),
            {
              "class": 1,
              "system:index": "2177"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.27744340896606, 19.65093598410188]),
            {
              "class": 1,
              "system:index": "2178"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.27561950683594, 19.654068186230333]),
            {
              "class": 1,
              "system:index": "2179"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.57841682434082, 19.391074704908778]),
            {
              "class": 1,
              "system:index": "2180"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.60073280334473, 19.403157818455995]),
            {
              "class": 1,
              "system:index": "2181"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.58073425292969, 19.408177005494988]),
            {
              "class": 1,
              "system:index": "2182"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.59090518951416, 19.391803360290123]),
            {
              "class": 1,
              "system:index": "2183"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.55326843261719, 19.400870798806544]),
            {
              "class": 1,
              "system:index": "2184"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.52990102767944, 19.407347231227746]),
            {
              "class": 1,
              "system:index": "2185"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.5279483795166, 19.39678241809236]),
            {
              "class": 1,
              "system:index": "2186"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.50938749313354, 19.378079802968653]),
            {
              "class": 1,
              "system:index": "2187"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.51125431060791, 19.376237762560105]),
            {
              "class": 1,
              "system:index": "2188"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.47863864898682, 19.374294488564495]),
            {
              "class": 1,
              "system:index": "2189"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.47441148757935, 19.361723375103562]),
            {
              "class": 1,
              "system:index": "2190"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.47724390029907, 19.339817766953583]),
            {
              "class": 1,
              "system:index": "2191"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.48788690567017, 19.323376506983124]),
            {
              "class": 1,
              "system:index": "2192"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.51206970214844, 19.360528967678473]),
            {
              "class": 1,
              "system:index": "2193"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.4955472946167, 19.361682886859533]),
            {
              "class": 1,
              "system:index": "2194"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.5326476097107, 19.378525128292594]),
            {
              "class": 1,
              "system:index": "2195"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.5776014328003, 19.383221212137048]),
            {
              "class": 1,
              "system:index": "2196"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.09797954559326, 19.33305755584008]),
            {
              "class": 1,
              "system:index": "2197"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.0844612121582, 19.343707486149633]),
            {
              "class": 1,
              "system:index": "2198"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.07132911682129, 19.349173910544007]),
            {
              "class": 1,
              "system:index": "2199"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.10076904296875, 19.315886624092116]),
            {
              "class": 1,
              "system:index": "2200"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.06132984161377, 19.326375686039572]),
            {
              "class": 1,
              "system:index": "2201"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.09579086303711, 19.374762438905265]),
            {
              "class": 1,
              "system:index": "2202"
            })]),
    puertorico = /* color: #0000ff */ee.Geometry.MultiPolygon(
        [[[[-64.59643363952637, 18.44655545817721],
           [-64.59772109985352, 18.44044880159166],
           [-64.58888053894043, 18.440204530813638],
           [-64.58106994628906, 18.43426050152987],
           [-64.5857048034668, 18.43124769586145],
           [-64.59085464477539, 18.426443383011076],
           [-64.59205627441406, 18.419033078010997],
           [-64.58802223205566, 18.412111076234652],
           [-64.58218574523926, 18.411948202251985],
           [-64.57394599914551, 18.415694264856906],
           [-64.56501960754395, 18.422371826371844],
           [-64.56201553344727, 18.42799054926036],
           [-64.56476211547852, 18.43312052721636],
           [-64.56793785095215, 18.432876246022772],
           [-64.56682205200195, 18.437598954242564],
           [-64.56132888793945, 18.438983171714927],
           [-64.56210136413574, 18.43466763338112],
           [-64.55411911010742, 18.43515619032974],
           [-64.55188751220703, 18.440937342105997],
           [-64.55471992492676, 18.44785818348789],
           [-64.55652236938477, 18.45429024486555],
           [-64.55789566040039, 18.459907924130018],
           [-64.5692253112793, 18.461373375441447],
           [-64.5715856552124, 18.458890242246614],
           [-64.57682132720947, 18.457221230896096],
           [-64.57703590393066, 18.45461591245108],
           [-64.57982540130615, 18.451807009214086],
           [-64.58304405212402, 18.45034147624132],
           [-64.58544731140137, 18.451644172834747],
           [-64.58652019500732, 18.453231820946478],
           [-64.58909511566162, 18.452661897672243],
           [-64.58892345428467, 18.450382185659443],
           [-64.58969593048096, 18.447695343364394],
           [-64.59111213684082, 18.44651474785206],
           [-64.59197044372559, 18.446270485698467],
           [-64.59287166595459, 18.448021023456995],
           [-64.59544658660889, 18.447939603491744]]],
         [[[-64.9017333984375, 17.671829516248756],
           [-64.8904037475586, 17.676082047346714],
           [-64.88525390625, 17.67837183012446],
           [-64.87598419189453, 17.680661583736246],
           [-64.86465454101562, 17.68033447786322],
           [-64.85435485839844, 17.675754933140635],
           [-64.84783172607422, 17.669866775670048],
           [-64.82208251953125, 17.678044720084674],
           [-64.8080062866211, 17.687857762317385],
           [-64.78809356689453, 17.693091165713415],
           [-64.77710723876953, 17.67968026433132],
           [-64.74723815917969, 17.680007371394904],
           [-64.73419189453125, 17.689493217256782],
           [-64.73324775695801, 17.69693434922425],
           [-64.72672462463379, 17.699632705518173],
           [-64.70844268798828, 17.699796240959905],
           [-64.70046043395996, 17.702821619761426],
           [-64.68955993652344, 17.704865765761966],
           [-64.66930389404297, 17.710752776158508],
           [-64.6596908569336, 17.718928859032836],
           [-64.64424133300781, 17.71762071081832],
           [-64.62638854980469, 17.727431589799693],
           [-64.60956573486328, 17.73233682793396],
           [-64.59754943847656, 17.740511926406995],
           [-64.57042694091797, 17.74378186132224],
           [-64.5556640625, 17.761765435716345],
           [-64.5718002319336, 17.76503498232132],
           [-64.59686279296875, 17.75947671753133],
           [-64.62295532226562, 17.76503498232132],
           [-64.66484069824219, 17.76699668159248],
           [-64.68097686767578, 17.761438477768536],
           [-64.70500946044922, 17.76078456007999],
           [-64.72183227539062, 17.761438477768536],
           [-64.73522186279297, 17.769939190146015],
           [-64.74655151367188, 17.785304836705016],
           [-64.76131439208984, 17.78399717354846],
           [-64.77951049804688, 17.784977921813393],
           [-64.80010986328125, 17.78399717354846],
           [-64.82002258300781, 17.771573896194067],
           [-64.8416519165039, 17.76438107778209],
           [-64.8629379272461, 17.771246956180338],
           [-64.8797607421875, 17.773208587293382],
           [-64.89521026611328, 17.757841900899674],
           [-64.89486694335938, 17.738222936441765],
           [-64.8855972290039, 17.708136350936922],
           [-64.90345001220703, 17.680988689014]]],
         [[[-64.57107066060416, 18.471676270433107],
           [-64.56956862355582, 18.476804943450396],
           [-64.57008360768668, 18.48103801832103],
           [-64.57283018971793, 18.48299170993163],
           [-64.57647799397819, 18.482299780032783],
           [-64.57961081410758, 18.47981694975749],
           [-64.58055495168082, 18.478595872496896],
           [-64.58278654958121, 18.477089865231783],
           [-64.58381651784293, 18.47542103092071],
           [-64.5817565813195, 18.47297880509418],
           [-64.57991122151725, 18.473182325241403],
           [-64.577164639486, 18.47456625583757],
           [-64.57476138020866, 18.47301950914294]]],
         [[[-65.59867842122912, 18.117209830575558],
           [-65.58975202962756, 18.077396510307228],
           [-65.53756697103381, 18.067604965305446],
           [-65.48675520345569, 18.07413272264572],
           [-65.37895202636719, 18.08849292939595],
           [-65.3192138671875, 18.106767862320034],
           [-65.25810241699219, 18.130261404130344],
           [-65.24574279785156, 18.147879490965828],
           [-65.28282165527344, 18.153099323930554],
           [-65.3411865234375, 18.16614822412978],
           [-65.42976379394531, 18.168757887180245],
           [-65.48332214355469, 18.14592201341512],
           [-65.57601928710938, 18.126346032750856]]],
         [[[-67.2308349609375, 18.532260967506335],
           [-67.32421875, 18.381153245300208],
           [-67.25830078125, 18.22469544834362],
           [-67.291259765625, 18.03153703106451],
           [-67.203369140625, 17.900904331903952],
           [-66.873779296875, 17.879994149862874],
           [-66.29150390625, 17.86953813537672],
           [-65.8795166015625, 17.89044954880924],
           [-65.753173828125, 18.041983469685132],
           [-65.67626953125, 18.151633561497043],
           [-65.5499267578125, 18.22469544834362],
           [-65.577392578125, 18.360300378218085],
           [-65.95092639327049, 18.506217408533427],
           [-66.26403674483299, 18.516635307946363],
           [-66.59911975264549, 18.516635307946363],
           [-66.87927111983299, 18.547885198677992]]]]),
    input1 = ee.Image("users/images/input/Haiti_2010_InputTOA3season"),
    input2 = ee.Image("users/images/input/Puerto_Rico_2010_InputTOA3season"),
    input3 = ee.Image("users/images/input/Dominican_Republic_2010_InputTOA3season"),
    haiti = /* color: #d63000 */ee.Geometry.Polygon(
        [[[-73.509521484375, 19.762137269222396],
          [-73.355712890625, 19.482733289307443],
          [-72.9437255859375, 19.45165848965483],
          [-72.9052734375, 19.114634920840004],
          [-72.7130126953125, 18.86531349117624],
          [-72.5042724609375, 18.636442596535854],
          [-72.8173828125, 18.521891169755023],
          [-73.311767578125, 18.58438331016271],
          [-73.7567138671875, 18.81332465701405],
          [-74.4927978515625, 18.714501613046245],
          [-74.5477294921875, 18.29255838801726],
          [-74.1522216796875, 18.125579877636678],
          [-73.8555908203125, 17.885269248873442],
          [-73.4600830078125, 17.947990532137542],
          [-72.861328125, 18.02113725862023],
          [-72.2186279296875, 18.0420307503011],
          [-71.91650390625, 18.015913498263366],
          [-71.707763671875, 17.984567684644272],
          [-71.707763671875, 18.15690053197778],
          [-71.6583251953125, 18.36556102415295],
          [-71.839599609375, 18.443743878670137],
          [-71.87255859375, 18.563555138907002],
          [-71.7462158203125, 18.662466261869636],
          [-71.6583251953125, 18.938070778720004],
          [-71.74072265625, 18.99002087543226],
          [-71.5594482421875, 19.18728313638811],
          [-71.7132568359375, 19.311748334396203],
          [-71.6363525390625, 19.462017418082382],
          [-71.7132568359375, 19.772476215874512],
          [-71.9659423828125, 19.782814491907345],
          [-72.4658203125, 19.906821389427275],
          [-72.8118896484375, 19.97365003079896],
          [-73.11676025390625, 19.983975191045623],
          [-73.377685546875, 19.885858892231877]]]),
    DR = /* color: #98ff00 */ee.Geometry.Polygon(
        [[[-71.8011474609375, 19.72564396383718],
          [-71.751708984375, 19.47466296175442],
          [-71.82586669921875, 19.332180892384613],
          [-71.685791015625, 19.19994996827984],
          [-71.9219970703125, 18.968939661577696],
          [-71.8670654296875, 18.878004900750355],
          [-71.7681884765625, 18.828619625124343],
          [-71.82861328125, 18.695987448152437],
          [-71.9879150390625, 18.672570958132408],
          [-72.0538330078125, 18.628330987648624],
          [-71.94671630859375, 18.41738276573465],
          [-71.76544189453125, 18.326152033656204],
          [-71.8231201171875, 18.133105961844166],
          [-71.7572021484375, 17.84313763575233],
          [-71.52374267578125, 17.440057074625436],
          [-71.03759765625, 18.021746857278103],
          [-70.72998046875, 18.19926165145989],
          [-70.16693115234375, 18.128799373426293],
          [-69.774169921875, 18.34270773040121],
          [-68.785400390625, 18.269043417816928],
          [-68.66729736328125, 18.282974378737777],
          [-68.46072017643394, 18.33069642305802],
          [-68.18801879882812, 18.43156259250589],
          [-68.29561138246288, 18.67040916078275],
          [-68.52447509765625, 18.85706121187768],
          [-68.91998291015625, 19.101204347193086],
          [-69.09027099609375, 19.119370875137225],
          [-69.071044921875, 19.297037716193636],
          [-69.2303466796875, 19.41494358701968],
          [-69.62860107421875, 19.382560359117292],
          [-69.796142578125, 19.46674333290396],
          [-69.76593017578125, 19.68282808636127],
          [-70.04257500738629, 19.770309491078397],
          [-70.34133911132812, 19.764269605638653],
          [-70.76156616210938, 19.939937936451475],
          [-71.10488891601562, 19.991568012228452],
          [-71.67892456054688, 19.968336569838076],
          [-71.79840087890625, 19.82241667403354]]]),
    haiti1 = /* color: #0b4a8b */ee.Geometry.Polygon(
        [[[-73.3612060546875, 18.97963215126041],
          [-73.2733154296875, 18.80292495980704],
          [-72.960205078125, 18.688485935624126],
          [-72.7789306640625, 18.646852541354523],
          [-72.75146484375, 18.787324208931736],
          [-72.9107666015625, 18.969242779201988]]]),
    haiti2 = /* color: #ffc82d */ee.Geometry.Polygon(
        [[[-73.0865478515625, 20.07027128872516],
          [-72.93136596679688, 20.02898923878902],
          [-72.58804321289062, 19.97479009178227],
          [-72.58804321289062, 20.05737181432333],
          [-72.806396484375, 20.117990114375953],
          [-72.96295166015625, 20.119279610511764]]]),
    NonCropClass = /* color: #00ffff */ee.FeatureCollection(
        [ee.Feature(
            ee.Geometry.Point([-70.87104320526123, 19.61449927907069]),
            {
              "class": 2,
              "system:index": "0"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.85842609405518, 19.61983530048155]),
            {
              "class": 2,
              "system:index": "1"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.89863777160645, 19.61001203307399]),
            {
              "class": 2,
              "system:index": "2"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.85619449615479, 19.57641435063993]),
            {
              "class": 2,
              "system:index": "3"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8259391784668, 19.611346092261204]),
            {
              "class": 2,
              "system:index": "4"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.79710006713867, 19.577950859729402]),
            {
              "class": 2,
              "system:index": "5"
            }),
        ee.Feature(
            ee.Geometry.Point([-70.8308744430542, 19.56545618993985]),
            {
              "class": 2,
              "system:index": "6"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.30972909927368, 19.63299033846555]),
            {
              "class": 2,
              "system:index": "7"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.29410791397095, 19.63264676449329]),
            {
              "class": 2,
              "system:index": "8"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.29164028167725, 19.64204425822495]),
            {
              "class": 2,
              "system:index": "9"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.27614784240723, 19.635213446404453]),
            {
              "class": 2,
              "system:index": "10"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.27601909637451, 19.64420661442064]),
            {
              "class": 2,
              "system:index": "11"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.27277898788452, 19.652168664494685]),
            {
              "class": 2,
              "system:index": "12"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.27492475509644, 19.664434328712183]),
            {
              "class": 2,
              "system:index": "13"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26810121536255, 19.67587065957613]),
            {
              "class": 2,
              "system:index": "14"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26640605926514, 19.685205010167373]),
            {
              "class": 2,
              "system:index": "15"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.26979637145996, 19.68591213577432]),
            {
              "class": 2,
              "system:index": "16"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.25797319412231, 19.682437088477307]),
            {
              "class": 2,
              "system:index": "17"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.24314594268799, 19.67904278344965]),
            {
              "class": 2,
              "system:index": "18"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23561429977417, 19.687871867567075]),
            {
              "class": 2,
              "system:index": "19"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23417663574219, 19.686114171088537]),
            {
              "class": 2,
              "system:index": "20"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22207450866699, 19.687488004465525]),
            {
              "class": 2,
              "system:index": "21"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.25318813323975, 19.707245656834303]),
            {
              "class": 2,
              "system:index": "22"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.23769569396973, 19.702518587772083]),
            {
              "class": 2,
              "system:index": "23"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22900533676147, 19.70663963014507]),
            {
              "class": 2,
              "system:index": "24"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2154655456543, 19.69878127619428]),
            {
              "class": 2,
              "system:index": "25"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2104229927063, 19.734433690916795]),
            {
              "class": 2,
              "system:index": "26"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.190016746521, 19.728576333017497]),
            {
              "class": 2,
              "system:index": "27"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.18836450576782, 19.73013158347052]),
            {
              "class": 2,
              "system:index": "28"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.18641185760498, 19.714053198867784]),
            {
              "class": 2,
              "system:index": "29"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.22250366210938, 19.719163715042882]),
            {
              "class": 2,
              "system:index": "30"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.24048519134521, 19.872847037215386]),
            {
              "class": 2,
              "system:index": "31"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.2272458076477, 19.865985738592]),
            {
              "class": 2,
              "system:index": "32"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.21537971496582, 19.867337841517777]),
            {
              "class": 2,
              "system:index": "33"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.20471525192261, 19.862413709732685]),
            {
              "class": 2,
              "system:index": "34"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.18988800048828, 19.872887396916994]),
            {
              "class": 2,
              "system:index": "35"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19134712219238, 19.883723604944894]),
            {
              "class": 2,
              "system:index": "36"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.19420099258423, 19.8664498946273]),
            {
              "class": 2,
              "system:index": "37"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.16911697387695, 19.881806638854904]),
            {
              "class": 2,
              "system:index": "38"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.1594181060791, 19.87262505867287]),
            {
              "class": 2,
              "system:index": "39"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.14300298690796, 19.878012995490014]),
            {
              "class": 2,
              "system:index": "40"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.13544988632202, 19.892884364654755]),
            {
              "class": 2,
              "system:index": "41"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.15677881240845, 19.89383269497281]),
            {
              "class": 2,
              "system:index": "42"
            }),
        ee.Feature(
            ee.Geometry.Point([-73.11579465866089, 19.90168142357424]),
            {
              "class": 2,
              "system:index": "43"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.9352068901062, 19.86049648592363]),
            {
              "class": 2,
              "system:index": "44"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.92359828948975, 19.865662846635676]),
            {
              "class": 2,
              "system:index": "45"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.9238772392273, 19.876943494512968]),
            {
              "class": 2,
              "system:index": "46"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.85607099533081, 19.88792067075703]),
            {
              "class": 2,
              "system:index": "47"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.83630847930908, 19.88174610270584]),
            {
              "class": 2,
              "system:index": "48"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.8050446510315, 19.900753316573873]),
            {
              "class": 2,
              "system:index": "49"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80152559280396, 19.90656398380624]),
            {
              "class": 2,
              "system:index": "50"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.80978679656982, 19.88384467570867]),
            {
              "class": 2,
              "system:index": "51"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.78481006622314, 19.87702421181966]),
            {
              "class": 2,
              "system:index": "52"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.77697801589966, 19.882613785298872]),
            {
              "class": 2,
              "system:index": "53"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.75607824325562, 19.867842354581178]),
            {
              "class": 2,
              "system:index": "54"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.74107933044434, 19.861788091879134]),
            {
              "class": 2,
              "system:index": "55"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73429870605469, 19.86788271555689]),
            {
              "class": 2,
              "system:index": "56"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.73110151290894, 19.886851236661244]),
            {
              "class": 2,
              "system:index": "57"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7019190788269, 19.913867367019925]),
            {
              "class": 2,
              "system:index": "58"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.70245552062988, 19.922522044733224]),
            {
              "class": 2,
              "system:index": "59"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67608404159546, 19.918103981731498]),
            {
              "class": 2,
              "system:index": "60"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.71344184875488, 19.929340548026207]),
            {
              "class": 2,
              "system:index": "61"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.7204155921936, 19.933576748057963]),
            {
              "class": 2,
              "system:index": "62"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.68822908401489, 19.89982520413103]),
            {
              "class": 2,
              "system:index": "63"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.67121315002441, 19.898614614505057]),
            {
              "class": 2,
              "system:index": "64"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.66269445419312, 19.900955079428243]),
            {
              "class": 2,
              "system:index": "65"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.65679359436035, 19.90761310931551]),
            {
              "class": 2,
              "system:index": "66"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64539957046509, 19.90242794047282]),
            {
              "class": 2,
              "system:index": "67"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.64121532440186, 19.905192039951448]),
            {
              "class": 2,
              "system:index": "68"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62610912322998, 19.893973935172497]),
            {
              "class": 2,
              "system:index": "69"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62226819992065, 19.89090697678725]),
            {
              "class": 2,
              "system:index": "70"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6191782951355, 19.892339576584256]),
            {
              "class": 2,
              "system:index": "71"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6220965385437, 19.881241633897467]),
            {
              "class": 2,
              "system:index": "72"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60596036911011, 19.876802239127343]),
            {
              "class": 2,
              "system:index": "73"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59679794311523, 19.888364584676]),
            {
              "class": 2,
              "system:index": "74"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62707471847534, 19.866248087822374]),
            {
              "class": 2,
              "system:index": "75"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63670921325684, 19.864714347711697]),
            {
              "class": 2,
              "system:index": "76"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.62653827667236, 19.85199987837945]),
            {
              "class": 2,
              "system:index": "77"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.63091564178467, 19.84376520230024]),
            {
              "class": 2,
              "system:index": "78"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61763334274292, 19.8389008914899]),
            {
              "class": 2,
              "system:index": "79"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60993003845215, 19.827254197596485]),
            {
              "class": 2,
              "system:index": "80"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57192850112915, 19.82261142998086]),
            {
              "class": 2,
              "system:index": "81"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55838871002197, 19.825720080692705]),
            {
              "class": 2,
              "system:index": "82"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54257440567017, 19.836317296531476]),
            {
              "class": 2,
              "system:index": "83"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5253438949585, 19.823862971994945]),
            {
              "class": 2,
              "system:index": "84"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52418518066406, 19.845359694989014]),
            {
              "class": 2,
              "system:index": "85"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55102872848511, 19.819866077498506]),
            {
              "class": 2,
              "system:index": "86"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56508350372314, 19.813103425536916]),
            {
              "class": 2,
              "system:index": "87"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57145643234253, 19.81179123598932]),
            {
              "class": 2,
              "system:index": "88"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55798101425171, 19.79782079376142]),
            {
              "class": 2,
              "system:index": "89"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56941795349121, 19.794590458985574]),
            {
              "class": 2,
              "system:index": "90"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58724927902222, 19.78687776964648]),
            {
              "class": 2,
              "system:index": "91"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.55961179733276, 19.774076303807767]),
            {
              "class": 2,
              "system:index": "92"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.58220672607422, 19.762182537888]),
            {
              "class": 2,
              "system:index": "93"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.59546756744385, 19.757760011560684]),
            {
              "class": 2,
              "system:index": "94"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6176118850708, 19.755538605041504]),
            {
              "class": 2,
              "system:index": "95"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61557340621948, 19.761455555681305]),
            {
              "class": 2,
              "system:index": "96"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60263442993164, 19.748975177814774]),
            {
              "class": 2,
              "system:index": "97"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.6586389541626, 19.738311557483954]),
            {
              "class": 2,
              "system:index": "98"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.61681795120239, 19.73534258189231]),
            {
              "class": 2,
              "system:index": "99"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.60108947753906, 19.73138386191475]),
            {
              "class": 2,
              "system:index": "100"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.57343053817749, 19.725041626457397]),
            {
              "class": 2,
              "system:index": "101"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56096363067627, 19.72346612766006]),
            {
              "class": 2,
              "system:index": "102"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54336833953857, 19.715305603299996]),
            {
              "class": 2,
              "system:index": "103"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.56040573120117, 19.70318524404052]),
            {
              "class": 2,
              "system:index": "104"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.54375457763672, 19.6942963969549]),
            {
              "class": 2,
              "system:index": "105"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52603054046631, 19.693569105799153]),
            {
              "class": 2,
              "system:index": "106"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52143859863281, 19.675789850178717]),
            {
              "class": 2,
              "system:index": "107"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.49884366989136, 19.65631121939927]),
            {
              "class": 2,
              "system:index": "108"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.51987218856812, 19.63872991638466]),
            {
              "class": 2,
              "system:index": "109"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.52225399017334, 19.611667130183832]),
            {
              "class": 2,
              "system:index": "110"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.50030279159546, 19.607098951305]),
            {
              "class": 2,
              "system:index": "111"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.5226616859436, 19.58866321238053]),
            {
              "class": 2,
              "system:index": "112"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.48172044754028, 19.576128938672063]),
            {
              "class": 2,
              "system:index": "113"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.47013330459595, 19.597456838138733]),
            {
              "class": 2,
              "system:index": "114"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45107889175415, 19.604552034179257]),
            {
              "class": 2,
              "system:index": "115"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.45691537857056, 19.607301085857486]),
            {
              "class": 2,
              "system:index": "116"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.43294715881348, 19.612374579910266]),
            {
              "class": 2,
              "system:index": "117"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42475032806396, 19.629958758313126]),
            {
              "class": 2,
              "system:index": "118"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.42365598678589, 19.638972430078173]),
            {
              "class": 2,
              "system:index": "119"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40058898925781, 19.639376618753364]),
            {
              "class": 2,
              "system:index": "120"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.40153312683105, 19.652552612190913]),
            {
              "class": 2,
              "system:index": "121"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3849892616272, 19.642771763451787]),
            {
              "class": 2,
              "system:index": "122"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37554788589478, 19.643782209318275]),
            {
              "class": 2,
              "system:index": "123"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37157821655273, 19.65754384862357]),
            {
              "class": 2,
              "system:index": "124"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.37977504730225, 19.660494061093143]),
            {
              "class": 2,
              "system:index": "125"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36799478530884, 19.674335096473467]),
            {
              "class": 2,
              "system:index": "126"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.35735177993774, 19.679305450438104]),
            {
              "class": 2,
              "system:index": "127"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.35876798629761, 19.699306535119433]),
            {
              "class": 2,
              "system:index": "128"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.36443281173706, 19.70158932831657]),
            {
              "class": 2,
              "system:index": "129"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.34065771102905, 19.713467407904155]),
            {
              "class": 2,
              "system:index": "130"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.32716083526611, 19.704417522505523]),
            {
              "class": 2,
              "system:index": "131"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.3029351234436, 19.708700121384148]),
            {
              "class": 2,
              "system:index": "132"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.31018781661987, 19.71314420652929]),
            {
              "class": 2,
              "system:index": "133"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.29724884033203, 19.704417522505523]),
            {
              "class": 2,
              "system:index": "134"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.27072715759277, 19.67819420582071]),
            {
              "class": 2,
              "system:index": "135"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.26886034011841, 19.676052512634563]),
            {
              "class": 2,
              "system:index": "136"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.27705717086792, 19.66006972867213]),
            {
              "class": 2,
              "system:index": "137"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.22978591918945, 19.633798725176472]),
            {
              "class": 2,
              "system:index": "138"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.21903562545776, 19.633354102133925]),
            {
              "class": 2,
              "system:index": "139"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20126867294312, 19.622076433497227]),
            {
              "class": 2,
              "system:index": "140"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.16878175735474, 19.621914740735892]),
            {
              "class": 2,
              "system:index": "141"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.17225790023804, 19.629857705313896]),
            {
              "class": 2,
              "system:index": "142"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.17152833938599, 19.61184904612505]),
            {
              "class": 2,
              "system:index": "143"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1795105934143, 19.597982418945232]),
            {
              "class": 2,
              "system:index": "144"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.19650506973267, 19.585711680897933]),
            {
              "class": 2,
              "system:index": "145"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.20701932907104, 19.578373049678962]),
            {
              "class": 2,
              "system:index": "146"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.2121262550354, 19.595597076886868]),
            {
              "class": 2,
              "system:index": "147"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.1826434135437, 19.581162981934142]),
            {
              "class": 2,
              "system:index": "148"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15770959854126, 19.575077632673956]),
            {
              "class": 2,
              "system:index": "149"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.15873956680298, 19.563593689773942]),
            {
              "class": 2,
              "system:index": "150"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14391231536865, 19.56951772728434]),
            {
              "class": 2,
              "system:index": "151"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.12891340255737, 19.54747839780964]),
            {
              "class": 2,
              "system:index": "152"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11331367492676, 19.552432454430328]),
            {
              "class": 2,
              "system:index": "153"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.14775323867798, 19.525537176451074]),
            {
              "class": 2,
              "system:index": "154"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.11835622787476, 19.513180024815984]),
            {
              "class": 2,
              "system:index": "155"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.08250045776367, 19.529703204432444]),
            {
              "class": 2,
              "system:index": "156"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.06494808197021, 19.527316852033913]),
            {
              "class": 2,
              "system:index": "157"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.03473567962646, 19.54098734243198]),
            {
              "class": 2,
              "system:index": "158"
            }),
        ee.Feature(
            ee.Geometry.Point([-72.01589584350586, 19.534738696770972]),
            {
              "class": 2,
              "system:index": "159"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.94557905197144, 19.55738635892754]),
            {
              "class": 2,
              "system:index": "160"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.89596891403198, 19.530451460212735]),
            {
              "class": 2,
              "system:index": "161"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.89794301986694, 19.487471697077613]),
            {
              "class": 2,
              "system:index": "162"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.84706687927246, 19.489049509094734]),
            {
              "class": 2,
              "system:index": "163"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.85419082641602, 19.461840233111655]),
            {
              "class": 2,
              "system:index": "164"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.86232328414917, 19.451319429684094]),
            {
              "class": 2,
              "system:index": "165"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.87575578689575, 19.446584845521333]),
            {
              "class": 2,
              "system:index": "166"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.83069467544556, 19.432056498692692]),
            {
              "class": 2,
              "system:index": "167"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.81299209594727, 19.43355390929083]),
            {
              "class": 2,
              "system:index": "168"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.73404932022095, 19.419226766458635]),
            {
              "class": 2,
              "system:index": "169"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.68401002883911, 19.389192330077293]),
            {
              "class": 2,
              "system:index": "170"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.65729522705078, 19.39680265785386]),
            {
              "class": 2,
              "system:index": "171"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.62957191467285, 19.39135807127799]),
            {
              "class": 2,
              "system:index": "172"
            }),
        ee.Feature(
            ee.Geometry.Point([-71.6127061843872, 19.41985411130683]),
            {
              "class": 2,
              "system:index": "173"
            })]),
    geometry = /* color: #bf04c2 */ee.Geometry.MultiPoint();
/***** End of imports. If edited, may not auto-convert in the playground. *****/
 

var zones=ee.FeatureCollection("ft:1emWmrrMBzdiKOitmcYSBmoCozs4Fpqq_f6A86pnR");
var zones2=ee.FeatureCollection("ft:13cK2cS_HzpvNGVZlIfH9zInVbJOMQgjXQKwgLHpL");
var countries = ee.FeatureCollection("ft:1tdSwUL7MVpOauSgRzqVTOwdfy17KDbw-1d9omPw");

function radians(img) {return img.toFloat().multiply(Math.PI).divide(180).divide(1.5708).toFloat();}
var terrain = ee.Algorithms.Terrain(ee.Image('USGS/SRTMGL1_003'));
var slope = radians(terrain.select('slope'));
var elevation = terrain.select('elevation').divide(4000.00).float();


//input=ee.ImageCollection([input1,input2,input3]).mosaic()

//input=input.select(ee.List.sequence(0,43)).addBands(slope).addBands(elevation);

//visual parameters for FCC display 
var vizParams = {
  bands: ['B4', 'B3', 'B2'],
  min: 0,
  max: 255,
  gamma: [1.5,1.6, 1.7]
};


//add all max val to map

//Map.addLayer(DRHaiti,vizParams,'FCC');

//throw('stop')

//create bounds for training samples inside area of interest
function buffer(geometry) {
  return geometry.buffer(60).bounds();
} 

//buffer function of 1km********************************************************
function buffer1(geometry) {
  return geometry.buffer(10000);
}

function buffer2(geometry) {
  return geometry.buffer(5000);
}




//Haiti
//-----------------------------------------------------------------------------


var studyArea =DRHaiti2


//print(CropSamples);
var CropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea);

//print(NonCropSamples);
var NonCropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea);


//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                    .merge(NonCropSamplesArea)
//                    .merge(NonCropSamplesArea2);
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);

var training = input.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});
 
studyArea =zones.filterMetadata('name','equals','DRHaiti')

//build classifier
var classifier = ee.Classifier.randomForest(200,10).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input.classify(classifier);

classified1 = classified
.clip(DRHaiti)
.updateMask(classified.eq(1))

//------------------------------------------------------------------------------





//DR
//----------------------------------------------------------------------------
var studyArea =DRHaiti2

//print(CropSamples);
var CropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea);

//print(NonCropSamples);
var NonCropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea);


//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                    .merge(NonCropSamplesArea)
//                    .merge(NonCropSamplesArea2);
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);

var training = input.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});
 
studyArea =zones.filterMetadata('name','equals','DRHaiti')

//build classifier
var classifier = ee.Classifier.randomForest(200,10).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input.classify(classifier);

classified1 = classified
.clip(DRHaiti)
.updateMask(classified.eq(1))



//-----------------------------------------------------------------------------



//Puerto Rico
//------------------------------------------------------------------------------

var studyArea =DRHaiti2


//print(CropSamples);
var CropSamplesArea = Cropclass.filterBounds(studyArea).map(buffer);
print('Crop:',CropSamplesArea);

//print(NonCropSamples);
var NonCropSamplesArea = NonCropClass.filterBounds(studyArea).map(buffer);
print('Non-crop:',NonCropSamplesArea);


//merge all training samples into one feature collection
var TrainingSamples=CropSamplesArea
                    .merge(NonCropSamplesArea)
//                    .merge(NonCropSamplesArea2);
print('Training samples:',TrainingSamples);

//add layer to map
//Map.addLayer(TrainingSamples, { },'Samples');

print('Study Area:');
print(studyArea);

var training = input.sampleRegions({
    collection: TrainingSamples,
  properties: ['class'],
  scale: 30
});
 
studyArea =zones.filterMetadata('name','equals','DRHaiti')

//build classifier
var classifier = ee.Classifier.randomForest(200,10).train(training, 'class');

print ('Classifier properties:',classifier);

//classify 
var classified = input.classify(classifier);

classified1 = classified
.clip(DRHaiti)
.updateMask(classified.eq(1))

//-----------------------------------------------------------------------------





////Export the classified image
Export.image.toAsset({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  description: 'DRHaiti_v2_asset',
  assetId: 'DRHaiti_2010_v2',
  region: studyArea, 
});


Export.image.toDrive({
  image: classified,
  scale: 30,
  maxPixels:9990000000000,
  folder: 'data',
  description: 'DRHaiti',
  fileNamePrefix: 'DRHaiti_2010_v2',
  region: studyArea, 
});
 

Export.table.toDrive({
  collection: training,
  description: 'RandomForestTrainingTable_DRHaiti_v2',
  folder: 'DRHaiti',
  fileNamePrefix: 'RFtable_DRHaiti_2010_v2',
  fileFormat: 'CSV'
});


//print('Classified',classified);

//add layer to map
Map.addLayer(classified, {palette: '00FF00'}, 'cropland');



