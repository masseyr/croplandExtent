/*-----------------------------------------------------------
|
|  Routine Name: do_region_classes_init (regular version)
|
|       Purpose: Initialize region_classes from current pixel_data values
|
|         Input: ncols            (Number of columns in pixel_data)
|                nrows            (Number of rows in pixel_data)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|                
|        Output: region_classes   (Class which holds region related information)
|
|         Other:
|
|       Returns: (void)
|
|    Written By: James C. Tilton
|          Date: December 9, 2002
| Modifications: February 10, 2003:  Changed region index to region label
|                September 30, 2003:  Added initialization of nghbrs_label_set
|                December 23, 2004:  Changed region label from short unsigned int to unsigned int
|                May 31, 2005 - Added temporary file I/O for faster processing of large data sets
|                May 12, 2008 - Revised to work with globally defined Params and oParams class objects
|                March 24, 2011 - Revised counting of recursive levels to start at level = 0 (instead of level = 1).
|                April 7, 2011 - Initiated using set_stride_sections to determine stride and nb_sections (nb_tasks for parallel).
|                August 1, 2013 - Revised to accommodate standard deviation and region edge information.
|                January 8, 2014 - Removed the RegionEdge class.
|                March 3, 2016 - Added code for processing window overlap.
|
------------------------------------------------------------*/

#include "region_class.h"
#include "region_object.h"
#include <params/params.h>
#include <pixel/pixel.h>
#include <spatial/spatial.h>
#include <index/index.h>
#include <iostream>
#include <vector>
#ifdef TIME_IT
#include <ctime>
#endif

extern HSEGTilton::Params params;

namespace HSEGTilton
{
 unsigned int do_region_classes_init(const int& ncols, const int& nrows,
                                     vector<Pixel>& pixel_data, vector<RegionClass>& region_classes)
 {
   unsigned int region_index, region_label, max_region_label;
   unsigned int pixel_index, region_classes_size;
   int col, row;
   int max_col = ncols + 2*params.overlap_width;
   int max_row = nrows + 2*params.overlap_width;

   max_region_label = 0;
   region_classes_size = region_classes.size( );
   for (row = 0; row < max_row; row++)
   {
     for (col = 0; col < max_col; col++)
     {
       pixel_index = col + row*max_col;
       region_label = pixel_data[pixel_index].get_region_label( );
       if (region_label != 0)
       {
         if (region_label > region_classes_size)
         {
           region_classes_size = region_label;
           region_classes.resize(region_classes_size);
         }
         region_index = region_label - 1;
         region_classes[region_index].init(pixel_data,col,row,ncols,nrows);
         if (region_label > max_region_label)
           max_region_label = region_label;
       }
     }
   }
#ifdef DEBUG
   if (params.debug > 3)
   {
     params.log_fs << endl << "Exiting do_region_classes_init, dump of the region data:" << endl << endl;
     for (region_index = 0; region_index < region_classes_size; ++region_index)
       if (region_classes[region_index].get_active_flag( ))
         region_classes[region_index].print(region_classes);
   }
#endif
   return max_region_label;
 }

/*-----------------------------------------------------------
|
|  Routine Name: do_region_classes_init (recursive version)
|
|       Purpose: Initialize region_classes from current pixel_data values with recursive calls as necessary
|
|         Input: recur_level      (Current recursive level of this task)
|                section          (Section or window processed by this call to do_region_classes_init)
|                ncols            (Number of columns in pixel_data)
|                nrows            (Number of rows in pixel_data)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|                
|        Output: region_classes      (Class which holds region related information)
|
|         Other: temp_data        (buffers used in communications between parallel tasks)
|
|       Returns: (void)
|
|    Written By: James C. Tilton
|          Date: December 9, 2002
| Modifications: (see comments for first do_region_classes_init function)
|
------------------------------------------------------------*/
 unsigned int do_region_classes_init(const short unsigned int& recur_level, const short unsigned int& section,
                                     const int& ncols, const int& nrows,
                                     vector<Pixel>& pixel_data, vector<RegionClass>& region_classes,
                                     Temp& temp_data)
 {
   unsigned int region_index, max_region_label;

   if (params.debug > 2)
   {
     params.log_fs << "do_region_classes_init called at recur_level = " << recur_level;
     params.log_fs << " with section = " << section << endl;
   }

   if (recur_level >= (params.onb_levels-1))
   {
    // At these recursive levels, the data is wholly contained in RAM memory and
    // the regular version of do_region_classes_init can be called.
     max_region_label = do_region_classes_init(ncols,nrows,pixel_data,region_classes);
#ifdef DEBUG
     unsigned int region_classes_size;
     region_classes_size = region_classes.size( );
     if (params.debug > 2)
     {
       params.log_fs << "Found max_region_label = " << max_region_label;
       params.log_fs << " in current task in do_region_classes_init " << endl;
     }
     if (params.debug > 3)
     {
       params.log_fs << endl << "After call to do_region_classes_init for current task, dump of the region data:" << endl << endl;
       for (region_index = 0; region_index < region_classes_size; ++region_index)
         if (region_classes[region_index].get_active_flag( ))
           region_classes[region_index].print(region_classes);
     }
#endif
   }
   else
   {
    // At these recursive levels, the data is not wholly contained in RAM memory and
    // do_region_classes_init must be called recursively.
      int recur_ncols = ncols;
      int recur_nrows = nrows;
      bool col_flag, row_flag;
      set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);
      if (col_flag)
        recur_ncols /= 2;
      if (row_flag)
        recur_nrows /= 2;
     int stride, nb_sections;
     set_stride_sections(recur_level,stride,nb_sections);
#ifdef PARALLEL
     unsigned int index, region_label, region_classes_size;
   // Send request to the parallel recur_tasks
     parallel_recur_requests((short unsigned int) 5,recur_level,0,ncols,nrows,0,0,0,temp_data);
   // Process current task's data section
     max_region_label = do_region_classes_init((recur_level+1),section,recur_ncols,recur_nrows,
                                               pixel_data,region_classes,temp_data);
     region_classes_size = region_classes.size( );

     unsigned int nregions;
     unsigned int int_buf_size = 0, float_buf_size = 0, double_buf_size = 0;
     int region_classes_init_tag = 105;
   // Receive region_classes information from the parallel recur_tasks
     int min_section = section + stride;
#ifdef TIME_IT
     float end_time, elapsed_time;
#endif
#else // PARALLEL
     int min_section = section;
     max_region_label = 0;
#endif // !PARALLEL
     int max_section = section + nb_sections;
     for (int recur_section = min_section; recur_section < max_section; recur_section += stride)
     {
#ifdef PARALLEL
#ifdef TIME_IT
       end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
       elapsed_time = end_time - temp_data.start_time;
       if (elapsed_time > 0.0) temp_data.compute += elapsed_time;
       temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
       MPI::COMM_WORLD.Recv(&region_index, 1, MPI::UNSIGNED, recur_section, region_classes_init_tag);
#ifdef TIME_IT
       end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
       elapsed_time = end_time - temp_data.start_time;
       if (elapsed_time > 0.0) temp_data.wait += elapsed_time;
       temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
       if (region_index > max_region_label)
         max_region_label = region_index;
       if (params.debug > 2)
       {
         params.log_fs << "Received region_classes_init results from task " << recur_section;
         params.log_fs << " with max_region_label = " << max_region_label << endl;
       }
       MPI::COMM_WORLD.Recv(&nregions, 1, MPI::UNSIGNED, recur_section, region_classes_init_tag);
       MPI::COMM_WORLD.Recv(&int_buf_size, 1, MPI::UNSIGNED, recur_section, region_classes_init_tag);
       MPI::COMM_WORLD.Recv(&float_buf_size, 1, MPI::UNSIGNED, recur_section, region_classes_init_tag);
       MPI::COMM_WORLD.Recv(&double_buf_size, 1, MPI::UNSIGNED, recur_section, region_classes_init_tag);
       if (nregions > 0)
       {
         check_buf_size(0,0,int_buf_size,float_buf_size,double_buf_size,temp_data);
         MPI::COMM_WORLD.Recv(temp_data.int_buffer, int_buf_size, MPI::UNSIGNED, recur_section, region_classes_init_tag);
         MPI::COMM_WORLD.Recv(temp_data.float_buffer, float_buf_size, MPI::FLOAT, recur_section, region_classes_init_tag);
         MPI::COMM_WORLD.Recv(temp_data.double_buffer, double_buf_size, MPI::DOUBLE, recur_section, region_classes_init_tag);
#ifdef TIME_IT
         end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
         elapsed_time = end_time - temp_data.start_time;
         if (elapsed_time > 0.0) temp_data.transfer += elapsed_time;
         temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
         if (max_region_label > region_classes_size)
         {
           region_classes_size = max_region_label;
           region_classes.resize(region_classes_size,RegionClass( ));
         }
         for (region_index = 0; region_index < max_region_label; ++region_index)
           region_classes[region_index].set_label(region_index+1);
         unsigned int int_buf_position = 0, float_buf_position = 0, double_buf_position = 0;
         for (index = 0; index < nregions; ++index)
         {
           region_label = temp_data.int_buffer[int_buf_position++];
           region_index = region_label - 1;
           region_classes[region_index].set_active_flag(true);
           region_classes[region_index].update_all_data(temp_data,int_buf_position,float_buf_position,double_buf_position);
         }
       }
#else // !PARALLEL
     // In the serial case, process the specified data section
       if (((recur_level+1) == (params.ionb_levels-1)) && (params.nb_sections > 1))
         restore_pixel_data(recur_section,pixel_data,temp_data);
       region_index = do_region_classes_init((recur_level+1),recur_section,recur_ncols,recur_nrows,
                                             pixel_data,region_classes,temp_data);
       if (region_index > max_region_label)
         max_region_label = region_index;
#endif // !PARALLEL
     } // for (recur_section = min_section; recur_section < max_section; recur_section += stride)

   // Obtain the neighborhood information from along the processing window seams
     unsigned int index_data_size = 1;
     if (col_flag)
       index_data_size = nrows*params.seam_size;
     vector<Index> col_seam_index_data(index_data_size);
     index_data_size = 1;
     if (row_flag)
       index_data_size = ncols*params.seam_size;
     vector<Index> row_seam_index_data(index_data_size);
     get_seam_index_data(recur_level,section,params.recur_mask_flags[recur_level],ncols,nrows,
                         pixel_data,col_seam_index_data,row_seam_index_data,temp_data);
     update_nghbrs_label_set(recur_level,ncols,nrows,col_seam_index_data,
                             row_seam_index_data,region_classes);
   }
#ifdef DEBUG
   region_classes_size = region_classes.size( );
   if (params.debug > 2)
   {
     params.log_fs << endl << "Exiting do_region_classes_init, dump of the region data:" << endl << endl;
     for (region_index = 0; region_index < region_classes_size; ++region_index)
       if (region_classes[region_index].get_active_flag( ))
       {
         params.log_fs << "For region label " << region_classes[region_index].get_label( );
         params.log_fs << ", npix = " << region_classes[region_index].get_npix( ) << endl;
        }
   }
#endif
   return max_region_label;
 }

/*-----------------------------------------------------------
|
|  Routine Name: do_region_objects_init (regular version)
|
|       Purpose: Initialize region_objects from current pixel_data and spatial_data values
|
|         Input: ncols            (Number of columns in pixel_data)
|                nrows            (Number of rows in pixel_data)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|                spatial_data     (Class which holds information pertaining to input and output spatial data)
|                
|        Output: region_objects (Class which holds connected region related information)
|
|         Other:
|
|       Returns: (void)
|
|    Written By: James C. Tilton
|          Date: December 9, 2002
| Modifications: (see comments for first do_region_classes_init function)
|          Note: Did not need to modify this code for processing window overlap - this code called after call to undo_overlap
|
------------------------------------------------------------*/
 void do_region_objects_init(const int& ncols, const int& nrows,
                             vector<Pixel>& pixel_data, Spatial& spatial_data,
                             vector<RegionObject>& region_objects)
 {
   unsigned int region_object_index, region_object_label, pixel_index;
   int col, row;

#ifdef DEBUG
   if (params.debug > 3)
   {
     params.log_fs << endl << "Entering do_region_objects_init, dump of spatial_data.region_object_label:" << endl << endl;
     for (row = 0; row < nrows; row++)
     {
       for (col = 0; col < ncols; col++)
       {
         pixel_index = col + row*ncols;
         params.log_fs << spatial_data.get_region_object_label(pixel_index) << " ";
//         params.log_fs << spatial_data.region_object_label_map[pixel_index] << " ";
       }
       params.log_fs << endl;
     }
     params.log_fs << endl;
   }
#endif

   for (row = 0; row < nrows; row++)
     for (col = 0; col < ncols; col++)
     {
       pixel_index = col + row*ncols;
       region_object_label = spatial_data.get_region_object_label(pixel_index);
       if (region_object_label != 0)
       {
         region_object_index = region_object_label - 1;
         region_objects[region_object_index].init(&pixel_data[pixel_index]);
       }
     }
#ifdef DEBUG
   if (params.debug > 3)
   {
     params.log_fs << endl << "Exiting region_objects_init, dump of the connected region data:" << endl << endl;
     unsigned int region_objects_size = region_objects.size( );
     for (region_object_index = 0; region_object_index < region_objects_size; ++region_object_index)
       if (region_objects[region_object_index].get_active_flag( ))
         region_objects[region_object_index].print(region_objects);
   }
#endif
   return;
 }

/*-----------------------------------------------------------
|
|  Routine Name: do_region_objects_init (recursive version)
|
|       Purpose: Initialize region_objects from current pixel_data and spatial_data values with recursive calls as necessary
|
|         Input: recur_level      (Current recursive level of this task)
|                section          (Section or window processed by this call to do_region_objects_init)
|                ncols            (Number of columns in pixel_data)
|                nrows            (Number of rows in pixel_data)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|                spatial_data     (Class which holds information pertaining to input and output spatial data)
|                
|        Output: region_objects (Class which holds connected region related information)
|
|         Other: temp_data        (buffers used in communications between parallel tasks)
|
|       Returns: (void)
|
|    Written By: James C. Tilton
|          Date: December 9, 2002
| Modifications: (see comments for first do_region_classes_init function)
|          Note: Did not need to modify this code for processing window overlap - this code called after call to undo_overlap
|
------------------------------------------------------------*/
 unsigned int do_region_objects_init(const short unsigned int& recur_level, const short unsigned int& section,
                                     const int& ncols, const int& nrows, vector<Pixel>& pixel_data,
                                     Spatial& spatial_data, vector<RegionObject>& region_objects,
                                     Temp& temp_data)
 {
   unsigned int region_object_index, region_objects_size, nb_objects;

   if (params.debug > 2)
   {
     params.log_fs << "do_region_objects_init called at recur_level = " << recur_level << endl;
   }

   if (recur_level >= (params.onb_levels-1))
   {
    // At these recursive levels, the data is wholly contained in RAM memory and
    // the regular version of do_region_objects_init can be called.
     do_region_objects_init(ncols,nrows,pixel_data,spatial_data,region_objects);
   }
   else
   {
    // At these recursive levels, the data is not wholly contained in RAM memory and
    // do_region_objects_init must be called recursively.
     int recur_ncols = ncols;
     int recur_nrows = nrows;
     bool col_flag, row_flag;
     set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);
     if (col_flag)
       recur_ncols /= 2;
     if (row_flag)
       recur_nrows /= 2;
     int stride, nb_sections;
     set_stride_sections(recur_level,stride,nb_sections);
#ifdef PARALLEL
     nb_objects = region_objects.size( );
   // Send request to the parallel recur_tasks
     parallel_recur_requests((short unsigned int) 5,recur_level,nb_objects,ncols,nrows,0,0,0,temp_data);
   // Process current task's data section
     do_region_objects_init((recur_level+1),section,recur_ncols,recur_nrows,
                             pixel_data,spatial_data,region_objects,temp_data);
     region_objects_size = region_objects.size( );
#ifdef DEBUG
     if (params.debug > 3)
     {
       params.log_fs << endl << "After recursive call to do_region_objects_init, dump of the region_object data:" << endl << endl;
       for (region_object_index = 0; region_object_index < region_objects_size; ++region_object_index)
         if (region_objects[region_object_index].get_active_flag( ))
           region_objects[region_object_index].print(region_objects);
     }
#endif

     unsigned int index, int_buf_size = 0, double_buf_size = 0;
     int region_classes_init_tag = 105;
   // Receive region_objects information from the parallel recur_tasks
     int min_section = section + stride;
#ifdef TIME_IT
     float end_time, elapsed_time;
#endif
#else
     int min_section = section;
#endif
     int max_section = section + nb_sections;
     for (int recur_section = min_section; recur_section < max_section; recur_section += stride)
     {
#ifdef PARALLEL
#ifdef TIME_IT
       end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
       elapsed_time = end_time - temp_data.start_time;
       if (elapsed_time > 0.0) temp_data.compute += elapsed_time;
       temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
       MPI::COMM_WORLD.Recv(&int_buf_size, 1, MPI::UNSIGNED, recur_section, region_classes_init_tag);
#ifdef TIME_IT
       end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
       elapsed_time = end_time - temp_data.start_time;
       if (elapsed_time > 0.0) temp_data.wait += elapsed_time;
       temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
       MPI::COMM_WORLD.Recv(&double_buf_size, 1, MPI::UNSIGNED, recur_section, region_classes_init_tag);
       if (params.debug > 2)
       {
         params.log_fs << "Received region_objects_init results from task " << recur_section;
         params.log_fs << " with int_buf_size = " << int_buf_size << " and double_buf_size = " << double_buf_size << endl;
       }
       if (int_buf_size > 0)
       {
         check_buf_size(0,0,int_buf_size,0,double_buf_size,temp_data);
         MPI::COMM_WORLD.Recv(temp_data.int_buffer, int_buf_size, MPI::UNSIGNED, recur_section, region_classes_init_tag);
         MPI::COMM_WORLD.Recv(temp_data.double_buffer, double_buf_size, MPI::DOUBLE, recur_section, region_classes_init_tag);
#ifdef TIME_IT
         end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
         elapsed_time = end_time - temp_data.start_time;
         if (elapsed_time > 0.0) temp_data.transfer += elapsed_time;
         temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
         nb_objects = int_buf_size/2;
         int_buf_size = double_buf_size = 0;
         for (index = 0; index < nb_objects; ++index)
         {
           region_object_index = temp_data.int_buffer[int_buf_size++] - 1;
           region_objects[region_object_index].set_active_flag(true);
           region_objects[region_object_index].update_data(temp_data,int_buf_size,double_buf_size);
         }
       }
#else // !PARALLEL
     // In the serial case, process the specified data section
       if (((recur_level+1) == (params.ionb_levels-1)) && (params.nb_sections > 1))
       {
         restore_pixel_data(recur_section,pixel_data,temp_data);
         spatial_data.restore_region_object_label_map(recur_section);
       }
       do_region_objects_init((recur_level+1),recur_section,
                                recur_ncols,recur_nrows,pixel_data,spatial_data,
                                region_objects,temp_data);
#endif // !PARALLEL
     } // for (recur_section = min_section; recur_section < max_section; recur_section += stride)
   }
   nb_objects = 0;
   region_objects_size = region_objects.size( );
   for (region_object_index = 0; region_object_index < region_objects_size; ++region_object_index)
     if (region_objects[region_object_index].get_active_flag( ))
       nb_objects++;
#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << "Completed region_objects initialization with " << nb_objects;
     params.log_fs << " active regions" << endl;
   }
   if (params.debug > 3)
   {
     params.log_fs << endl << "Exiting do_region_objects_init, dump of the region_object data:" << endl << endl;
     for (region_object_index = 0; region_object_index < region_objects_size; ++region_object_index)
       if (region_objects[region_object_index].get_active_flag( ))
         region_objects[region_object_index].print(region_objects);
   }
#endif
   return nb_objects;
 }

} // namespace HSEGTilton
