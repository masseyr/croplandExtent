/*-----------------------------------------------------------
|
|  Routine Name: get_border_region_labels (regular version)
|
|       Purpose: Gets the col_border_region_labels and row_border_region_labels values
|                from pixel_data
|
|         Input: recur_level      (Current recursive level)
|                section          (Section or window processed by this call to get_border_region_labels)
|                border_flag      (Border selection flag)
|                ncols            (Number of columns in data being processed)
|                nrows            (Number of rows in data being processed)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|
|        Output: col_border_region_labels (Region labels from the processing window column border)
|                row_border_region_labels (Region labels from the processing window row border)
|
|         Other:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|          Date: March 11, 2016 (based on ../index/get_border_index_data.cc)
| Modifications: March 22, 2016 - Modified parameter order in function calls.
|
------------------------------------------------------------*/

#include <params/params.h>
#include <pixel/pixel.h>

extern HSEGTilton::Params params;

namespace HSEGTilton
{
 void get_border_region_labels(const unsigned char& border_flag, const int& ncols, const int& nrows,
                               vector<Pixel>& pixel_data, vector<unsigned int>& col_border_region_labels,
                               vector<unsigned int>& row_border_region_labels)
 {
   unsigned int pixel_index;
   int col, row;
   int pixel_col, pixel_row;
   int pixel_ncols = ncols + 2*params.overlap_width;

  // Set border_flags
   bool col_border_flag, row_border_flag;

   set_recur_flags(border_flag,col_border_flag,row_border_flag);

#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << endl << "Entering get_border_region_labels, ncols = " << ncols;
     params.log_fs << " and nrows = " << nrows << endl << endl;
     if (col_border_flag)
       params.log_fs << "Requesting col_border_region_labels" << endl;
     if (row_border_flag)
       params.log_fs << "Requesting row_border_region_labels" << endl;
   }
#endif

   if (col_border_flag)
   {
    // Set values for col_border_region_labels
       for (row = 0; row < nrows; row++)
       {
         pixel_row = row + params.overlap_width;
         for (col = 0; col < 2*params.overlap_width; col++)
         {
           pixel_index = col + pixel_row*pixel_ncols;
           col_border_region_labels[row + col*nrows] = pixel_data[pixel_index].get_region_label();
         }
         for (col = 2*params.overlap_width; col < 4*params.overlap_width; col++)
         {
           pixel_col = col + ncols - 2*params.overlap_width;
           pixel_index = pixel_col + pixel_row*pixel_ncols;
           col_border_region_labels[row + col*nrows] = pixel_data[pixel_index].get_region_label();
         }
       }
   } // if (col_border_flag)

   if (row_border_flag)
   {
    // Set values for row_border_region_labels
       for (row = 0; row < 2*params.overlap_width; row++)
       {
         for (col = 0; col < ncols; col++)
         {
           pixel_col = col + params.overlap_width;
           pixel_index = pixel_col + row*pixel_ncols;
           row_border_region_labels[col + row*ncols] = pixel_data[pixel_index].get_region_label();
         }
       }
       for (row = 2*params.overlap_width; row < 4*params.overlap_width; row++)
       {
         pixel_row = row + nrows - 2*params.overlap_width;
         for (col = 0; col < ncols; col++)
         {
           pixel_col = col + params.overlap_width;
           pixel_index = pixel_col + pixel_row*pixel_ncols;
           row_border_region_labels[col + row*ncols] = pixel_data[pixel_index].get_region_label();
         }
       }
   } // if (row_border_flag)

#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << endl << "Exiting get_border_region_labels" << endl << endl;
   }
#endif
   return;
 }

/*-----------------------------------------------------------
|
|  Routine Name: get_border_region_labels (recursive version)
|
|       Purpose: Gets the col_border_region_labels and row_border_region_labels values
|                from pixel_data
|
|         Input: recur_level      (Current recursive level)
|                section          (Section or window processed by this call to get_border_region_labels)
|                border_flag      (Border selection flag)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|                ncols            (Number of columns in data being processed)
|                nrows            (Number of rows in data being processed)
|                
|        Output: col_border_region_labels (Region labels from the processing window column border)
|                row_border_region_labels (Region labels from the processing window row border)
|
|         Other: temp_data        (buffers used in communications between parallel tasks)
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|          Date: March 11, 2016
| Modifications: (See comments for first instance of get_border_region_labels.)
|
------------------------------------------------------------*/
 void get_border_region_labels(const short unsigned int& recur_level, const short unsigned int& section,
                               const unsigned char& border_flag, const int& ncols, const int& nrows,
                               vector<Pixel>& pixel_data, vector<unsigned int>& col_border_region_labels,
                               vector<unsigned int>& row_border_region_labels, Temp& temp_data)
 {
   int col, row;

   int recur_ncols = ncols;
   int recur_nrows = nrows;
   bool col_flag, row_flag;
   set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);
   if (col_flag)
     recur_ncols /= 2;
   if (row_flag)
     recur_nrows /= 2;

  // Set border_flags
   bool col_border_flag, row_border_flag;

   set_recur_flags(border_flag,col_border_flag,row_border_flag);

   if (params.debug > 2)
   {
     params.log_fs << "Calling get_border_region_labels(P) for section = " << section << " with ncols = " << ncols << ", nrows = " << nrows;
     params.log_fs << endl << " at recur_level = " << recur_level << endl;
     if (col_border_flag)
       params.log_fs << "Requesting col_border_region_labels" << endl;
     if (row_border_flag)
       params.log_fs << "Requesting row_border_region_labels" << endl;
   }

   if (recur_level >= (params.onb_levels-1))
   {
    // At these recursive levels, the data is wholly contained in RAM memory and
    // the regular version of get_border_region_labels can be called.
     get_border_region_labels(border_flag,ncols,nrows,pixel_data,
                              col_border_region_labels,row_border_region_labels);
   }
   else // if (recur_level < (params.onb_levels-1))
   {
    // At these recursive levels, the data is not wholly contained in RAM memory and get_border_region_labels must be called recursively.
     unsigned int recur_border_data_size = 1;
     if (col_border_flag)
       recur_border_data_size = 4*recur_nrows*params.overlap_width;
     vector<unsigned int> recur_col_border_region_labels(recur_border_data_size);
     recur_border_data_size = 1;
     if (row_border_flag)
       recur_border_data_size = 4*recur_ncols*params.overlap_width;
     vector<unsigned int> recur_row_border_region_labels(recur_border_data_size);

     int recur_section, min_section;
     int stride, nb_sections;
     set_stride_sections(recur_level,stride,nb_sections);
#ifdef PARALLEL
     unsigned int value = border_flag;
   // Send request to the parallel recursive tasks
     parallel_recur_requests((short unsigned int) 11,recur_level,value,ncols,nrows,
                             0,0,0,temp_data);
   // Process current task's data section
     get_border_region_labels((recur_level+1),section,border_flag,recur_ncols,recur_nrows,pixel_data,
                              recur_col_border_region_labels,recur_row_border_region_labels,
                              temp_data);

     if (col_border_flag)
     {
        for (row = 0; row < recur_nrows; row++)
         for (col = 0; col < 2*params.overlap_width; col++)
           col_border_region_labels[row + col*nrows] =
                                recur_col_border_region_labels[row + col*recur_nrows];
     } // if (col_border_flag)
     if (row_border_flag)
     {
        for (row = 0; row < 2*params.overlap_width; row++)
         for (col = 0; col < recur_ncols; col++)
           row_border_region_labels[col + row*ncols] =
                                recur_row_border_region_labels[col + row*recur_ncols];
     } // if (row_border_flag)

     unsigned int int_buf_size = 0;
     if (col_border_flag)
       int_buf_size = 4*params.overlap_width*recur_nrows;
     if (row_border_flag)
       int_buf_size += 4*params.overlap_width*recur_ncols;
     check_buf_size(0,0,int_buf_size,0,0,temp_data);

     unsigned int int_buf_position;
   // Receive border_region_labels information from the parallel recur_tasks
     int index, border_region_labels_tag = 111;
     min_section = section + stride;
     unsigned int proc_section = 1;
#else // PARALLEL
     min_section = section;
     unsigned int proc_section = 0;
#endif // !PARALLEL

     int col_section, row_section, nb_col_sections, nb_row_sections;
     nb_col_sections = 1;
     if (col_flag)
       nb_col_sections = 2;
     nb_row_sections = 1;
     if (row_flag)
       nb_row_sections = 2;

     recur_section = section;
     for (row_section = 0; row_section < nb_row_sections; row_section++)
       for (col_section = 0; col_section < nb_col_sections; col_section++)
       {
         proc_section = col_section;
         if (params.nb_dimensions > 1)
           proc_section += 2*row_section;

         if (recur_section >= min_section)
         {
#ifdef PARALLEL
           if (params.debug > 2)
             params.log_fs << "Waiting for border_region_labels result from task " << recur_section << endl;
           MPI::COMM_WORLD.Recv(temp_data.int_buffer, int_buf_size, MPI::UNSIGNED, recur_section, border_region_labels_tag);
           if (params.debug > 2)
             params.log_fs << "Received border_region_labels information from task " << recur_section << endl;
           int_buf_position = 0;
           if (col_border_flag)
           {
             for (index = 0; index < (4*params.overlap_width*recur_nrows); ++index)
               recur_col_border_region_labels[index] = temp_data.int_buffer[int_buf_position++];
           } // if (col_border_flag)
           if (row_border_flag)
           {
             for (index = 0; index < (4*params.overlap_width*recur_ncols); ++index)
               recur_row_border_region_labels[index] = temp_data.int_buffer[int_buf_position++];
           } //if (row_border_flag)
#else // !PARALLEL
         // In the serial case, process the specified data section
           if (((recur_level+1) == (params.ionb_levels-1)) && (params.nb_sections > 1))
             restore_pixel_data(recur_section,pixel_data,temp_data);
           get_border_region_labels((recur_level+1),recur_section,border_flag,
                                    recur_ncols,recur_nrows,pixel_data,
                                    recur_col_border_region_labels,recur_row_border_region_labels,
                                    temp_data);
#endif // !PARALLEL
           switch(proc_section)
           {
             case 0:  if (col_border_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (2*params.overlap_width); col++)
                            col_border_region_labels[row + col*nrows] =
                                                 recur_col_border_region_labels[row + col*recur_nrows];
                      } // if (col_border_flag)
                      if (row_border_flag)
                      {
                        for (row = 0; row < (2*params.overlap_width); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_border_region_labels[col + row*ncols] =
                                                 recur_row_border_region_labels[col + row*recur_ncols];
                      } //if (row_border_flag)
                      break;
             case 1:  if (col_border_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = (2*params.overlap_width); col < (4*params.overlap_width); col++)
                            col_border_region_labels[row + col*nrows] =
                                                 recur_col_border_region_labels[row + col*recur_nrows];
                      } // if (col_border_flag)
                      if (row_border_flag)
                      {
                        for (row = 0; row < (2*params.overlap_width); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_border_region_labels[col + recur_ncols + row*ncols] =
                                                 recur_row_border_region_labels[col + row*recur_ncols];
                      } //if (row_border_flag)
                      break;
             case 2:  if (col_border_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (2*params.overlap_width); col++)
                            col_border_region_labels[row + recur_nrows + col*nrows] =
                                                 recur_col_border_region_labels[row + col*recur_nrows];
                      } // if (col_border_flag)
                      if (row_border_flag)
                      {
                        for (row = (2*params.overlap_width); row < (4*params.overlap_width); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_border_region_labels[col + row*ncols] =
                                                 recur_row_border_region_labels[col + row*recur_ncols];
                      } //if (row_border_flag)
                      break;
             case 3:  if (col_border_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = (2*params.overlap_width); col < (4*params.overlap_width); col++)
                            col_border_region_labels[row + recur_nrows + col*nrows] =
                                                 recur_col_border_region_labels[row + col*recur_nrows];
                      } // if (col_border_flag)
                      if (row_border_flag)
                      {
                        for (row = (2*params.overlap_width); row < (4*params.overlap_width); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_border_region_labels[col + recur_ncols + row*ncols] =
                                                 recur_row_border_region_labels[col + row*recur_ncols];
                      } //if (row_border_flag)
                      break;
           }
         } // if (recur_section >= min_section))
         recur_section += stride;
       } // for (row_section = 0; row_section < nb_row_sections; row_section++)
          //  for (col_section = 0; col_section < nb_col_sections; col_section++)
   }
#ifdef DEBUG
   if (params.debug > 3)
   {
     if (col_border_flag)
     {
         params.log_fs << endl << "Exiting get_border_region_labels(P), col_border_region_labels:" << endl << endl;
         for (row = 0; row < nrows; row++)
         {
           for (col = 0; col < 4*params.overlap_width; col++)
           {
              params.log_fs << col_border_region_labels[row + col*nrows] << " ";
           }
           params.log_fs << endl;
         }
         params.log_fs << endl;
     } // if (col_border_flag)
     if (row_border_flag)
     {
        params.log_fs << endl << "Exiting get_border_region_labels(P), row_border_region_labels:" << endl << endl;
        for (row = 0; row < 4*params.overlap_width; row++)
        {
         for (col = 0; col < ncols; col++)
         {
            params.log_fs << row_border_region_labels[col + row*ncols] << " ";
         }
         params.log_fs << endl;
        }
        params.log_fs << endl;
     } // if (row_border_flag)
   }
#endif
   if (params.debug > 2)
   {
     params.log_fs << endl << "Exiting get_border_region_labels(P-V1)" << endl;
   }
   return;
 }

} // namespace HSEGTilton
