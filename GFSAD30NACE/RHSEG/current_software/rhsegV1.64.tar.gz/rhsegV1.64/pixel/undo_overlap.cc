/*-----------------------------------------------------------
|
|  Routine Name: undo_overlap
|
|       Purpose: Undo processing window overlap in pixel_data with parallel calls as necessary
|                NOTE:  Must only be called from recur_level = 0 and only in RHSEG mode
|
|         Input/Output: pixel_data (Class which holds information pertaining to the pixel of pixels processed by this task)
|
|         Other: temp_data        (buffers used in section i/o when nb_sections > 1)
|
|       Returns: (void)
|
|    Written By: James C. Tilton
|          Date: March 14, 2016
| Modifications: 
|
------------------------------------------------------------*/

#include <params/params.h>
#include <pixel/pixel.h>
#include <spatial/spatial.h>
#include <iostream>
#include <vector>

extern HSEGTilton::Params params;

namespace HSEGTilton
{
  void undo_overlap(vector<Pixel>& pixel_data, Temp& temp_data)
  {
    short unsigned int section;
    int col, row;
    int pixel_index, overlap_pixel_index;

    int ionb_coloffset, ionb_rowoffset;
#ifdef PARALLEL
    int undo_overlap_tag = 114;
#endif
    int overlap_width = params.overlap_width;

    for (ionb_rowoffset = 0;
         ionb_rowoffset < params.nrows;
         ionb_rowoffset += params.onb_nrows)
    {
      for (ionb_coloffset = 0;
           ionb_coloffset < params.ncols;
           ionb_coloffset += params.onb_ncols)
      {
     // Determine which section of data is currently to be dealt with
        section = find_section(ionb_coloffset,ionb_rowoffset);
#ifdef PARALLEL
     // For section != 0, send request for data to dependent parallel tasks
        if (section > 0)
          parallel_request((short unsigned int) 14, section, 0, 0, 0, 0, 0, temp_data);
        else
        {
#else // ifndef PARALLEL
       // In the serial case for nb_sections > 1, read data from appropriate temporary file
          if (params.nb_sections > 1)
            restore_pixel_data( section, pixel_data, temp_data);
#endif
          for (row = 0; row < params.onb_nrows; row++)
          {
            for (col = 0; col < params.onb_ncols; col++)
            {
              pixel_index = col + row*params.onb_ncols;
              overlap_pixel_index = (col + params.overlap_width) + (row + params.overlap_width)*(params.onb_ncols + 2*params.overlap_width);
              pixel_data[pixel_index] = pixel_data[overlap_pixel_index];
            }
          }

#ifdef PARALLEL
        }
#else
       // In the serial case for nb_sections > 1, data is saved to appropriate temporary file
          if (params.nb_sections > 1)
          { 
            params.overlap_width = 0;
            save_pixel_data(section, pixel_data, temp_data);
            params.overlap_width = overlap_width;
          }
#endif
      }
    }

#ifdef PARALLEL
    for (ionb_rowoffset = 0;
         ionb_rowoffset < params.nrows;
         ionb_rowoffset += params.onb_nrows)
    {
      for (ionb_coloffset = 0;
           ionb_coloffset < params.ncols;
           ionb_coloffset += params.onb_ncols)
      {
         // Determine which section of data is currently to be dealt with
        section = find_section(ionb_coloffset,ionb_rowoffset);
        if (section > 0)
        {
        // Receive confirmation of completion from appropriate dependent parallel task
          MPI::COMM_WORLD.Recv(&pixel_index, 1, MPI::UNSIGNED, section, undo_overlap_tag);
        }
      } // for (ionb_coloffset = 0; ionb_coloffset < params.ncols; ionb_coloffset += params.onb_ncols)
    } // for (ionb_rowoffset = 0; ionb_rowoffset < params.nrows; ionb_rowoffset += params.onb_nrows)
#endif

    params.overlap_width = 0;
    return;
  }

} // namespace HSEGTilton
