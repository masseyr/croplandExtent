/*-----------------------------------------------------------
|
|  Routine Name: get_seam_index_data (regular version)
|
|       Purpose: Gets the col_seam_index_data and row_seam_index_data values
|                from pixel_data
|
|         Input: recur_level      (Current recursive level)
|                section          (Section or window processed by this call to get_seam_index_data)
|                seam_flag        (Seam selection flag)
|                ncols            (Current number of columns in data being processed)
|                nrows            (Current number of rows in data being processed)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|
|        Output: col_seam_index_data   (Index class information from the processing window column seam)
|                row_seam_index_data   (Index class information from the processing window row seam)
|
|         Other:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|          Date: October 6, 2003
| Modifications: November 13, 2003 - Made class member variables private.
|                December 23, 2004 - Changed region_class label from short unsigned int to unsigned int
|                June 15, 2005 - Added temporary file I/O for faster processing of large data sets
|                May 12, 2008 - Revised to work with globally defined Params and oParams class objects
|                March 24, 2011 - Revised counting of recursive levels to start at level = 0 (instead of level = 1).
|                April 7, 2011 - Initiated using set_stride_sections to determine stride and nb_sections (nb_tasks for parallel).
|                April 25, 2011 - Added seam_flag to designate: 1 => col only, 2 => row only, 3=> col & row
|                March 4, 2016 - Modified code for processing window overlapping.
|                March 22, 2016 - Modified parameter order in function calls.
|
------------------------------------------------------------*/

#include "index.h"
#include <params/params.h>
#include <pixel/pixel.h>
#include <spatial/spatial.h>
#ifdef TIME_IT
#include <ctime>
#endif

extern HSEGTilton::Params params;

namespace HSEGTilton
{
 void get_seam_index_data(const short unsigned int& recur_level, const short unsigned int& section,
                          const unsigned char& seam_flag, const int& ncols, const int& nrows,
                          vector<Pixel>& pixel_data, vector<Index>& col_seam_index_data,
                          vector<Index>& row_seam_index_data)
 {
   unsigned int pixel_index;
   int col, row;
   int pixel_col, pixel_row;
   int pixel_ncols = ncols + 2*params.overlap_width;

  // Set recursive image sizes
   int recur_ncols = ncols;
   int recur_nrows = nrows;
   bool col_flag, row_flag;
   set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);
   if (col_flag)
     recur_ncols /= 2;
   if (row_flag)
     recur_nrows /= 2;

  // Set seam_flags
   bool col_seam_flag, row_seam_flag;

   set_recur_flags(seam_flag,col_seam_flag,row_seam_flag);

#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << endl << "Regular version of get_seam_index_data called at recur_level = " << recur_level << endl;
     params.log_fs << "with ncols = " << ncols << " and nrows = " << nrows;
     params.log_fs << " for section " << section << endl << endl;
     if (col_seam_flag)
       params.log_fs << "Requesting col_seam_index_data" << endl;
     if (row_seam_flag)
       params.log_fs << "Requesting row_seam_index_data" << endl;
   }
#endif
   if (col_seam_flag)
   {
    // Set values for col_seam_index_data
     for (row = 0; row < nrows; row++)
     {
       pixel_row = row + params.overlap_width;
       for (col = 0; col < params.seam_size; col++)
       {
         pixel_col = col + params.overlap_width;
         pixel_index = (pixel_col+recur_ncols-(params.seam_size/2)) + pixel_row*pixel_ncols;
         col_seam_index_data[row + col*nrows].set_data(section,pixel_data,pixel_index);
       }
     }
   } // if (col_seam_flag)
   if (row_seam_flag)
   {
    // Set values for row_seam_index_data
     for (row = 0; row < params.seam_size; row++)
     {
       pixel_row = row + params.overlap_width;
       for (col = 0; col < ncols; col++)
       {
         pixel_col = col + params.overlap_width;
         pixel_index = pixel_col + (pixel_row+recur_nrows-(params.seam_size/2))*pixel_ncols;
         row_seam_index_data[col + row*ncols].set_data(section,pixel_data,pixel_index);
       }
     }
   } // if (row_seam_flag)
#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << endl << "Exiting get_seam_index_data" << endl << endl;
   }
#endif
   return;
 }

/*-----------------------------------------------------------
|
|  Routine Name: get_seam_index_data (recursive version)
|
|       Purpose: Gets the col_seam_index_data and row_seam_index_data values
|                from pixel_data
|
|         Input: recur_level      (Current recursive level)
|                section          (Section or window processed by this call to get_seam_index_data)
|                ncols            (Current number of columns in data being processed)
|                nrows            (Current number of rows in data being processed)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|                
|        Output: col_seam_index_data (index_class information from the processing window column seam)
|                row_seam_index_data (Index class information from the processing window row seam)
|
|         Other: temp_data    (buffers used in communications between parallel tasks)
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|          Date: October 7, 2003.
| Modifications: (See comments for first instance of get_seam_index_data.)
|
------------------------------------------------------------*/
 void get_seam_index_data(const short unsigned int& recur_level, const short unsigned int& section,
                          const unsigned char& seam_flag, const int& ncols, const int& nrows,
                          vector<Pixel>& pixel_data, vector<Index>& col_seam_index_data,
                          vector<Index>& row_seam_index_data, Temp& temp_data)
 {
   int col, row;
 
  // Set recursive image sizes
   int recur_ncols = ncols;
   int recur_nrows = nrows;
   bool col_flag, row_flag;
   set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);
   if (col_flag)
     recur_ncols /= 2;
   if (row_flag)
     recur_nrows /= 2;

  // Set seam_flags
   bool col_seam_flag, row_seam_flag;

   set_recur_flags(seam_flag,col_seam_flag,row_seam_flag);

   if (params.debug > 2)
   {
     params.log_fs << "Recursive version of get_seam_index_data called at recur_level = " << recur_level << endl;
     params.log_fs << "with ncols = " << ncols << " and nrows = " << nrows;
     params.log_fs << " for section " << section << endl << endl;
     if (col_seam_flag)
       params.log_fs << "Requesting col_seam_index_data" << endl;
     if (row_seam_flag)
       params.log_fs << "Requesting row_seam_index_data" << endl;
   }

   if (recur_level >= (params.onb_levels-1))
   {
    // At these recursive levels, the data is wholly contained in RAM memory and
    // the regular version of get_seam_index_data can be called.
     get_seam_index_data(recur_level,section,seam_flag,ncols,nrows,pixel_data,
                         col_seam_index_data,row_seam_index_data);
   }
   else // if (recur_level < (params.onb_levels-1))
   {
    // At these recursive levels, the data is not wholly contained in RAM memory and get_seam_index_data must be called recursively.
     unsigned int recur_index_data_size = 1;
     if (col_seam_flag)
       recur_index_data_size = recur_nrows*params.seam_size;
     vector<Index> recur_col_border_index_data(recur_index_data_size);
     recur_index_data_size = 1;
     if (row_seam_flag)
       recur_index_data_size = recur_ncols*params.seam_size;
     vector<Index> recur_row_border_index_data(recur_index_data_size);
     int recur_section, min_section;
     int stride, nb_sections;
     set_stride_sections(recur_level,stride,nb_sections);
#ifdef PARALLEL
     unsigned int value = seam_flag;
   // Send request to the parallel recursive tasks.
     parallel_recur_requests((short unsigned int) 6,recur_level,value,ncols,nrows,
                             0,0,0,temp_data);
   // Process current task's data section
     get_border_index_data((recur_level+1),section,seam_flag,recur_ncols,recur_nrows,pixel_data,
                           recur_col_border_index_data,recur_row_border_index_data,
                           temp_data);

     if (col_seam_flag)
     {
       for (row = 0; row < recur_nrows; row++)
         for (col = 0; col < (params.seam_size/2); col++)
           col_seam_index_data[row + col*nrows] =
               recur_col_border_index_data[row + (col+(params.seam_size/2))*recur_nrows];
     } // if (col_seam_flag)
     if (row_seam_flag)
     {
       for (row = 0; row < (params.seam_size/2); row++)
         for (col = 0; col < recur_ncols; col++)
           row_seam_index_data[col + row*ncols] =
               recur_row_border_index_data[col + (row+(params.seam_size/2))*recur_ncols];
     } // if (row_seam_flag)

     unsigned int short_buf_size = 0, int_buf_size = 0;
     short unsigned int short_factor = 1, int_factor = 2;
     if (col_seam_flag)
     {
       short_buf_size = short_factor*params.seam_size*recur_nrows;
       int_buf_size = int_factor*params.seam_size*recur_nrows;
     } // if (col_seam_flag)
     if (row_seam_flag)
     {
       short_buf_size += short_factor*params.seam_size*recur_ncols;
       int_buf_size += int_factor*params.seam_size*recur_ncols;
     } // if (row_seam_flag)
     check_buf_size(0,short_buf_size,int_buf_size,0,0,temp_data);

     unsigned int short_buf_position, int_buf_position;
   // Receive index_data information from the parallel recur_tasks
     int index, border_index_data_tag = 106;
     min_section = section + stride;
     unsigned int proc_section = 1;
#ifdef TIME_IT
     float end_time, elapsed_time;
#endif
#else // PARALLEL
     min_section = section;
     unsigned int proc_section = 0;
#endif // !PARALLEL

     int col_section, row_section, nb_col_sections, nb_row_sections;
     nb_col_sections = 1;
     if (col_flag)
       nb_col_sections = 2;
     nb_row_sections = 1;
     if (row_flag)
       nb_row_sections = 2;

     recur_section = section;
     for (row_section = 0; row_section < nb_row_sections; row_section++)
       for (col_section = 0; col_section < nb_col_sections; col_section++)
       {
         proc_section = col_section;
         if (params.nb_dimensions > 1)
           proc_section += 2*row_section;
         if (recur_section >= min_section)
         {
#ifdef PARALLEL
           if (params.debug > 3)
             params.log_fs << "Waiting for border_index_data information from task " << recur_section << endl;
#ifdef TIME_IT
           end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
           elapsed_time = end_time - temp_data.start_time;
           if (elapsed_time > 0.0) temp_data.compute += elapsed_time;
           temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
           MPI::COMM_WORLD.Recv(&short_buf_size, 1, MPI::UNSIGNED, recur_section, border_index_data_tag);
           end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
           elapsed_time = end_time - temp_data.start_time;
           if (elapsed_time > 0.0) temp_data.wait += elapsed_time;
           temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
           MPI::COMM_WORLD.Recv(temp_data.short_buffer, short_buf_size, MPI::UNSIGNED_SHORT, recur_section, border_index_data_tag);
           MPI::COMM_WORLD.Recv(temp_data.int_buffer, int_buf_size, MPI::UNSIGNED, recur_section, border_index_data_tag);
#ifdef TIME_IT
           end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
           elapsed_time = end_time - temp_data.start_time;
           if (elapsed_time > 0.0) temp_data.transfer += elapsed_time;
           temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
           short_buf_position = int_buf_position = 0;
           if (col_seam_flag)
           {
             for (index = 0; index < (params.seam_size*recur_nrows); ++index)
               recur_col_border_index_data[index].set_data(false,temp_data,short_buf_position,int_buf_position);
           } // if (col_seam_flag)
           if (row_seam_flag)
           {
             for (index = 0; index < (params.seam_size*recur_ncols); ++index)
               recur_row_border_index_data[index].set_data(false,temp_data,short_buf_position,int_buf_position);
           } //if (row_seam_flag)
#else // !PARALLEL
         // In the serial case, process the specified data section
           if (((recur_level+1) == (params.ionb_levels-1)) && (params.nb_sections > 1))
              restore_pixel_data(recur_section,pixel_data,temp_data);
           get_border_index_data((recur_level+1),recur_section,seam_flag,recur_ncols,recur_nrows,
                                 pixel_data,recur_col_border_index_data,recur_row_border_index_data,
                                 temp_data);
#endif // !PARALLEL
           switch(proc_section)
           {
             case 0:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[row + col*nrows] =
                                recur_col_border_index_data[row + (col+(params.seam_size/2))*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[col + row*ncols] =
                                recur_row_border_index_data[col + (row+(params.seam_size/2))*recur_ncols];
                      } //if (row_seam_flag)
                      break;
             case 1:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[row + (col+(params.seam_size/2))*nrows] =
                                recur_col_border_index_data[row + col*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[(recur_ncols+col) + row*ncols] =
                                recur_row_border_index_data[col + (row+(params.seam_size/2))*recur_ncols];
                      } //if (row_seam_flag)
                      break;
             case 2:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[(recur_nrows+row) + col*nrows] =
                                recur_col_border_index_data[row + (col+(params.seam_size/2))*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[col + (row+(params.seam_size/2))*ncols] =
                                recur_row_border_index_data[col + row*recur_ncols];
                      } //if (row_seam_flag)
                      break;
             case 3:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[(recur_nrows+row) + (col+(params.seam_size/2))*nrows] =
                                recur_col_border_index_data[row + col*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[(recur_ncols+col) + (row+(params.seam_size/2))*ncols] =
                                recur_row_border_index_data[col + row*recur_ncols];
                      } //if (row_seam_flag)
                      break;
           }
         } // if (recur_section >= min_section))
         recur_section += stride;
       } // for (row_section = 0; row_section < nb_row_sections; row_section++)
          //  for (col_section = 0; col_section < nb_col_sections; col_section++)
   }
#ifdef DEBUG
   if (params.debug > 3)
   {
     if (col_seam_flag)
     {
        params.log_fs << endl << "Exiting get_seam_index_data(P), col_seam_index_data:" << endl << endl;
        for (row = 0; row < nrows; row++)
        {
         for (col = 0; col < params.seam_size; col++)
         {
            params.log_fs << col_seam_index_data[row + col*nrows].get_region_class_label( ) << " ";
         }
         params.log_fs << endl;
        }
        params.log_fs << endl;
     } // if (col_seam_flag)
     if (row_seam_flag)
     {
        params.log_fs << endl << "Exiting get_seam_index_data(P), row_seam_index_data:" << endl << endl;
        for (row = 0; row < params.seam_size; row++)
        {
         for (col = 0; col < ncols; col++)
         {
            params.log_fs << row_seam_index_data[col + row*ncols].get_region_class_label( ) << " ";
         }
         params.log_fs << endl;
        }
        params.log_fs << endl;
     } // if (row_seam_flag)
   }
   if (params.debug > 2)
   {
     params.log_fs << endl << "Exiting get_seam_index_data (P)" << endl << endl;
   }
#endif
   return;
 }

/*-----------------------------------------------------------
|
|  Routine Name: get_seam_index_data (regular version)
|
|       Purpose: Gets the col_seam_index_data and row_seam_index_data values
|                from spatial_data
|
|         Input: recur_level      (Current recursive level)
|                section          (Section or window processed by this call to get_seam_index_data)
|                seam_flag        (Seam selection flag)
|                ncols            (Current number of columns in data being processed)
|                nrows            (Current number of rows in data being processed)
|                spatial_data     (Class which holds information pertaining to input and output spatial data)
|
|        Output: col_seam_index_data   (Index class information from the processing window column seam)
|                row_seam_index_data   (Index class information from the processing window row seam)
|
|         Other:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|          Date: October 6, 2003
| Modifications: (See comments for first instance of get_seam_index_data.)
|
------------------------------------------------------------*/
 void get_seam_index_data(const short unsigned int& recur_level, const short unsigned int& section,
                          const unsigned char& seam_flag, const int& ncols, const int& nrows,
                          Spatial& spatial_data, vector<Index>& col_seam_index_data,
                          vector<Index>& row_seam_index_data)
 {
   unsigned int pixel_index;
   int col, row;
   int pixel_col, pixel_row;
   int pixel_ncols = ncols + 2*params.overlap_width;

  // Set recursive image sizes
   int recur_ncols = ncols;
   int recur_nrows = nrows;
   bool col_flag, row_flag;
   set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);
   if (col_flag)
     recur_ncols /= 2;
   if (row_flag)
     recur_nrows /= 2;

  // Set seam_flags
   bool col_seam_flag, row_seam_flag;

   set_recur_flags(seam_flag,col_seam_flag,row_seam_flag);

#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << endl << "Calling get_seam_index_data(V2) for section = " << section << " with ncols = " << ncols;
     params.log_fs << " and nrows = " << nrows << endl << endl;
     if (col_seam_flag)
       params.log_fs << "Requesting col_seam_index_data" << endl;
     if (row_seam_flag)
       params.log_fs << "Requesting row_seam_index_data" << endl;
   }
#endif
   if (col_seam_flag)
   {
    // Set values for col_seam_index_data
     for (row = 0; row < nrows; row++)
     {
       pixel_row = row + params.overlap_width;
       for (col = 0; col < params.seam_size; col++)
       {
         pixel_col = col + params.overlap_width;
         pixel_index = (pixel_col+recur_ncols-(params.seam_size/2)) + pixel_row*pixel_ncols;
         col_seam_index_data[row + col*nrows].set_data(section,spatial_data,pixel_index);
       }
     }
   } // if (col_seam_flag)
   if (row_seam_flag)
   {
    // Set values for row_seam_index_data
     for (row = 0; row < params.seam_size; row++)
     {
       pixel_row = row + params.overlap_width;
       for (col = 0; col < ncols; col++)
       {
         pixel_col = col + params.overlap_width;
         pixel_index = pixel_col + (pixel_row+recur_nrows-(params.seam_size/2))*pixel_ncols;
         row_seam_index_data[col + row*ncols].set_data(section,spatial_data,pixel_index);
       }
     }
   } // if (row_seam_flag)
#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << endl << "Exiting get_seam_index_data(V2)" << endl << endl;
   }
#endif
   return;
 }

/*-----------------------------------------------------------
|
|  Routine Name: get_seam_index_data (recursive version)
|
|       Purpose: Gets the col_seam_index_data and row_seam_index_data values
|                from spatial_data
|
|         Input: recur_level      (Current recursive level)
|                section          (Section or window processed by this call to get_seam_index_data)
|                seam_flag        (Seam selection flag)
|                ncols            (Current number of columns in data being processed)
|                nrows            (Current number of rows in data being processed)
|                spatial_data     (Class which holds information pertaining to input and output spatial data)
|                
|        Output: col_seam_index_data (index_class information from the processing window column seam)
|                row_seam_index_data (Index class information from the processing window row seam)
|
|         Other: temp_data    (buffers used in communications between parallel tasks)
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|          Date: October 7, 2003.
| Modifications: (See comments for first instance of get_seam_index_data.)
|
------------------------------------------------------------*/
 void get_seam_index_data(const short unsigned int& recur_level, const short unsigned int& section,
                          const unsigned char& seam_flag, const int& ncols, const int& nrows,
                          Spatial& spatial_data, vector<Index>& col_seam_index_data,
                          vector<Index>& row_seam_index_data, Temp& temp_data)
 {
   int col, row;

  // Set recursive image sizes
   int recur_ncols = ncols;
   int recur_nrows = nrows;
   bool col_flag, row_flag;
   set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);
   if (col_flag)
     recur_ncols /= 2;
   if (row_flag)
     recur_nrows /= 2;

  // Set seam_flags
   bool col_seam_flag, row_seam_flag;

   set_recur_flags(seam_flag,col_seam_flag,row_seam_flag);

#ifdef DEBUG
   if (params.debug > 2)
   {
     params.log_fs << endl << "Calling get_seam_index_data(P-V2) for section = " << section << " with ncols = " << ncols;
     params.log_fs << " and nrows = " << nrows << endl << "at recur_level = " << recur_level;
     if (col_seam_flag)
       params.log_fs << "Requesting col_seam_index_data" << endl;
     if (row_seam_flag)
       params.log_fs << "Requesting row_seam_index_data" << endl;
   }
#endif

   if (recur_level >= (params.onb_levels-1))
   {
    // At these recursive levels, the data is wholly contained in RAM memory and
    // the regular version of get_seam_index_data can be called.
     get_seam_index_data(recur_level,section,seam_flag,ncols,nrows,spatial_data,
                         col_seam_index_data,row_seam_index_data);
   }
   else // if (recur_level < (params.onb_levels-1))
   {
    // At these recursive levels, the data is not wholly contained in RAM memory and
    // get_seam_index_data must be called recursively.
     unsigned int recur_index_data_size = 1;
     if (col_seam_flag)
       recur_index_data_size = recur_nrows*params.seam_size;
     vector<Index> recur_col_border_index_data(recur_index_data_size);
     recur_index_data_size = 1;
     if (row_seam_flag)
       recur_index_data_size = recur_ncols*params.seam_size;
     vector<Index> recur_row_border_index_data(recur_index_data_size);

     int stride, nb_sections;
     set_stride_sections(recur_level,stride,nb_sections);
#ifdef PARALLEL
     unsigned int value = seam_flag;
   // Send request to the parallel recursive tasks
     parallel_recur_requests((short unsigned int) 9,recur_level,value,ncols,nrows,
                             0,0,0,temp_data);
   // Process current task's data section
     get_border_index_data((recur_level+1),section,seam_flag,recur_ncols,recur_nrows,
                           spatial_data,recur_col_border_index_data,recur_row_border_index_data,
                           temp_data);

     if (col_seam_flag)
     {
       for (row = 0; row < recur_nrows; row++)
         for (col = 0; col < (params.seam_size/2); col++)
           col_seam_index_data[row + col*nrows] =
               recur_col_border_index_data[row + (col+(params.seam_size/2))*recur_nrows];
     }
     if (row_seam_flag)
     {
       for (row = 0; row < (params.seam_size/2); row++)
         for (col = 0; col < recur_ncols; col++)
           row_seam_index_data[col + row*ncols] =
               recur_row_border_index_data[col + (row+(params.seam_size/2))*recur_ncols];
     }
     unsigned int short_buf_size = 0, int_buf_size = 0;
     short unsigned int short_factor = 2, int_factor = 3;
     if (col_seam_flag)
     {
       short_buf_size = short_factor*params.seam_size*recur_nrows;
       int_buf_size = int_factor*params.seam_size*recur_nrows;
     }
     if (row_seam_flag)
     {
       short_buf_size += short_factor*params.seam_size*recur_ncols;
       int_buf_size += int_factor*params.seam_size*recur_ncols;
     }
     check_buf_size(0,short_buf_size,int_buf_size,0,0,temp_data);

     unsigned int short_buf_position, int_buf_position;
   // Receive recur_border_index_data information from the parallel recur_tasks
     int index, border_index_data_tag2 = 109;
     int min_section = section + stride;
     unsigned int proc_section = 1;
#ifdef TIME_IT
     float end_time, elapsed_time;
#endif
#else
     int min_section = section;
     unsigned int proc_section = 0;
#endif

     int col_section, row_section, nb_col_sections, nb_row_sections;
     nb_col_sections = 1;
     if (col_flag)
       nb_col_sections = 2;
     nb_row_sections = 1;
     if (row_flag)
       nb_row_sections = 2;

     int recur_section = section;
     for (row_section = 0; row_section < nb_row_sections; row_section++)
       for (col_section = 0; col_section < nb_col_sections; col_section++)
       {
         proc_section = col_section;
         if (params.nb_dimensions > 1)
           proc_section += 2*row_section;

         if (recur_section >= min_section)
         {
#ifdef PARALLEL
           if (params.debug > 2)
             params.log_fs << "Waiting for border_index_data information from task " << recur_section << endl;
#ifdef TIME_IT
           end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
           elapsed_time = end_time - temp_data.start_time;
           if (elapsed_time > 0.0) temp_data.compute += elapsed_time;
           temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));    
           MPI::COMM_WORLD.Recv(&short_buf_size, 1, MPI::UNSIGNED, recur_section, border_index_data_tag2);
           end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
           elapsed_time = end_time - temp_data.start_time;
           if (elapsed_time > 0.0) temp_data.wait += elapsed_time;
           temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
           MPI::COMM_WORLD.Recv(temp_data.short_buffer, short_buf_size, MPI::UNSIGNED_SHORT, recur_section, border_index_data_tag2);
           MPI::COMM_WORLD.Recv(temp_data.int_buffer, int_buf_size, MPI::UNSIGNED, recur_section, border_index_data_tag2);
#ifdef TIME_IT
           end_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
           elapsed_time = end_time - temp_data.start_time;
           if (elapsed_time > 0.0) temp_data.transfer += elapsed_time;
           temp_data.start_time = (((float) clock( ))/((float) CLOCKS_PER_SEC));
#endif
           if (params.debug > 2)
             params.log_fs << "Received border_index_data information from task " << recur_section << endl;
           short_buf_position = int_buf_position = 0;
           if (col_seam_flag)
           {
             for (index = 0; index < (params.seam_size*recur_nrows); ++index)
               recur_col_border_index_data[index].set_data(true,temp_data,short_buf_position,int_buf_position);
           } // if (col_seam_flag)
           if (row_seam_flag)
           {
             for (index = 0; index < (recur_ncols*params.seam_size); ++index)
               recur_row_border_index_data[index].set_data(true,temp_data,short_buf_position,int_buf_position);
           } // if (row_seam_flag)
#else // !PARALLEL
         // In the serial case, process the specified data section
           if (((recur_level+1) == (params.ionb_levels-1)) && (params.nb_sections > 1))
           {
             spatial_data.restore_region_class_label_map(recur_section);
             if (params.region_nb_objects_flag) // Added this check May 23, 2011
               spatial_data.restore_region_object_label_map(recur_section);
             spatial_data.restore_boundary_map(recur_section);
           }
           get_border_index_data((recur_level+1),recur_section,seam_flag,recur_ncols,recur_nrows,
                                 spatial_data,recur_col_border_index_data,recur_row_border_index_data,
                                 temp_data);
#endif // !PARALLEL
           switch(proc_section)
           {
             case 0:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[row + col*nrows] =
                                recur_col_border_index_data[row + (col+(params.seam_size/2))*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[col + row*ncols] =
                                recur_row_border_index_data[col + (row+(params.seam_size/2))*recur_ncols];
                      } // if (row_seam_flag)
                      break;
             case 1:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[row + (col+(params.seam_size/2))*nrows] =
                                recur_col_border_index_data[row + col*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[(recur_ncols+col) + row*ncols] =
                                recur_row_border_index_data[col + (row+(params.seam_size/2))*recur_ncols];
                      } // if (row_seam_flag)
                      break;
             case 2:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[(recur_nrows+row) + col*nrows] =
                                recur_col_border_index_data[row + (col+(params.seam_size/2))*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[col + (row+(params.seam_size/2))*ncols] =
                                recur_row_border_index_data[col + row*recur_ncols];
                      } // if (row_seam_flag)
                      break;
             case 3:  if (col_seam_flag)
                      {
                        for (row = 0; row < recur_nrows; row++)
                          for (col = 0; col < (params.seam_size/2); col++)
                            col_seam_index_data[(recur_nrows+row) + (col+(params.seam_size/2))*nrows] =
                                recur_col_border_index_data[row + col*recur_nrows];
                      } // if (col_seam_flag)
                      if (row_seam_flag)
                      {
                        for (row = 0; row < (params.seam_size/2); row++)
                          for (col = 0; col < recur_ncols; col++)
                            row_seam_index_data[(recur_ncols+col) + (row+(params.seam_size/2))*ncols] =
                                recur_row_border_index_data[col + row*recur_ncols];
                      } // if (row_seam_flag)
                      break;
           }
         } // if (recur_section >= min_section)
         recur_section += stride;
       } // for (row_section = 0; row_section < nb_row_sections; row_section++)
         //  for (col_section = 0; col_section < nb_col_sections; col_section++)
   }

#ifdef DEBUG
   int value;
   if (params.debug > 2)
   {
     if (col_seam_flag)
     {
       params.log_fs << endl << "Exiting get_seam_index_data(P-V2), col_seam_index_data.region_class_label" << endl << endl;
         for (row = 0; row < nrows; row++)
         {
           for (col = 0; col < params.seam_size; col++)
           {
             value = (int) col_seam_index_data[row + col*nrows].get_region_class_label( );
             if (value < 10)
               params.log_fs << "0" << value << " ";
             else
               params.log_fs << value << " ";
           }
           params.log_fs << endl;
         }
         params.log_fs << endl;
     } // if (col_seam_flag)
     if (row_seam_flag)
     {
       params.log_fs << endl << "Exiting get_seam_index_data(P-V2), row_seam_index_data.region_class_label:" << endl << endl;
         for (row = 0; row < params.seam_size; row++)
         {
           for (col = 0; col < ncols; col++)
           {
             value = (int) row_seam_index_data[col + row*ncols].get_region_class_label( );
             if (value < 10)
               params.log_fs << "0" << value << " ";
             else
               params.log_fs << value << " ";
           }
           params.log_fs << endl;
         }
         params.log_fs << endl;
     } // if (row_seam_flag)
     if (params.object_labels_map_flag)
     {
       if (col_seam_flag)
       {
           params.log_fs << endl << "Exiting get_seam_index_data(P-V2), col_seam_index_data.region_object_label:" << endl << endl;
           for (row = 0; row < nrows; row++)
           {
             for (col = 0; col < params.seam_size; col++)
             {
               params.log_fs << col_seam_index_data[row + col*nrows].get_region_object_label( ) << " ";
             }
             params.log_fs << endl;
           }
           params.log_fs << endl;
       } // if (col_seam_flag)
       if (row_seam_flag)
       {
           params.log_fs << endl << "Exiting get_seam_index_data(P-V2), row_seam_index_data.region_object_label:" << endl << endl;
           for (row = 0; row < params.seam_size; row++)
           {
             for (col = 0; col < ncols; col++)
             {
               params.log_fs << row_seam_index_data[col + row*ncols].get_region_object_label( ) << " ";
             }
             params.log_fs << endl;
           }
           params.log_fs << endl;
       } // if (row_seam_flag)
     } // if (params.object_labels_map_flag)
     if (col_seam_flag)
     {
       params.log_fs << endl << "Exiting get_seam_index_data(P-V2), col_seam_index_data.boundary_map:" << endl << endl;
         for (row = 0; row < nrows; row++)
         {
           for (col = 0; col < params.seam_size; col++)
           {
             value = (int) col_seam_index_data[row + col*nrows].get_boundary_map( );
             if (value < 10)
               params.log_fs << "0" << value << " ";
             else
               params.log_fs << value << " ";
           }
           params.log_fs << endl;
         }
         params.log_fs << endl;
     } // if (col_seam_flag)
     if (row_seam_flag)
     {
       params.log_fs << endl << "Exiting get_seam_index_data(P-V2), row_seam_index_data.boundary_map:" << endl << endl;
         for (row = 0; row < params.seam_size; row++)
         {
           for (col = 0; col < ncols; col++)
           {
             value = (int) row_seam_index_data[col + row*ncols].get_boundary_map( );
             if (value < 10)
               params.log_fs << "0" << value << " ";
             else
               params.log_fs << value << " ";
           }
           params.log_fs << endl;
         }
         params.log_fs << endl;
     } // if (row_seam_flag)
     if (col_seam_flag)
     {
         params.log_fs << endl << "Exiting get_seam_index_data(P-V2), col_seam_index_data.section" << endl << endl;
         for (row = 0; row < nrows; row++)
         {
           for (col = 0; col < params.seam_size; col++)
           {
             value = (int) col_seam_index_data[row + col*nrows].get_section( );
             if (value < 10)
               params.log_fs << "0" << value << " ";
             else
               params.log_fs << value << " ";
           }
           params.log_fs << endl;
         }
         params.log_fs << endl;
     } // if (col_seam_flag)
     if (row_seam_flag)
     {
         params.log_fs << endl << "Exiting get_seam_index_data(P-V2), row_seam_index_data.section:" << endl << endl;
         for (row = 0; row < params.seam_size; row++)
         {
           for (col = 0; col < ncols; col++)
           {
             value = (int) row_seam_index_data[col + row*ncols].get_section( );
             if (value < 10)
               params.log_fs << "0" << value << " ";
             else
               params.log_fs << value << " ";
           }
           params.log_fs << endl;
         }
         params.log_fs << endl;
     } // if (row_seam_flag)
   }
   if (params.debug > 2)
   {
     params.log_fs << endl << "Exiting get_seam_index_data (P-V2)" << endl << endl;
   }
#endif
   return;
 }

} // namespace HSEGTilton
