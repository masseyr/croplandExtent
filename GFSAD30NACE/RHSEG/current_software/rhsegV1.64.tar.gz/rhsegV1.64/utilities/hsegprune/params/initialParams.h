#ifndef INITIALPARAMS_H
#define INITIALPARAMS_H

#include <defines.h>
#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <vector>
#include "gdal_priv.h"
#include "cpl_conv.h"

using namespace std;

namespace HSEGTilton
{

  class InitialParams 
  {
    public:
    // Constructor and Destructor
      InitialParams();
      virtual ~InitialParams();

    // Member functions
      bool read(const char *param_file);
      bool read_oparam();
      void set_temp_files();
      void print();
      void print_oparam();
      void remove_temp_files();

    // Member variables (public)

    /*-- RHSeg output parameter file (required) --*/
      string  oparam_file;           /*-- USER INPUT FILE NAME --*/

   /*-- Prune Factors (optional, default provided) --*/
//      float   npix_factor;          /*-- USER INPUT PARAMETER --*/
      float   std_dev_factor;        /*-- USER INPUT PARAMETER --*/
      float   bp_ratio_factor;       /*-- USER INPUT PARAMETER --*/

   /*-- Prune option (optional, default provided) --*/
      unsigned int   prune_option;   /*-- USER INPUT PARAMETER --*/

   /*-- Minimun region size for pruning (optional, default provided) --*/
      unsigned int   minimum_npix;   /*-- USER INPUT PARAMETER --*/

    /*-- Output prune_labels_map image file (required) --*/
      string  prune_labels_map_file; /*-- USER INPUT FILENAME --*/

    /*-- Output prune_npix image file (optional) --*/
      string  prune_npix_file;       /*-- USER INPUT FILENAME --*/
      bool    prune_npix_flag;       /*-- EXISTENCE FLAG --*/

    /*-- Output prune_mean image file (optional) --*/
      string  prune_mean_file;       /*-- USER INPUT FILENAME --*/
      bool    prune_mean_flag;       /*-- EXISTENCE FLAG --*/

    /*-- Output prune_std_dev image file (optional) --*/
      string  prune_std_dev_file;    /*-- USER INPUT FILENAME --*/
      bool    prune_std_dev_flag;    /*-- EXISTENCE FLAG --*/

    /*-- Output prune_bp_ratio image file (optional) --*/
      string  prune_bp_ratio_file;   /*-- USER INPUT FILENAME --*/
      bool    prune_bp_ratio_flag;   /*-- EXISTENCE FLAG --*/

    /*-- Temporary files and associated GDALDatasets --*/
      vector<string> temp_seg_level_label_files; /* -- PROGRAM PARAMETERS --*/
      vector<GDALDataset *> tempDatasets;        /* -- PROGRAM PARAMETERS --*/

    /*-- Temporary filename prefix --*/
      string prefix;              /* -- PROGRAM PARAMETER --*/

    protected:

    private:

  };

} // HSEGTilton

#endif /* INITIALPARAMS_H */
