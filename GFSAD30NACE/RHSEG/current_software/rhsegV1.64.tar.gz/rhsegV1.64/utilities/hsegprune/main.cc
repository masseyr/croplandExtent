/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the hsegprune program
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>    Written By: James C. Tilton, NASA GSFC, Mail Code 606.3, Greenbelt, MD 20771
   >>>>                James.C.Tilton@nasa.gov
   >>>>
   >>>>       Written: November 10, 2014
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include <defines.h>
#include "hsegprune.h"
#include "params/initialParams.h"
#include "params/params.h"
#include <iostream>
#include <fstream>

using namespace std;
using namespace HSEGTilton;

// Globals
InitialParams initialParams;
Params params("Version 1.64, Sept. 1, 2016");
oParams oparams;

// Forward function declarations
void usage();
void help();

int main(int argc, char *argv[])
{
  bool status;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: hsegprune -h or hsegprune -help" << endl << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_FAILURE;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = initialParams.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (initialParams.read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
// Call hsegprune function
    status = hsegprune();
    initialParams.remove_temp_files();
  }

  if (status)
  {
    cout << endl << "Successful completion of hsegprune program" << endl;
    return EXIT_SUCCESS;
  }
  else
  {
    cout << endl << "The hsegprune program terminated improperly." << endl;
    return EXIT_FAILURE;
  }
  
}

void usage() // Informs user of proper usage of program when mis-used.
{
    cout << endl << "Usage: " << endl << endl;
    cout << "hsegprune parameter_file_name" << endl << endl;
    cout << "For help information: hsegprune -h or hsegprune -help" << endl;
    cout << "For version information: hsegprune -v or hsegprune -version" << endl;

    return ;
}

void help()
{
    cout << endl << "The hsegprune progam is called in the following manner:" << endl;
    cout << "hsegprune parameter_file_name" << endl;
    cout << endl << "where \"parameter_file_name\" is the name of the input parameter file" << endl;
    cout << "For contents see below." << endl;
    cout << endl << "For this help: hsegprune -h or hsegprune -help" << endl;
    cout << "For version information: hsegprune -v or hsegprune -version" << endl;
    cout << endl << "The parameter file consists of entries of the form:" << endl << endl;
    cout << "-parameter_name parameter_value(s)" << endl;
    cout << endl << "Each parameter name and its value(s) must be entered on a separate, single line" << endl;

    fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n");
    fprintf(stdout,"\nInput File:\n"
"-oparam			(string)	HSeg/RHSeg output parameter file\n"
"					(required)\n");
    fprintf(stdout,"\nPrune Factors:\n"
/*
"-npix_factor		(float)		Prune Factor on Region Number of Pixels\n"
"					(optional, default = 1.5)\n"
*/
"-std_dev_factor		(float)		Prune Factor on Region Standard\n"
"					Deviation (optional, default = 1.05)\n"
"-bp_ratio_factor	(float)		Prune Factor on Region Boundary Pixel\n"
"					Ratio (optional, default = 1.05)\n");
    fprintf(stdout,"\nOther input parameters:\n"
"-prune_option		(int)		Prune option:\n"
"					  1.\"Prune on region classes\",\n"
"					  2.\"Prune on region objects\",\n"
"					(default: 2. \"Prune on region objects\")\n"
"-minimum_npix		(int)		Minimum size of region involved in\n"
"					pruning (optional, default = 100)\n");

    fprintf(stdout,"\nOutput Files:\n"
"-prune_labels_map	(string)	Region class or object labels map image\n"
"					at pruned hierarchical levels (required)\n"
"-prune_npix		(string)	Region number of pixels image at\n"
"					pruned hierarchical levels (optional)\n"
"-prune_mean		(string)	Region mean image at\n"
"					pruned hierarchical levels (optional)\n"
"-prune_std_dev		(string)	Region standard deviation image at\n"
"					pruned hierarchical levels (optional)\n"
"-prune_bp_ratio		(string)	Region boundary pixel ratio image at\n"
"					pruned hierarchical levels (optional)\n"
"NOTE: The output image files will have the same format as the\n"
"      \"class_labels_map\" specified in \"oparam\".\n");

    return ;
}
