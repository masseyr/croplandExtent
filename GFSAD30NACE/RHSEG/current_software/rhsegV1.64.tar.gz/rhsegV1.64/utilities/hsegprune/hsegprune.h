#ifndef HSEGPRUNE_H
#define HSEGPRUNE_H

#include <defines.h>

using namespace std;

namespace HSEGTilton
{
    // Global function definitions
    bool hsegprune();

} // HSEGTilton

#endif // HSEGPRUNE_H
