/*-----------------------------------------------------------
|
|  Routine Name: hsegprune - Program to prune an image segmentation hierarchy
|
|       Purpose: Main function for the hsegprune program
|
|         Input: 
|
|        Output: 
|
|       Returns: TRUE (1) on success, FALSE (0) on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: November 12, 2014
| Modifications: December 1, 2014 - Added optional output of standard deviation (std_dev) and boundary pixel ratio (bp_ratio) images.
|
------------------------------------------------------------*/

#include "hsegprune.h"
#include "params/initialParams.h"
#include "params/params.h"
#include <region/region_class.h>
#include <region/region_object.h>
#include <results/results.h>
#include <iostream>
#include <algorithm>

extern HSEGTilton::InitialParams initialParams;
extern HSEGTilton::Params params;
extern HSEGTilton::oParams oparams;

namespace HSEGTilton
{

  bool hsegprune()
  {
    initialParams.print();
//    initialParams.print_oparam();

    if ((initialParams.prune_option == 2) && (oparams.level0_nb_objects == 0))
    {
      cout << "ERROR: HSeg/RHSeg output does not include region object information" << endl;
      cout << "Rerun HSeg/RHSeg requesting that this information be included in the HSeg/RHSeg output" << endl;
      return false;
    }

    if (params.region_std_dev_flag)
    {
      int prune_segLevel;
      int nb_classes = oparams.level0_nb_classes;
      RegionClass::set_static_vals();
      unsigned int region_classes_size = nb_classes;
      vector<RegionClass> level0_region_classes(region_classes_size);
      vector<RegionClass> region_classes(region_classes_size);

      int nb_objects = oparams.level0_nb_objects;
      if (nb_objects == 0)
        nb_objects = 1;
      RegionObject::set_static_vals(false,false);
      unsigned int region_objects_size = nb_objects;
      vector<RegionObject> level0_region_objects(region_objects_size);
      vector<RegionObject> region_objects(region_objects_size);
      nb_objects = oparams.level0_nb_objects;

     // Read in region_objects information at hierarchical level 0
cout << "Reading in region_classes and region_objects information at hierarchical level 0" << endl;
      int segLevel = 0;
      Results results_data;
      results_data.set_buffer_sizes(params.nbands,nb_classes,nb_objects);
      results_data.open_input(params.region_classes_file,params.region_objects_file);
      results_data.read(segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,level0_region_classes,level0_region_objects);
      results_data.close_input();
cout << "Read in region labels map information (region_classes or region_objects, as appropriate) at hierarchical level 0" << endl;
      GDALDataset    *labelsInDataset, *maskDataset = NULL;
      GDALDriver     *driver;
      GDALRasterBand *labelsInBand,    *maskBand = NULL;

      GDALDataset    *pruneNpixDataset, *pruneLabelsMapDataset, *pruneMeanDataset;
      pruneNpixDataset = pruneLabelsMapDataset = pruneMeanDataset = NULL;
      GDALDataset    *pruneStdDevDataset, *pruneBPRatioDataset;
      pruneStdDevDataset = pruneBPRatioDataset = NULL;
      GDALRasterBand *pruneNpixBand, *pruneLabelsMapBand, *pruneMeanBand, *pruneStdDevBand, *pruneBPRatioBand;
      GDALRasterBand *tempRasterBand;
      char **papszOptions = NULL;
        
      if (initialParams.prune_option == 1)
        labelsInDataset = (GDALDataset *)GDALOpen(params.class_labels_map_file.c_str(), GA_ReadOnly);
      else
        labelsInDataset = (GDALDataset *)GDALOpen(params.object_labels_map_file.c_str(), GA_ReadOnly);
      driver = labelsInDataset->GetDriver();
      labelsInBand = labelsInDataset->GetRasterBand(1);
      int data_size = params.ncols*params.nrows;
      unsigned int *level0_labels_map = new unsigned int[data_size];
      unsigned int *segLevel_labels_map = new unsigned int[data_size];
      unsigned int *prune_labels_map = new unsigned int[data_size];
      unsigned int *prune_hlevel = new unsigned int[data_size];
      unsigned char *mask = NULL;
      unsigned int *prune_npix = NULL;
      float *prune_mean = NULL;
      float *prune_std_dev = NULL;
      float *prune_bp_ratio = NULL;
      labelsInBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,level0_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
      GDALClose( (GDALDatasetH) labelsInDataset);
      if (params.mask_flag)
      {
        mask = new unsigned char[data_size];
        maskDataset = (GDALDataset *)GDALOpen(params.mask_file.c_str(), GA_ReadOnly);
        maskBand = maskDataset->GetRasterBand(1);
        maskBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,mask,params.ncols,params.nrows,GDT_Byte,0,0);
        GDALClose( (GDALDatasetH) maskDataset);
      }
      if (initialParams.prune_npix_flag)
        prune_npix = new unsigned int[data_size];
      if (initialParams.prune_mean_flag)
        prune_mean = new float[params.nbands*data_size];
      if (initialParams.prune_std_dev_flag)
        prune_std_dev = new float[data_size];
      if (initialParams.prune_bp_ratio_flag)
        prune_bp_ratio = new float[data_size];
      int index, band;
      for (index = 0; index < data_size; index++)
      {
        prune_labels_map[index] = 0;
        prune_hlevel[index] = oparams.nb_levels;
        if (initialParams.prune_npix_flag)
          prune_npix[index] = 0;
        if (initialParams.prune_mean_flag)
        {
          for (band = 0; band < params.nbands; band++)
            prune_mean[band + index*params.nbands] = 0.0;
        }
        if (initialParams.prune_std_dev_flag)
          prune_std_dev[index] = 0.0;
        if (initialParams.prune_bp_ratio_flag)
          prune_bp_ratio[index] = 0.0;
      }

      unsigned int region_index, region_label, region_npix, heap_index;
      int class_heap_size, object_heap_size;
      unsigned int region_boundary_npix;
      vector <unsigned int> region_hlevel_label;
      vector <unsigned int> region_hlevel_npix;
      vector <float> region_hlevel_bp_ratio, region_hlevel_std_dev;
      vector <float> region_hlevel_mean;
      vector<RegionClass *> class_heap;
      vector<RegionObject *> object_heap;
      region_hlevel_label.resize(oparams.nb_levels);
      region_hlevel_npix.resize(oparams.nb_levels);
      region_hlevel_bp_ratio.resize(oparams.nb_levels);
      region_hlevel_std_dev.resize(oparams.nb_levels);
      region_hlevel_mean.resize(oparams.nb_levels*params.nbands);

      class_heap_size = nb_classes+1; // Put these two lines here to avoid unititialized compile warnings
      object_heap_size = nb_objects+1;
      if (initialParams.prune_option == 1)
      {
        class_heap.resize(class_heap_size);
        heap_index = 0;
        for (region_index = 0; region_index < region_classes_size; ++region_index)
          if (level0_region_classes[region_index].get_active_flag())
            class_heap[heap_index++] = &level0_region_classes[region_index];
        class_heap[--class_heap_size] = NULL;
        make_heap(&class_heap[0],&class_heap[class_heap_size],ClassNpixMoreThan());
        region_hlevel_label[0] = class_heap[0]->get_label();
      }
      else
      {
        object_heap.resize(object_heap_size);
        heap_index = 0;
        for (region_index = 0; region_index < region_objects_size; ++region_index)
          if (level0_region_objects[region_index].get_active_flag())
            object_heap[heap_index++] = &level0_region_objects[region_index];
        object_heap[--object_heap_size] = NULL;
        make_heap(&object_heap[0],&object_heap[object_heap_size],ObjectNpixMoreThan());
        region_hlevel_label[0] = object_heap[0]->get_label();
      }

      region_index = region_hlevel_label[0] - 1;
      if (initialParams.prune_option == 1)
        region_npix = level0_region_classes[region_index].get_npix();
      else
        region_npix = level0_region_objects[region_index].get_npix();
      while ((region_index >= 0) && (region_npix >= initialParams.minimum_npix))
      {
        region_index = region_hlevel_label[0] - 1;
        if (initialParams.prune_option == 1)
        {
          region_hlevel_npix[0] = level0_region_classes[region_index].get_npix();
cout << endl << "Largest region class (npix = " << region_hlevel_npix[0] << ") has label " << region_hlevel_label[0] << " at hierarchical level 0" << endl;
          if (params.region_boundary_npix_flag)
          {
            region_boundary_npix = level0_region_classes[region_index].get_boundary_npix();
            region_hlevel_bp_ratio[0] = ((float) region_boundary_npix)/((float) region_hlevel_npix[0]);
          }
          region_hlevel_std_dev[0] = level0_region_classes[region_index].get_std_dev();
          for (band = 0; band < params.nbands; band++)
            region_hlevel_mean[band] = level0_region_classes[region_index].get_unscaled_mean(band);
        }
        else
        {
          region_hlevel_npix[0] = level0_region_objects[region_index].get_npix();
cout << endl << "Largest region object (npix = " << region_hlevel_npix[0] << ") has label " << region_hlevel_label[0] << " at hierarchical level 0" << endl;
          if (params.region_boundary_npix_flag)
          {
            region_boundary_npix = level0_region_objects[region_index].get_boundary_npix();
            region_hlevel_bp_ratio[0] = ((float) region_boundary_npix)/((float) region_hlevel_npix[0]);
          }
          region_hlevel_std_dev[0] = level0_region_objects[region_index].get_std_dev();
          for (band = 0; band < params.nbands; band++)
            region_hlevel_mean[band] = level0_region_objects[region_index].get_unscaled_mean(band);
        }
        results_data.open_input(params.region_classes_file,params.region_objects_file);
        segLevel = 0;
        results_data.read(segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,region_classes,region_objects);
        for (segLevel = 1; segLevel < oparams.nb_levels; segLevel++)
        {
          results_data.read(segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,region_classes,region_objects);
          if (initialParams.prune_option == 1)
          {
            if (region_classes[region_index].get_active_flag())
              region_hlevel_label[segLevel] = region_hlevel_label[segLevel-1];
            else
              region_hlevel_label[segLevel] = region_classes[region_index].get_merge_region_label();
            if (region_hlevel_label[segLevel] > 0)
            {
              region_index = region_hlevel_label[segLevel] - 1;
              region_hlevel_npix[segLevel] = region_classes[region_index].get_npix();
              if (params.region_boundary_npix_flag)
              {
                region_boundary_npix = region_classes[region_index].get_boundary_npix();
                region_hlevel_bp_ratio[segLevel] = ((float) region_boundary_npix)/((float) region_hlevel_npix[segLevel]);
              }
              region_hlevel_std_dev[segLevel] = region_classes[region_index].get_std_dev();
              for (band = 0; band < params.nbands; band++)
                region_hlevel_mean[band + segLevel*params.nbands] = region_classes[region_index].get_unscaled_mean(band);
            }
          }
          else
          {
            if (region_objects[region_index].get_active_flag())
              region_hlevel_label[segLevel] = region_hlevel_label[segLevel-1];
            else
              region_hlevel_label[segLevel] = region_objects[region_index].get_merge_region_label();
            if (region_hlevel_label[segLevel] > 0)
            {
              region_index = region_hlevel_label[segLevel] - 1;
              region_hlevel_npix[segLevel] = region_objects[region_index].get_npix();
              if (params.region_boundary_npix_flag)
              {
                region_boundary_npix = region_objects[region_index].get_boundary_npix();
                region_hlevel_bp_ratio[segLevel] = ((float) region_boundary_npix)/((float) region_hlevel_npix[segLevel]);
              }
              region_hlevel_std_dev[segLevel] = region_objects[region_index].get_std_dev();
              for (band = 0; band < params.nbands; band++)
                region_hlevel_mean[band + segLevel*params.nbands] = region_objects[region_index].get_unscaled_mean(band);
            }
          } // if (region_hlevel_label[segLevel] > 0)
        }
        results_data.close_input();
        prune_segLevel = oparams.nb_levels - 1;
        for (segLevel = 1; segLevel < oparams.nb_levels; segLevel++)
        {
          if (region_hlevel_std_dev[segLevel] > initialParams.std_dev_factor*region_hlevel_std_dev[segLevel-1])
          {
            prune_segLevel = segLevel - 1;
cout << "Do prune at segmentation hierarchy level = " << prune_segLevel << endl;
cout << "because of increase in std_dev (" << region_hlevel_std_dev[segLevel] << " vs. " << region_hlevel_std_dev[segLevel-1] << ")" << endl;
            segLevel = oparams.nb_levels;
          }
          else if ((params.region_boundary_npix_flag) && (region_hlevel_bp_ratio[segLevel] > initialParams.bp_ratio_factor*region_hlevel_bp_ratio[segLevel-1]))
          {
            prune_segLevel = segLevel - 1;
cout << "Do prune at segmentation hierarchy level = " << prune_segLevel << endl;
cout << "because of increase in bp_ratio (" << region_hlevel_bp_ratio[segLevel] << " vs. " << region_hlevel_bp_ratio[segLevel-1] << ")" << endl;
            segLevel = oparams.nb_levels;
          }
/*
          else if (region_hlevel_npix[segLevel] > initialParams.npix_factor*region_hlevel_npix[segLevel-1])
          {
            prune_segLevel = segLevel - 1;
cout << "Do prune at segmentation hierarchy level = " << prune_segLevel << endl;
cout << "because of increase in npix (" << region_hlevel_npix[segLevel] << " vs. " << region_hlevel_npix[segLevel-1] << ")" << endl;
            segLevel = oparams.nb_levels;
          }
*/
        }
if (prune_segLevel == (oparams.nb_levels-1))
  cout << "Do prune at segmentation hierarchy level = " << prune_segLevel << endl;
        if (initialParams.tempDatasets[prune_segLevel] == NULL)
        {
          if (initialParams.prune_option == 1)
            cout << "Need to create class_label_map at hierarchical level = " << prune_segLevel << endl;
          else
            cout << "Need to create object_label_map at hierarchical level = " << prune_segLevel << endl;
          results_data.open_input(params.region_classes_file,params.region_objects_file);
          results_data.read(prune_segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,region_classes,region_objects);
          results_data.close_input();
          for (index = 0; index < data_size; index++)
          {
            region_label = 0;
            if ((!params.mask_flag) || (mask[index]))
            {
              region_label = level0_labels_map[index];
              if (region_label != 0)
              {
                region_index = region_label - 1;
                if (initialParams.prune_option == 1)
                {
                  while (!region_classes[region_index].get_active_flag())
                  {
                    region_label = region_classes[region_index].get_merge_region_label();
                    region_index = region_label - 1;
                  }
                }
                else
                {
                  while (!region_objects[region_index].get_active_flag())
                  {
                    region_label = region_objects[region_index].get_merge_region_label();
                    region_index = region_label - 1;
                  }
                }
              }
            }
            segLevel_labels_map[index] = region_label;
          }
          initialParams.tempDatasets[prune_segLevel] = 
            driver->Create(initialParams.temp_seg_level_label_files[prune_segLevel].c_str(), params.ncols, params.nrows, 1, GDT_UInt32, papszOptions);
	  tempRasterBand = initialParams.tempDatasets[prune_segLevel]->GetRasterBand(1);
          tempRasterBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,segLevel_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
          GDALClose( (GDALDatasetH) initialParams.tempDatasets[prune_segLevel]);
          initialParams.tempDatasets[prune_segLevel] =
             (GDALDataset *)GDALOpen(initialParams.temp_seg_level_label_files[prune_segLevel].c_str(), GA_ReadOnly);
        } // if (initialParams.tempDatasets[prune_segLevel] == NULL)
        tempRasterBand = initialParams.tempDatasets[prune_segLevel]->GetRasterBand(1);
        tempRasterBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,segLevel_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
        region_index = region_hlevel_label[prune_segLevel];
        bool redundant_flag = false;
        int redundant_hlevel, redundant_label;
        redundant_hlevel = oparams.nb_levels;
        redundant_label = 0;
        for (index = 0; index < data_size; index++)
        {
          if ((segLevel_labels_map[index] == region_hlevel_label[prune_segLevel]) && (prune_labels_map[index] != 0))
          {
            redundant_flag = true;
            redundant_label = prune_labels_map[index];
            redundant_hlevel = prune_hlevel[index];
            index = data_size;
          }
        }
        if (redundant_flag)
        {
          cout << "NOTE: Found redundant labeling, with redundant_label = " << redundant_label << endl;
          if (redundant_hlevel == prune_segLevel)
          {
            cout << "Equivalent redundant labeling; skip labeling for this region." << endl;
          }
          else if (redundant_hlevel < prune_segLevel)
          {
            cout << "Need to adjust pruning to segmentation hierarchy level = " << redundant_hlevel << endl;
            prune_segLevel = redundant_hlevel;
            tempRasterBand = initialParams.tempDatasets[prune_segLevel]->GetRasterBand(1);
            tempRasterBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,segLevel_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
            redundant_flag = false;
          }
          else
          {
            cout << "Need to redo the prune of region_hlevel_label = " << redundant_label << " previously performed at" << endl;
            cout << "segmentation hierarchy level = " << redundant_hlevel << " at segmentation hierarchy level = " << prune_segLevel << endl;

            results_data.open_input(params.region_classes_file,params.region_objects_file);
            results_data.read(prune_segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,region_classes,region_objects);
            results_data.close_input();

            for (index = 0; index < data_size; index++)
            {
              if (prune_labels_map[index] == (unsigned int) redundant_label)
              {
                prune_labels_map[index] = 0;
                prune_hlevel[index] = oparams.nb_levels;
                if (initialParams.prune_npix_flag)
                  prune_npix[index] = 0;
                if (initialParams.prune_mean_flag)
                {
                  for (band = 0; band < params.nbands; band++)
                    prune_mean[index + band*data_size] = 0.0;
                }
                if (initialParams.prune_std_dev_flag)
                  prune_std_dev[index] = 0.0;
                if (initialParams.prune_bp_ratio_flag)
                  prune_bp_ratio[index] = 0.0;
              }
            }
            region_label = redundant_label;
            region_index = region_label - 1;
            if (initialParams.prune_option == 1)
            {
              while (!region_classes[region_index].get_active_flag())
              {
                region_label = region_classes[region_index].get_merge_region_label();
                region_index = region_label - 1;
              }
            }
            else
            {
              while (!region_objects[region_index].get_active_flag())
              {
                region_label = region_objects[region_index].get_merge_region_label();
                region_index = region_label - 1;
              }
            }
//cout << "At prune_segLevel = " << prune_segLevel << ", redundant_label = " << redundant_label << " becomes region_label = " << region_label << endl;
            for (index = 0; index < data_size; index++)
            {
              if (segLevel_labels_map[index] == region_label)
              {
                prune_labels_map[index] = redundant_label;
                prune_hlevel[index] = prune_segLevel;
                if (initialParams.prune_option == 1)
                {
                  if (initialParams.prune_npix_flag)
                    prune_npix[index] = region_classes[region_index].get_npix();
                  if (initialParams.prune_mean_flag)
                  {
                    for (band = 0; band < params.nbands; band++)
                      prune_mean[index + band*data_size] = region_classes[region_index].get_unscaled_mean(band);
                  }
                  if (initialParams.prune_std_dev_flag)
                    prune_std_dev[index] = region_classes[region_index].get_std_dev();
                  if (initialParams.prune_bp_ratio_flag)
                    prune_bp_ratio[index] = ((float) region_classes[region_index].get_boundary_npix())/((float) region_classes[region_index].get_npix());
                }
                else
                {
                  if (initialParams.prune_npix_flag)
                    prune_npix[index] = region_objects[region_index].get_npix();
                  if (initialParams.prune_mean_flag)
                  {
                    for (band = 0; band < params.nbands; band++)
                      prune_mean[index + band*data_size] = region_objects[region_index].get_unscaled_mean(band);
                  }
                  if (initialParams.prune_std_dev_flag)
                    prune_std_dev[index] = region_objects[region_index].get_std_dev();
                  if (initialParams.prune_bp_ratio_flag)
                    prune_bp_ratio[index] = ((float) region_objects[region_index].get_boundary_npix())/((float) region_objects[region_index].get_npix());
                }
              }
            }
            redundant_flag = false;  
          }
        }
        if (!redundant_flag)
        {
          for (index = 0; index < data_size; index++)
          {
            if (segLevel_labels_map[index] == region_hlevel_label[prune_segLevel])
            {
//              prune_labels_map[index] = region_hlevel_label[prune_segLevel];  // Use label at segLevel = 0 instead!!
              prune_labels_map[index] = region_hlevel_label[0];
              prune_hlevel[index] = prune_segLevel;
              if (initialParams.prune_npix_flag)
                prune_npix[index] = region_hlevel_npix[prune_segLevel];
              if (initialParams.prune_mean_flag)
              {
                for (band = 0; band < params.nbands; band++)
                  prune_mean[index + band*data_size] = region_hlevel_mean[band + prune_segLevel*params.nbands];
              }
              if (initialParams.prune_std_dev_flag)
                prune_std_dev[index] = region_hlevel_std_dev[prune_segLevel];
              if (initialParams.prune_bp_ratio_flag)
                prune_bp_ratio[index] = region_hlevel_bp_ratio[prune_segLevel];
            }
          }
        }
        if (initialParams.prune_option == 1)
        {
          pop_heap(&class_heap[0],&class_heap[class_heap_size--],ClassNpixMoreThan());
          region_hlevel_label[0] = class_heap[0]->get_label();
        }
        else
        {
          pop_heap(&object_heap[0],&object_heap[object_heap_size--],ObjectNpixMoreThan());
          region_hlevel_label[0] = object_heap[0]->get_label();
        }
        region_index = region_hlevel_label[0] - 1;
        if (initialParams.prune_option == 1)
          region_npix = level0_region_classes[region_index].get_npix();
        else
          region_npix = level0_region_objects[region_index].get_npix();
      } // while ((region_index >= 0) && (region_npix >= initialParams.minimum_npix))
    // Just copy values at hierarchical level 0 for small regions not previously labeled
      for (index = 0; index < data_size; index++)
      {
        if ((prune_labels_map[index] == 0) && (level0_labels_map[index] != 0))
        {
          region_hlevel_label[0] = level0_labels_map[index];
          region_index = region_hlevel_label[0] - 1;
          if (initialParams.prune_option == 1)
          {
            region_hlevel_npix[0] = level0_region_classes[region_index].get_npix();
            if (params.region_boundary_npix_flag)
            {
              region_boundary_npix = level0_region_classes[region_index].get_boundary_npix();
              region_hlevel_bp_ratio[0] = ((float) region_boundary_npix)/((float) region_hlevel_npix[0]);
            }
            region_hlevel_std_dev[0] = level0_region_classes[region_index].get_std_dev();
            for (band = 0; band < params.nbands; band++)
              region_hlevel_mean[band] = level0_region_classes[region_index].get_unscaled_mean(band);
          }
          else
          {
            region_hlevel_npix[0] = level0_region_objects[region_index].get_npix();
            if (params.region_boundary_npix_flag)
            {
              region_boundary_npix = level0_region_objects[region_index].get_boundary_npix();
              region_hlevel_bp_ratio[0] = ((float) region_boundary_npix)/((float) region_hlevel_npix[0]);
            }
            region_hlevel_std_dev[0] = level0_region_objects[region_index].get_std_dev();
            for (band = 0; band < params.nbands; band++)
              region_hlevel_mean[band] = level0_region_objects[region_index].get_unscaled_mean(band);
          }
          prune_labels_map[index] = region_hlevel_label[0];
          prune_hlevel[index] = 0;
          if (initialParams.prune_npix_flag)
            prune_npix[index] = region_hlevel_npix[0];
          if (initialParams.prune_mean_flag)
          {
            for (band = 0; band < params.nbands; band++)
              prune_mean[index + band*data_size] = region_hlevel_mean[band];
          }
          if (initialParams.prune_std_dev_flag)
            prune_std_dev[index] = region_hlevel_std_dev[0];
          if (initialParams.prune_bp_ratio_flag)
            prune_bp_ratio[index] = region_hlevel_bp_ratio[0];
        }
      }

      pruneLabelsMapDataset =  driver->Create(initialParams.prune_labels_map_file.c_str(), params.ncols, params.nrows, 1, GDT_UInt32, papszOptions);
      pruneLabelsMapBand = pruneLabelsMapDataset->GetRasterBand(1);
      pruneLabelsMapBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,prune_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
      if (initialParams.prune_npix_flag)
      {
        pruneNpixDataset = driver->Create(initialParams.prune_npix_file.c_str(), params.ncols, params.nrows, 1, GDT_UInt32, papszOptions);
        pruneNpixBand = pruneNpixDataset->GetRasterBand(1);
        pruneNpixBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,prune_npix,params.ncols,params.nrows,GDT_UInt32,0,0);
      }
      if (initialParams.prune_mean_flag)
      {
        pruneMeanDataset =  driver->Create(initialParams.prune_mean_file.c_str(), params.ncols, params.nrows, params.nbands, GDT_Float32, papszOptions);
        for (band = 0; band < params.nbands; band++)
        {
          pruneMeanBand = pruneMeanDataset->GetRasterBand(band+1);
   	  pruneMeanBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,&prune_mean[band*data_size],params.ncols,params.nrows,GDT_Float32,0,0);
        }
      }
      if (initialParams.prune_std_dev_flag)
      {
        pruneStdDevDataset = driver->Create(initialParams.prune_std_dev_file.c_str(), params.ncols, params.nrows, 1, GDT_Float32, papszOptions);
        pruneStdDevBand = pruneStdDevDataset->GetRasterBand(1);
        pruneStdDevBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,prune_std_dev,params.ncols,params.nrows,GDT_Float32,0,0);
      }
      if (initialParams.prune_bp_ratio_flag)
      {
        pruneBPRatioDataset = driver->Create(initialParams.prune_bp_ratio_file.c_str(), params.ncols, params.nrows, 1, GDT_Float32, papszOptions);
        pruneBPRatioBand = pruneBPRatioDataset->GetRasterBand(1);
        pruneBPRatioBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,prune_bp_ratio,params.ncols,params.nrows,GDT_Float32,0,0);
      }
      for (segLevel = 0; segLevel < oparams.nb_levels; segLevel++)
        if (initialParams.tempDatasets[segLevel] != NULL)
          GDALClose( (GDALDatasetH) initialParams.tempDatasets[segLevel]);
      if (pruneLabelsMapDataset != NULL)
        GDALClose( (GDALDatasetH) pruneLabelsMapDataset);
      if (pruneNpixDataset != NULL)
        GDALClose( (GDALDatasetH) pruneNpixDataset);
      if (pruneMeanDataset != NULL)
        GDALClose( (GDALDatasetH) pruneMeanDataset);
      if (pruneStdDevDataset != NULL)
        GDALClose( (GDALDatasetH) pruneStdDevDataset);
      if (pruneBPRatioDataset != NULL)
        GDALClose( (GDALDatasetH) pruneBPRatioDataset);
    }
    else
    {
      cout << "ERROR: HSeg/RHSeg output does not include region standard deviation information" << endl;
      cout << "Rerun HSeg/RHSeg requesting that this information be included in the HSeg/RHSeg output" << endl;
      return false;
    }

    return true;
  }

} // namespace HSEGTilton

