#ifndef HSEGSIZEOBJ_H
#define HSEGSIZEOBJ_H

#include <defines.h>
#include <region/region_class.h>
#include <region/region_object.h>
#include <results/results.h>

using namespace std;

namespace HSEGTilton
{
    // Global function definitions
    bool hsegsizeobj();
    void sizeobj();

} // HSEGTilton

#endif // HSEGSIZEOBJ_H
