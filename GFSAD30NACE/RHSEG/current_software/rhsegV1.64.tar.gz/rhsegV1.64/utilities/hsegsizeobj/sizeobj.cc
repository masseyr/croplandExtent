#include "params/initialParams.h"
#include "params/params.h"
#include <region/region_class.h>
#include <region/region_object.h>
#include <results/results.h>
#include "gdal_priv.h"
#include "cpl_conv.h" 
#include <string>
#include <iostream>

using namespace std;

extern HSEGTilton::InitialParams initialParams;
extern HSEGTilton::Params params;
extern HSEGTilton::oParams oparams;

namespace HSEGTilton
{
  void sizeobj() 
  {
        int nb_classes = oparams.level0_nb_classes;
        RegionClass::set_static_vals();
        int region_classes_size = nb_classes;
        vector<RegionClass> region_classes(region_classes_size);

        int nb_objects = 1;
        if (params.region_nb_objects_flag)
          nb_objects = oparams.level0_nb_objects;
        RegionObject::set_static_vals(false,false);
        int region_objects_size = nb_objects;
        vector<RegionObject> region_objects(region_objects_size);
        if (!params.region_nb_objects_flag)
          nb_objects = 0;

        Results results_data;
        results_data.set_buffer_sizes(params.nbands,nb_classes,nb_objects);
        results_data.open_input(params.region_classes_file,params.region_objects_file);

        unsigned int region_label, region_index, region_npix;

        GDALDataset    *objInDataset, *maskDataset;
        GDALDriver     *driver;
        GDALRasterBand *objInBand,    *maskBand;
        
        objInDataset = (GDALDataset *)GDALOpen(params.object_labels_map_file.c_str(), GA_ReadOnly);
        maskDataset = (GDALDataset *)GDALOpen(params.mask_file.c_str(), GA_ReadOnly);
        driver = objInDataset->GetDriver();
	
	unsigned int xsize = objInDataset->GetRasterXSize();
	unsigned int ysize = objInDataset->GetRasterYSize();
	unsigned int size = xsize*ysize;
	int i;
	unsigned int j;
	/*size thresholds*/
	const unsigned int sizethres1 = 500;
	const unsigned int sizethres2 = 5000;
	const unsigned int sizethres3 = 50000;
	const unsigned int sizethres4 = 500000;
	
	/*read object_labels_map */
	objInBand = objInDataset->GetRasterBand(1);
	unsigned int *object_labels_map = new unsigned int[size];
        objInBand->RasterIO(GF_Read,0,0,xsize,ysize,&object_labels_map[0],xsize,ysize,GDT_UInt32,0,0);

	/*read mask band*/
	maskBand = maskDataset->GetRasterBand(1);
	unsigned char *mask = new unsigned char[size];
        maskBand->RasterIO(GF_Read,0,0,xsize,ysize,&mask[0],xsize,ysize,GDT_Byte,0,0);

    /*set up buffer*/
        unsigned int **sobj = new unsigned int*[4];
	unsigned int **sobjnpix = new unsigned int*[4];
        sobj[0] = new unsigned int[size];
        sobj[1] = new unsigned int[size];
        sobj[2] = new unsigned int[size];
        sobj[3] = new unsigned int[size];
        sobjnpix[0] = new unsigned int[size];
        sobjnpix[1] = new unsigned int[size];
        sobjnpix[2] = new unsigned int[size];
        sobjnpix[3] = new unsigned int[size];
        for (j=0;j<size;j++) 
        {
		if (mask[j] == 0) 
                {
			sobj[0][j] = 0;
			sobjnpix[0][j] = 0;
			sobj[1][j] = 0;
			sobjnpix[1][j] = 0;
			sobj[2][j] = 0;
			sobjnpix[2][j] = 0;
			sobj[3][j] = 0;
			sobjnpix[3][j] = 0;
		}
	}
        for (i=0;i<oparams.nb_levels;i++)
        {
cout << "Processing hierarchical level " << i<< endl;
            results_data.read(i,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,region_classes,region_objects);
            if (i == 0) 
            {
	        for (j=0;j<size;j++) 
                {
                        region_label = object_labels_map[j];
                        if (region_label != 0)
                        {
                          region_index = region_label - 1;
                          region_npix = region_objects[region_index].get_npix();
                        }
                        else
                          region_npix = 0;
        		if (mask[j] == 1) 
                        {
				sobj[0][j] = region_label;
				sobjnpix[0][j] = region_npix;
				sobj[1][j] = region_label;
				sobjnpix[1][j] = region_npix;
				sobj[2][j] = region_label;
				sobjnpix[2][j] = region_npix;
				sobj[3][j] = region_label;
				sobjnpix[3][j] = region_npix;
			}
		}
	    }
	    else 
            {
		for (j=0;j<size;j++) 
                {
                        region_label = object_labels_map[j];
                        if (region_label != 0)
                        {
                          region_index = region_label - 1;
                          if (!region_objects[region_index].get_active_flag())
                          {
                            region_label = region_objects[region_index].get_merge_region_label();
                            object_labels_map[j] = region_label;
                            region_index = region_label - 1;
                          }
                          if (!region_objects[region_index].get_active_flag())
                          { 
                            region_label = 0;
                            region_npix = 0;
                            cout << "WARNING: Found inactive region for j = " << j << " and i = " << i << endl;
                          }
                          if (region_label != 0)
                          {
                            region_index = region_label - 1;
                            region_npix = region_objects[region_index].get_npix();
                          }
                          else
                          { 
                            region_npix = 0;
                            cout << "WARNING: Found region_label = 0 for j = " << j << " and i = " << i << endl;
                          }
                        }
                        else
                          region_npix = 0;
        		if (mask[j] == 1) 
                        {
					if (region_npix<=sizethres1) 
                                        {
						sobj[0][j] = region_label;
						sobjnpix[0][j] = region_npix;
					}
					if (region_npix<=sizethres2) 
                                        {
						sobj[1][j] = region_label;
						sobjnpix[1][j] = region_npix;
					}
					if (region_npix<=sizethres3) 
                                        {						
						sobj[2][j] = region_label;
						sobjnpix[2][j] = region_npix;
					}
					if (region_npix<=sizethres4) 
                                        {						
						sobj[3][j] = region_label;
						sobjnpix[3][j] = region_npix;
					}
			}
		}
	    }
	    printf("%d->",i);
        }
        results_data.close_input();

        GDALClose( (GDALDatasetH) objInDataset);
        GDALClose( (GDALDatasetH) maskDataset);
	
        GDALDataset    *npixOutDataset, *objOutDataset;
        GDALRasterBand *npixOutBand,    *objOutBand;
        char **papszOptions = NULL;
        npixOutDataset = driver->Create(initialParams.sizenpix_file.c_str(), xsize, ysize, 4, GDT_UInt32, papszOptions);
        objOutDataset =  driver->Create(initialParams.sizeobj_file.c_str(), xsize, ysize, 4, GDT_UInt32, papszOptions);

	for(i=0;i<4;i++)
        {
		objOutBand = objOutDataset->GetRasterBand(i+1);
		objOutBand->RasterIO(GF_Write,0,0,xsize,ysize,sobj[i],xsize,ysize,GDT_UInt32,0,0);
	}
        GDALClose( (GDALDatasetH) objOutDataset);
	
	for(i=0;i<4;i++)
        {
		npixOutBand = npixOutDataset->GetRasterBand(i+1);
		npixOutBand->RasterIO(GF_Write,0,0,xsize,ysize,sobjnpix[i],xsize,ysize,GDT_UInt32,0,0);
	}
        GDALClose( (GDALDatasetH) npixOutDataset);
	printf("\n");
	return; 
  }
} // namespace HSEGTilton
