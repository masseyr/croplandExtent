// counts.cc

#include "counts.h"
#include <iostream>

namespace HSEGTilton
{

 // Constructors
  SampleCounts::SampleCounts()
  {
    count = 0;
    return;
  }

  SampleCounts::SampleCounts(int& field_value, int& region_value)
  {
    field_label = field_value;
    count = 1;
    object_label_count.insert(make_pair(region_value,count));
    return;
  }

 // Destructor...
  SampleCounts::~SampleCounts() 
  {
    object_label_count.clear();
    return;
  }

  void SampleCounts::operator =(const SampleCounts& source)
  {

    if (this == &source)
      return;
 
  // Copy member variables
    field_label = source.field_label;
    count = source.count;
    object_label_count_copy(source);

    return;
  }

  void SampleCounts::clear()
  {
    field_label = 0;
    count = 0;
    object_label_count.clear();
  }

  void SampleCounts::add_object(int& region_value)
  {
    int region_count;
    map<int, int>::iterator object_label_count_iter;

    object_label_count_iter = object_label_count.begin();
    bool found_flag = false;
    while ((!found_flag) && (object_label_count_iter != object_label_count.end()))
    {
      if ((*object_label_count_iter).first == region_value)
      {
        region_count = (*object_label_count_iter).second;
        region_count++;
        (*object_label_count_iter).second = region_count;
        found_flag = true;
      }
      ++object_label_count_iter;
    }
    if (!found_flag)
    {
      region_count = 1;
      object_label_count.insert(make_pair(region_value,region_count));
    }

    count++;

    return;
  }

  void SampleCounts::object_label_count_copy(const SampleCounts& source)
  {
    object_label_count.clear( );
    if (!source.object_label_count.empty( ))
    {
      map<int, int>::const_iterator object_label_count_iter;
      object_label_count_iter = source.object_label_count.begin();
      while (object_label_count_iter != source.object_label_count.end())
      {
        object_label_count.insert(make_pair((*object_label_count_iter).first,(*object_label_count_iter).second));
        ++object_label_count_iter;
      }
    }

    return;
  }



} // namespace HSEGTilton
