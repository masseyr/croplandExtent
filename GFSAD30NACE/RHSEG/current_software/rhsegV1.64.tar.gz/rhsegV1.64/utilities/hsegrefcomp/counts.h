#ifndef COUNTS_H
#define COUNTS_H

#include <map>

using namespace std;

namespace HSEGTilton
{

  class SampleCounts 
  {
    public:
    // Constructor and Destructor
      SampleCounts();
      SampleCounts(int& field_value, int& region_value);
      virtual ~SampleCounts();

    // Member functions
      void operator =(const SampleCounts& source);
      void clear();
      int get_field_label() const { return field_label; }
      int get_count() const { return count; }
      void add_object(int& region_value);
      void object_label_count_copy(const SampleCounts& source);

    // Member variables (public)
      map<int, int> object_label_count;

    protected:

    private:
      int field_label;
      int count;

  };

} // HSEGTilton

#endif /* COUNTS_H */
