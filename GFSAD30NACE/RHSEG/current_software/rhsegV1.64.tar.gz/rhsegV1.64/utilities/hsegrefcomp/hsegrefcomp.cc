/*-----------------------------------------------------------
|
|  Routine Name: hsegrefcomp - Find RHSeg hierarchical level in which the region objects best
|                              correspond to an input field samples file
|
|       Purpose: Main function for the hsegrefcomp program
|
|         Input: 
|
|        Output: 
|
|       Returns: TRUE (1) on success, FALSE (0) on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: March 22, 2017
| Modifications: 
|
------------------------------------------------------------*/

#include "hsegrefcomp.h"
#include "counts.h"
#include "params/initialParams.h"
#include <params/params.h>
#include <iostream>

extern HSEGTilton::InitialParams initialParams;
extern HSEGTilton::Params params;
extern HSEGTilton::oParams oparams;
extern Image trainingSamplesImage;

namespace HSEGTilton
{
  bool hsegrefcomp()
  {
    initialParams.print();

    Image RHSEGLabelImage;
    if (params.object_labels_map_flag)
    {
      RHSEGLabelImage.open(params.object_labels_map_file);
      if (!RHSEGLabelImage.info_valid())
      {
        cout << "ERROR: " << params.object_labels_map_file << " is not a valid object labels map image file" << endl;
        cout << "Exiting with status = false" << endl;
        return EXIT_FAILURE;
      }
    }
    else
    {
      cout << "ERROR: Must have a valid object labels map image file (in .oparam) as input" << endl;
      cout << "Exiting with status = false" << endl;
      return EXIT_FAILURE;
    }
//    RHSEGLabelImage.print_info();

    int ncols = trainingSamplesImage.get_ncols();
    int nrows = trainingSamplesImage.get_nrows();

    if ((ncols != RHSEGLabelImage.get_ncols()) || (nrows != RHSEGLabelImage.get_nrows()))
    {
      cout << "ERROR: Image size mismatch between pixelClass image and regionSeg image" << endl;
      return false;
    }

    Image segLevelLabelImage;
    segLevelLabelImage.create(initialParams.temp_seg_level_label_file, RHSEGLabelImage,
                              1, RHSEGLabelImage.get_data_type(), "GTiff");
    segLevelLabelImage.registered_data_copy(0,RHSEGLabelImage,0);
    segLevelLabelImage.flush_data();
    segLevelLabelImage.computeMinMax();
//    segLevelLabelImage.print_info();

    int nb_classes = oparams.level0_nb_classes;
    RegionClass::set_static_vals();
    int region_classes_size = nb_classes;
    vector<RegionClass> region_classes(region_classes_size);

    int nb_objects = 1;
    if (params.region_nb_objects_flag)
      nb_objects = oparams.level0_nb_objects;
    RegionObject::set_static_vals(false,false);
    int region_objects_size = nb_objects;
    vector<RegionObject> region_objects(region_objects_size);
    if (!params.region_nb_objects_flag)
      nb_objects = 0;

    Results results_data;
    results_data.set_buffer_sizes(params.nbands,nb_classes,nb_objects);
    results_data.open_input(params.region_classes_file,params.region_objects_file);

    int segLevel, regionSeg_value, fieldSample_value;
    int col, row;
    SampleCounts *sample_count_ptr;
    set<SampleCounts *> sample_count_set;
    set<SampleCounts *>::iterator sample_count_iter;
    params.log_fs << "h_level, classes, objects, mg_thresh, sample_label, sample_pixels, object_label, object_pixels, overlap_pixels, error_rate" << endl;
    for (segLevel = 0; segLevel < oparams.nb_levels; segLevel++)
    {
      results_data.read(segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,region_classes,region_objects);

      if (segLevel > 0)
        set_segLevelLabel(ncols,nrows,segLevel,region_classes,region_objects,RHSEGLabelImage,segLevelLabelImage);

      sample_count_set.clear();
      for (row = 0; row < nrows; row++)
      {
        for (col = 0; col < ncols; col++)
        {
          fieldSample_value = (int) trainingSamplesImage.get_data(col,row,0);
          if (fieldSample_value > 0)
          {
            regionSeg_value = (int) segLevelLabelImage.get_data(col,row,0);

            if (sample_count_set.empty())
            {
              SampleCounts *sample_count = new SampleCounts(fieldSample_value,regionSeg_value);
              sample_count_set.insert(sample_count);
            }
            else
            {
              sample_count_iter = sample_count_set.begin();
              bool found_flag = false;
              while ((!found_flag) && (sample_count_iter != sample_count_set.end()))
              {
                sample_count_ptr = *sample_count_iter;
                if (sample_count_ptr->get_field_label() == fieldSample_value)
                {
                  sample_count_ptr->add_object(regionSeg_value);
                  found_flag = true;
                }
                ++sample_count_iter;
              }
              if (!found_flag)
              {
                SampleCounts *sample_count = new SampleCounts(fieldSample_value,regionSeg_value);
                sample_count_set.insert(sample_count);
              }
            }
          }
        }
      }

      map<int, int>::iterator object_label_count_iter;
      int region_index;
      int max_object_label, max_intersect_pixels;
      float error_rate;
//      params.log_fs << endl << "At hierarchical level = " << segLevel << ", # region classes = " << nb_classes << endl;
//      if (params.region_nb_objects_flag)
//        params.log_fs << "# region objects = " << nb_objects << " and maximum merging threshold = " << oparams.max_threshold[segLevel] << endl; 
      sample_count_iter = sample_count_set.begin();
      while (sample_count_iter != sample_count_set.end())
      {
        max_intersect_pixels = 0;
        max_object_label = 0;
        sample_count_ptr = *sample_count_iter;
//        params.log_fs << "For Field Sample Label = " << sample_count_ptr->get_field_label();
//        params.log_fs << ", #pixels = " << sample_count_ptr->get_count() << endl;
        object_label_count_iter = sample_count_ptr->object_label_count.begin();
        while (object_label_count_iter != sample_count_ptr->object_label_count.end())
        {
          if ((*object_label_count_iter).second > max_intersect_pixels)
          {
             max_intersect_pixels = (*object_label_count_iter).second;
             max_object_label = (*object_label_count_iter).first;
          }
//          params.log_fs << "    For region object label = " << (*object_label_count_iter).first;
//          params.log_fs << " number of intersecting pixels = " << (*object_label_count_iter).second;
          if (params.region_nb_objects_flag)
          {
            region_index = (*object_label_count_iter).first - 1;
//            params.log_fs << " out of a total # pixels = " << region_objects[region_index].get_npix() << endl;
          }
          ++object_label_count_iter;
        }
//        params.log_fs << " Label of largest intersecting region object is " << max_object_label;
        region_index = max_object_label - 1;
        error_rate = (sample_count_ptr->get_count() - max_intersect_pixels) + (region_objects[region_index].get_npix() - max_intersect_pixels);
        error_rate = error_rate/((float)(sample_count_ptr->get_count() + region_objects[region_index].get_npix()));
//        params.log_fs << " with error rate = " << error_rate << endl;
        params.log_fs << segLevel << ", " << nb_classes << ", " << nb_objects << ", " << oparams.max_threshold[segLevel] << ", ";
        params.log_fs << sample_count_ptr->get_field_label() << ", " << sample_count_ptr->get_count() << ", " << max_object_label << ", ";
        params.log_fs << region_objects[region_index].get_npix() << ", " << max_intersect_pixels << ", " << error_rate << endl;

        ++sample_count_iter;
      }
      
// Short out the loop...
//segLevel = oparams.nb_levels;
    } // for (segLevel = 0; segLevel < oparams.nb_levels; segLevel++)
    results_data.close_input( );

    RHSEGLabelImage.close();

    segLevelLabelImage.close();

    return true;
  }

  void set_segLevelLabel(const int& ncols, const int& nrows, const int& segLevel,
                         vector<RegionClass>& region_classes, vector<RegionObject>& region_objects,
                         Image& RHSEGLabelImage, Image& segLevelLabelImage)
  {
    int col, row, region_label, region_index;

    if (params.region_nb_objects_flag)
    {
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          region_label = (int) RHSEGLabelImage.get_data(col,row,0);
          if ((segLevel > 0) && (region_label > 0))
          {
            region_index = region_label - 1;
            if (!region_objects[region_index].get_active_flag())
              region_label = region_objects[region_index].get_merge_region_label();
          }
          segLevelLabelImage.put_data(region_label,col,row,0);
        }
      segLevelLabelImage.flush_data();
    }
    else
    {
      for (row = 0; row < nrows; row++)
        for (col = 0; col < ncols; col++)
        {
          region_label = (int) RHSEGLabelImage.get_data(col,row,0);
          if ((segLevel > 0) && (region_label > 0))
          {
            region_index = region_label - 1;
            if (!region_classes[region_index].get_active_flag())
              region_label = region_classes[region_index].get_merge_region_label();
          }
          segLevelLabelImage.put_data(region_label,col,row,0);
        }
      segLevelLabelImage.flush_data();
    }

    return;
  }

} // namespace HSEGTilton

