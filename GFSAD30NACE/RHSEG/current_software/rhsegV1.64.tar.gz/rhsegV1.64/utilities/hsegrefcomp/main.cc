/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the hsegrefcomp program
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>    Written By: James C. Tilton, NASA GSFC, Mail Code 606.3, Greenbelt, MD 20771
   >>>>                James.C.Tilton@nasa.gov
   >>>>
   >>>>       Written: March 22, 2017
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include <defines.h>
#include "hsegrefcomp.h"
#include "params/initialParams.h"
#include <params/params.h>
#include <image/image.h>
#include <gdal_priv.h>
#include <iostream>
#include <fstream>

using namespace std;
using namespace CommonTilton;
using namespace HSEGTilton;

// Globals
InitialParams initialParams;
Params params("Version 1.64, March 22, 2017");
oParams oparams;

// Externals
extern Image pixelClassImage;
extern Image trainingSamplesImage;

// Forward function declarations
void usage();
void help();

int main(int argc, char *argv[])
{
  bool status;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: hsegrefcomp -h or hsegrefcomp -help" << endl << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_FAILURE;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = initialParams.read(argv[1]);
      if (status)
      {
        params.log_fs.open(initialParams.log_file.c_str(),ios_base::out);
        status = params.log_fs.is_open();
      }
      else
      {
        usage();
        cout << "ERROR: Error reading parameter file (initialParams.read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
// Call hsegrefcomp function
    status = hsegrefcomp();
  }

  trainingSamplesImage.close();
  initialParams.remove_temp_files();
  params.log_fs.close();

  if (status)
  {
    cout << endl << "Successful completion of hsegrefcomp program" << endl;
  }
  else
  {
    cout << endl << "The hsegrefcomp program terminated improperly." << endl;
  }
  
  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

void usage() // Informs user of proper usage of program when mis-used.
{
    cout << endl << "Usage: " << endl << endl;
    cout << "hsegrefcomp parameter_file_name" << endl << endl;
    cout << "For help information: hsegrefcomp -h or hsegrefcomp -help" << endl;
    cout << "For version information: hsegrefcomp -v or hsegrefcomp -version" << endl;

    return ;
}

void help()
{
    cout << endl << "The hsegrefcomp progam is called in the following manner:" << endl;
    cout << "hsegrefcomp parameter_file_name" << endl;
    cout << endl << "where \"parameter_file_name\" is the name of the input parameter file" << endl;
    cout << "For contents see below." << endl;
    cout << endl << "For this help: hsegrefcomp -h or hsegrefcomp -help" << endl;
    cout << "For version information: hsegrefcomp -v or hsegrefcomp -version" << endl;
    cout << endl << "The parameter file consists of entries of the form:" << endl << endl;
    cout << "-parameter_name parameter_value(s)" << endl;
    cout << endl << "Each parameter name and its value(s) must be entered on a separate, single line" << endl;

    fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n");
    fprintf(stdout,"\nInput Files:\n"
"-oparam				(string)	HSeg/RHSeg output parameter file\n"
"						(required)\n"
"NOTE: The oparam file must contain entries for -object_labels_map and -region_objects.\n"
"-training_samples	(string)	Training field sample data (required)\n");

    fprintf(stdout,"\nOutput Files:\n"
"-log_file		(string)	Log file (required)\n");

    return ;
}
