#ifndef HSEGPRUNE2_H
#define HSEGPRUNE2_H

#include <defines.h>
#include <map>

using namespace std;

namespace HSEGTilton
{
    // Global function definitions
    bool hsegprune2();
    bool cut_hierarchy(const double& l_std_dev, const unsigned int& l_region_label,
                       unsigned int *l_labels_map, float* pixel_std_dev, unsigned char *pixel_std_dev_mask);
    void do_region_relabel(map<unsigned int,unsigned int>& region_class_relabel_pairs, unsigned int *labels_map);

} // HSEGTilton

#endif // HSEGPRUNE2_H
