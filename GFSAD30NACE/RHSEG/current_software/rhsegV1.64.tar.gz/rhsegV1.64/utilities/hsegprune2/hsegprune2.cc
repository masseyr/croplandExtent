/*-----------------------------------------------------------
|
|  Routine Name: hsegprune2 - Program to prune an image segmentation hierarchy
|
|       Purpose: Main function for the hsegprune2 program
|
|         Input: 
|
|        Output: 
|
|       Returns: TRUE (1) on success, FALSE (0) on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: December 4, 2014
| Modifications: December 22, 2014 - Activated the ignoring of regions smaller than "minimum_npix"
|                February 7, 2015 - Improved program efficiency and added required "pruned_hlevel_map" output.
|                May 1, 2015 - Modified program output.
|                May 9, 2015 - Implemented compacting of region_classes and region_objects and corrected *.oparam output.
|                May 10, 2015 - Corrected prune_option = 2 case.
|
------------------------------------------------------------*/

#include "hsegprune2.h"
#include "params/initialParams.h"
#include "params/params.h"
#include <spatial/spatial.h>
#include <pixel/pixel.h>
#include <region/region_class.h>
#include <region/region_object.h>
#include <results/results.h>
#include <iostream>
#include <algorithm>

extern HSEGTilton::InitialParams initialParams;
extern HSEGTilton::Params params;
extern HSEGTilton::oParams oparams;

namespace HSEGTilton
{

  bool hsegprune2()
  {
    if ((initialParams.prune_option == 2) && (oparams.level0_nb_objects == 0))
    {
      cout << "ERROR: HSeg/RHSeg output does not include region object information" << endl;
      cout << "Rerun HSeg/RHSeg requesting that this information be included in the HSeg/RHSeg output" << endl;
      return false;
    }

    if (params.region_std_dev_flag)
    {
      int nb_classes = oparams.level0_nb_classes;
      int nb_objects = oparams.level0_nb_objects;

     // Read in region labels class map (and region labels object map, if available) information at hierarchical level 0
      unsigned int segLevel = 0;
      unsigned int data_index, data_size = params.ncols*params.nrows;
      GDALDataset    *classLabelsInDataset, *objectLabelsInDataset;
      GDALRasterBand *classLabelsInBand, *objectLabelsInBand;
      unsigned int *lm1_class_labels_map = new unsigned int[data_size];
      unsigned int *l_class_labels_map = new unsigned int[data_size];
      unsigned int *lm1_object_labels_map = NULL;
      unsigned int *l_object_labels_map = NULL;
      if (oparams.level0_nb_objects > 0)
      {
        lm1_object_labels_map = new unsigned int[data_size];
        l_object_labels_map = new unsigned int[data_size];
      }

      classLabelsInDataset = (GDALDataset *)GDALOpen(params.class_labels_map_file.c_str(), GA_ReadOnly);
      classLabelsInBand = classLabelsInDataset->GetRasterBand(1);
      classLabelsInBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,l_class_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
      objectLabelsInDataset = NULL;
      if (oparams.level0_nb_objects > 0)
      {
        objectLabelsInDataset = (GDALDataset *)GDALOpen(params.object_labels_map_file.c_str(), GA_ReadOnly);
        objectLabelsInBand = objectLabelsInDataset->GetRasterBand(1);
        objectLabelsInBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,l_object_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
        GDALClose( (GDALDatasetH) objectLabelsInDataset);
      }

     // Declare region_classes and region_objects data objects
      RegionClass::set_static_vals();
      unsigned int region_classes_size = nb_classes;
      vector<RegionClass> lm1_region_classes(region_classes_size);
      vector<RegionClass> l_region_classes(region_classes_size);
      vector<RegionClass> pruned_region_classes(region_classes_size);

      if (oparams.level0_nb_objects == 0)
        nb_objects = 1;
      RegionObject::set_static_vals();
      unsigned int region_objects_size = nb_objects;
      vector<RegionObject> lm1_region_objects(region_objects_size);
      vector<RegionObject> l_region_objects(region_objects_size);
      vector<RegionObject> pruned_region_objects(region_objects_size);
      nb_objects = oparams.level0_nb_objects;

     // Read in region_classes and region_objects information at hierarchical level 0
cout << endl << "Reading in region_classes and region_objects information at hierarchical level " << segLevel << endl;
      Results results_data;
      results_data.set_buffer_sizes(params.nbands,nb_classes,nb_objects);
      results_data.open_input(params.region_classes_file,params.region_objects_file);
      results_data.read(segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,l_region_classes,l_region_objects);

     // Read in pixel standard deviation image and mask data
cout << "Reading in pixel standard deviation image and mask data " << endl;
      float *pixel_std_dev = new float[data_size];
      unsigned char *pixel_std_dev_mask = new unsigned char[data_size];
      GDALDataset    *pixelStdDevDataset, *pixelStdDevMaskDataset = NULL;
      GDALRasterBand *pixelStdDevBand,    *pixelStdDevMaskBand = NULL;
      pixelStdDevDataset = (GDALDataset *)GDALOpen(initialParams.pixel_std_dev_file.c_str(), GA_ReadOnly);
      pixelStdDevBand = pixelStdDevDataset->GetRasterBand(1);
      pixelStdDevBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,pixel_std_dev,params.ncols,params.nrows,GDT_Float32,0,0);
      GDALClose( (GDALDatasetH) pixelStdDevDataset);
      pixelStdDevMaskDataset = (GDALDataset *)GDALOpen(initialParams.pixel_std_dev_mask_file.c_str(), GA_ReadOnly);
      pixelStdDevMaskBand = pixelStdDevMaskDataset->GetRasterBand(1);
      pixelStdDevMaskBand->RasterIO(GF_Read,0,0,params.ncols,params.nrows,pixel_std_dev_mask,params.ncols,params.nrows,GDT_Byte,0,0);
      GDALClose( (GDALDatasetH) pixelStdDevMaskDataset);

      unsigned int *pruned_class_labels_map = new unsigned int[data_size];
      unsigned int *pruned_object_labels_map = NULL;
      if (nb_objects > 0)
        pruned_object_labels_map = new unsigned int[data_size];
      int *pruned_hlevel_map = new int[data_size];
      int *pruned_hlevel;
      bool *checked_l_regions, *cut_l_regions, *cut_lm1_regions;
      unsigned int index, nb_regions;
      if (initialParams.prune_option == 1)
        nb_regions = oparams.level0_nb_classes;
      else
        nb_regions = oparams.level0_nb_objects;
      pruned_hlevel = new int[nb_regions];
      checked_l_regions = new bool[nb_regions];
      cut_l_regions = new bool[nb_regions];
      cut_lm1_regions = new bool[nb_regions];
      for (index = 0; index < nb_regions; index++)
        pruned_hlevel[index] = oparams.nb_levels;

      int lm1_region_index, l_region_index;
      unsigned int lm1_region_label, l_region_label, lm1_region_npix, l_region_npix;
      for (data_index = 0; data_index < data_size; data_index++)
      {
        pruned_hlevel_map[data_index] = oparams.nb_levels;
        pruned_class_labels_map[data_index] = 0;
        if (oparams.level0_nb_objects > 0)
          pruned_object_labels_map[data_index] = 0;
        l_region_label = l_class_labels_map[data_index];
        if (l_region_label > 0)
        {
          pruned_class_labels_map[data_index] = l_region_label;
          l_region_index = l_region_label-1;   // Note the convention that region_label = region_index  + 1 (for all valid regions)
          pruned_region_classes[l_region_index] = l_region_classes[l_region_index];
        }
        if (oparams.level0_nb_objects > 0) 
        {
          l_region_label = l_object_labels_map[data_index];
          if (l_region_label > 0)
          {
            pruned_object_labels_map[data_index] = l_region_label;
            l_region_index = l_region_label-1;   // Note the convention that region_label = region_index  + 1 (for all valid regions)
            pruned_region_objects[l_region_index] = l_region_objects[l_region_index];
          } // if (l_region_label > 0)
        } // if (oparams.level0_nb_objects > 0)
      } // for (data_index = 0; data_index < data_size; data_index++)

      vector <unsigned int> changed_region_labels;
      unsigned int nb_changed_regions;
      bool cut_flag = false;
      bool done_flag = false;
      for (segLevel = 1; segLevel < (unsigned int) (oparams.nb_levels); segLevel++)
      {
     // Read in region_classes and region_objects information at current hierarchical level
cout << "Reading in region_classes and region_objects information at hierarchical level " << segLevel << endl;
        for (l_region_index = 0; l_region_index < oparams.level0_nb_classes; l_region_index++)
          lm1_region_classes[l_region_index] = l_region_classes[l_region_index];
        if (oparams.level0_nb_objects > 0)
        {
          for (l_region_index = 0; l_region_index < oparams.level0_nb_objects; l_region_index++)
            lm1_region_objects[l_region_index] = l_region_objects[l_region_index];
        }
        results_data.read(segLevel,nb_classes,nb_objects,oparams.nb_levels,oparams.int_buffer_size,l_region_classes,l_region_objects);
cout << "Creating region labels map data (region_classes and region_objects, if available) at hierarchical level " << segLevel << endl;
        for (data_index = 0; data_index < data_size; data_index++)
        {
          lm1_class_labels_map[data_index] = l_class_labels_map[data_index];
          if (oparams.level0_nb_objects > 0)
            lm1_object_labels_map[data_index] = l_object_labels_map[data_index];
         // lm1_region_label is in l_labels_map from previous iteration.
          lm1_region_label = l_region_label = 0;
          lm1_region_label = lm1_class_labels_map[data_index];
          if (lm1_region_label != 0)
          {
            l_region_label = lm1_region_label;
            l_region_index = l_region_label - 1;
            while (!l_region_classes[l_region_index].get_active_flag())
            {
              l_region_label = l_region_classes[l_region_index].get_merge_region_label();
              l_region_index = l_region_label - 1;
            }
          }
          l_class_labels_map[data_index] = l_region_label;
          if (oparams.level0_nb_objects > 0)
          {
            lm1_region_label = lm1_object_labels_map[data_index];
            if (lm1_region_label != 0)
            {
              l_region_label = lm1_region_label;
              l_region_index = l_region_label - 1;
              while (!l_region_objects[l_region_index].get_active_flag())
              {
                l_region_label = l_region_objects[l_region_index].get_merge_region_label();
                l_region_index = l_region_label - 1;
              }
            }
            l_object_labels_map[data_index] = l_region_label;
          }
        } // for (data_index = 0; data_index < data_size; data_index++)
      // Find region classes or objects involved in merges between hierarchical level l and lm1
        changed_region_labels.clear();
        if (initialParams.prune_option == 1)
        {
          for (lm1_region_index = 0; lm1_region_index < oparams.level0_nb_classes; lm1_region_index++)
          {
            if ((pruned_hlevel[lm1_region_index] == oparams.nb_levels) && (lm1_region_classes[lm1_region_index].get_active_flag()))
            {
              lm1_region_label = lm1_region_classes[lm1_region_index].get_label(); // lm1_region_label = lm1_region_index + 1;
              if (l_region_classes[lm1_region_index].get_active_flag())
              {
                lm1_region_npix = lm1_region_classes[lm1_region_index].get_npix();
                l_region_npix = l_region_classes[lm1_region_index].get_npix();
                if ((lm1_region_npix != l_region_npix) && (l_region_npix >= initialParams.minimum_npix))
                {
                  changed_region_labels.push_back(lm1_region_label);
                }
              }
              else
              {
                l_region_label = l_region_classes[lm1_region_index].get_merge_region_label();
                l_region_index = l_region_label - 1;
                l_region_npix = l_region_classes[l_region_index].get_npix();
                if (l_region_npix >= initialParams.minimum_npix)
                {
                  changed_region_labels.push_back(lm1_region_label);
                }
              }
            } // if ((pruned_hlevel[lm1_region_index] == oparams.nb_levels) && (lm1_region_classes[lm1_region_index].get_active_flag()))
          } // for (lm1_region_index = 0; lm1_region_index < oparams.level0_nb_classes; lm1_region_index++)
        } // if (initialParams.prune_option == 1)
        else
        {
          for (lm1_region_index = 0; lm1_region_index < oparams.level0_nb_objects; lm1_region_index++)
          {
            if ((pruned_hlevel[lm1_region_index] == oparams.nb_levels) && (lm1_region_objects[lm1_region_index].get_active_flag()))
            {
              lm1_region_label = lm1_region_objects[lm1_region_index].get_label(); // lm1_region_label = lm1_region_index + 1;
              if (l_region_objects[lm1_region_index].get_active_flag())
              {
                lm1_region_npix = lm1_region_objects[lm1_region_index].get_npix();
                l_region_npix = l_region_objects[lm1_region_index].get_npix();
                if ((lm1_region_npix != l_region_npix) && (l_region_npix >= initialParams.minimum_npix))
                {
                  changed_region_labels.push_back(lm1_region_label);
                }
              }
              else
              {
                l_region_label = l_region_objects[lm1_region_index].get_merge_region_label();
                l_region_index = l_region_label - 1;
                l_region_npix = l_region_objects[l_region_index].get_npix();
                if (l_region_npix >= initialParams.minimum_npix)
                {
                  changed_region_labels.push_back(lm1_region_label);
                }
              }
            } // if ((pruned_hlevel[lm1_region_index] == oparams.nb_levels) && (lm1_region_objects[lm1_region_index].get_active_flag()))
          } // for (lm1_region_index = 0; lm1_region_index < oparams.level0_nb_objects; lm1_region_index++)
        } // else if (initialParams.prune_option == 2)
        nb_changed_regions = changed_region_labels.size();
        if (nb_changed_regions > 0)
        {
cout << "The following " << nb_changed_regions << " regions at segLevel = " << segLevel << " with npix >= " << initialParams.minimum_npix;
cout << " (after merge) were involved in merges at this hierarchical level:" << endl;
for (index = 0; index < nb_changed_regions; index++)
  cout << changed_region_labels[index] << ", ";
cout << endl;
          for (index = 0; index < nb_regions; index++)
          {
            checked_l_regions[index] = false;
            cut_l_regions[index] = false;
            cut_lm1_regions[index] = false;
          }
          for (index = 0; index < nb_changed_regions; index++)
          {
            lm1_region_label = changed_region_labels[index];
            lm1_region_index = lm1_region_label - 1;
            if (initialParams.prune_option == 1)
            {
              if (l_region_classes[lm1_region_index].get_active_flag())
              {
                l_region_index = lm1_region_index;
                l_region_label = lm1_region_label;
              }
              else
              {
                l_region_label = l_region_classes[lm1_region_index].get_merge_region_label();
                l_region_index = l_region_label - 1;
              }
              if (!checked_l_regions[l_region_index])
              {
                cut_flag = cut_hierarchy(l_region_classes[l_region_index].get_std_dev(), l_region_label,
                                         l_class_labels_map, pixel_std_dev, pixel_std_dev_mask);
                checked_l_regions[l_region_index] = true;
                cut_l_regions[l_region_index] = cut_flag;
              }
            }
            else
            {
              if (l_region_objects[lm1_region_index].get_active_flag())
              {
                l_region_index = lm1_region_index;
                l_region_label = lm1_region_label;
              }
              else
              {
                l_region_label = l_region_objects[lm1_region_index].get_merge_region_label();
                l_region_index = l_region_label - 1;
              }
              if (!checked_l_regions[l_region_index])
              {
                cut_flag = cut_hierarchy(l_region_objects[l_region_index].get_std_dev(), l_region_label,
                                         l_object_labels_map, pixel_std_dev, pixel_std_dev_mask);
                checked_l_regions[l_region_index] = true;
                cut_l_regions[l_region_index] = cut_flag;
              }
            }
            cut_lm1_regions[lm1_region_index] = cut_l_regions[l_region_index];
            if (cut_lm1_regions[lm1_region_index])
              cout << "Cut region " << lm1_region_label << " at hierarchical level " << (segLevel-1) << endl;
          } // for (index = 0; index < nb_changed_regions; index++)

          for (data_index = 0; data_index < data_size; data_index++)
          {
            if (initialParams.prune_option == 1)
            {
              lm1_region_label = lm1_class_labels_map[data_index];
              lm1_region_index = lm1_region_label-1;
              if ((cut_lm1_regions[lm1_region_index]) && (pruned_hlevel_map[data_index] == oparams.nb_levels))
              {
                pruned_hlevel[lm1_region_index] = segLevel - 1;
                pruned_class_labels_map[data_index] = lm1_region_label;
                pruned_hlevel_map[data_index] = segLevel - 1;
                pruned_region_classes[lm1_region_index] = lm1_region_classes[lm1_region_index];
                if (oparams.level0_nb_objects > 0)
                {
                  lm1_region_label = lm1_object_labels_map[data_index];
                  lm1_region_index = lm1_region_label-1;
                  pruned_object_labels_map[data_index] = lm1_region_label;
                  pruned_region_objects[lm1_region_index] = lm1_region_objects[lm1_region_index];
                }
              }
            }
            else
            {
              lm1_region_label = lm1_object_labels_map[data_index];
              lm1_region_index = lm1_region_label-1;
              if ((cut_lm1_regions[lm1_region_index]) && (pruned_hlevel_map[data_index] == oparams.nb_levels))
              {
                pruned_hlevel[lm1_region_index] = segLevel - 1;
                pruned_object_labels_map[data_index] = lm1_region_label;
                pruned_hlevel_map[data_index] = segLevel - 1;
                pruned_region_objects[lm1_region_index] = lm1_region_objects[lm1_region_index];
               // pruned_region_classes ignored here
              }
            }
          } // for (data_index = 0; data_index < data_size; data_index++)
        } // if (nb_changed_regions > 0)
        done_flag = true;
        if (initialParams.prune_option == 1)
        {
          for (l_region_index = 0; l_region_index < oparams.level0_nb_classes; l_region_index++)
            if (pruned_hlevel[l_region_index] == oparams.nb_levels)
              done_flag = false;
        }
        else
        {
          for (l_region_index = 0; l_region_index < oparams.level0_nb_objects; l_region_index++)
            if (pruned_hlevel[l_region_index] == oparams.nb_levels)
              done_flag = false;
        }
        if (done_flag)
        {
          cout << "Pruning complete at hierarchical level = " << segLevel << endl;
          segLevel = oparams.nb_levels;
        }
      } // for (segLevel = 1; segLevel < (unsigned int) oparams.nb_levels; segLevel++)
      results_data.close_input();

      unsigned int compact_region_index;
      if (initialParams.prune_option == 1)
      {
       // Verify the number of region classes.
        region_classes_size = pruned_region_classes.size();
        for (l_region_index = 0; l_region_index < (int) region_classes_size; ++l_region_index)
          pruned_region_classes[l_region_index].set_active_flag(false);
        for (data_index = 0; data_index < data_size; data_index++)
        {
           l_region_label = pruned_class_labels_map[data_index];
           l_region_index = l_region_label-1;
           pruned_region_classes[l_region_index].set_active_flag(true);
        }
        nb_classes = 0;
        for (l_region_index = 0; l_region_index < (int) region_classes_size; ++l_region_index)
          if (pruned_region_classes[l_region_index].get_active_flag())
            nb_classes++;
cout << "After pruning, the number of region classes = " << nb_classes << endl;

        compact_region_index = 0;
        if (nb_classes != oparams.level0_nb_classes)
        {
          vector<RegionClass> compact_region_classes(nb_classes,RegionClass());
          for (l_region_index = 0; l_region_index < (int) region_classes_size; ++l_region_index)
          { 
            if (pruned_region_classes[l_region_index].get_active_flag())
            {
              compact_region_classes[compact_region_index++] = pruned_region_classes[l_region_index];
            }
            if ((int) compact_region_index == nb_classes)
              break;
          }
          region_classes_size = nb_classes;
          pruned_region_classes.resize(region_classes_size);

       // Renumber region_classes and set up region_relabel_pairs.
          map<unsigned int,unsigned int> region_relabel_pairs;
          for (l_region_index = 0; l_region_index < nb_classes; ++l_region_index)
          {
            pruned_region_classes[l_region_index] = compact_region_classes[l_region_index];
            l_region_label = pruned_region_classes[l_region_index].get_label();
            pruned_region_classes[l_region_index].set_label(l_region_index+1);
            if (l_region_label != pruned_region_classes[l_region_index].get_label())
              region_relabel_pairs.insert(make_pair(l_region_label,pruned_region_classes[l_region_index].get_label()));
          }

          if (!(region_relabel_pairs.empty()))
          {
          // Use region_relabel_pairs to renumber the nghbrs_label_set for each region.
            for (l_region_index = 0; l_region_index < nb_classes; ++l_region_index)
              pruned_region_classes[l_region_index].nghbrs_label_set_renumber(region_relabel_pairs);
          // Use region_relabel_pairs to renumber region_label in pruned_class_labels_map.
            do_region_relabel(region_relabel_pairs,pruned_class_labels_map);
          }
        }
      } // if (initialParams.prune_option == 1)
  
      if ((oparams.level0_nb_objects > 0) && ((initialParams.pruned_object_labels_map_flag) || (initialParams.prune_option == 2)))
      {
       // Verify the number of region objects.
        region_objects_size = pruned_region_objects.size();
        for (l_region_index = 0; l_region_index < (int) region_objects_size; ++l_region_index)
          pruned_region_objects[l_region_index].set_active_flag(false);
        for (data_index = 0; data_index < data_size; data_index++)
        {
          l_region_label = pruned_object_labels_map[data_index];
          l_region_index = l_region_label-1;
          pruned_region_objects[l_region_index].set_active_flag(true);        
        }
        nb_objects = 0;
        for (l_region_index = 0; l_region_index < (int) region_objects_size; ++l_region_index)
          if (pruned_region_objects[l_region_index].get_active_flag())
            nb_objects++;
cout << "After pruning, the number of region objects = " << nb_objects << endl;
        compact_region_index = 0;
        if (nb_objects != oparams.level0_nb_objects)
        {
          vector<RegionObject> compact_region_objects(nb_objects,RegionObject());
          for (l_region_index = 0; l_region_index < (int) region_objects_size; ++l_region_index)
          {
            if (pruned_region_objects[l_region_index].get_active_flag())
            {
              compact_region_objects[compact_region_index++] = pruned_region_objects[l_region_index];
            }
            if ((int) compact_region_index == nb_objects)
              break;
          }
          region_objects_size = nb_objects;
          pruned_region_objects.resize(region_objects_size);
   
        // Renumber region_objects and set up region_relabel_pairs.
          map<unsigned int,unsigned int> region_relabel_pairs;
          for (l_region_index = 0; l_region_index < nb_objects; ++l_region_index)
          {
            pruned_region_objects[l_region_index] = compact_region_objects[l_region_index];
            l_region_label = pruned_region_objects[l_region_index].get_label();
            pruned_region_objects[l_region_index].set_label(l_region_index+1);
            if (l_region_label != pruned_region_objects[l_region_index].get_label()) 
              region_relabel_pairs.insert(make_pair(l_region_label,pruned_region_objects[l_region_index].get_label()));
          }
          if (!(region_relabel_pairs.empty()))
          {
          // Use region_relabel_pairs to renumber the nghbrs_label_set for each region.
            for (l_region_index = 0; l_region_index < nb_objects; ++l_region_index)
              pruned_region_objects[l_region_index].object_nghbrs_set_renumber(region_relabel_pairs);
          // Use region_relabel_pairs to renumber region_label in pruned_object_labels_map.
            do_region_relabel(region_relabel_pairs,pruned_object_labels_map);
          }
        }
      } // if ((oparams.level0_nb_objects > 0) && (initialParams.pruned_object_labels_map_flag))
cout << "Completed pruning loop, writing output files" << endl;
      GDALDataset    *hlevelDataset, *classDataset, *objectDataset = NULL;
      GDALRasterBand *hlevelBand, *classBand, *objectBand;

      char **papszOptions = NULL;
      GDALDriver     *driver;      
      driver = classLabelsInDataset->GetDriver();
      hlevelDataset =  driver->Create(initialParams.pruned_hlevel_map_file.c_str(), params.ncols, params.nrows, 1, GDT_UInt32, papszOptions);
      classDataset =  driver->Create(initialParams.pruned_class_labels_map_file.c_str(), params.ncols, params.nrows, 1, GDT_UInt32, papszOptions);
      if ((initialParams.prune_option == 1) && (oparams.level0_nb_objects > 0))
        objectDataset =  driver->Create(initialParams.pruned_object_labels_map_file.c_str(), params.ncols, params.nrows, 1, GDT_UInt32, papszOptions);

      const char *pszProj = classLabelsInDataset->GetProjectionRef();
      if ((pszProj != NULL) && (strlen(pszProj) > 0))
      {
        hlevelDataset->SetProjection(pszProj);
        classDataset->SetProjection(pszProj);
        if ((initialParams.prune_option == 1) && (oparams.level0_nb_objects > 0))
          objectDataset->SetProjection(pszProj);
      }

      double imageGeoTransform[6];
      bool geoTransformFlag = classLabelsInDataset->GetGeoTransform( imageGeoTransform );
      if (geoTransformFlag == CE_None)
      {
        hlevelDataset->SetGeoTransform(imageGeoTransform);
        classDataset->SetGeoTransform(imageGeoTransform);
        if ((initialParams.prune_option == 1) && (oparams.level0_nb_objects > 0))
          objectDataset->SetGeoTransform(imageGeoTransform);
      }

      const char *pszGCPProj = classLabelsInDataset->GetGCPProjection();
      int nGCPs = 0;
      if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
        nGCPs = classLabelsInDataset->GetGCPCount();
      if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0) && (nGCPs > 0))
      {
        const GDAL_GCP *psGCP;
        psGCP = classLabelsInDataset->GetGCPs();
        hlevelDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
        classDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
        if ((initialParams.prune_option == 1) && (oparams.level0_nb_objects > 0))
          objectDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
      GDALClose( (GDALDatasetH) classLabelsInDataset);

      hlevelBand = hlevelDataset->GetRasterBand(1);
      hlevelBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,pruned_hlevel_map,params.ncols,params.nrows,GDT_UInt32,0,0);
      GDALClose( (GDALDatasetH) hlevelDataset);
      if (initialParams.prune_option == 1)
      {
        classBand = classDataset->GetRasterBand(1);
        classBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,pruned_class_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
        GDALClose( (GDALDatasetH) classDataset);

        if (oparams.level0_nb_objects > 0)
        {
          objectBand = objectDataset->GetRasterBand(1);
          objectBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,pruned_object_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
          GDALClose( (GDALDatasetH) objectDataset);
        }
      }
      else
      {
       // Write the pruned_object_labels_map to pruned_class_labels_map_file.
        classBand = classDataset->GetRasterBand(1);
        classBand->RasterIO(GF_Write,0,0,params.ncols,params.nrows,pruned_object_labels_map,params.ncols,params.nrows,GDT_UInt32,0,0);
        GDALClose( (GDALDatasetH) classDataset);
      }
cout << "Finished writing output image files" << endl;
      params.region_boundary_npix_flag = false; // May want to modify hsegprune2 to allow true value here.
      short unsigned int hlevel=0;
      oParams pruned_oparams;
      Results pruned_results_data;
      if (initialParams.prune_option == 1)
      {
        pruned_results_data.set_buffer_sizes(params.nbands,nb_classes,nb_objects);
        pruned_results_data.open_output(initialParams.pruned_region_classes_file,initialParams.pruned_region_objects_file);
        pruned_results_data.write(hlevel,nb_classes,nb_objects,pruned_region_classes,pruned_region_objects);
        pruned_oparams.int_buffer_size.push_back(pruned_results_data.get_int_buffer_index());
        pruned_results_data.close_output();

        pruned_oparams.level0_nb_classes = nb_classes;
        if (params.region_nb_objects_flag)
          pruned_oparams.level0_nb_objects = nb_objects;
        hlevel++;
        pruned_oparams.nb_levels = hlevel;
        pruned_oparams.set_scale_offset(oparams);
        initialParams.write_pruned_oparam(pruned_oparams);
      }
      else
      {
      // Write out the pruned_region_objects as if they were pruned_region_classes
        pruned_region_classes.resize(nb_objects);
        for (l_region_index = 0; l_region_index < nb_objects; ++l_region_index)
          pruned_region_classes[l_region_index] = pruned_region_objects[l_region_index];
        nb_classes = nb_objects;
        nb_objects = 0;
        params.region_objects_list_flag = false;
        params.region_nb_objects_flag = false;
        params.region_threshold_flag = false;

        pruned_results_data.set_buffer_sizes(params.nbands,nb_classes,nb_objects);
        pruned_results_data.open_output(initialParams.pruned_region_classes_file,initialParams.pruned_region_objects_file);
        pruned_results_data.write(hlevel,nb_classes,nb_objects,pruned_region_classes,pruned_region_objects);
        pruned_oparams.int_buffer_size.push_back(pruned_results_data.get_int_buffer_index());
        pruned_results_data.close_output();

        pruned_oparams.level0_nb_classes = nb_classes;
        pruned_oparams.level0_nb_objects = 0;
        hlevel++;
        pruned_oparams.nb_levels = hlevel;
        pruned_oparams.set_scale_offset(oparams);
        initialParams.write_pruned_oparam(pruned_oparams);
      }
cout << "Finished writing output data files" << endl;
    }
    else // if (!params.region_std_dev_flag)
    {
      cout << "ERROR: HSeg/RHSeg output does not include region standard deviation information" << endl;
      cout << "Rerun HSeg/RHSeg requesting that this information be included in the HSeg/RHSeg output" << endl;
      return false;
    }
cout << "Successful exit of hsegprune2 function" << endl;
    return true;
  }

  bool cut_hierarchy(const double& l_std_dev, const unsigned int& l_region_label,
                     unsigned int *l_labels_map, float* pixel_std_dev, unsigned char *pixel_std_dev_mask)
  {
    bool flag = false;

    cout << endl << "For region " << l_region_label << " std_dev at l level = " << l_std_dev << endl;

    unsigned int data_size = params.ncols*params.nrows;
    unsigned int data_index;
    vector <float> pixel_std_dev_vector;
    int mid_point, pixel_std_dev_vector_size;
    for (data_index = 0; data_index < data_size; data_index++)
    {
      if (l_labels_map[data_index] != 0)
      {
        if (l_region_label == l_labels_map[data_index])
        {
          if (pixel_std_dev_mask[data_index])
          {
            pixel_std_dev_vector.push_back(pixel_std_dev[data_index]);
          }
        }
      }
    } // for (data_index = 0; data_index < data_size; data_index++)
    pixel_std_dev_vector_size = pixel_std_dev_vector.size();
    mid_point = pixel_std_dev_vector_size/2;
//    cout << "pixel_std_dev_vector.size() = " << pixel_std_dev_vector_size << endl;
    sort(pixel_std_dev_vector.begin(),pixel_std_dev_vector.end());
    float h_threshold = pixel_std_dev_vector[mid_point];
    cout << "region homogeneity threshold value = " << h_threshold << endl;

    if (l_std_dev > h_threshold)
    {
      flag = true;
//      cout << "cut_flag = true" << endl;
    }
    else
    {
      flag = false;
//      cout << "cut_flag = false" << endl;
    }

    return flag;
  }

  void do_region_relabel(map<unsigned int,unsigned int>& region_class_relabel_pairs, unsigned int *labels_map)
  {
    unsigned int region_label, index, data_size;
    map<unsigned int,unsigned int>::iterator region_class_relabel_pair_iter;
    data_size = params.ncols*params.nrows;
    for (index = 0; index < data_size; index++)
    {
      region_label = labels_map[index];
      if (region_label != 0)
      {
        region_class_relabel_pair_iter = region_class_relabel_pairs.find(region_label);
        if (region_class_relabel_pair_iter != region_class_relabel_pairs.end( ))
        {
          region_label = (*region_class_relabel_pair_iter).second;
        }
      }
      labels_map[index] = region_label;
    }

    return;
  }

} // namespace HSEGTilton

