#ifndef HSEGNPIXPRUNE_H
#define HSEGNPIXPRUNE_H

#include <defines.h>
#include <map>

using namespace std;

namespace HSEGTilton
{
    // Global function definitions
    bool hsegnpixprune();
    void do_region_relabel(map<unsigned int,unsigned int>& region_class_relabel_pairs, unsigned int *labels_map);

} // HSEGTilton

#endif // HSEGNPIXPRUNE_H
