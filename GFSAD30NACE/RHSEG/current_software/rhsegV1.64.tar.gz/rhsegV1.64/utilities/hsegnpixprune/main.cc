/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the hsegnpixprune program
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>    Written By: James C. Tilton, NASA GSFC, Mail Code 606.3, Greenbelt, MD 20771
   >>>>                James.C.Tilton@nasa.gov
   >>>>
   >>>>       Written: July 17, 2015 (Based on hsegprune2)
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include <defines.h>
#include "hsegnpixprune.h"
#include "params/initialParams.h"
#include "params/params.h"
#include <iostream>
#include <fstream>

using namespace std;
using namespace HSEGTilton;

// Globals
InitialParams initialParams;
Params params("Version 1.64, Sept. 1, 2016");
oParams oparams;

// Forward function declarations
void usage();
void help();

int main(int argc, char *argv[])
{
  bool status;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: hsegnpixprune -h or hsegnpixprune -help" << endl << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_FAILURE;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = initialParams.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (initialParams.read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
    initialParams.print();
//    initialParams.print_oparam();

// Call hsegnpixprune function
    status = hsegnpixprune();
    initialParams.remove_temp_files();
  }

  if (status)
  {
    cout << endl << "Successful completion of hsegnpixprune program" << endl;
    return EXIT_SUCCESS;
  }
  else
  {
    cout << endl << "The hsegnpixprune program terminated improperly." << endl;
    return EXIT_FAILURE;
  }
  
}

void usage() // Informs user of proper usage of program when mis-used.
{
    cout << endl << "Usage: " << endl << endl;
    cout << "hsegnpixprune parameter_file_name" << endl << endl;
    cout << "For help information: hsegnpixprune -h or hsegnpixprune -help" << endl;
    cout << "For version information: hsegnpixprune -v or hsegnpixprune -version" << endl;

    return ;
}

void help()
{
    cout << endl << "The hsegnpixprune progam is called in the following manner:" << endl;
    cout << "hsegnpixprune parameter_file_name" << endl;
    cout << endl << "where \"parameter_file_name\" is the name of the input parameter file" << endl;
    cout << "For contents see below." << endl;
    cout << endl << "For this help: hsegnpixprune -h or hsegnpixprune -help" << endl;
    cout << "For version information: hsegnpixprune -v or hsegnpixprune -version" << endl;
    cout << endl << "The parameter file consists of entries of the form:" << endl << endl;
    cout << "-parameter_name parameter_value(s)" << endl;
    cout << endl << "Each parameter name and its value(s) must be entered on a separate, single line" << endl;

    fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n");
    fprintf(stdout,"\nInput File:\n"
"-oparam			(string)	HSeg/RHSeg output parameter file\n"
"					(required)\n");
    fprintf(stdout,"\nOther input parameters:\n"
"-prune_option		(int)		Prune option:\n"
"					  1.\"Prune on region classes\",\n"
"					  2.\"Prune on region objects\",\n"
"					(default: 1. \"Prune on region classes\")\n"
"-minimum_npix		(int)		Minimum region size in pixels after\n"
"					pruning (optional, default = 2000)\n");

    fprintf(stdout,"\nOutput Files:\n"
"-pruned_hlevel_map	(string)	Map of hierarchical level at which the\n"
"					pruning occurred (required)\n"
"-pruned_class_labels_map(string)	Region class labels map image\n"
"					at pruned hierarchical levels (required)\n"
"-pruned_region_classes	(string)	Output pruned region classes file name\n"
"					(required)\n"
"-pruned_object_labels_map(string)	Region object labels map image\n"
"					at pruned hierarchical levels (optional\n"
"					 for prune_option = 1, ignored for\n"
"					 prune_option = 2)\n"
"-pruned_region_objects	(string)	Output pruned region objects file name\n"
"					(optional for prune_option = a, ignored\n"
"					 for prune_option = 2)\n"
"-pruned_oparam		(string)	Output parameter file name for\n"
"					pruned result (required)\n"
"NOTE: The output image files will have the same format as the\n"
"      \"class_labels_map\" specified in \"oparam\".\n");

    return ;
}
