#ifndef INITIALPARAMS_H
#define INITIALPARAMS_H

#include <defines.h>
#include <params/params.h>
#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <vector>
#include "gdal_priv.h"
#include "cpl_conv.h"

using namespace std;

namespace HSEGTilton
{

  class InitialParams 
  {
    public:
    // Constructor and Destructor
      InitialParams();
      virtual ~InitialParams();

    // Member functions
      bool read(const char *param_file);
      bool read_oparam();
      void set_temp_files();
      void print();
      void print_oparam();
      void write_pruned_oparam(const oParams& pruned_oparams);
      void remove_temp_files();

    // Member variables (public)

    /*-- RHSeg output parameter file (required) --*/
      string  oparam_file;             /*-- USER INPUT FILE NAME --*/

   /*-- Prune option (optional, default provided) --*/
      unsigned int   prune_option;     /*-- USER INPUT PARAMETER --*/

   /*-- Minimum region size for pruning (optional, default provided) --*/
      unsigned int   minimum_npix;     /*-- USER INPUT PARAMETER --*/

    /*-- Output pruned_hlevel map image file (required) --*/
      string  pruned_hlevel_map_file;           /*-- USER INPUT FILENAME --*/

    /*-- Output pruned class labels map image file (required) --*/
      string  pruned_class_labels_map_file;     /*-- USER INPUT FILENAME --*/

    /*-- Output pruned region class file (required) --*/
      string pruned_region_classes_file;        /*-- USER INPUT FILENAME --*/

    /*-- Output pruned object labels map image file (optional) --*/
      string pruned_object_labels_map_file;     /*-- USER INPUT FILENAME --*/
      bool   pruned_object_labels_map_flag;     /*-- EXISTENCE FLAG --*/

    /*-- Output pruned region objects file (optional) --*/
      string pruned_region_objects_file;	/*-- USER INPUT FILENAME --*/
      bool   pruned_region_objects_flag;        /*-- EXISTENCE FLAG --*/

    /*-- Pruned output parameter file (required) --*/
      string pruned_oparam_file;                /*-- USER INPUT FILENAME --*/

    /*-- Temporary files and associated GDALDatasets --*/
      vector<string> temp_seg_level_label_files;/* -- PROGRAM PARAMETERS --*/
      vector<GDALDataset *> tempDatasets;       /* -- PROGRAM PARAMETERS --*/

    /*-- Temporary filename prefix --*/
      string prefix;                            /* -- PROGRAM PARAMETER --*/

    protected:

    private:

  };

} // HSEGTilton

#endif /* INITIALPARAMS_H */
