/*-----------------------------------------------------------
|
|  Routine Name: do_region_class_relabel (regular version)
|
|       Purpose: Performs the region relabeling operation on pixel_data
|                as specified by the region_class_relabel_pairs map
|
|         Input: region_class_relabel_pairs (Map specifying the region relabel table)
|                pixel_data       (Class which holds information pertaining to the pixel of pixels processed by this task)
|                
|        Output:
|
|         Other:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|          Date: September 13, 2002.
| Modifications: February 10, 2003:  Changed region index to region label
|                June 11, 2003 - Modified the temp_data structure and its use.
|                November 17, 2003 - Added region_object version.
|                December 22, 2004 - Changed region label from short unsigned int to unsigned int
|                May 31, 2005 - Added temporary file I/O for faster processing of large data sets
|                October 21, 2005 - Added slice dimension (extension to three-dimensional analysis)
|                May 12, 2008 - Revised to work with globally defined Params and oParams class objects
|                March 24, 2011 - Revised counting of recursive levels to start at level = 0 (instead of level = 1).
|                April 7, 2011 - Initiated using set_stride_sections to determine stride and nb_sections (nb_tasks for parallel).
|
------------------------------------------------------------*/

#include "pixel.h"
#include <params/params.h>
#include <spatial/spatial.h>
#include <iostream>
#ifdef TIME_IT
#include <ctime>
#endif

extern HSEGTilton::Params params;

namespace HSEGTilton
{
 void do_region_class_relabel(map<unsigned int,unsigned int>& region_class_relabel_pairs,
                        vector<Pixel>& pixel_data)
 {
   unsigned int region_label, pixel_index, pixel_data_size;
   map<unsigned int,unsigned int>::iterator region_class_relabel_pair_iter;
#ifdef DEBUG
   if (params.debug > 3)
   {
     params.log_fs << endl << "Entering do_region_label, dump of the pixel data:" << endl << endl;
     pixel_data_size = pixel_data.size( );
     for (pixel_index = 0; pixel_index < pixel_data_size; pixel_index++)
     {
       region_label = pixel_data[pixel_index].get_region_label( );
       if (region_label != 0)
         params.log_fs << "Element " << pixel_index << " is associated with region label " << region_label << endl;
//     pixel_data[pixel_index].print(pixel_index);
     }
   }
   if (params.debug > 2)
   {
     params.log_fs << endl << "The region relabelings performed in do_region_class_relabel:" << endl;
     region_class_relabel_pair_iter = region_class_relabel_pairs.begin( );
     while (region_class_relabel_pair_iter != region_class_relabel_pairs.end( ))
     {
       if ((*region_class_relabel_pair_iter).first != (*region_class_relabel_pair_iter).second)
       {
         params.log_fs << "Region label " << (*region_class_relabel_pair_iter).first << " relabeled to ";
         params.log_fs << (*region_class_relabel_pair_iter).second << endl;
       }
       ++region_class_relabel_pair_iter;
     }
   }
#endif
   pixel_data_size = pixel_data.size( );
   for (pixel_index = 0; pixel_index < pixel_data_size; pixel_index++)
   {
     region_label = pixel_data[pixel_index].get_region_label( );
     if (region_label != 0)
     {
       region_class_relabel_pair_iter = region_class_relabel_pairs.find(region_label);
       if (region_class_relabel_pair_iter != region_class_relabel_pairs.end( ))
       {
         region_label = (*region_class_relabel_pair_iter).second;
         if (region_label == 0)
         {
           if (params.debug > 0)
           {
             params.log_fs << "WARNING:  Region label " << pixel_data[pixel_index].get_region_label( );
             params.log_fs << "relabeled to 0 (unknown label)." << endl;
           }
           else
           {
             cout << "WARNING:  Region label " << pixel_data[pixel_index].get_region_label( );
             cout << "relabeled to 0 (unknown label)." << endl;
           }
         }
         pixel_data[pixel_index].set_region_label(region_label);
       }
     }
   }
#ifdef DEBUG
   if (params.debug > 3)
   {
     params.log_fs << endl << "Exiting do_region_class_relabel, dump of the pixel data:" << endl << endl;
     pixel_data_size = pixel_data.size( );
     for (pixel_index = 0; pixel_index < pixel_data_size; pixel_index++)
     {
       region_label = pixel_data[pixel_index].get_region_label( );
       if (region_label != 0)
       {
         params.log_fs << "Element " << pixel_index << " is associated with region label " << region_label << endl;
//       pixel_data[pixel_index].print(pixel_index);
       }
     }
   }
#endif
   return;
 }
} // namespace HSEGTilton
