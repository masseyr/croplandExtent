#ifndef SERIALKEY_H
#define SERIALKEY_H

int serialkey();

#endif
