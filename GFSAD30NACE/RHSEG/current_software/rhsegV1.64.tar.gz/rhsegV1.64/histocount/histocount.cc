/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>          File:  histocount.cc
   >>>>
   >>>>          See histocount.h for documentation
   >>>>
   >>>>          Date:  March 10, 2016
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "histocount.h"

namespace HSEGTilton
{
 HistoCount::HistoCount()
 {
   region_index1 = 0;
   region_index2 = 0;
   count = 0;

   return;
 }

 HistoCount::HistoCount(const HistoCount& source)
 {
// Copy member variables
   region_index1 = source.region_index1;
   region_index2 = source.region_index2;
   count = source.count;

   return;
 }

 HistoCount::~HistoCount()
 {
   return;
 }

 void HistoCount::operator =(const HistoCount& source)
 {
   if (this == &source)
     return;

// Copy member variables
   region_index1 = source.region_index1;
   region_index2 = source.region_index2;
   count = source.count;

   return;
 }

 void HistoCount::init(const unsigned int& rindex1_value, const unsigned int& rindex2_value)
 {
// Set member variables
   if (rindex1_value < rindex2_value)
   {
     region_index1 = rindex1_value;
     region_index2 = rindex2_value;
   }
   else
   {
     region_index2 = rindex1_value;
     region_index1 = rindex2_value;
   }
   count = 1;

   return;
 }

 void HistoCount::init(const unsigned int& rindex1_value, const unsigned int& rindex2_value, const unsigned int& count_value)
 {
// Set member variables
   if (rindex1_value < rindex2_value)
   {
     region_index1 = rindex1_value;
     region_index2 = rindex2_value;
   }
   else
   {
     region_index2 = rindex1_value;
     region_index1 = rindex2_value;
   }
   count = count_value;

   return;
 }

 void HistoCount::clear()
 {
   region_index1 = 0;
   region_index2 = 0;
   count = 0;

   return;
 }

 void HistoCount::increment()
 {
   count++;

   return;
 }

} // namespace HSEGTilton
