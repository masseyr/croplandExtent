/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the HistoCount class.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  March 10, 2016
   >>>>
   >>>> Modifications:  March 17, 2016 - Added the increment function and a new version of the init function
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#ifndef HISTOCOUNT_H
#define HISTOCOUNT_H

using namespace std;

namespace HSEGTilton
{

  class HistoCount
  {
    public:
      //  CONSTRUCTORS and DESTRUCTOR
      HistoCount();
      HistoCount(const HistoCount& source);
      ~HistoCount();

      //  MODIFICATION MEMBER FUNCTIONS
      void operator =(const HistoCount& source);
      void init(const unsigned int& rindex1_value, const unsigned int& rindex2_value);
      void init(const unsigned int& rindex1_value, const unsigned int& rindex2_value, const unsigned int& count_value);
      void clear();
      void increment();

      //  CONSTANT MEMBER FUNCTIONS
      unsigned int get_region_index1() const {return region_index1; }
      unsigned int get_region_index2() const {return region_index2; }
      unsigned int get_count() const {return count; }

      // FRIEND FUNCTIONS and CLASSES
      friend class IndexMoreThan;

    private:
      //  PRIVATE FUNCTIONS

      //  PRIVATE DATA
      unsigned int region_index1;
      unsigned int region_index2;
      unsigned int count;

  };

  class IndexMoreThan
  {
    public:
      bool operator () (const HistoCount& hc1, const HistoCount& hc2) const
      {    
        if ((hc1.region_index2 == hc2.region_index2) && (hc1.count == hc2.count))
          return (hc1.region_index1 > hc2.region_index1);
        else if (hc1.region_index2 == hc2.region_index2)
          return (hc1.count > hc2.count);
        else
          return (hc1.region_index2 > hc2.region_index2); }
   };

} // HSEGTilton

#endif /* HISTOCOUNT_H */
