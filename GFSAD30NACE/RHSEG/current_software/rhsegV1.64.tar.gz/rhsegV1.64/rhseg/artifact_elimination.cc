/*-----------------------------------------------------------
|
|  Routine Name: artifact_elimination
|
|       Purpose: Performs region merges along the processing window seams so as to eliminate processing window artifacts
|
|         Input: recur_level             (Current recursive level of this task)
|                section                 (Section or window processed by this call to lrhseg)
|                ncols                   (Current number of columns in data being processed)
|                nrows                   (Current number of rows in data being processed)
|                col_seam_region_labels  (Region labels along processing window column seam - with overlap)
|                row_seam_region_labels  (Region labels along processing window row seam - with overlap)
|                pixel_data              (Class which holds information pertaining to the pixels processed by this task)
|                
|         Other: nregions                (Current number of regions)
|                region_classes          (Class which holds region class related information)
|                temp_data               (buffers used in communications between parallel tasks)
|
|       Returns:
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: January 27, 2014
| Modifications: March 28, 2014 - Revised artifact elimination process (using edge information).
|                March 9, 2016 - Completely revised artifact elimination process (using processing window overlap).
|                March 17, 2016 - Modified approach to accumulating the class co-occurrence histogram.
|                March 19, 2016 - Made an additional modification to reduce memory usage.
|
------------------------------------------------------------*/

#include "hseg.h"
#include <params/params.h>
#include <index/index.h>
#include <region/region_class.h>
#include <pixel/pixel.h>
#include <histocount/histocount.h>
#include <algorithm>
#include <iostream>

extern HSEGTilton::Params params;
extern HSEGTilton::oParams oparams;

namespace HSEGTilton
{
 void artifact_elimination(const short unsigned int& recur_level, const short unsigned int& section,
                           const int& ncols, const int& nrows, double& max_threshold,
                           vector<unsigned int>& col_seam_region_labels, vector<unsigned int>& row_seam_region_labels,
                           unsigned int& nregions, vector<RegionClass>& region_classes,
                           vector<Pixel>& pixel_data, Temp& temp_data)
 {
   bool col_flag, row_flag;
   int col, row, histo_index, seam_length, seam_index, seam_half_width = 2*params.overlap_width;
   unsigned int region_index1, region_index2, region_label1, region_label2;
   unsigned int onregions = nregions;
   unsigned int region_index, region_label, merge_region_index, merge_region_label;
   int histocounts_size = 0;
   vector<HistoCount> dynamic_histocounts;

   set_recur_flags(params.recur_mask_flags[recur_level],col_flag,row_flag);

   if (col_flag)
   {
     seam_length = nrows;
     for (row = 0; row < seam_length; row++)
     {
      for (col = 0; col < seam_half_width; col++)  
      {
        seam_index = col + row*2*seam_half_width;
        region_label1 = col_seam_region_labels[seam_index];
        if (region_label1 > 0)
        {
         region_index1 = region_label1 - 1;
         if (region_classes[region_index1].get_npix() > MIN_HISTO_COUNT)
         {
           seam_index += seam_half_width;
           region_label2 = col_seam_region_labels[seam_index];
           if (region_label2 > 0)
           {
            region_index2 = region_label2 - 1;
            if (region_classes[region_index2].get_npix() > MIN_HISTO_COUNT)
            {
             if (histocounts_size == 0)
             { 
               HistoCount new_histocount;
               new_histocount.init(region_index1, region_index2);
               dynamic_histocounts.push_back(new_histocount);
               histocounts_size++;
             }
             else
             {
               for (histo_index = 0; histo_index < histocounts_size; histo_index++)
               {
                 if ((dynamic_histocounts[histo_index].get_region_index1() == region_index1) &&
                     (dynamic_histocounts[histo_index].get_region_index2() == region_index2))
                   break;
                 if ((dynamic_histocounts[histo_index].get_region_index1() == region_index2) &&
                     (dynamic_histocounts[histo_index].get_region_index2() == region_index1))
                   break;
               }
               if (histo_index < histocounts_size)
                 dynamic_histocounts[histo_index].increment();
               else
               { 
                 HistoCount new_histocount;
                 new_histocount.init(region_index1, region_index2);
                 dynamic_histocounts.push_back(new_histocount);
                 histocounts_size++;
               }
             }
            } // if (region_classes[region_index2].get_npix() > MIN_HISTO_COUNT)
           } // if (region_label2 > 0)
         } // if (region_classes[region_index].get_npix() > MIN_HISTO_COUNT)
        } // if (region_label1 > 0)
      } // for (col = 0; col < seam_half_width; col++)  
     } // for (row = 0; row < seam_length; row++)
   } // if (col_flag)

   if (row_flag)
   {
     seam_length = ncols;
     for (row = 0; row < seam_length; row++)
     {
      for (col = 0; col < seam_half_width; col++)  
      {
        seam_index = col + row*2*seam_half_width;
        region_label1 = row_seam_region_labels[seam_index];
        if (region_label1 > 0)
        {
         region_index1 = region_label1 - 1;
         if (region_classes[region_index1].get_npix() > MIN_HISTO_COUNT)
         {
           seam_index += seam_half_width;
           region_label2 = row_seam_region_labels[seam_index];
           if (region_label2 > 0)
           {
            region_index2 = region_label2 - 1;
            if (region_classes[region_index2].get_npix() > MIN_HISTO_COUNT)
            {
             if (histocounts_size == 0)
             { 
               HistoCount new_histocount;
               new_histocount.init(region_index1, region_index2);
               dynamic_histocounts.push_back(new_histocount);
               histocounts_size++;
             }
             else
             {
               for (histo_index = 0; histo_index < histocounts_size; histo_index++)
               {
                 if ((dynamic_histocounts[histo_index].get_region_index1() == region_index1) &&
                     (dynamic_histocounts[histo_index].get_region_index2() == region_index2))
                   break;
                 if ((dynamic_histocounts[histo_index].get_region_index1() == region_index2) &&
                     (dynamic_histocounts[histo_index].get_region_index2() == region_index1))
                   break;
               }
               if (histo_index < histocounts_size)
                 dynamic_histocounts[histo_index].increment();
               else
               { 
                 HistoCount new_histocount;
                 new_histocount.init(region_index1, region_index2);
                 dynamic_histocounts.push_back(new_histocount);
                 histocounts_size++;
               }
             }
            } // if (region_classes[region_index2].get_npix() > MIN_HISTO_COUNT)
           } // if (region_label2 > 0)
         } // if (region_classes[region_index].get_npix() > MIN_HISTO_COUNT)
        } // if (region_label1 > 0)
      } // for (col = 0; col < seam_half_width; col++)  
     } // for (row = 0; row < seam_length; row++)
   } // if (row_flag)

   vector<HistoCount> histocounts;
   for (histo_index = 0; histo_index < histocounts_size; histo_index++)
   {
     if (dynamic_histocounts[histo_index].get_count() > MIN_HISTO_COUNT)
       histocounts.push_back(dynamic_histocounts[histo_index]);
   }
   sort(histocounts.begin(), histocounts.end(), IndexMoreThan());

   unsigned int base_region_index, merged_region_index;
   histocounts_size = histocounts.size();
   for (histo_index = 0; histo_index < histocounts_size; histo_index++)
   {
     base_region_index = histocounts[histo_index].get_region_index1();
     while (!region_classes[base_region_index].get_active_flag())
     {
       base_region_index = (region_classes[base_region_index].get_merge_region_label() - 1);
     }
     merged_region_index = histocounts[histo_index].get_region_index2();
     while (!region_classes[merged_region_index].get_active_flag())
     {
       merged_region_index = (region_classes[merged_region_index].get_merge_region_label() - 1);
     }
     if (base_region_index != merged_region_index)
     {
       if (base_region_index > merged_region_index)
       {
         region_index = base_region_index;
         base_region_index = merged_region_index;
         merged_region_index = region_index;
       }
       if (params.debug > 1)
         params.log_fs << "Merging region " << (merged_region_index+1) << " into region " << (base_region_index+1) << " in artifact_elimination" << endl;
       region_classes[base_region_index].merge_regions(false,max_threshold,&region_classes[merged_region_index],region_classes);
       nregions--;
     }

   }

   map<unsigned int,unsigned int> region_class_relabel_pairs;
   unsigned int region_classes_size = region_classes.size();

   if (onregions != nregions)
   {
     for (region_index = 0; region_index < region_classes_size; ++region_index)
     {
       merge_region_index = region_index;
       merge_region_label = region_classes[merge_region_index].get_merge_region_label();
       if (merge_region_label != 0)
       {
         while (merge_region_label != 0)
         {
           merge_region_index = merge_region_label - 1;
           merge_region_label = region_classes[merge_region_index].get_merge_region_label();
         }
         region_classes[region_index].set_merge_region_label(region_classes[merge_region_index].get_label());
       }
     }

     for (region_index = 0; region_index < region_classes_size; ++region_index)
     {
       region_label = region_index + 1;
       merge_region_label = region_classes[region_index].get_merge_region_label();
       if (merge_region_label != 0)
         region_class_relabel_pairs.insert(make_pair(region_label,merge_region_label));
     }
     for (region_index = 0; region_index < region_classes_size; ++region_index)
       region_classes[region_index].set_merge_region_label(0);
   } // if (onregions != nregions)

   if (!(region_class_relabel_pairs.empty()))
   {
     do_region_class_relabel(recur_level,section,region_class_relabel_pairs,pixel_data,temp_data);
   }

   return;
 }

} // namespace HSEGTilton
