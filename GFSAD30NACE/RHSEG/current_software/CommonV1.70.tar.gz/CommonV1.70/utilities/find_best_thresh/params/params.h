/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Params class, which is a class 
   >>>>                 holding program parameters.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  March 28, 2017
   >>>> Modifications:  April 6, 2017 - Added prefix and suffix string input parameters.
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */
#ifndef PARAMS_H
#define PARAMS_H

#include <string>
#include <fstream>
#include <sstream>
#include <stdexcept>

using namespace std;

namespace CommonTilton
{
// Params class
  class Params 
  {
    public:
    // Constructor and Destructor
      Params(const string& value);
      virtual ~Params();

    // Member functions
      void print_version();
      bool read(const char *param_file);
      void print();

    // Member variables (public)
    /*-- Name of the input file containing the output log files from the hsegrefcomp program (required) --*/
      string input_log_files;         /*-- USER INPUT TEXT FILENAME --*/
      fstream input_log_fs;           /*-- ASSOCIATED FILE STREAM --*/

    /*-- prefix of the hsegrefcomp output log filenames (required) --*/
      string prefix;                  /*-- USER INPUT STRING --*/

    /*-- suffix of the hsegrefcomp output log filenames (required) --*/
      string suffix;                  /*-- USER INPUT STRING --*/

    /*-- Output log file (required) --*/
      string output_log_file;         /*-- USER OUTPUT TEXT FILENAME --*/
      fstream output_log_fs;          /*-- ASSOCIATED FILE STREAM --*/

    /* Program version */
      string version;                 /* -- PROGRAM PARAMETER --*/

    // FRIEND FUNCTIONS and CLASSES
    protected:

    private:
  };

  string process_line(const string& line, const bool& list_flag);

} // CommonTilton

#endif /* PARAMS_H */
