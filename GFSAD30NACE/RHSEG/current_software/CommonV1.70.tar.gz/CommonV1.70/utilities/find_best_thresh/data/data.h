/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Data class, which provides an encapsulation of Data information.
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3, NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  March 31, 2017
   >>>>
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#ifndef DATA_H
#define DATA_H

using namespace std;
#include <string>
#include <vector>

namespace CommonTilton
{

  class Data
  {
    public:
      //  CONSTRUCTORS and DESTRUCTOR
      Data();
      Data(const int& tileID_val, const int& sample_label_val);
      Data(const Data& source);
      ~Data();

      //  MODIFICATION MEMBER FUNCTIONS
      void operator =(const Data& source);
      void add_level(const int& h_level_val, const int& nb_classes_val, const int& nb_objects_val, const float& mg_thresh_val,
                     const int& sample_label_val, const int& sample_pixels_val, const int& object_label_val,
                     const int& object_pixels_val, const int& overlap_pixels_val, const float& error_rate_val);
      void set_best_thresh();

      //  CONSTANT MEMBER FUNCTIONS
      int  get_tileID() const { return tileID; }
      int  get_sample_label() const { return sample_label; }
      int  get_nb_levels() const { return nb_levels; }
      void get_data(const int& level, int& h_level_val, int& nb_classes_val, int& nb_objects_val, float& mg_thresh_val,
                    int& sample_pixels_val, int& object_label_val, int& object_pixels_val, int& overlap_pixels_val, float& error_rate_val);
      void get_best_thresh(float& best_mg_thresh_val, float& best_error_rate_val);
      float get_min_mg_thresh() const { return mg_thresh[0]; }
      float get_max_mg_thresh() const { return mg_thresh[nb_levels-1]; }
      float get_mg_thresh(const int& level) const { return mg_thresh[level]; }
      float get_error_rate(const int& level) const { return error_rate[level]; }

      // FRIEND FUNCTIONS and CLASSES
      friend class ThreshLessThan;

    private:
      //  PRIVATE FUNCTIONS

      //  PRIVATE DATA
      int tileID;
      int sample_label;
      int nb_levels;
      vector<int> h_level;
      vector<int> nb_classes;
      vector<int> nb_objects;
      vector<float> mg_thresh;
      vector<int> sample_pixels;
      vector<int> object_label;
      vector<int> object_pixels;
      vector<int> overlap_pixels;
      vector<float> error_rate;
      float best_mg_thresh;
      float best_error_rate;

  };

  class ThreshLessThan
  {
    public:
      bool operator () (const Data& data1, const Data& data2) const
      {
        if (data1.best_error_rate == data2.best_error_rate)
          return (data1.best_mg_thresh < data2.best_mg_thresh);
        else
          return (data1.best_mg_thresh < data2.best_mg_thresh);
      }
  };

} // CommonTilton

#endif /* DATA_H */
