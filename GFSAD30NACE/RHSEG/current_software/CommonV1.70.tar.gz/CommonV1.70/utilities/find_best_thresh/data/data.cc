/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>          File:  data.cc
   >>>>
   >>>>          See data.h for documentation
   >>>>
   >>>>          Date:  March 31, 2017
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "data.h"
#include "../params/params.h"
#include "../find_best_thresh.h"
#include <iostream>

extern CommonTilton::Params params;

namespace CommonTilton
{
  Data::Data()
  {
    tileID = sample_label = nb_levels = 0;
    best_mg_thresh = 0.0;
    best_error_rate = 1.00;

    return;
  }

  Data::Data(const int& tileID_val, const int& sample_label_val)
  {
    tileID = tileID_val;
    sample_label = sample_label_val;
    nb_levels = 0;
    best_mg_thresh = 0.0;
    best_error_rate = 1.00;

    return;
  }

  Data::Data(const Data& source)
  {
    int level;

 // Appropriately resize member vectors
    h_level.resize(source.nb_levels);
    nb_classes.resize(source.nb_levels);
    nb_objects.resize(source.nb_levels);
    mg_thresh.resize(source.nb_levels);
    sample_pixels.resize(source.nb_levels);
    object_label.resize(source.nb_levels);
    object_pixels.resize(source.nb_levels);
    overlap_pixels.resize(source.nb_levels);
    error_rate.resize(source.nb_levels);

 // Copy member variables
    tileID = source.tileID;
    sample_label = source.sample_label;
    nb_levels = source.nb_levels;
    for (level = 0; level < nb_levels; level++)
    {
      h_level[level] = source.h_level[level];
      nb_classes[level] = source.nb_classes[level];
      nb_objects[level] = source.nb_objects[level];
      mg_thresh[level] = source.mg_thresh[level];
      sample_pixels[level] = source.sample_pixels[level];
      object_label[level] = source.object_label[level];
      object_pixels[level] = source.object_pixels[level];
      overlap_pixels[level] = source.overlap_pixels[level];
      error_rate[level] = source.error_rate[level];
    }
    best_mg_thresh = source.best_mg_thresh;
    best_error_rate = source.best_error_rate;

    return;
  }

  Data::~Data()
  {
    return;
  }

  void Data::operator =(const Data& source)
  {
    if (this == &source)
      return;

    int level;

 // Appropriately resize member vectors
    h_level.resize(source.nb_levels);
    nb_classes.resize(source.nb_levels);
    nb_objects.resize(source.nb_levels);
    mg_thresh.resize(source.nb_levels);
    sample_pixels.resize(source.nb_levels);
    object_label.resize(source.nb_levels);
    object_pixels.resize(source.nb_levels);
    overlap_pixels.resize(source.nb_levels);
    error_rate.resize(source.nb_levels);

 // Copy member variables
    tileID = source.tileID;
    sample_label = source.sample_label;
    nb_levels = source.nb_levels;
    for (level = 0; level < nb_levels; level++)
    {
      h_level[level] = source.h_level[level];
      nb_classes[level] = source.nb_classes[level];
      nb_objects[level] = source.nb_objects[level];
      mg_thresh[level] = source.mg_thresh[level];
      sample_pixels[level] = source.sample_pixels[level];
      object_label[level] = source.object_label[level];
      object_pixels[level] = source.object_pixels[level];
      overlap_pixels[level] = source.overlap_pixels[level];
      error_rate[level] = source.error_rate[level];
    }
    best_mg_thresh = source.best_mg_thresh;
    best_error_rate = source.best_error_rate;

    return;
  }

  void Data::add_level(const int& h_level_val, const int& nb_classes_val, const int& nb_objects_val, const float& mg_thresh_val,
                       const int& sample_label_val, const int& sample_pixels_val, const int& object_label_val,
                       const int& object_pixels_val, const int& overlap_pixels_val, const float& error_rate_val)
  {
    nb_levels++;

// Add member variables
    h_level.push_back(h_level_val);
    nb_classes.push_back(nb_classes_val);
    nb_objects.push_back(nb_objects_val);
    mg_thresh.push_back(mg_thresh_val);
    sample_pixels.push_back(sample_pixels_val);
    object_label.push_back(object_label_val);
    object_pixels.push_back(object_pixels_val);
    overlap_pixels.push_back(overlap_pixels_val);
    error_rate.push_back(error_rate_val);

    return;
  }

  void Data::set_best_thresh()
  {
    int level;
    
    if (nb_levels > 0)
    {
      best_mg_thresh = mg_thresh[0];
      best_error_rate = error_rate[0];
    }
    else
    {
      best_mg_thresh = 0.0;
      best_error_rate = 1.00;
    }

    for (level = 1; level < nb_levels; level++)
    {
      if (best_error_rate > error_rate[level])
      {
        best_mg_thresh = mg_thresh[level];
        best_error_rate = error_rate[level];
      }
    }
    
    return;
  }

  void Data::get_data(const int& level, int& h_level_val, int& nb_classes_val, int& nb_objects_val, float& mg_thresh_val,
                      int& sample_pixels_val, int& object_label_val, int& object_pixels_val, int& overlap_pixels_val, float& error_rate_val)
  {
    h_level_val = h_level[level];
    nb_classes_val = nb_classes[level];
    nb_objects_val = nb_objects[level];
    mg_thresh_val = mg_thresh[level];
    sample_pixels_val = sample_pixels[level];
    object_label_val = object_label[level];
    object_pixels_val = object_pixels[level];
    overlap_pixels_val = overlap_pixels[level];
    error_rate_val = error_rate[level];
   

    return;
  }

  void Data::get_best_thresh(float& best_mg_thresh_val, float& best_error_rate_val)
  {
    best_mg_thresh_val = best_mg_thresh;
    best_error_rate_val = best_error_rate;
    
    return;
  }

} // namespace CommonTilton
