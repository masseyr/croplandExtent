/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the find_best_thresh program
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: March 28, 2017
   >>>> Modifications: April 6, 2017 - Added prefix and suffix string input parameters.
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "find_best_thresh.h"
#include "params/params.h"
#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;
using namespace CommonTilton;

//Globals
Params params("Version 1.70, April 6, 2017");

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for the find_best_thresh program interface
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           opens log file (if requested), calls the find_best_thresh function and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: March 28, 2017
| Modifications: 
|
------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  int status = true;

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: find_best_thresh -h or find_best_thresh -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
// Open output log file
    params.output_log_fs.open(params.output_log_file.c_str(),ios_base::out);
    status = params.output_log_fs.is_open();
  }

  if (status)
  {
// Print program parameters
    params.print();

// Call find_best_thresh function
    status = find_best_thresh();
  }

  if (params.output_log_fs.is_open())
    params.output_log_fs.close( );

  if (status)
  {
    cout << endl << "Successful completion of find_best_thresh program" << endl;
  }
  else
  {
    cout << endl << "The find_best_thresh program terminated improperly." << endl;
  }
  
  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

/*-----------------------------------------------------------
|
|  Routine Name: usage - Usage function
|
|       Purpose: Informs user of proper usage of program when mis-used.
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: March 28, 2017.
| Modifications: 
|
------------------------------------------------------------*/
void usage()
{
  cout << endl << "Usage: " << endl << endl;
  cout << "find_best_thresh parameter_file_name" << endl << endl;
  cout << "For help information: find_best_thresh -h or find_best_thresh -help" << endl;
  cout << "For version information: find_best_thresh -v or find_best_thresh -version" << endl;

  return;
}

/*-----------------------------------------------------------
|
|  Routine Name: help - Help function
|
|       Purpose: Provides help information to user on program parameters
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: March 28, 2017
| Modifications: 
|
------------------------------------------------------------*/
void help()
{
  cout << endl << "The find_best_thresh progam is called in the following manner:" << endl;
  cout << endl << "find_best_thresh parameter_file_name" << endl;
  cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
  cout << "file. For contents see below." << endl;
  cout << endl << "For this help: find_best_thresh -h or find_best_thresh -help" << endl;
  cout << endl << "For version information: find_best_thresh -v or find_best_thresh -version";
  cout << endl;
  cout << endl << "The parameter file consists of entries of the form:" << endl;
  cout << endl << "-parameter_name parameter_value(s)" << endl;

  fprintf(stdout,"\nThe following parameters must be specified in the input parameter file:\n\n");
  fprintf(stdout,"Input File and parameters:\n"
"-input_log_files	(string)	Input ASCII text file containing the\n"
"					file names of the log file outputs\n"
"					from runs of the hsegrefcomp program\n"
"					(required - one file name per line)\n"
"NOTE: The file names of the log file outputs from runs of the hsegrefcomp\n"
"program must be formatted as follows: <prefix><tileID><suffix>. For example,\n"
"a valid log file name would be \"Heartland_2010_56_hsegrefcomp.log\" where\n"
"prefix = Heartland_2010_, tileID = 56, and suffix = _hsegrefcomp.log.\n"
"-prefix		(string)	Prefix of the file names of the log\n"
"					file outputs from runs of the\n"
"					hsegrefcomp program (required)\n"
"-suffix		(string)	Suffix of the file names of the log\n"
"					file outputs from runs of the\n"
"					hsegrefcomp program (required)\n");
  fprintf(stdout,"Output File:\n"
"-output_log_file	(string)	Output log file (required)\n");

  return;
}
