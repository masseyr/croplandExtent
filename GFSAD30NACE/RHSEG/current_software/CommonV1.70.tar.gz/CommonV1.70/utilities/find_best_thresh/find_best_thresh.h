#ifndef FINDBESTTHRESH_H
#define FINDBESTTHRESH_H

#include <string>

using namespace std;

namespace CommonTilton
{

  bool find_best_thresh();
  string get_next_sub_string(string& line);

} // CommonTilton

#endif // FINDBESTTHRESH_H
