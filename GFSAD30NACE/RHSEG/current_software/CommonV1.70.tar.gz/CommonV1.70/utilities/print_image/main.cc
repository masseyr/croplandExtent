/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the print_image program - with optional GDAL dependencies
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: zAugust 15, 2014
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "params/params.h"
#include <image/image.h>
#ifdef GDAL
#include <gdal_priv.h>
#endif
#include <iostream>
#include <cstdlib>
#include <climits>
#include <cstring>

using namespace std;
using namespace CommonTilton;

//Globals
Params params("Version 1.70, April 19, 2016");

extern Image inputImage;

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for the print_image program interface
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           opens log file (if requested), calls the print_image function and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: August 15, 2014.
| Modifications: 
|
------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  bool status = true;

#ifdef GDAL
  GDALAllRegister();
#endif

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: print_image -h or print_image -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
    params.print();
    inputImage.print_info();
// Print the requested section of the image
    if (params.band_flag)
      inputImage.print_window(params.band,params.srcwin);
    else
    {
      int nbands = inputImage.get_nbands();
      for (int band = 0; band < nbands; band++)
      {
        inputImage.print_window(band,params.srcwin);
      }
    }
  }

  inputImage.close();

  if (status)
  {
    cout << endl << "Successful completion of print_image program" << endl;
    return EXIT_SUCCESS;
  }
  else
  {
    cout << endl << "The print_image program terminated improperly." << endl;
    return EXIT_FAILURE;
  }
  
}

/*-----------------------------------------------------------
|
|  Routine Name: usage - Usage function
|
|       Purpose: Informs user of proper usage of program when mis-used.
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: August 15, 2014.
| Modifications: 
|
------------------------------------------------------------*/
void usage()
{
  cout << endl << "Usage: " << endl << endl;
  cout << "print_image parameter_file_name" << endl << endl;
  cout << "For help information: print_image -h or print_image -help" << endl;
  cout << "For version information: print_image -v or print_image -version" << endl;

  return;
}

/*-----------------------------------------------------------
|
|  Routine Name: help - Help function
|
|       Purpose: Provides help information to user on program parameters
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: August 15, 2014.
| Modifications: 
|
------------------------------------------------------------*/
void help()
{
  cout << endl << "The print_image progam is called in the following manner:" << endl;
  cout << endl << "print_image parameter_file_name" << endl;
  cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
  cout << "file. For contents see below." << endl;
  cout << endl << "For this help: print_image -h or print_image -help" << endl;
  cout << endl << "For version information: print_image -v or print_image -version";
  cout << endl;
  cout << endl << "The parameter file consists of entries of the form:" << endl;
  cout << endl << "-parameter_name parameter_value(s)" << endl;

  fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
  fprintf(stdout,"Input Files or parameters:\n"
#ifdef GDAL
"-input_image		(string)	Input image (required)\n");
#else
"-input_image		(string)	Input image (required)\n"
"-ncols			(int)		Number of columns in fnput image\n"
"				        (0 < ncols < %d, required)\n"
"-nrows			(int)		Number of rows in input image\n"
"				        (0 < nrows < %d, required)\n"
"-nbands		(int)		Number of spectral bands in input image\n"
"					(0 < nbands < %d, required)\n"
"-dtype			(string)	Input image data type. Must be either:\n"
"					 UInt8   => \"unsigned char (8-bit)\" or\n"
"					 UInt16  => \"unsigned short int\n"
"						     (16-bit)\" or\n"
"					 Float32 => \"float (32-bit)\"\n"
"					(required)\n",USHRT_MAX,USHRT_MAX,USHRT_MAX);
#endif
  fprintf(stdout,"Other parameters:\n"
"-band			(int)		Band to be printed (optional,\n"
"					 default: all bands printed.)\n"
"-window		(list of int)	The spatial window of image to be printed,\n"
"					provided as a comma delimited list:\n"
"					columm_offset,row_offset,#columns,#rows\n"
"					(optional, default: entire image printed\n");

  return;
}
