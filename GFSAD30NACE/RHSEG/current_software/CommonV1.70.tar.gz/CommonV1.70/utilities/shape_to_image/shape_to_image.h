#ifndef SHAPE_TO_IMAGE_H
#define SHAPE_TO_IMAGE_H

namespace CommonTilton
{

  bool shape_to_image();

} // CommonTilton

#endif // SHAPE_TO_IMAGE_H

