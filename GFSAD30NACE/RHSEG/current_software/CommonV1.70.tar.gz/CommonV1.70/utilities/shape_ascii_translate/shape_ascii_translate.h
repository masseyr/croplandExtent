#ifndef SHAPE_ASCII_TRANSLATE_H
#define SHAPE_ASCII_TRANSLATE_H

namespace CommonTilton
{

  bool shape_ascii_translate();

} // CommonTilton

#endif // SHAPE_ASCII_TRANSLATE_H

