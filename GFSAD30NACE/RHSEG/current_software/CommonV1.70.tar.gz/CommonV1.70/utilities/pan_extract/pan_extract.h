#ifndef PAN_EXTRACT_H
#define PAN_EXTRACT_H

using namespace std;

namespace CommonTilton
{

  bool pan_extract();

} // CommonTilton

#endif // PAN_EXTRACT_H

