#ifndef SHAPEINFO_H
#define SHAPEINFO_H

namespace CommonTilton
{

  bool shape_info();

} // CommonTilton

#endif // SHAPEINFO_H

