// sum_bands.cc

#include "sum_bands.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool sum_bands()
  {
    int col, row, band, index;
    int ncols, nrows, nbands;
    GDALDataset *inDataset, *outDataset;
    GDALDataType datatype;
    GDALDriver *driver;
    GDALRasterBand *rb, *wb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    datatype = inDataset->GetRasterBand(1)->GetRasterDataType();
    driver = inDataset->GetDriver();
    cout << "Summing the bands of input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

   // Create output sum_bands image
    int out_nbands = 1;
    char **papszOptions = NULL;
    outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, out_nbands, datatype, papszOptions);
    const char *pszProj = inDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
    {
      outDataset->SetProjection(pszProj);
    }
    double imageGeoTransform[6];
    if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = inDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inDataset->GetGCPs();
      if (nGCPs > 0)
      {
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    float *input_image = new float[ncols*nrows];
    float *output_image = new float[ncols*nrows];
    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        index = col + row*ncols;
        output_image[index] = 0.0;
      }
    }
    for (band = 0; band < nbands; band++)
    {
      rb = inDataset->GetRasterBand((band+1));
      rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Float32, 0, 0);
      for (row = 0; row < nrows; row++)
      {
        for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          output_image[index] += input_image[index];
        }
      }
    }
    wb = outDataset->GetRasterBand((1));
    wb->RasterIO(GF_Write, 0, 0, ncols, nrows, output_image, ncols, nrows, GDT_Float32, 0, 0);

    GDALClose( (GDALDatasetH) inDataset);
    GDALClose( (GDALDatasetH) outDataset);

    return true;
  }

} // CommonTilton

