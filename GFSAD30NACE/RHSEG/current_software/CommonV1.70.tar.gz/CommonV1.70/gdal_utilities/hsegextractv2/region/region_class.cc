/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>          File:  region_class.cc
   >>>>
   >>>>          See region_class.h for documentation
   >>>>
   >>>>          Date:  June 24, 2016 - Based on RegionClass class from RHSEG/rhsegV1.64
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "region_class.h"
#include "region_object.h"
#include "../params/params.h"
#include "../spatial/spatial.h"
#include <iostream>
#include <cmath>
#include <algorithm>

extern CommonTilton::Params params;
extern CommonTilton::oParams oparams;

namespace CommonTilton
{

 bool RegionClass::sumsq_flag;
 bool RegionClass::sumxlogx_flag;
 int  RegionClass::nbands;
 double *RegionClass::scale;
 double *RegionClass::offset;

 RegionClass::RegionClass()
 {
  int band;

// Initialize member variables
  active_flag = false;
  label = 0;
  npix = 0;
  sum = new double[nbands];
  for (band = 0; band < nbands; band++)
    sum[band] = 0.0;
  sumsq = NULL;
  if (sumsq_flag)
  {
    sumsq = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumsq[band] = 0.0;
  }
  if (sumxlogx_flag)
  {
    sumxlogx = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumxlogx[band] = 0.0;
  }
  max_edge_value = -FLT_MAX;
  std_dev = 0.0;
  nghbrs_label_set.clear();
  merge_region_label = 0;
  sum_pixel_gdissim = 0.0;
  min_region_dissim = FLT_MAX;
  nb_region_objects = 0;
  region_objects_set.clear();
  boundary_npix = 0;
  merge_threshold = 0.0;

  return;
 }

 RegionClass::RegionClass(const RegionClass& source)
 {
  int band;

// Copy member variables
  active_flag = source.active_flag;
  label = source.label;
  npix = source.npix;
  sum = new double[nbands];
  for (band = 0; band < nbands; band++)
    sum[band] = source.sum[band];
  if (sumsq_flag)
  {
    sumsq = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumsq[band] = source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    sumxlogx = new double[nbands];
    for (band = 0; band < nbands; band++)
      sumxlogx[band] = source.sumxlogx[band];
  }
  std_dev = source.std_dev;
  max_edge_value = source.max_edge_value;

  merge_region_label = source.merge_region_label;
  sum_pixel_gdissim = source.sum_pixel_gdissim;
  min_region_dissim = source.min_region_dissim;
  nb_region_objects = source.nb_region_objects;
  boundary_npix = source.boundary_npix;
  merge_threshold = source.merge_threshold;

  nghbrs_label_set_copy(source);
  region_objects_set_copy(source);

  return;
 }

 RegionClass::~RegionClass()
 {
  delete [ ] sum;
  if (sumsq_flag)
    delete [ ] sumsq;
  if (sumxlogx_flag)
    delete [ ] sumxlogx;
  nghbrs_label_set.clear();
  region_objects_set.clear();

  return;
 }

 void RegionClass::set_static_vals()
 {
  int band;

  sumsq_flag = params.region_sumsq_flag;
  sumxlogx_flag = params.region_sumxlogx_flag;
  nbands = params.nbands;
  scale = new double[nbands];
  offset = new double[nbands];
 // Coarsen to float to maintain consistency of results between different computing platforms and operating systems.
  for (band = 0; band < nbands; band++)
  {
    scale[band] = (float) (oparams.scale[band]*params.scale[band]);
    offset[band] = (float) (params.offset[band] + (oparams.offset[band]/params.scale[band]));
  }
  return;
 }

 void RegionClass::operator =(const RegionClass& source)
 {
  int band;

  if (this == &source)
    return;

// Copy member variables
  active_flag = source.active_flag;
  label = source.label;
  npix = source.npix;
  for (band = 0; band < nbands; band++)
    sum[band] = source.sum[band];
  if (sumsq_flag)
  {
    for (band = 0; band < nbands; band++)
      sumsq[band] = source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    for (band = 0; band < nbands; band++)
      sumxlogx[band] = source.sumxlogx[band];
  }
  std_dev = source.std_dev;
  max_edge_value = source.max_edge_value;

  merge_region_label = source.merge_region_label;
  sum_pixel_gdissim = source.sum_pixel_gdissim;
  min_region_dissim = source.min_region_dissim;
  nb_region_objects = source.nb_region_objects;
  boundary_npix = source.boundary_npix;
  merge_threshold = source.merge_threshold;

  nghbrs_label_set_copy(source);
  region_objects_set_copy(source);

  return;
 }

 void RegionClass::operator =(const RegionObject& source)
 {
  short unsigned int band;

// Copy member variables
  active_flag = source.active_flag;
  label = source.label;
  npix = source.npix;
  for (band = 0; band < nbands; band++)
    sum[band] = source.sum[band];
  if (sumsq_flag)
  {
    for (band = 0; band < nbands; band++)
      sumsq[band] = source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    for (band = 0; band < nbands; band++)
      sumxlogx[band] = source.sumxlogx[band];
  }
  std_dev = source.std_dev;
  boundary_npix = source.boundary_npix;
  nghbrs_label_set_copy(source);

  return;
 }

 void RegionClass::operator +=(const RegionClass& source)
 {
  int band;

// Update private data - label remains unchanged
  npix += source.npix;
  for (band = 0; band < nbands; band++)
    sum[band] += source.sum[band];
  if (sumsq_flag)
  {
    for (band = 0; band < nbands; band++)
      sumsq[band] += source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    for (band = 0; band < nbands; band++)
      sumxlogx[band] += source.sumxlogx[band];
  }

// These values returned to original default values - must be updated by other means
  max_edge_value = -FLT_MAX;
  std_dev = 0.0;
  merge_region_label = 0;
  sum_pixel_gdissim = 0.0;
  min_region_dissim = FLT_MAX;
  boundary_npix = 0;
  merge_threshold = 0.0;
  nb_region_objects = 0;
  nghbrs_label_set.clear();
  region_objects_set.clear();

// Combine nghbrs_label_set
  if (!source.nghbrs_label_set.empty())
  {
    set<unsigned int>::const_iterator nghbrs_label_set_iter = source.nghbrs_label_set.begin();
    while (nghbrs_label_set_iter != source.nghbrs_label_set.end())
    {
      nghbrs_label_set.insert(*nghbrs_label_set_iter);
      ++nghbrs_label_set_iter;
    }
    nghbrs_label_set.erase(label);
    nghbrs_label_set.erase(source.label);
  }

  return;
 }

 void RegionClass::operator -=(const RegionClass& source)
 {
  int band;

// Update private data - label remains unchanged
  npix -= source.npix;
  for (band = 0; band < nbands; band++)
    sum[band] -= source.sum[band];
  if (sumsq_flag)
  {
    for (band = 0; band < nbands; band++)
      sumsq[band] -= source.sumsq[band];
  }
  if (sumxlogx_flag)
  {
    for (band = 0; band < nbands; band++)
      sumxlogx[band] -= source.sumxlogx[band];
  }

// These values returned to original default values - must be updated by other means
  max_edge_value = -FLT_MAX;
  std_dev = 0.0;
  merge_region_label = 0;
  sum_pixel_gdissim = 0.0;
  min_region_dissim = FLT_MAX;
  boundary_npix = 0;
  merge_threshold = 0.0;
  nb_region_objects = 0;
  nghbrs_label_set.clear();
  region_objects_set.clear();

  return;
 }

 void RegionClass::clear()
 {
      int band;

      active_flag = false;
// Don't clear label!!!
      npix = 0;
      for (band = 0; band < nbands; band++)
        sum[band] = 0.0;
      if (sumsq_flag)
      {
        for (band = 0; band < nbands; band++)
          sumsq[band] = 0.0;
      }
      if (sumxlogx_flag)
      {
        for (band = 0; band < nbands; band++)
          sumxlogx[band] = 0.0;
      }
      max_edge_value = -FLT_MAX;
      std_dev = 0.0;
      nghbrs_label_set.clear();
      merge_region_label = 0;
      sum_pixel_gdissim = 0.0;
      min_region_dissim = FLT_MAX;
      nb_region_objects = 0;
      region_objects_set.clear();
      boundary_npix = 0;
      merge_threshold = 0.0;

      return;
 }

 void RegionClass::partial_clear()
 {
   max_edge_value = -FLT_MAX;
   std_dev = 0.0;
   merge_region_label = 0;
   sum_pixel_gdissim = 0.0;
   min_region_dissim = FLT_MAX;
   boundary_npix = 0;
   merge_threshold = 0.0;
   nb_region_objects = 0;
   nghbrs_label_set.clear();
   region_objects_set.clear();

   return;
 }

 void RegionClass::clear_region_info()
 {
      boundary_npix = 0;
      region_objects_set.clear();

      return;
 }

 void RegionClass::nghbrs_label_set_copy(const RegionClass& source)
 {
    nghbrs_label_set.clear();
    if (!source.nghbrs_label_set.empty())
    {
      set<unsigned int>::const_iterator nghbrs_label_set_iter = source.nghbrs_label_set.begin();
      while (nghbrs_label_set_iter != source.nghbrs_label_set.end())
      {
        nghbrs_label_set.insert(*nghbrs_label_set_iter);
        ++nghbrs_label_set_iter;
      }
    }

    return;
 }

 void RegionClass::nghbrs_label_set_copy(const RegionObject& source)
 {
    nghbrs_label_set.clear();
    if (!source.object_nghbrs_set.empty())
    {
      set<unsigned int>::const_iterator object_nghbrs_iter = source.object_nghbrs_set.begin();
      while (object_nghbrs_iter != source.object_nghbrs_set.end())
      {
        nghbrs_label_set.insert(*object_nghbrs_iter);
        ++object_nghbrs_iter;
      }
    }

    return;
 }

 void RegionClass::region_objects_set_copy(const RegionClass& source)
 {
    region_objects_set.clear();
    if (!source.region_objects_set.empty())
    {
      set<unsigned int>::const_iterator region_object_iter = source.region_objects_set.begin();
      while (region_object_iter != source.region_objects_set.end())
      {
        region_objects_set.insert(*region_object_iter);
        ++region_object_iter;
      }
    }

    return;
 }

 void RegionClass::calc_std_dev()
 {
 // Postcondition: If npix <= 1, std_dev is set to 0.0.  If npix > 1,
 // std_dev is the region standard deviation.

  std_dev = 0.0;
  if (npix <= 1)
    return;

  int band;
  float  sumf, sumsqf, tempf;
  double tempd;
  double numpix = (double) npix;

  for (band = 0; band < nbands; band++)
  {
/*  The original code for at this point was:
    tempd = (sumsq[band] - ((sum[band]*sum[band])/numpix))/(numpix-1.0);
    However, minor differences in the value of sumsq due to different
    order of summation performed by instances of the program run with
    different number of processors was magnified by this form of the
    equation.  The following four lines of code reduce or eliminate
    this magnification of differences of value of sumsq - even though
    the calculations are performed in single rather than double precision!!
*/
    sumf = (float) ((sum[band]*sum[band])/numpix);
    sumsqf = (float) sumsq[band];
    tempf = sumsqf - sumf;
    tempd = tempf/(numpix-1.0);
    if (tempd > 0.0)
      tempd = sqrt(tempd);
    else
      tempd = 0.0;
    std_dev += tempd/oparams.scale[band];
  }
  std_dev /= (double) nbands;

  return;
 }

 double RegionClass::get_unscaled_mean(int band) const
 {
   return (((sum[band]/npix)/oparams.scale[band])+oparams.offset[band]);
 }

 double RegionClass::get_unscaled_std_dev(int band) const
 {
   return (get_std_dev(band)/oparams.scale[band]);
 }

 double RegionClass::get_std_dev(int band) const
 {
   double stdDev = 0.0;

   if (npix <= 1)
     return stdDev;

   double numpix = (double) npix;

   stdDev = (sumsq[band] - ((sum[band]*sum[band])/numpix))/(numpix-1.0);
   if (stdDev > 0.0)
     stdDev = sqrt(stdDev);
   else
     stdDev = 0.0;

   return (stdDev/oparams.scale[band]);
 }

 RegionClass operator -(const RegionClass& arg1, const RegionClass& arg2)
 {
  int band;
  RegionClass result;

// Update private data - label remains unchanged
  result.npix = arg1.npix - arg2.npix;
  for (band = 0; band < result.nbands; band++)
    result.sum[band] = arg1.sum[band] - arg2.sum[band];
  if (result.sumsq_flag)
  {
    for (band = 0; band < result.nbands; band++)
      result.sumsq[band] = arg1.sumsq[band] - arg2.sumsq[band];
  }
  if (result.sumxlogx_flag)
  {
    for (band = 0; band < result.nbands; band++)
      result.sumxlogx[band] = arg1.sumxlogx[band] - arg2.sumxlogx[band];
  }

// These values returned to original default values - must be updated by other means
  result.std_dev = 0.0;
  result.max_edge_value = -FLT_MAX;
  result.merge_region_label = 0;
  result.sum_pixel_gdissim = 0.0;
  result.min_region_dissim = FLT_MAX;
  result.boundary_npix = 0;
  result.merge_threshold = 0.0;
  result.nb_region_objects = 0;
  result.region_objects_set.clear();
  result.nghbrs_label_set.clear();

  return result;
 }

} // namespace CommonTilton
