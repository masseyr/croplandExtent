/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for hsegextractv2/hsegextractv2 - Hierarchical Segmentation Feature Extract - program
   >>>>         Version 2 => Clear example for porting to Goggle Earth Engine
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: June 21, 2016: Based on hsegextract program from RHSEG/rhsegV1.64
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "hsegextractv2.h"
#include "params/initialParams.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <cstring>

using namespace std;
using namespace CommonTilton;

//Globals
InitialParams initialParams;
Params params("Version 1.70, June 21, 2016");
oParams oparams;

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for Hierarchical Segmentation
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           calls the hsegextractv2 function and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: July 6, 2009 (Based on earlier versions of rhseg_read/hsegreader and feature_extract programs)
| Modifications: July 8, 2009: Final clean-up of code for release
|
------------------------------------------------------------*/
int main(int argc, char **argv)
{
  bool status = true;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: hsegextractv2 -h or hsegextractv2 -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = initialParams.read(argv[1]);
    }
  }

  if (status)
  {
    initialParams.print();
    params.print();
    status = hsegextractv2();
  }
  else
  {
    usage();
    cout << "ERROR: Error reading parameter file (read)" << endl;
    return EXIT_FAILURE;
  }

  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

void usage() // Informs user of proper usage of program when mis-used.
{
    cout << endl << "Usage: " << endl << endl;
    cout << "hsegextractv2 parameter_file_name" << endl << endl;
    cout << "For help information: hsegextractv2 -h or hsegextractv2 -help" << endl;
    cout << "For version information: hsegextractv2 -v or hsegextractv2 -version" << endl;

    return ;
}

void help()
{
    cout << endl << "The hsegextractv2 progam is called in the following manner:" << endl;
    cout << endl << "hsegextractv2 parameter_file_name" << endl;
    cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
    cout << "file. For contents see below." << endl;
    cout << endl << "For this help: hsegextractv2 -h or hsegextractv2 -help" << endl;
    cout << "For version information: hsegextractv2 -v or hsegextractv2 -version" << endl;
    cout << endl << "The parameter file consists of entries of the form:" << endl;
    cout << endl << "-parameter_name parameter_value(s)" << endl;

    fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
    fprintf(stdout,"-oparam	        	    (string)	HSeg/RHSeg output parameter file\n"
"					(required)\n"
"-hseg_level	(short unsigned int)	Hierarchical segmentation level at\n"
"					which the selected feature values\n"
"					are extracted. (required)\n\n");

    fprintf(stdout,"One or more of the following are required:\n\n"
"-class_labels_map_ext	    (string)	File name for the class labels map\n"
"					extracted at the selected\n"
"					hierarchical segmentation level.\n"
"-class_npix_map_ext	    (string)	File name for the class # of pixels map\n"
"					extracted at the selected\n"
"					hierarchical segmentation level.\n"
"-class_mean_map_ext	    (string)	File name for the class mean feature\n"
"					map extracted at the selected\n"
"					hierarchical segmentation level.\n"
"-class_std_dev_map_ext	    (string)	File name for the class standard\n"
"					deviation feature map extracted at the\n"
"					selected hierarchical segmentation\n"
"					level.\n"
"-class_bpratio_map_ext	    (string)	File name for the class boundary pixel\n"
"					ratio feature map extracted at the\n"
"					selected hierarchical segmentation\n"
"					level.\n"
"-object_labels_map_ext	    (string)	File name for the object labels map\n"
"					extracted at the selected\n"
"					hierarchical segmentation level.\n"
"-object_npix_map_ext	    (string)	File name for the object # of pixels\n"
"					map extracted at the selected\n"
"					hierarchical segmentation level.\n"
"-object_mean_map_ext	    (string)	File name for the object mean feature\n"
"					map extracted at the selected\n"
"					hierarchical segmentation level.\n"
"-object_std_dev_map_ext    (string)	File name for the object standard\n"
"					deviation feature map extracted at the\n"
"					selected hierarchical segmentation\n"
"					level.\n"
"-object_bpratio_map_ext    (string)	File name for the object boundary pixel\n"
"					ratio feature map extracted at the\n"
"					selected hierarchical segmentation level.\n");

fprintf(stdout,"\nNOTE: The \"object\" files will be ignored if the\n"
"\"object_labels_map\" is not specified in the HSeg/RHSeg output parameter file\n"
"(-oparam above).\n\n");

    return ;
}
