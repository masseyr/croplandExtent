/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>          File:  spatial.cc
   >>>>
   >>>>          See spatial.h for documentation
   >>>>
   >>>>    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt, MD 20771
   >>>>        E-Mail: James.C.Tilton@nasa.gov
   >>>>          Date:  June 24, 2016 - Based on Spatial class from RHSEG/rhsegV1.64
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "spatial.h"
#include "../params/params.h"
#include "../region/region_class.h"
#include "../region/region_object.h"
#include <iostream>

extern CommonTilton::Params params;

namespace CommonTilton
{
 Spatial::Spatial()
 {
// Initialize member parameters as necessary.
  region_class_label_map = NULL;
  region_object_label_map = NULL;

  return;
 }

 Spatial::~Spatial()
 {
// Delete any allocated member arrays.
  if (region_class_label_map != NULL)
    delete [ ] region_class_label_map;
  if (region_object_label_map != NULL)
    delete [ ] region_object_label_map;

  return;
 }

// Used in hsegextract and hsegreader only
  void Spatial::read_region_maps( )
  {
 // Read region_class_label_map and region_object_label_map (if requested) data from specified disk files.
     unsigned int io_size;

 // "io_size" is the number of data elements read or written at one time to or from disk
     io_size = params.ncols*params.nrows;   // No need to change 3/1/2016
     if (region_class_label_map == NULL)
       region_class_label_map = new unsigned int[io_size];
     if ((params.object_labels_map_flag) && (region_object_label_map == NULL))
       region_object_label_map = new unsigned int[io_size];

// Opens, reads and closes, the region_class_label_map (and, if requested, the region_object_label_map)
     GDALDataset *inDataset;
     GDALRasterBand *rb;

     inDataset = (GDALDataset *)GDALOpen(params.class_labels_map_file.c_str(), GA_ReadOnly);
/* Could check - but will always have ncols = params.ncols, nrows = params.nrows and nbands = 1
     ncols = inDataset->GetRasterXSize();
     nrows = inDataset->GetRasterYSize();
     nbands = inDataset->GetRasterCount();
*/
     params.driver = inDataset->GetDriver(); // Use same driver for output image data files
     rb = inDataset->GetRasterBand(1);
     rb->RasterIO(GF_Read, 0, 0, params.ncols, params.nrows, &region_class_label_map[0], params.ncols, params.nrows, GDT_UInt32, 0, 0);
     GDALClose( (GDALDatasetH) inDataset);

     if (params.object_labels_map_flag)
     {
       inDataset = (GDALDataset *)GDALOpen(params.object_labels_map_file.c_str(), GA_ReadOnly);
       rb = inDataset->GetRasterBand(1);
       rb->RasterIO(GF_Read, 0, 0, params.ncols, params.nrows, &region_object_label_map[0], params.ncols, params.nrows, GDT_UInt32, 0, 0);
       GDALClose( (GDALDatasetH) inDataset);
     }

     return;
  }

// Update the region_class_label_map and object_labels_map (if requested) for the selected hierarchical segmentation level.
// Used in hsegextract only
  void Spatial::update_region_maps(const short unsigned int& hseg_level, 
                                   vector<RegionClass>& region_classes, vector<RegionObject>& region_objects)
  {
     unsigned int index, region_label, region_index;
     int row, col;

 // Read in the data
     if (hseg_level > 0)
     {
         for (row = 0; row < params.nrows; row++)
         {
           for (col = 0; col < params.ncols; col++)
           {
             index = col + row*params.ncols;
             region_label = region_class_label_map[index];
             if (region_label > 0)
             {
               region_index = region_label - 1;
               if (!region_classes[region_index].get_active_flag())
                 region_label = region_classes[region_index].get_merge_region_label();
             }
             region_class_label_map[index] = region_label;
           }
         }
     }
     if (params.object_labels_map_flag)
     {
       if (hseg_level > 0)
       {
           for (row = 0; row < params.nrows; row++)
           {
             for (col = 0; col < params.ncols; col++)
             {
               index = col + row*params.ncols;
               region_label = region_object_label_map[index];
               if (region_label > 0)
               {
                 region_index = region_label - 1;
                 if (!region_objects[region_index].get_active_flag())
                  region_label = region_objects[region_index].get_merge_region_label();
               }
               region_object_label_map[index] = region_label;
             }
           }
       }
     }

     return;
  }

  void Spatial::write_class_labels_map_ext(const string& class_labels_map_ext_file, vector<RegionClass>& region_classes)
  {
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    outDataset = params.driver->Create(class_labels_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_UInt32, papszOptions);
    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, region_class_label_map, params.ncols, params.nrows, GDT_UInt32, 0, 0);
    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_class_npix_map_ext(const string& class_npix_map_ext_file, vector<RegionClass>& region_classes)
  {
    int row, col, index;
    unsigned int region_index, region_label;
    unsigned int io_size = params.ncols*params.nrows;
    unsigned int *npix_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    npix_map = new unsigned int[io_size];
    outDataset = params.driver->Create(class_npix_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_UInt32, papszOptions);

    for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        index = col + row*params.ncols;
        region_label = region_class_label_map[index];
        region_index = region_label - 1;
        if (region_label == 0)
          npix_map[index] = 0;
        else
          npix_map[index] = region_classes[region_index].get_npix();
      }

    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, npix_map, params.ncols, params.nrows, GDT_UInt32, 0, 0);
    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_class_mean_map_ext(const string& class_mean_map_ext_file, vector<RegionClass>& region_classes)
  {
    unsigned int region_label, region_index;
    int index, row, col, band;
    unsigned int io_size = params.ncols*params.nrows;
    float *class_mean_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    char **papszOptions = NULL;

    class_mean_map = new float[io_size];
    outDataset = params.driver->Create(class_mean_map_ext_file.c_str(), params.ncols, params.nrows, params.nbands, GDT_Float32, papszOptions);

    for (band = 0; band < params.nbands; band++)
    {
      for (row = 0; row < params.nrows; row++)
      {
        for (col = 0; col < params.ncols; col++)
        {
          index = col + row*params.ncols;
          region_label = region_class_label_map[index];
          region_index = region_label - 1;
          if (region_label == 0)
            class_mean_map[index] = 0.0;
          else
          {
            class_mean_map[index] = (float) region_classes[region_index].get_unscaled_mean(band);
          }
        }
      }
      wb = outDataset->GetRasterBand((band+1));
      wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, class_mean_map, params.ncols, params.nrows, GDT_Float32, 0, 0);
    }

    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_class_std_dev_map_ext(const string& class_std_dev_map_ext_file, vector<RegionClass>& region_classes)
  {
    unsigned int index, region_label, region_index;
    int row, col;
    unsigned int io_size = params.ncols*params.nrows;
    float *std_dev_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    std_dev_map = new float[io_size];
    outDataset = params.driver->Create(class_std_dev_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_Float32, papszOptions);

      for (row = 0; row < params.nrows; row++)
      {
        for (col = 0; col < params.ncols; col++)
        {
          index = col + row*params.ncols;
          region_label = region_class_label_map[index];
          region_index = region_label - 1;
          index = col + row*params.ncols;
          if (region_label == 0)
            std_dev_map[index] = 0.0;
          else
            std_dev_map[index] = (float) region_classes[region_index].get_std_dev();
        }
      }

    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, std_dev_map, params.ncols, params.nrows, GDT_Float32, 0, 0);

    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_class_bpratio_map_ext(const string& class_bpratio_map_ext_file, vector<RegionClass>& region_classes)
  {
    unsigned int index, region_label, region_index;
    int row, col;
    unsigned int io_size = params.ncols*params.nrows;
    float npix, boundary_npix;
    float *bpratio_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    bpratio_map = new float[io_size];
    outDataset = params.driver->Create(class_bpratio_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_Float32, papszOptions);

      for (row = 0; row < params.nrows; row++)
      {
        for (col = 0; col < params.ncols; col++)
        {
          index = col + row*params.ncols;
          region_label = region_class_label_map[index];
          region_index = region_label - 1;
          index = col + row*params.ncols;
          if (region_label == 0)
            bpratio_map[index] = 0.0;
          else
          {
            npix = region_classes[region_index].get_npix();
            boundary_npix = region_classes[region_index].get_boundary_npix();
            bpratio_map[index] = boundary_npix/npix;
          }
        }
      }

    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, bpratio_map, params.ncols, params.nrows, GDT_Float32, 0, 0);

    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_object_labels_map_ext(const string& object_labels_map_ext_file, vector<RegionObject>& region_objects)
  {
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    outDataset = params.driver->Create(object_labels_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_UInt32, papszOptions);
    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, region_object_label_map, params.ncols, params.nrows, GDT_UInt32, 0, 0);
    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_object_npix_map_ext(const string& object_npix_map_ext_file, vector<RegionObject>& region_objects)
  {
    int row, col, index;
    unsigned int region_index, region_label;
    unsigned int io_size = params.ncols*params.nrows;
    unsigned int *npix_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    npix_map = new unsigned int[io_size];
    outDataset = params.driver->Create(object_npix_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_UInt32, papszOptions);

    for (row = 0; row < params.nrows; row++)
      for (col = 0; col < params.ncols; col++)
      {
        index = col + row*params.ncols;
        region_label = region_object_label_map[index];
        region_index = region_label - 1;
        if (region_label == 0)
          npix_map[index] = 0;
        else
          npix_map[index] = region_objects[region_index].get_npix();
      }

    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, npix_map, params.ncols, params.nrows, GDT_UInt32, 0, 0);
    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_object_mean_map_ext(const string& object_mean_map_ext_file, vector<RegionObject>& region_objects)
  {
    unsigned int region_label, region_index;
    int index, row, col, band;
    unsigned int io_size = params.ncols*params.nrows;
    float *object_mean_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    char **papszOptions = NULL;

    object_mean_map = new float[io_size];
    outDataset = params.driver->Create(object_mean_map_ext_file.c_str(), params.ncols, params.nrows, params.nbands, GDT_Float32, papszOptions);

    for (band = 0; band < params.nbands; band++)
    {
      for (row = 0; row < params.nrows; row++)
      {
        for (col = 0; col < params.ncols; col++)
        {
          index = col + row*params.ncols;
          region_label = region_object_label_map[index];
          region_index = region_label - 1;
          if (region_label == 0)
            object_mean_map[index] = 0.0;
          else
          {
            object_mean_map[index] = (float) region_objects[region_index].get_unscaled_mean(band);
          }
        }
      }
      wb = outDataset->GetRasterBand((band+1));
      wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, object_mean_map, params.ncols, params.nrows, GDT_Float32, 0, 0);
    }

    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_object_std_dev_map_ext(const string& object_std_dev_map_ext_file, vector<RegionObject>& region_objects)
  {
    unsigned int index, region_label, region_index;
    int row, col;
    unsigned int io_size = params.ncols*params.nrows;
    float *std_dev_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    std_dev_map = new float[io_size];
    outDataset = params.driver->Create(object_std_dev_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_Float32, papszOptions);

      for (row = 0; row < params.nrows; row++)
      {
        for (col = 0; col < params.ncols; col++)
        {
          index = col + row*params.ncols;
          region_label = region_object_label_map[index];
          region_index = region_label - 1;
          index = col + row*params.ncols;
          if (region_label == 0)
            std_dev_map[index] = 0.0;
          else
            std_dev_map[index] = (float) region_objects[region_index].get_std_dev();
        }
      }

    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, std_dev_map, params.ncols, params.nrows, GDT_Float32, 0, 0);

    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

  void Spatial::write_object_bpratio_map_ext(const string& object_bpratio_map_ext_file, vector<RegionObject>& region_objects)
  {
    unsigned int index, region_label, region_index;
    int row, col;
    unsigned int io_size = params.ncols*params.nrows;
    float npix, boundary_npix;
    float *bpratio_map;
    GDALDataset *outDataset;
    GDALRasterBand *wb;
    int out_nbands = 1;
    char **papszOptions = NULL;

    bpratio_map = new float[io_size];
    outDataset = params.driver->Create(object_bpratio_map_ext_file.c_str(), params.ncols, params.nrows, out_nbands, GDT_Float32, papszOptions);

      for (row = 0; row < params.nrows; row++)
      {
        for (col = 0; col < params.ncols; col++)
        {
          index = col + row*params.ncols;
          region_label = region_object_label_map[index];
          region_index = region_label - 1;
          index = col + row*params.ncols;
          if (region_label == 0)
            bpratio_map[index] = 0.0;
          else
          {
            npix = region_objects[region_index].get_npix();
            boundary_npix = region_objects[region_index].get_boundary_npix();
            bpratio_map[index] = boundary_npix/npix;
          }
        }
      }

    wb = outDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, params.ncols, params.nrows, bpratio_map, params.ncols, params.nrows, GDT_Float32, 0, 0);

    GDALClose( (GDALDatasetH) outDataset);

    return;
  }

} // namespace CommonTilton
