/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>>       Purpose:  Provides the Results class, which is a class dealing
   >>>>                 with output results data
   >>>>
   >>>>    Written By:  James C. Tilton, MC 606.3 NASA's GSFC, Greenbelt, MD 20771
   >>>>                 e-mail:  James.C.Tilton@nasa.gov
   >>>>          Date:  June 24, 2016 - Based on Results class from RHSEG/rhsegV1.64
   >>>>
   >>>> Modifications:  
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#ifndef RESULTS_H
#define RESULTS_H

#include <fstream>
#include <vector>

using namespace std;

namespace CommonTilton
{

    class RegionClass;
    class RegionObject;

    class Results
    {
      public:
          //  CONSTRUCTORS and DESTRUCTOR
          Results();
          Results(const Results& source);
          ~Results();
          //  MODIFICATION MEMBER FUNCTIONS
          void operator =(const Results& source);
          void set_buffer_sizes(const int& nb_bands, const int& nb_classes, const int& nb_objects);
          void read(const int& hlevel, int& nb_classes, int& nb_objects, const int& nb_levels, 
                    vector<unsigned int>& int_buffer_size,
                    vector<RegionClass>& region_classes, vector<RegionObject>& region_objects);
          //  CONSTANT MEMBER FUNCTIONS
          int  get_int_buffer_index() const { return int_buffer_index; }
          void open_input(const string& region_classes_file, const string& region_objects_file);
          void close_input();
      private:
         //  PRIVATE DATA
          int      nbands;            // Number of spectral bands in input image data
          int      orig_nb_classes;   // Number of region classes at onset of writing hierarchical segmentation results
          int      orig_nb_objects;   // Number of region objects at onset of writing hierarchical segmentation results
          int      int_buffer_size, double_buffer_size, object_int_buffer_size, object_double_buffer_size;
          int      *int_buffer, max_int_buffer_size;
          double   *double_buffer;
          int      int_buffer_index, double_buffer_index, object_int_buffer_index;
          ofstream region_classes_ofs;  // File stream variables for region classes output file
          ofstream region_objects_ofs;  // File stream variables for region objects output file
          ifstream region_classes_ifs;  // File stream variable for the region classes input file
          ifstream region_objects_ifs;  // File stream variable for the region objects input file
  } ;

} // CommonTilton

#endif /* RESULTS_H */
