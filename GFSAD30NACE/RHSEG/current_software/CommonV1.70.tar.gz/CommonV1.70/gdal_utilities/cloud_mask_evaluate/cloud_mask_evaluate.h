#ifndef CLOUD_MASK_EVALUATE_H
#define CLOUD_MASK_EVALUATE_H

using namespace std;

namespace CommonTilton
{

  bool cloud_mask_evaluate();

} // CommonTilton

#endif // CLOUD_MASK_EVALUATE_H

