// cloud_mask_evaluate.cc

#include "cloud_mask_evaluate.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool cloud_mask_evaluate()
  {
    int col, row, index;
    int ncols, nrows;
    GDALDataset *inDataset;
    GDALRasterBand *rb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_CM_mask.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_CM_mask << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    cout << "Evaluating Cloud Mask from image file " << params.input_CM_mask << endl;
    cout << "with ncols = " << ncols << " and nrows = " << nrows << endl;

    rb = inDataset->GetRasterBand(1);

    unsigned int total_npix, mask_npix;
    unsigned char *input_image = new unsigned char[ncols*nrows];
    rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &input_image[0], ncols, nrows, GDT_Byte, 0, 0);
    total_npix = mask_npix = 0;
    unsigned int value;
    for (row = 0; row < nrows; row++)
      for (col = 0; col < ncols; col++)
      {
        index = col + row*ncols;
        value = (unsigned int) input_image[index];
        if (value != 0)
        {
          total_npix++;
          if ((value > 1) && (value < 6))
            mask_npix++;
        }
      }
    double double_mask_npix = mask_npix;
    double double_total_npix = total_npix;
    cout << "Percentage Cloud Cover = " << (double_mask_npix/double_total_npix)*100.0 << endl;

    GDALClose( (GDALDatasetH) inDataset);

    return true;

  }

} // CommonTilton

