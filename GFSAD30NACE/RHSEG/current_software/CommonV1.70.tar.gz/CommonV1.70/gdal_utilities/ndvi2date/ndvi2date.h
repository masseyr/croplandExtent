#ifndef NDVI2DATE_H
#define NDVI2DATE_H

using namespace std;

namespace CommonTilton
{

  bool ndvi2date();

} // CommonTilton

#endif // NDVI2DATE_H

