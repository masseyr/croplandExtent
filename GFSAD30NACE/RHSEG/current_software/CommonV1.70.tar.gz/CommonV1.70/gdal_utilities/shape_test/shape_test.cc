// shape_test.cc

#include "shape_test.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <ogrsf_frmts.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool shape_test()
  {
    GDALAllRegister();

    GDALDataset *vecDS;

    vecDS = (GDALDataset*) GDALOpenEx(params.input_shapefile.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL );
    if (vecDS == NULL)
    {
       cout << "Open of " << params.input_shapefile << " failed" << endl;
       return false;
    }

    cout << "Successfully opened " << params.input_shapefile << endl;

    return true;
  }

} // CommonTilton

