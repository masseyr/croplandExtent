// convert_to_geotiff.cc

#include "convert_to_geotiff.h"
#include "params/params.h"
#include <image/image.h>
#include <iostream>
#include <gdal_priv.h>
#include "ogr_spatialref.h"

extern CommonTilton::Params params;

namespace CommonTilton
{

  bool convert_to_geotiff()
  {
    int band, has_fill = false;
    int ncols, nrows, nbands;
    double fill_value = 0.0;
    GDALDataset *inDataset, *outDataset;
    GDALDataType datatype;
    GDALDriver *driver;
    GDALRasterBand *rb, *wb;

    GDALAllRegister();
  
  // Check input image
    inDataset = (GDALDataset *)GDALOpen(params.input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << params.input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    datatype = inDataset->GetRasterBand(1)->GetRasterDataType();
    for (band = 2; band <= nbands; band++)
    {
      if (inDataset->GetRasterBand(band)->GetRasterDataType() > datatype)
        datatype = inDataset->GetRasterBand(band)->GetRasterDataType();
    }
    cout << "Creating GeoTIFF image from input image " << params.input_image_file << endl;
    cout << "with ncols = " << ncols << ", nrows = " << nrows << " nbands = " << nbands << "," << endl;
    cout << "datatype = " << GDALGetDataTypeName(datatype) << ", and output image file name = " << params.output_image_file << endl;

    const char *pszFormat = "GTiff";
    driver = GetGDALDriverManager()->GetDriverByName(pszFormat);

   // Create output image with projections and geotransforms, if provided.
    char **papszOptions = NULL;
    outDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, nbands, datatype, papszOptions);
    const char *pszProj = inDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
      outDataset->SetProjection( pszProj);
    double imageGeoTransform[6];
    if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
      outDataset->SetGeoTransform( imageGeoTransform);
    const char *pszGCPProj = inDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inDataset->GetGCPs();
      if (nGCPs > 0)
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
    }

    double *image_data = new double[ncols*nrows];
    for (band = 1; band <= nbands; band++)
    {
      rb = inDataset->GetRasterBand(band);
      rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &image_data[0], ncols, nrows, GDT_Float64, 0, 0);
      has_fill = false;
      fill_value = rb->GetNoDataValue(&has_fill);
      wb = outDataset->GetRasterBand(band);
      wb->RasterIO(GF_Write, 0, 0, ncols, nrows, image_data, ncols, nrows, GDT_Float64, 0, 0);
      if (has_fill)
        wb->SetNoDataValue(fill_value);
    }

    GDALClose( (GDALDatasetH) inDataset);
    GDALClose( (GDALDatasetH) outDataset);

    return true;
  }


} // CommonTilton
