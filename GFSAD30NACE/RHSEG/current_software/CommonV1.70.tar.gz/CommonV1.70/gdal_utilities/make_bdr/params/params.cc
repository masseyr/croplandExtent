// params.cc

#include "params.h"
#include <iostream>
#include <cstdlib>

#include <iostream>
#include <ctime>

namespace CommonTilton
{

 // Constructor
  Params::Params(const string& value)
  {
    version = value;

    input_mask_flag = false;

    return;
  }

 // Destructor...
  Params::~Params() 
  {
    return;
  }

 // Print version
  void Params::print_version( )
  {
    cout << endl << version << endl << endl;

    return;
  }

 // Read parameters
  bool Params::read(const char *param_file)
  {
//    cout << "Reading parameters from " << param_file << endl;
    ifstream param_fs(param_file);
    if (!param_fs.is_open())
    {
      cout << "Cannot open input file " << param_file << endl;
      return false;
    }

  // Read initial parameters from parameter file until End-of-File reached
    bool first_image_flag = false;
    bool second_image_flag = false;
    bool bdr_image_flag = false;
    bool output_mask_flag = false;
    int sub_pos;
    string line, sub_string;
    while (!param_fs.eof())
    {
      getline(param_fs,line);
      sub_pos = line.find("-");
      while ((!param_fs.eof()) && (sub_pos != 0))
      {
        getline(param_fs,line);
        sub_pos = line.find("-");
      }
      if (line.find("-first_image") != string::npos)
      {
        first_image_file = process_line(line,false);
        first_image_flag = true;
      }
      if (line.find("-second_image") != string::npos)
      {
        second_image_file = process_line(line,false);
        second_image_flag = true;
      }
      if (line.find("-input_mask") != string::npos)
      {
        input_mask_file = process_line(line,false);
        input_mask_flag = true;
      }
      if (line.find("-bdr_image") != string::npos)
      {
        bdr_image_file = process_line(line,false);
        bdr_image_flag = true;
      }
      if (line.find("-output_mask") != string::npos)
      {
        output_mask_file = process_line(line,false);
        output_mask_flag = true;
      }
    }
    param_fs.close();

// Exit with false status if a required parameter is not set, or an improper parameter
// setting is detected.
    if (!first_image_flag)
    {
      cout << "ERROR: -first_image (First input image file) is required" << endl;
      return false;
    }
    if (!second_image_flag)
    {
      cout << "ERROR: -second_image (Second input image file) is required" << endl;
      return false;
    }
    if (!bdr_image_flag)
    {
      cout << "ERROR: -bdr_image (Output band difference ratio image file) is required" << endl;
      return false;
    }
    if (!output_mask_flag)
    {
      cout << "ERROR: -output_mask (Output mask image file) is required" << endl;
      return false;
    }

    return true;
  }

 // Print parameters
  void Params::print()
  {
  // Print version
      cout << "This is " << version << endl << endl;

  // Print input parameters
      cout << "First input image file name: " << first_image_file << endl;
      cout << "Second input image file name: " << second_image_file << endl;
      if (input_mask_flag)
        cout << "Input mask image file name: " << input_mask_file << endl;
      cout << "Output band difference ratio image file name: " << bdr_image_file << endl;
      cout << "Output mask image file name: " << output_mask_file << endl;

      return;
  }

  string process_line(const string& line, const bool& list_flag)
  {
    int sub_pos, sub_pos_space, sub_pos_tab;
    string sub_string;

    sub_pos_space = line.find_first_of(" ");
    sub_pos_tab = line.find_first_of("\t");
    sub_pos = sub_pos_space;
    if (sub_pos ==  (int) string::npos)
      sub_pos = sub_pos_tab;
    if (sub_pos ==  (int) string::npos)
      return " ";

    sub_string = line.substr(sub_pos);
    while ((sub_string.substr(0,1) == "\t") || (sub_string.substr(0,1) == " "))
      sub_string = line.substr(++sub_pos);
#ifndef WINDOWS
    if (list_flag)
      return sub_string;

    sub_pos = sub_string.find_first_of(" ");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\t");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
    sub_pos = sub_string.find_first_of("\r");
    if (sub_pos !=  (int) string::npos)
      sub_string = sub_string.substr(0,sub_pos);
#endif
    return sub_string;
  }

} // namespace CommonTilton
