// make_bdr.cc

#include "make_bdr.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool make_bdr()
  {
    int col, row, index, first_has_fill = false, second_has_fill;
    int ncols, nrows;
    float first_fill_value = 0.0, second_fill_value = 0.0, bdr_fill_value = -1.0;
    GDALDataset *firstDataset, *secondDataset, *maskDataset, *bdrDataset;
    GDALDriver *driver;
    GDALRasterBand *firstrb, *secondrb, *maskrb, *bdrrb;

  // Check first input image
    firstDataset = (GDALDataset *)GDALOpen(params.first_image_file.c_str(), GA_ReadOnly);
    if (!firstDataset)
    {
      cout << "ERROR:  Could not open first_image file name = " << params.first_image_file << endl;
      return false;
    }
    ncols = firstDataset->GetRasterXSize();
    nrows = firstDataset->GetRasterYSize();
    if (firstDataset->GetRasterCount() > 1)
      cout << "WARNING: Only first band of first_image = " << params.first_image_file << " will be used." << endl;
    firstrb = firstDataset->GetRasterBand(1);
    cout << "First input image, " << params.first_image_file;
    cout << ", has ncols = " << ncols << " and nrows = " << nrows << endl;

  // Check second input image
    secondDataset = (GDALDataset *)GDALOpen(params.second_image_file.c_str(), GA_ReadOnly);
    if (!secondDataset)
    {
      cout << "ERROR: Could not open second_image file name = " << params.second_image_file << endl;
      return false;
    }
    if (secondDataset->GetRasterXSize() != ncols)
    {
      cout << "ERROR: Second input image size is not the same as the first input image" << endl;
      return false;
    }
    if (secondDataset->GetRasterYSize() != nrows)
    {
      cout << "ERROR: Second input image size is not the same as the first input image" << endl;
      return false;
    }
    if (secondDataset->GetRasterCount() > 1)
      cout << "WARNING: Only first band of second_image = " << params.second_image_file << " will be used." << endl;
    secondrb = secondDataset->GetRasterBand(1);

    if (params.input_mask_flag)
    {
    // Check input_mask image
      maskDataset = (GDALDataset *)GDALOpen(params.input_mask_file.c_str(), GA_ReadOnly);
      if (!maskDataset)
      {
        cout << "ERROR: Could not open input_mask file name = " << params.input_mask_file << endl;
        return false;
      }
      if (maskDataset->GetRasterXSize() != ncols)
      {
        cout << "ERROR: Second input image size is not the same as the first input image" << endl;
        return false;
      }
      if (maskDataset->GetRasterYSize() != nrows)
      {
        cout << "ERROR: Second input image size is not the same as the first input image" << endl;
        return false;
      }
      if (maskDataset->GetRasterCount() > 1)
        cout << "WARNING: Only first band of input_mask = " << params.input_mask_file << " will be used." << endl;
      maskrb = maskDataset->GetRasterBand(1);
    }
    else
    {
      maskDataset = NULL;
      maskrb = NULL;

     // Check for fill value of first input image
      first_has_fill = false;
      first_fill_value = firstrb->GetNoDataValue(&first_has_fill);

     // Check for fill value of second input image
      second_has_fill = false;
      second_fill_value = secondrb->GetNoDataValue(&second_has_fill);
    }
    driver = firstDataset->GetDriver();

    float *first_image = new float[ncols*nrows];
    float *second_image = new float[ncols*nrows];
    float *bdr_image = new float[ncols*nrows];
    unsigned char *mask = new unsigned char[ncols*nrows];
    firstrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &first_image[0], ncols, nrows, GDT_Float32, 0, 0);
    secondrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &second_image[0], ncols, nrows, GDT_Float32, 0, 0);
    if (params.input_mask_flag)
    {
      maskrb->RasterIO(GF_Read, 0, 0, ncols, nrows, &mask[0], ncols, nrows, GDT_Byte, 0, 0);
      GDALClose( (GDALDatasetH) maskDataset);
    }

   // Create output band difference ratio image and output mask image
    int out_nbands = 1;
    char **papszOptions = NULL;
    bdrDataset = driver->Create(params.bdr_image_file.c_str(), ncols, nrows, out_nbands, GDT_Float32, papszOptions);
    maskDataset = driver->Create(params.output_mask_file.c_str(), ncols, nrows, out_nbands, GDT_Byte, papszOptions);
    const char *pszProj = firstDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
    {
      bdrDataset->SetProjection(pszProj);
      maskDataset->SetProjection(pszProj);
    }
    double imageGeoTransform[6];
    if ( firstDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      bdrDataset->SetGeoTransform( imageGeoTransform);
      maskDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = firstDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = firstDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = firstDataset->GetGCPs();
      if (nGCPs > 0)
      {
        bdrDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
        maskDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    GDALClose( (GDALDatasetH) firstDataset);
    GDALClose( (GDALDatasetH) secondDataset);

    bool good_data_flag;
//    int count = 0;
    float data_value, min_value, max_value;
    float scale, offset;
    min_value = FLT_MAX;
    max_value = -FLT_MAX;
    for (row = 0; row < nrows; row++)
      for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          good_data_flag = true;
          if (params.input_mask_flag)
          {
            if (mask[index] == 0)
              good_data_flag = false;
          }
          else
          {
            if ((first_has_fill) && (first_image[index] == first_fill_value))
              good_data_flag = false;
            if ((second_has_fill) && (second_image[index] == second_fill_value))
              good_data_flag = false;
            mask[index] = 0;
            if (good_data_flag)
              mask[index] = 1;
          }
          data_value = bdr_fill_value;
          if (good_data_flag)
          {
            data_value = first_image[index] + second_image[index];
            if (data_value != 0.0)
            {
              data_value = (first_image[index] - second_image[index])/data_value;
            }
            if (data_value > max_value)
              max_value = data_value;
            if (data_value < min_value)
              min_value = data_value;
          }
          bdr_image[index] = data_value;
        }
//cout << "max_value = " << max_value << " and min_value = " << min_value << endl;
    scale = 1.0/(max_value - min_value);
    offset = min_value/(max_value - min_value);
    for (row = 0; row < nrows; row++)
      for (col = 0; col < ncols; col++)
        {
          index = col + row*ncols;
          if (mask[index] == 1)
            bdr_image[index] = scale*bdr_image[index] - offset;
          else
          {
            bdr_image[index] = bdr_fill_value;
//            count++;
          }
        }
//if (count > 0)
//  cout << count << " data points masked out" << endl;
    bdrrb = bdrDataset->GetRasterBand(1);
    bdrrb->RasterIO(GF_Write, 0, 0, ncols, nrows, bdr_image, ncols, nrows, GDT_Float32, 0, 0);
    bdrrb->SetNoDataValue(bdr_fill_value);
    maskrb = maskDataset->GetRasterBand(1);
    maskrb->RasterIO(GF_Write, 0, 0, ncols, nrows, mask, ncols, nrows, GDT_Byte, 0, 0);
 
    GDALClose( (GDALDatasetH) bdrDataset);
    GDALClose( (GDALDatasetH) maskDataset);

    return true;

  }

} // CommonTilton

