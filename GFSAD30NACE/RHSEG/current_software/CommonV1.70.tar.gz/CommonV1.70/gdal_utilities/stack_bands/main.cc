/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the stack_bands program - with required GDAL dependencies
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: February 1, 2017.
   >>>> Modifications: 
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <cstdlib>
#include <climits>
#include <cstring>

using namespace std;
using namespace CommonTilton;

//Globals
Params params("Version 1.70G, Feb. 1, 2017");

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for the stack_bands
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           opens log file (if requested), creates the stacked image and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: February 1, 2017.
| Modifications: 
|
------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  bool status = true;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: stack_bands -h or stack_bands -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
 // Print program parameters
    params.print();

 // Get image size and other information from the first input image
    int image, ncols, nrows;
    GDALDataset  *inputDataset, *outputDataset;
    GDALDataType datatype;
    GDALDriver *driver;
    inputDataset = (GDALDataset *)GDALOpen(params.input_image_list[0].c_str(), GA_ReadOnly);
    if (!inputDataset)
    {
      cout << "ERROR:  Could not open input_image file name = " << params.input_image_list[0] << endl;
      return false;
    }
    ncols = inputDataset->GetRasterXSize();
    nrows = inputDataset->GetRasterYSize();
    params.nbands = inputDataset->GetRasterCount();
    datatype = inputDataset->GetRasterBand(1)->GetRasterDataType();
    driver = inputDataset->GetDriver();
    GDALClose( (GDALDatasetH) inputDataset);
  // Check other input images
    for (image = 1; image < params.nbimages; image++)
    {
      inputDataset = (GDALDataset *)GDALOpen(params.input_image_list[image].c_str(), GA_ReadOnly);
      if (!inputDataset)
      {
        cout << "ERROR:  Could not open input_image file name = " << params.input_image_list[image] << endl;
        return false;
      }
      if ((ncols != inputDataset->GetRasterXSize()) || (nrows != inputDataset->GetRasterYSize()))
      {
        cout << "ERROR:  All input images must have the same number of columns and rows" << endl;
        return false;
      }
      params.nbands += inputDataset->GetRasterCount();
      if (datatype != inputDataset->GetRasterBand(image+1)->GetRasterDataType())
      {
        cout << "ERROR:  All input images must have the same data type" << endl;
        return false;
      }
      GDALClose( (GDALDatasetH) inputDataset);
    }
  // Create output image data set
    char **papszOptions = NULL;
    outputDataset = driver->Create(params.output_image_file.c_str(), ncols, nrows, params.nbands, datatype, papszOptions);
  // Use projection from first input image
    inputDataset = (GDALDataset *)GDALOpen(params.input_image_list[0].c_str(), GA_ReadOnly);
    const char *pszProj = inputDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
    {
      outputDataset->SetProjection(pszProj);
    }
    double imageGeoTransform[6];
    if ( inputDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outputDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = inputDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inputDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inputDataset->GetGCPs();
      if (nGCPs > 0)
      {
        outputDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }
    GDALClose( (GDALDatasetH) inputDataset);

 // Copy the input image data to the output image
    float *buffer = new float[ncols*nrows];
    int nbands, input_band, output_band = 0;
    for (image = 0; image < params.nbimages; image++)
    {
      cout << "Processing image " << params.input_image_list[image] << endl;
      inputDataset = (GDALDataset *)GDALOpen(params.input_image_list[image].c_str(), GA_ReadOnly);
      if (!inputDataset)
      {
        cout << "ERROR:  Could not open input_image file name = " << params.input_image_list[image] << endl;
        return false;
      }
      nbands = inputDataset->GetRasterCount();
      for (input_band = 0; input_band < nbands; input_band++)
      {
cout << "Processing input_band = " << input_band << " and output_band = " << output_band << endl;
        GDALRasterBand *rb = inputDataset->GetRasterBand(input_band+1);
        GDALRasterBand *wb = outputDataset->GetRasterBand(output_band+1);
        rb->RasterIO(GF_Read, 0, 0, ncols, nrows, buffer, ncols, nrows, GDT_Float32, 0, 0);
        wb->RasterIO(GF_Write, 0, 0, ncols, nrows, buffer, ncols, nrows, GDT_Float32, 0, 0);
        output_band++;
      } 
      GDALClose( (GDALDatasetH) inputDataset);
    }
    GDALClose( (GDALDatasetH) outputDataset);
  }

  if (status)
  {
    cout << endl << "Successful completion of stack_bands program" << endl;
  }
  else
  {
    cout << endl << "The stack_bands program terminated improperly." << endl;
  }
  
  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

/*-----------------------------------------------------------
|
|  Routine Name: usage - Usage function
|
|       Purpose: Informs user of proper usage of program when mis-used.
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: February 1, 2017.
| Modifications: 
|
------------------------------------------------------------*/
void usage()
{
  cout << endl << "Usage: " << endl << endl;
  cout << "stack_bands parameter_file_name" << endl << endl;
  cout << "For help information: stack_bands -h or stack_bands -help" << endl;
  cout << "For version information: stack_bands -v or stack_bands -version" << endl;

  return;
}

/*-----------------------------------------------------------
|
|  Routine Name: help - Help function
|
|       Purpose: Provides help information to user on program parameters
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: February 1, 2017.
| Modifications: 
|
------------------------------------------------------------*/
void help()
{
  cout << endl << "The stack_bands progam is called in the following manner:" << endl;
  cout << endl << "stack_bands parameter_file_name" << endl;
  cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
  cout << "file. For contents see below." << endl;
  cout << endl << "For this help: stack_bands -h or stack_bands -help" << endl;
  cout << endl << "For version information: stack_bands -v or stack_bands -version";
  cout << endl;
  cout << endl << "The parameter file consists of entries of the form:" << endl;
  cout << endl << "-parameter_name parameter_value(s)" << endl;

  fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
  fprintf(stdout,"Input file specification:\n"
"-input_image_list	(string)	The set of images to be stacked as a\n"
"					multiband image (required,\n"
"					 a comma delimited list)\n");
  fprintf(stdout,"Output File:\n"
"-output_image		(string)	Output image (required)\n");
  cout << endl << "NOTE: All input images must have the same number of columns, number of rows and data type." << endl;
  cout << "However, the number of bands may differ." << endl;

  return;
}
