// normalized_band_diff.cc

#include "normalized_band_diff.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

bool normalized_band_diff(string input_image_file, string output_image_file)
{
    int col, row, index;
    int ncols, nrows, nbands;
    GDALDataset *inDataset, *outDataset;
    GDALDataType datatype;
    GDALDriver *driver;
    GDALRasterBand *rb, *wb;

  // Check input image
    inDataset = (GDALDataset *)GDALOpen(input_image_file.c_str(), GA_ReadOnly);
    if (!inDataset)
    {
      cout << "Could not open input_image file name = " << input_image_file << endl;
      return false;
    }
    ncols = inDataset->GetRasterXSize();
    nrows = inDataset->GetRasterYSize();
    nbands = inDataset->GetRasterCount();
    if (nbands < 5)
    {
      cout << "Multiband image of at least 5 band expected" << endl;
      return false;
    }

   // Create output normalized_band_diff image
    driver = inDataset->GetDriver();
    datatype = GDT_Float32;
    int out_nbands = 1;
    char **papszOptions = NULL;
    outDataset = driver->Create(output_image_file.c_str(), ncols, nrows, out_nbands, datatype, papszOptions);
    const char *pszProj = inDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
    {
      outDataset->SetProjection(pszProj);
    }
    double imageGeoTransform[6];
    if ( inDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = inDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inDataset->GetGCPs();
      if (nGCPs > 0)
      {
        outDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    float *band3_image = new float[ncols*nrows];
    float *band5_image = new float[ncols*nrows];
    float *out_image = new float[ncols*nrows];
    rb = inDataset->GetRasterBand(3);
    rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &band3_image[0], ncols, nrows, GDT_Float32, 0, 0);
    rb = inDataset->GetRasterBand(5);
    rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &band5_image[0], ncols, nrows, GDT_Float32, 0, 0);
    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        index = col + row*ncols;
        out_image[index] = (band5_image[index] - band3_image[index])/(band5_image[index] + band3_image[index]);
      }
    }
    wb = outDataset->GetRasterBand((1));
    wb->RasterIO(GF_Write, 0, 0, ncols, nrows, out_image, ncols, nrows, GDT_Float32, 0, 0);

    GDALClose( (GDALDatasetH) inDataset);
    GDALClose( (GDALDatasetH) outDataset);

    return true;
}
