#ifndef REGISTER_H
#define REGISTER_H

using namespace std;

namespace CommonTilton
{

  bool register_image();

} // CommonTilton

#endif // REGISTER_H

