#ifndef COMBINEFF_H
#define COMBINEFF_H

using namespace std;

namespace CommonTilton
{

  bool combineff();

} // CommonTilton

#endif // COMBINEFF_H

