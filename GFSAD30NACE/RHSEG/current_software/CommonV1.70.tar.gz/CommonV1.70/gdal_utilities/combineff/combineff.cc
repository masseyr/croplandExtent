// combineff.cc

#include "combineff.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <float.h>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool combineff()
  {
    int col, row;
    unsigned int index;
    int ncols, nrows, nbands;
    GDALDataset *inRegSegDataset, *inPixelCropDataset, *outRegCropDataset;
    GDALDataType datatype;
    GDALDriver *driver;
    GDALRasterBand *rb, *wb;

  // Check input images
    inRegSegDataset = (GDALDataset *)GDALOpen(params.region_seg_file.c_str(), GA_ReadOnly);
    if (!inRegSegDataset)
    {
      cout << "Could not open input region segmentation image of file name = " << params.region_seg_file << endl;
      return false;
    }
    ncols = inRegSegDataset->GetRasterXSize();
    nrows = inRegSegDataset->GetRasterYSize();
    nbands = inRegSegDataset->GetRasterCount();
    cout << "Input Region Segmentation image " << params.region_seg_file << endl;
    cout << "has ncols = " << ncols << ", nrows = " << nrows << " and nbands = " << nbands << endl;

    inPixelCropDataset = (GDALDataset *)GDALOpen(params.pixel_cropextent_file.c_str(), GA_ReadOnly);
    if (!inPixelCropDataset)
    {
      cout << "Could not open input pixel crop extent image of file name = " << params.pixel_cropextent_file << endl;
      return false;
    }
    if ((ncols != inPixelCropDataset->GetRasterXSize()) ||
        (nrows != inPixelCropDataset->GetRasterYSize()) ||
        (nbands != inPixelCropDataset->GetRasterCount()))
    {
      cout << "ERROR: Image size mismatch between input Region Segmentation image and input Pixel-based Crop Extent image" << endl;
      return false;
    }

   // Create output region crop extent image
    driver = inRegSegDataset->GetDriver();
    datatype = GDT_Byte;
    int out_nbands = 1;
    char **papszOptions = NULL;
    outRegCropDataset = driver->Create(params.region_cropextent_file.c_str(), ncols, nrows, out_nbands, datatype, papszOptions);
    const char *pszProj = inRegSegDataset->GetProjectionRef();
    if ((pszProj != NULL) && (strlen(pszProj) > 0))
    {
      outRegCropDataset->SetProjection(pszProj);
    }
    double imageGeoTransform[6];
    if ( inRegSegDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
    {
      outRegCropDataset->SetGeoTransform( imageGeoTransform);
    }
    const char *pszGCPProj = inRegSegDataset->GetGCPProjection();
    if ((pszGCPProj != NULL) && (strlen(pszGCPProj) > 0))
    {
      int nGCPs = inRegSegDataset->GetGCPCount();
      const GDAL_GCP *psGCP;
      psGCP = inRegSegDataset->GetGCPs();
      if (nGCPs > 0)
      {
        outRegCropDataset->SetGCPs(nGCPs,psGCP,pszGCPProj);
      }
    }

    unsigned int *reg_seg_image = new unsigned int[ncols*nrows];
    unsigned char *pixel_crop_image = new unsigned char[ncols*nrows];
    unsigned char *reg_crop_image = new unsigned char[ncols*nrows];
    rb = inRegSegDataset->GetRasterBand(1);
    rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &reg_seg_image[0], ncols, nrows, GDT_UInt32, 0, 0);
    rb = inPixelCropDataset->GetRasterBand(1);
    rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &pixel_crop_image[0], ncols, nrows, GDT_Byte, 0, 0);
    unsigned int max_reg_label = 0;
    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        index = col + row*ncols;
        if (reg_seg_image[index] > max_reg_label)
          max_reg_label = reg_seg_image[index];
/* Not necessary
        if (pixel_crop_image[index] > 1)
          pixel_crop_image[index] = 1;
        else
          pixel_crop_image[index] = pixel_crop_image[index];
*/      }
    }
// cout << "max_reg_label = " << max_reg_label << endl;

    unsigned int *region_count = new unsigned int[max_reg_label + 1];
    unsigned int *crop_count = new unsigned int[max_reg_label + 1];
    unsigned int region_label;
    for (index = 0; index <= max_reg_label; index++)
    {
      region_count[index] = 0;
      crop_count[index] = 0;
    }
// NOTE: region_label = 0 signifies "bad data"
    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        index = col + row*ncols;
        region_label = reg_seg_image[index];
        if (region_label > 0)
        {
          region_count[region_label] += 1;
          if (pixel_crop_image[index] != 0)
            crop_count[region_label] += 1;
        }
      }
    }

    for (row = 0; row < nrows; row++)
    {
      for (col = 0; col < ncols; col++)
      {
        index = col + row*ncols;
        region_label = reg_seg_image[index];
        if (region_label > 0)
        {
          reg_crop_image[index] = (unsigned char) ((100*crop_count[region_label])/region_count[region_label]);
        }
      }
    }

    wb = outRegCropDataset->GetRasterBand((1));
    wb->RasterIO(GF_Write, 0, 0, ncols, nrows, reg_crop_image, ncols, nrows, GDT_Byte, 0, 0);

    GDALClose( (GDALDatasetH) inRegSegDataset);
    GDALClose( (GDALDatasetH) inPixelCropDataset);
    GDALClose( (GDALDatasetH) outRegCropDataset);

    return true;
  }

} // CommonTilton

