// connected_component.cc

#include "connected_component.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <gdal_alg.h>
#include <iostream>
#include <float.h>
#include <map>

// Externals
extern CommonTilton::Params params;

namespace CommonTilton
{
  bool connected_component()
  {
    int col, row, pixel_index;
    int ncols, nrows, nbands;
    unsigned int nb_objects = 0;
    GDALDataset *classSegDataset, *objectSegDataset;
    GDALDataType data_type;
    GDALDriver *driver;
    GDALRasterBand *rb, *wb;
/*
GDALRasterBandH hSrcBand;
GDALRasterBandH hMaskBand;
OGRLayerH hOutLayer;
int iPixValField;
*/
char **papszOptions = NULL;
/*
GDALProgressFunc pfnProgress;
void * pProgressArg;
GDALPolygonize(hSrcBand, hMaskBand, hOutLayer, iPixValField, papszOptions, pfnProgress, pProgressArg);
*/

  // Check input segmentation image
    classSegDataset = (GDALDataset *)GDALOpen(params.class_segmentation_file.c_str(), GA_ReadOnly);
    if (!classSegDataset)
    {
      cout << "Could not open class_segmentation file name = " << params.class_segmentation_file << endl;
      return false;
    }
    ncols = classSegDataset->GetRasterXSize();
    nrows = classSegDataset->GetRasterYSize();
    nbands = classSegDataset->GetRasterCount();
    if (nbands > 1)
      cout << "WARNING: Only first band of " << params.class_segmentation_file << " will be used" << endl;
    nbands = 1;
    cout << "Performing 4nn connected component labeling on " << params.class_segmentation_file << endl;
    cout << "with ncols = " << ncols << " and nrows = " << nrows << endl;
    driver = classSegDataset->GetDriver();
    rb = classSegDataset->GetRasterBand(1);
    data_type = rb->GetRasterDataType();

   // Create output segmentation image
//    char **papszOptions = NULL;
    objectSegDataset = driver->Create(params.object_segmentation_file.c_str(), ncols, nrows, nbands, data_type, papszOptions);
    char **metadata = classSegDataset->GetMetadata("");
    objectSegDataset->SetMetadata(metadata,"");
    string projection_type = classSegDataset->GetProjectionRef();
    if ((projection_type != "") && ((projection_type.find("Unknown") == string::npos) || (projection_type.size() > 10)))
      objectSegDataset->SetProjection( projection_type.c_str());
    double imageGeoTransform[6];
    if ( classSegDataset->GetGeoTransform( imageGeoTransform ) == CE_None )
      objectSegDataset->SetGeoTransform( imageGeoTransform);

    float *class_segmentation = new float[ncols*nrows];
    float *object_segmentation = new float[ncols*nrows];
    for (row = 0; row < nrows; row++)
      for (col = 0; col < ncols; col++)
      {
        pixel_index = col + row*ncols;
        object_segmentation[pixel_index] = 0;
      }

    rb->RasterIO(GF_Read, 0, 0, ncols, nrows, &class_segmentation[0], ncols, nrows, GDT_Float32, 0, 0);

    short unsigned int nbdir, maxnbdir = 4;
    unsigned int nbpixel_index=0;
    unsigned int region_class_label, nbregion_class_label;
    unsigned int region_object_label, nbregion_object_label, max_label = nb_objects;
    map<unsigned int,unsigned int> region_object_relabel_pairs;
    map<unsigned int,unsigned int>::iterator region_object_relabel_pairs_iter;

    int nbcol, nbrow;
    for (row = 0; row < nrows; row++)
    {
     for (col = 0; col < ncols; col++)
     {
       pixel_index = col + row*ncols;
       region_class_label = class_segmentation[pixel_index];
       if (region_class_label != 0)
       {
         region_object_label = object_segmentation[pixel_index];
         if (region_object_label == 0)
         {
           region_object_label = ++max_label;
           object_segmentation[pixel_index] = region_object_label;
         }
         for (nbdir = 0; nbdir < maxnbdir; nbdir++)
         {
           nbregion_class_label = 0;
           find_nghbr(col,row,nbdir,nbcol,nbrow);
           if ((nbrow>=0) && (nbcol>=0) &&
               (nbrow<nrows) && (nbcol<ncols))
           {
             nbpixel_index = nbcol + nbrow*ncols;
             nbregion_class_label = class_segmentation[nbpixel_index];
           }
           if (nbregion_class_label == region_class_label)
           {
             nbregion_object_label = object_segmentation[nbpixel_index];
             if (nbregion_object_label == 0)
             {
               object_segmentation[nbpixel_index] = region_object_label;
             }
             else if (region_object_label < nbregion_object_label)
             {
               object_segmentation[nbpixel_index] = region_object_label;
               region_object_relabel_pairs.insert(make_pair(nbregion_object_label,region_object_label));
             }
             else if (region_object_label > nbregion_object_label)
             {
               object_segmentation[pixel_index] = nbregion_object_label;
               region_object_relabel_pairs.insert(make_pair(region_object_label,nbregion_object_label));
               region_object_label = nbregion_object_label;
             }
           } // if (nbregion_class_label == region_class_label)
         } // for (nbdir = 0; nbdir < maxnbdir; nbdir++)
       } // if (region_class_label != 0)
     } // for (col = 0; col < ncols; col++)
    } // for (row = 0; row < nrows; row++)

    while (!region_object_relabel_pairs.empty())
    {
    // Clean up labeling
      for (row = 0; row < nrows; row++)
      {
       for (col = 0; col < ncols; col++)
       {
         pixel_index = col + row*ncols;
         region_object_label = object_segmentation[pixel_index];
         if (region_object_label != 0)
         {
           region_object_relabel_pairs_iter = region_object_relabel_pairs.find(region_object_label);
           while (region_object_relabel_pairs_iter != region_object_relabel_pairs.end())
           {
             region_object_label = (*region_object_relabel_pairs_iter).second;
             region_object_relabel_pairs_iter = region_object_relabel_pairs.find(region_object_label);
           }
           object_segmentation[pixel_index] = region_object_label;
         }
       } // for (col = 0; col < ncols; col++)
      } // for (row = 0; row < nrows; row++)

      region_object_relabel_pairs.clear();
      for (row = 0; row < nrows; row++)
      {
       for (col = 0; col < ncols; col++)
       {
         pixel_index = col + row*ncols;
         region_class_label = class_segmentation[pixel_index];
         region_object_label = object_segmentation[pixel_index];
         if (region_class_label != 0)
         {
           for (nbdir = 0; nbdir < maxnbdir; nbdir++)
           {
             nbregion_class_label = 0;
             find_nghbr(col,row,nbdir,nbcol,nbrow);
             if ((nbrow>=0) && (nbcol>=0) &&
                 (nbrow<nrows) && (nbcol<ncols))
             {
               nbpixel_index = nbcol + nbrow*ncols;
               nbregion_class_label = class_segmentation[nbpixel_index];
             }
             if (nbregion_class_label == region_class_label)
             {
               nbregion_object_label = object_segmentation[nbpixel_index];
               if (region_object_label < nbregion_object_label)
               {
                 object_segmentation[nbpixel_index] = region_object_label;
                 region_object_relabel_pairs.insert(make_pair(nbregion_object_label,region_object_label));
               }
               else if (region_object_label > nbregion_object_label)
               {
                 object_segmentation[pixel_index] = nbregion_object_label;
                 region_object_relabel_pairs.insert(make_pair(region_object_label,nbregion_object_label));
                 region_object_label = nbregion_object_label;
               }
             } // if (nbregion_class_label == region_class_label)
           } // for (nbdir = 0; nbdir < maxnbdir; nbdir++)
         } // if (region_class_label != 0)
       } // for (col = 0; col < ncols; col++)
      } // for (row = 0; row < nrows; row++)
    } // while (!region_object_labels_pairs.empty())

  // Make the region_class_label numbering compact
    region_object_relabel_pairs.clear();
    for (row = 0; row < nrows; row++)
    {
     for (col = 0; col < ncols; col++)
     {
       pixel_index = col + row*ncols;
       region_object_label = object_segmentation[pixel_index];
       if (region_object_label != 0)
       {
         region_object_relabel_pairs_iter = region_object_relabel_pairs.find(region_object_label);
         if (region_object_relabel_pairs_iter != region_object_relabel_pairs.end())
         {
           region_object_label = (*region_object_relabel_pairs_iter).second;
         }
         else
         {
           region_object_relabel_pairs.insert(make_pair(region_object_label,++nb_objects));
           region_object_label = nb_objects;
         }
         object_segmentation[pixel_index] = region_object_label;
       }
     }
    }

    wb = objectSegDataset->GetRasterBand(1);
    wb->RasterIO(GF_Write, 0, 0, ncols, nrows, object_segmentation, ncols, nrows, GDT_Float32, 0, 0);

    GDALClose( (GDALDatasetH) classSegDataset);
    GDALClose( (GDALDatasetH) objectSegDataset);

    cout <<  "4nn connected component labeling completed";
    cout << ", with " << nb_objects << " regions" << endl;

    return true;

  }

  void find_nghbr(const int& col, const int& row,
                  const short unsigned int& nbdir, int& nbcol, int& nbrow)
  {
    nbcol = nbrow = 0;

    switch(nbdir)
    {
     // W
      case 0:  nbcol = col-1; nbrow = row;
               break;
     // E
      case 1:  nbcol = col+1; nbrow = row;
               break;
     // N
      case 2:  nbcol = col; nbrow = row-1;
               break;
     // S
      case 3:  nbcol = col; nbrow = row+1;
               break;
    }

    return;
  }
} // CommonTilton
