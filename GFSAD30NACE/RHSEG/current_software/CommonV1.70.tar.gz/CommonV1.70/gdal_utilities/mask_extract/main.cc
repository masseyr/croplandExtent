/* >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<<
   >>>>
   >>>> 	Main program for the mask_extract program - with required GDAL dependencies
   >>>>
   >>>>  Private:
   >>>> 	main(int argc, char **argv)
   >>>> 	usage()
   >>>> 	help()
   >>>>
   >>>>   Static:
   >>>>   Public:
   >>>>
   >>>>       Written: April 22, 2014
   >>>> Modifications: August 10, 2016 - Added optional mask_value
   >>>>                August 25, 2016 - Added output_image
   >>>>
   >>>>>>>>>>>>>>>>>>>>>>>>>>>>> <<<<<<<<<<<<<<<<<<<<<<<<<< */

#include "mask_extract.h"
#include "params/params.h"
#include <gdal_priv.h>
#include <iostream>
#include <cstdlib>
#include <climits>
#include <cstring>

using namespace std;
using namespace CommonTilton;

//Globals
Params params("Version 1.70G, August 10, 2016");

// Forward function declarations
void usage();
void help();

/*-----------------------------------------------------------
|
|  Routine Name: main - Main program for the mask_extract program interface
|
|  Purpose: Declares program parameters, reads parameter file and initializes program parameters,
|           calls the mask_extract function, and returns an exit status.
|
|  Input from command line - parameter_file_name
|
|       Returns: EXIT_SUCCESS on success, EXIT_FAILURE on failure
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: April 22, 2014
| Modifications: 
|
------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  bool status = true;

  GDALAllRegister();

  if (argc == 1)
  {
    usage();
    cout << "ERROR: Need parameter file as argument." << endl;
    return EXIT_FAILURE;
  }
  else if ((strncmp(argv[1],"-v",2) == 0) || (strncmp(argv[1],"-version",8) == 0))
  {
    params.print_version();
    cout << "For help information: mask_extract -h or mask_extract -help" << endl << endl;
    return EXIT_SUCCESS;
  }
  else if ((strncmp(argv[1],"-h",2) == 0) || (strncmp(argv[1],"-help",5) == 0))
  {
    help();
    return EXIT_SUCCESS;
  }
  else if (strncmp(argv[1],"-",1) == 0)
  {
    usage();
    cout << "ERROR: The parameter file name cannot start with an \"-\"" << endl;
    return EXIT_FAILURE;
  }
  else
  {
    if (argc != 2)
    {
      usage();
      cout << "ERROR: Incorrect number of parameters on command line" << endl;
      return EXIT_FAILURE;
    }
    else
    {
      status = params.read(argv[1]);
      if (!status)
      {
        usage();
        cout << "ERROR: Error reading parameter file (read)" << endl;
        return EXIT_FAILURE;
      }
    }
  }

  if (status)
  {
    params.print();
    status = mask_extract();
  }

  if (status)
  {
    cout << endl << "Successful completion of mask_extract program" << endl;
  }
  else
  {
    cout << endl << "The mask_extract program terminated improperly." << endl;
  }
  
  if (status)
    return EXIT_SUCCESS;
  else
    return EXIT_FAILURE;
}

/*-----------------------------------------------------------
|
|  Routine Name: usage - Usage function
|
|       Purpose: Informs user of proper usage of program when mis-used.
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: April 15, 2013
| Modifications: 
|
------------------------------------------------------------*/
void usage()
{
  cout << endl << "Usage: " << endl << endl;
  cout << "mask_extract parameter_file_name" << endl << endl;
  cout << "For help information: mask_extract -h or mask_extract -help" << endl;
  cout << "For version information: mask_extract -v or mask_extract -version" << endl;

  return;
}

/*-----------------------------------------------------------
|
|  Routine Name: help - Help function
|
|       Purpose: Provides help information to user on program parameters
|
|         Input:
|
|        Output:
|
|       Returns: (void)
|
|    Written By: James C. Tilton, NASA's GSFC, Mail Code 606.3, Greenbelt,MD 20771
|        E-Mail: James.C.Tilton@nasa.gov
|
|       Written: April 22, 2014
| Modifications: 
|
------------------------------------------------------------*/
void help()
{
  cout << endl << "The mask_extract progam is called in the following manner:" << endl;
  cout << endl << "mask_extract parameter_file_name" << endl;
  cout << endl << "where \"parameter_file_name\" is the name of the input parameter" << endl;
  cout << "file. For contents see below." << endl;
  cout << endl << "For this help: mask_extract -h or mask_extract -help" << endl;
  cout << endl << "For version information: mask_extract -v or mask_extract -version";
  cout << endl;
  cout << endl << "The parameter file consists of entries of the form:" << endl;
  cout << endl << "-parameter_name parameter_value(s)" << endl;

  fprintf(stdout,"\nThe following parameters may be specified in the input parameter file:\n\n");
  fprintf(stdout,"Input File and parameter:\n"
"-input_image		(string)	Input image file name(required)\n"
"-output_type		(int)		Output mask type:\n"
"					  1. \"Multispectral mask, or\"\n"
"					  2. \"Single combined mask.\"\n"
"					(default = 2 -> \"Single combined mask\")\n"
"-mask_logic		(int)		Logic for single combined mask:\n"
"					  1. \"AND logic, or\"\n"
"					  2. \"OR logic.\"\n"
"					(default = 2 -> \"OR logic.\")\n"
"-mask_value		(int)		Mask value (optional, if not provided\n"
"					 NO_DATA value is used)\n"
"NOTE: AND logic means the single combined mask will mask out pixels that are invalid in all spectral bands.\n"
"NOTE: OR logic means the single combined mask will mask out pixels that are invalid in any spectral band.\n");
  fprintf(stdout,"Output Files:\n"
"-output_image		(string)	Output image (optional, \n"
"					 if provided, output image\n"
"					 will be a copy of the input\n"
"					 with pixels with \"mask_value\"\n"
"					 reset to 0.0)\n"
"-output_mask_image	(string)	Output mask image (required)\n");

  return;
}

