#ifndef EDGE_H
#define EDGE_H

using namespace std;

namespace CommonTilton
{

  bool gen_image();

} // CommonTilton

#endif // EDGE_H

