#ifndef IMAGE_STATS_H
#define IMAGE_STATS_H

using namespace std;

namespace CommonTilton
{

  bool image_stats();

} // CommonTilton

#endif // IMAGE_STATS_H

